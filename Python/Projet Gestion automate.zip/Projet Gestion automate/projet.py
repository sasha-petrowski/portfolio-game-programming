from graphviz import Digraph
import re
import ast

def get_list(dict):
    list = [] 
    for key in dict.keys(): 
        list.append(key) 
    return list

def input_aet():
    stop = 1
    this = { ">"  : [], "<"  : [], "<>" : [] }
    print("\nEntrez les états sous cette forme : ^[A-Za-z0-9]+$\nN'utilisez pas de charactéres spéciaux ou d'espaces\nOn ne peut pas utiliser le meme etat deux fois\n")
    p = re.compile('^[A-Za-z0-9]+$')
    while(stop): 
        str = input('"*" pour arreter / finir les états\nEntrez le nom de l\'état : ')
        if str == '*':
            if(len(this) > 3):
                stop = 0
            else:
                return "Erreur : aucuns etats définis"
        else:
            if p.match(str):
                this[str] = {}
                reg = '^'
                for i in range(3,len(this)): # ne pas avoir le meme etat plusieur fois
                    reg += '(?!'+get_list(this)[i]+')'
                reg += '([A-Za-z0-9]+)$'
                p = re.compile(reg)
                print('état "'+str+'" ajouté.')
            else:
                print('Nom invalide / deja utilisé')
    stop = 1
    print("\nEntrez l'alphabet sous cette forme : ^[A-Za-z]+$\nN'utilisez pas de charactéres spéciaux ou d'espaces\nOn ne peut pas avoir deux fois la meme \"lettre\" dans l'alphabet\n")
    p = re.compile('^[A-Za-z]+$')
    while(stop):
        str = input('"*" pour arreter / finir l\'alphabet\nEntrez le nom de la "lettre" : ')
        if str == '*':
            if(len(this) > 0):
                stop = 0
            else:
                return "Erreur : aucune \"lettre\" défini"
        else:
            if p.match(str):
                this["<>"].append(str)
                reg = '^'
                for i in range(len(this["<>"])): # ne pas avoir le meme etat plusieur fois
                    reg += '(?!'+this["<>"][i]+')'
                reg += '([A-Za-z]+)$'
                p = re.compile(reg)
                print('"Lettre" "'+str+'" ajoutée.')
            else:
                print('"Lettre" invalide / deja utilisée')
    print("\nEntrez les fonctions de transition sous la forme du nom d'un etat\nOn ne peut pas mettre plusieurs transition vers un meme etat dans une meme case.")
    reg_base = "("+get_list(this)[3]+")"
    for i in range(4,len(this)):
        reg_base += "|("+get_list(this)[i]+")"
    for etat in range(3, len(this)):
        etat_str = get_list(this)[etat]
        for lettre in range(len(this["<>"])):
            lettre_str = this["<>"][lettre]
            this[etat_str][lettre_str] = []
            reg = "^("+reg_base+")$"
            p = re.compile(reg)
            print("\nEtat : "+etat_str+" : Lettre : "+lettre_str+"\n")
            stop = 1
            while(stop):
                str = input('"*" pour arreter / finir les fonctions\nEntrez le nom de l\'état : ')
                if str == '*':
                    stop = 0
                else:
                    if p.match(str):
                        this[etat_str][lettre_str].append(str)
                        reg = '^'
                        for i in range(len(this[etat_str][lettre_str])): # ne pas avoir le meme etat plusieur fois
                            reg += '(?!'+this[etat_str][lettre_str][i]+')'
                        reg += "("+reg_base+")$"
                        p = re.compile(reg)
                        print('fonction "'+str+'" ajoutée.')
                    else:
                        print('fonction invalide / deja utilisée')
    print("\nEntrez les etats de depart sous la forme du nom d'un etat\nOn ne peut pas mettre plusieurs fois le meme depart.\n")
    reg_base = "("+get_list(this)[3]+")"
    for i in range(4,len(this)):
        reg_base += "|("+get_list(this)[i]+")"
    reg = "^("+reg_base+")$"
    p = re.compile(reg)
    stop = 1
    while(stop):
        str = input('"*" pour arreter / finir les états de départ\nEntrez le nom de l\'état : ')
        if str == '*':
            if len(this[">"]) > 0:
                stop = 0
            else:
                print("Erreur : Il faut inserer un etat de depart")
        else:
            if p.match(str):
                this[">"].append(str)
                reg = '^'
                for i in range(len(this[">"])): # ne pas avoir le meme etat plusieur fois
                    reg += '(?!'+this[">"][i]+')'
                reg += "("+reg_base+")$"
                p = re.compile(reg)
                print('etat de depart "->'+str+'" ajoutée.')
            else:
                print('etat de depart invalide / deja utilisée')
    print("\nEntrez les etats finaux sous la forme du nom d'un etat\nOn ne peut pas mettre plusieurs fois la meme fin.\n")
    reg_base = "("+get_list(this)[3]+")"
    for i in range(4,len(this)):
        reg_base += "|("+get_list(this)[i]+")"
    reg = "^("+reg_base+")$"
    p = re.compile(reg)
    stop = 1
    while(stop):
        str = input('"*" pour arreter / finir les états finaux\nEntrez le nom de l\'état : ')
        if str == '*':
            if len(this["<"]) > 0:
                stop = 0
            else:
                print("Erreur : Il faut inserer un etat final")
        else:
            if p.match(str):
                this["<"].append(str)
                reg = '^'
                for i in range(len(this["<"])): # ne pas avoir le meme etat plusieur fois
                    reg += '(?!'+this["<"][i]+')'
                reg += "("+reg_base+")$"
                p = re.compile(reg)
                print('etat de depart "<-'+str+'" ajoutée.')
            else:
                print('etat final invalide / deja utilisée')
    print(this)
    return this

def aet_str(mot, size):
    size = size-len(mot)
    if(size < 1): 
        size = 0
    return " "*size+mot+"|"

def afficher_aet(this, size):
    ligne_str = aet_str("",size)
    for i in range(len(this["<>"])):
        ligne_str += aet_str(this["<>"][i], size)
    print(ligne_str)
    for ligne in range(3,len(this)):
        ligne_str = ""
        etat_str = get_list(this)[ligne]
        mot =""
        dep = 0
        fin = 0
        for i in range(len(this[">"])):
            if(etat_str == this[">"][i]):
                dep = 1
        for i in range(len(this["<"])):
            if(etat_str == this["<"][i]):
                fin = 1
        if(dep == 1 & fin == 1):
            mot += "*->"+etat_str
        elif(dep == 1):
            mot += " ->"+etat_str
        elif(fin == 1):
            mot += " * "+etat_str
        else:
            mot += "   "+etat_str
        ligne_str += aet_str(mot, size)
        for col in range(len(this["<>"])):
            col_str = this["<>"][col]
            mot =""
            for i in range(len(this[etat_str][col_str])):
                if(i > 0):
                    mot += ","
                mot += this[etat_str][col_str][i]
            ligne_str += aet_str(mot, size)
        print(ligne_str)

def pdf_aet(this, fichier):
    f = Digraph('aet_pdf()', filename=fichier)
    f.attr(rankdir='LR', size='8,5')
    for ligne in range(3,len(this)):
        etat_str = get_list(this)[ligne]
        dep = 0
        fin = 0
        for i in range(len(this[">"])):
            if(etat_str in this[">"]):
                dep = 1
        for i in range(len(this["<"])):
            if(etat_str in this["<"]):
                fin = 1
        if(fin == 1):
            f.attr('node', shape='doublecircle')
            f.node(etat_str)
        else:
            f.attr('node', shape='circle')
            f.node(etat_str)
        if(dep == 1):
            f.attr('node', shape='none')
            f.node(' '*ligne)
            f.edge(' '*ligne, etat_str)
        f.attr('node', shape='circle')
    for ligne in range(3,len(this)):
        etat_str = get_list(this)[ligne]
        for col in range(len(this["<>"])):
            col_str = this["<>"][col]
            for i in range(len(this[etat_str][col_str])):
                f.edge(etat_str, liste_str(this[etat_str][col_str]), label=col_str)
    f.view()

def save_aet(this,fichier):
    dest = open(fichier, "w")
    dest.write(str(this))
    dest.close()

def load_aet(fichier):
    source = open(fichier, "r")
    this = source.read(-1)
    return ast.literal_eval(this)

def completer_aet(this):
    completed = 0
    for ligne in range(3,len(this)):
        etat_str = get_list(this)[ligne]
        for col in range(len(this["<>"])):
            col_str = this["<>"][col]
            if(len(this[etat_str][col_str]) == 0):
                this[etat_str][col_str].append("/P")
                completed = 1
    if(completed == 1):
        this["/P"] = {}
        for col in range(len(this["<>"])):
            col_str = this["<>"][col]
            this["/P"][col_str] = []
            this["/P"][col_str].append("/P")
    return this

def determiner_aet(this):
    other = { ">"  : [], "<" : this["<"], "<>" : this["<>"] }
    final = ""
    for i in range(len(this[">"])):
        for n in range(0,len(other["<"])):
            if(len(other["<"]) > n and this[">"][i] == other["<"][n]):
                final = liste_str(this[">"])
                break
    other["<"].append(final)
    print("Nouveaux etats finaux : "+str(other["<"]))
    other[">"].append(liste_str(this[">"]))
    print("Nouvel etat de depart : "+str(other[">"]))
    other = determiner(other, this, this[">"], 0)
    return other

def determiner(other, this, cible, nest):
    if(cible):
        name = liste_str(cible)
        valid = 1
        for i in range(len(other)):
            if name == get_list(other)[i]:
                valid = 0
        if valid:
            other[name] = {}
            for col in range(len(other["<>"])):
                col_str = other["<>"][col]
                liste = this[cible[0]][col_str]
                for i in range(1, len(cible)):
                    x = cible[i]
                    valid = 1
                    for n in range(len(liste)):
                        for j in range(len(this[x][col_str])):
                            if(liste[n] in this[x][col_str][j]):
                                valid = 0
                    if(valid):
                        for j in range(len(this[x][col_str])):
                            liste.append(this[x][col_str][j])
                other[name][col_str] = liste
                if(liste and liste != cible):
                    print(". "*nest+name+" -> "+str(liste))
                    other = determiner(other, this, liste, nest+1)
    return other

def liste_str(cible):
    mot = cible[0]
    for i in range(1, len(cible)):
        mot += ","+str(cible[i])
    return mot

#aet = input_aet()

#aet = {'>': ['1', '2'], '<': ['2'], '<>': ['a', 'b'], '1': {'a': ['1'], 'b': ['2']}, '2': {'a': ['1'], 'b': ['2']}}

#aet = {'>': ['1', '3'], '<': ['1', '5'], '<>': ['a', 'b', 'c', 'd'], '1': {'a': ['2', '3', '4'], 'b': ['4'], 'c': [], 'd': []}, '2': {'a': [], 'b': [], 'c': ['5'], 'd': ['5']}, '3': {'a': ['3'], 'b': ['4'], 'c': [], 'd': []}, '4': {'a': [], 'b': [], 'c': ['5'], 'd': ['5']}, '5': {'a': [], 'b': [], 'c': [], 'd': []}}

#save_aet(aet, "aet_save.txt")

aet = load_aet("aet_save.txt")

pdf_aet(aet, "load")

aet = determiner_aet(aet)

pdf_aet(aet, "determine")

aet = completer_aet(aet)

pdf_aet(aet, "completer")

afficher_aet(aet, 10)

#print(aet)