package com.fges.solid.reigns;

public enum TypeCondition {
    INFERIEUR, SUPERIEUR;
}
