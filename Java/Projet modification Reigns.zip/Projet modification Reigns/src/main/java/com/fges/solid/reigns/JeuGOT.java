package com.fges.solid.reigns;


public class JeuGOT {
    private static boolean active;
    private static int winter = 0;

    public static void debutTour(){
        winter++;
        if(winter == 9){
            System.out.println("* * * L'hiver approche * * *");
        }else if(winter == 10){
            System.out.println("* * * L'hiver est la * * *");
        }else if(winter == 15){
            System.out.println("* * * L'hiver se termine bientot * * *");
        }else if(winter == 16){
            System.out.println("* * * L'hiver est terminé * * *");
            winter = 0;
        }
    }

    public static boolean isActive(){
        return active;
    }

    public static void on(){
        active = true;
    }
    public static void off(){
        active = false;
    }
    public static boolean isWinter(){
        return winter > 9;
    }
}
