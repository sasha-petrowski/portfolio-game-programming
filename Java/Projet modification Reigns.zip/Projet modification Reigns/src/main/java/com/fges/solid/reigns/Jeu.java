/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fges.solid.reigns;

import static com.fges.solid.reigns.Genre.REINE;
import static com.fges.solid.reigns.Genre.ROI;

import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author julie.jacques
 */
public class Jeu {
    
    private static Personnage personnage;
    private static BanqueQuestion banqueQuestions;
    
    public static void main(String args[]){
        
        // début du jeu 
        System.out.println("Bienvenue sur Reigns");

        initDLC();
        
        initBanqueQuestion();
        
        System.out.println("Création du personnage...");
        
        initPersonnage();
        
        System.out.println(personnage.getGenre().longRegne() + " " + personnage.getNom());
                
        // tirage des questions
        int nbTours = 0;
        while(!personnage.finDuJeu()){
            nbTours++;

            effetsTourDLC();
            personnage.AfficheJauges();

            reponseQuestion(banqueQuestions.questionAleatoire(personnage));
        }
        
        // fin du jeu
        System.out.println(
            personnage.getNom() 
            + " a perdu ! Son règne a duré "
            +nbTours
            + " tours");
         
    }
    
    private static void effetsTourDLC(){
        if(JeuGOT.isActive()){
            JeuGOT.debutTour();
        }
    }

    private static void reponseQuestion(Question question){
        question.afficheQuestion();
        // récupère la réponse
        Scanner scanner = new Scanner(System.in);
        String reponse = "";
        while(!reponse.equals("G") && !reponse.equals("D")){
            System.out.println("Entrez la réponse (G ou D)");
            System.out.flush();
            reponse = scanner.nextLine();
        }
        // applique les malus
        if(reponse.equals("G")){
            question.appliqueEffetsGauche(personnage);
        }else{
            question.appliqueEffetsDroite(personnage);
        }
    }

    private static void initBanqueQuestion(){
        ArrayList<Question> questions = new ArrayList<>();
        Question question;

        question = new Question(
                "Main du roi",
                "Le peuple souhaite libérer les prisonniers",
                "Oui",
                "Non");
        question.ajouteEffetGauche(TypeJauge.ARMEE, -5);
        question.ajouteEffetGauche(TypeJauge.PEUPLE, +5);
        question.ajouteEffetDroite(TypeJauge.PEUPLE, -7);
        questions.add(question);
        
        question = new Question(
                "Paysan",
                "Il n'y a plus rien à manger",
                "Importer de la nourriture",
                "Ne rien faire");
        question.ajouteEffetGauche(TypeJauge.FINANCE,-5);
        question.ajouteEffetGauche(TypeJauge.PEUPLE, +5);
        question.ajouteEffetDroite(TypeJauge.PEUPLE, -5);
        questions.add(question);
      
        question = new Question(
                "Prêtre",
                "Les dieux sont en colère",
                "Faire un sacrifice",
                "Ne rien faire");
        question.ajouteEffetGauche(TypeJauge.CLERGE, +5);
        question.ajouteEffetGauche(TypeJauge.PEUPLE, -3);
        question.ajouteEffetDroite(TypeJauge.CLERGE, -5);
        questions.add(question);

        question = new Question(
                "Main du roi",
                "Le roi Baratheon rassemble son armée",
                "Le soutenir",
                "Rester neutre");
        question.ajouteEffetGauche(TypeJauge.ARMEE, +3);
        question.ajouteEffetGauche(TypeJauge.FINANCE, -3);
        question.ajouteEffetGauche(TypeJauge.CLERGE, -3);
        question.ajouteEffetDroite(TypeJauge.PEUPLE, +3);
        questions.add(question);

        question = new Question(
                    "Paysan",
                    "Abondance de récoltes cette année",
                    "Taxer énormément",
                    "Taxer un tout petit peu");
        question.ajouteEffetGauche(TypeJauge.FINANCE, +10);
        question.ajouteEffetGauche(TypeJauge.PEUPLE, -5);
        question.ajouteEffetDroite(TypeJauge.FINANCE, +1);
        question.ajouteEffetDroite(TypeJauge.PEUPLE, -3);
        questions.add(question);

        question = new Question(
                    "Main du Roi",
                    "Les caisses sont vides...",
                    "Augmenter les taxes",
                    "Emprunter");
        question.ajouteEffetGauche(TypeJauge.FINANCE, +10);
        question.ajouteEffetGauche(TypeJauge.PEUPLE, -5);
        question.ajouteEffetDroite(TypeJauge.FINANCE, +7);
        question.ajouteEffetDroite(TypeJauge.PEUPLE, -3);
        question.ajouteCondition(TypeJauge.FINANCE, TypeCondition.INFERIEUR, 10);
        questions.add(question);

        question = new Question(
                    "Prêtre",
                    "J'aimerais qu'on nous considère en tant que tel",
                    "Construire un monastère",
                    "Ecouter sans rien faire");
        question.ajouteEffetGauche(TypeJauge.CLERGE, +5);
        question.ajouteEffetGauche(TypeJauge.FINANCE, -5);
        question.ajouteEffetDroite(TypeJauge.CLERGE, -5);
        question.ajouteCondition(TypeJauge.CLERGE, TypeCondition.INFERIEUR, 10);
        question.ajouteCondition(TypeJauge.FINANCE, TypeCondition.SUPERIEUR, 30);
        questions.add(question);


        banqueQuestions = new BanqueQuestion(questions);
    }
    
    private static void initPersonnage(){        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez le nom du personnage: ");
        System.out.flush();
        String nom = scanner.nextLine();
        System.out.println(
            "Faut-il vous appeler Roi ou Reine ? (1 pour Roi, 2 pour Reine)");
        int genre = scanner.nextInt();
        Genre roiReine; 
        if(genre==1){
            roiReine = ROI;
        }else{
            roiReine = REINE;
        }

        // initialisation des jauges entre 15 et 35 points
        ArrayList<Jauge> jauges = new ArrayList<>();
        
        jauges.add(new Jauge("Clergé"));
        jauges.add(new Jauge("Peuple"));
        jauges.add(new Jauge("Armée"));
        jauges.add(new Jauge("Finance"));
        
        personnage = new Personnage(nom,roiReine, jauges);
    }

    private static void initDLC(){
        Scanner scanner = new Scanner(System.in);
        System.out.println(
            "Faut-il vous activer le DLC Game Of Thrones ? Y/N");
        String scan = scanner.nextLine();
        if(scan.contains("Y") || scan.contains("y")){
            System.out.println("DLC Games Of Thrones activé");
            JeuGOT.on();
        }
        else{
            System.out.println("DLC Games Of Thrones désactivé");
            JeuGOT.off();
        }
    }
}
