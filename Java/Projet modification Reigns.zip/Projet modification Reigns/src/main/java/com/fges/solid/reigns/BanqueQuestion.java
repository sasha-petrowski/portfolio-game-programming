package com.fges.solid.reigns;

import java.util.ArrayList;

public class BanqueQuestion {
    ArrayList<Question> banqueQuestions;
    public BanqueQuestion(ArrayList<Question> questions){
        banqueQuestions = questions;
    }

    public int size(){
        return banqueQuestions.size();
    }

    public ArrayList<Question> getQuestions(){
        return banqueQuestions;
    }

    public Question questionAleatoire(Personnage personnage){
        int numQuestion;
        while(true){
            numQuestion = (int) (Math.random()*banqueQuestions.size());

            if(banqueQuestions.get(numQuestion).verifConditions(personnage)){
                return banqueQuestions.get(numQuestion);
            }
        }
    }
    Question get(int index){
        return banqueQuestions.get(index); 
    }
}
