package com.fges.solid.reigns;

import java.lang.ProcessBuilder.Redirect.Type;

public class Condition {
    TypeCondition type;
    TypeJauge jauge;
    int valeur;

    public Condition(TypeJauge jauge, TypeCondition type, int valeur){
        this.type = type;
        this.jauge = jauge;
        this.valeur = valeur;
    }

    public boolean verifier(Personnage personnage){
        int valeurJauge;
        switch (this.jauge) {
            case CLERGE:
                valeurJauge = personnage.getJaugeClerge().getValeur();
                break;
            case PEUPLE:
                valeurJauge = personnage.getJaugePeuple().getValeur();
                break;
            case ARMEE:
                valeurJauge = personnage.getJaugeArmee().getValeur();
                break;
            case FINANCE:
                valeurJauge = personnage.getJaugeFinance().getValeur();
                break;
        
            default:
                return true;
        }
        if(this.type == TypeCondition.SUPERIEUR){
            return (valeurJauge > this.valeur); 
        }
        else{ // INFERIEUR
            return (valeurJauge < this.valeur); 
        }
    }
}
