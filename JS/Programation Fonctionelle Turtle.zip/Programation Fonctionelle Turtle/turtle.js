// A compléter

// Point :: Num (x,y) -> (x,y) -> (x,y)
const Point = (x,y) => {return {x,y}};

console.log(Point(10, 10)); // {x : 10, y : 10}

// Turtle :: (point, angle) -> (point, angle) -> (point, angle)
const Turtle = (point, angle) => {return {point, angle}};

console.log(Turtle(Point(10, 10), 90)); // {point:{x : 10, y : 10}, angle:90}

// forward :: Float -> Turtle -> Turtle
const forward = x => turtle => Turtle(Point(turtle["point"]["x"]+(x*Math.cos((turtle["angle"]*Math.PI)/180)),turtle["point"]["y"]+(x*Math.sin(turtle["angle"]*Math.PI/180))), turtle["angle"]);

console.log(forward(10)(Turtle(Point(0, 0), 90)));
console.log(forward(10)(Turtle(Point(0, 0), 45)));
console.log(forward(10)(Turtle(Point(0, 0), 0 )));

// addPoint :: [Point] -> Turtle -> [Point]
const addPoint = points => turtle => {return points.concat(turtle["point"])};

let turtle_test = Turtle(Point(100,0), 0);
console.log(addPoint([Point(0,0), Point(50,50)])(turtle_test)); // [{x: 0, y: 0},{x: 50, y: 50},{x: 100, y: 0}]

// left :: Double -> Turtle -> Turtle 
const left = angle => turtle => Turtle(turtle["point"], ( turtle["angle"] - angle ) % 360);

console.log(left(90)(turtle_test));
// right :: Double -> Turtle -> Turtle
const right = angle => turtle => Turtle(turtle["point"], ( turtle["angle"] + angle ) % 360);
//( 360 + -(-( turtle["angle"] - angle )%360)) % 360)
console.log(right(450)(turtle_test));

// vonKochRules :: Rules
const vonKochRules = {"F":"F-F++F-F", "+":"+", "-":"-"};

// shift :: [t] -> [t]
const shift = liste => liste.slice(1, liste.length);

// reduce :: (t -> t -> t) -> t -> [t] -> t
const reduce = f => acc => liste => (liste.length > 0) ? reduce(f)(f(acc)(liste[0]))(shift(liste)) : acc;

// next :: Rules -> Word -> Word
const next = Rules => Word => reduce(f1 => f2 => f1.concat(Rules[f2]))("")(Word);

console.log(next(vonKochRules)("F-F++F-F")); // F-F++F-F-F-F++F-F++F-F++F-F-F-F++F-F

// lSysteme :: Axiom -> Rules -> Int -> Word
const lSystem = Axiom => Rules => Int => Int > 0 ? lSystem(next(Rules)(Axiom))(Rules)(Int-1) : Axiom;

console.log(lSystem("F")(vonKochRules)(2)); // F-F++F-F-F-F++F-F++F-F++F-F-F-F++F-F

//Config :: (Turtle, StepSize, Angle) -> Config
const Config = (t, l, a) => {return {turtle:t, stepSize:l, angle:a}};

//DrawState :: (Turtle, [Points]) -> DrawState
const DrawState = (turtle, path) =>{return {path, turtle}};

//interpretSymbol :: Config -> DrawState -> Symbol -> DrawState
const interpretSymbol = config => drawState => symbol => (symbol == "F") ? DrawState(forward(config["stepSize"])(drawState["turtle"]), addPoint(drawState["path"])(forward(config["stepSize"])(drawState["turtle"]))) : (symbol == "+") ? DrawState(right(config["angle"])(drawState["turtle"]), drawState["path"]) : DrawState(left(config["angle"])(drawState["turtle"]), drawState["path"]) ;

let turtle_test2 = Turtle(Point(0,0),0);
let config_test = Config(turtle_test2, 100, 90);
let drawState = DrawState(turtle_test2, []);
console.log(interpretSymbol(config)(drawState)('F')); // { path: [{x: 100, y: 0}], turtle: {angle: 0,point: {x: 100, y: 0}}}
console.log(interpretSymbol(config)(drawState)('+')); // { path: [], turtle: {angle: 90, point: {x: 0,y: 0}}}

//interpretWord :: Config -> DrawState -> Word -> DrawState
const interpretWord = config => drawState => word => word.length != 0 ? interpretWord(config)(interpretSymbol(config)(drawState)(word[0]))(shift(word)) : drawState ;

//lSystemPath :: Config -> LSystem -> Int -> [Point]
const lSystemPath = config => lsystem => int => interpretWord(config)(DrawState(config["turtle"], [config["turtle"]["point"]]))(lsystem(int))["path"]

console.log(lSystemPath(config_test)(lSystem("F")(vonKochRules))(3)); // [ {x: 100, y: 0}, {x: 100, y: 100},...]