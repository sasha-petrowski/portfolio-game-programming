﻿using System;
using System.Collections.Generic;
using System.Collections;
using UnityEngine;

public class InputManager : MonoBehaviour
{
    private static Dictionary<KeyCode, List<Action>> _keys = new();
    private static Dictionary<KeyCode, List<Action>> _keysDown = new();
    private static Dictionary<KeyCode, List<Action>> _keysUp = new();

    private static Dictionary<string, List<Action<float>>> _axises = new();
    private static Dictionary<string, List<Action<float>>> _axisesRaw = new();


    #region Input Subscriptions
    private static void AddTo<TKey, TAction>(Dictionary<TKey, List<TAction>> dict, TKey key, TAction action)
    {
        if (dict.TryGetValue(key, out List<TAction> list))
        {
            list.Add(action);
        }
        else
        {
            dict.Add(key, new List<TAction> { action });
        }
    }
    private static void RemoveFrom<TKey, TAction>(Dictionary<TKey, List<TAction>> dict, TKey key, TAction action)
    {
        if (dict.TryGetValue(key, out List<TAction> list))
        {
            list.Remove(action);
        }
    }
    #region Add
    public static void AddKey(KeyCode key, Action action)
    {
        AddTo(_keys, key, action);
    }
    public static void AddKeyDown(KeyCode key, Action action)
    {
        AddTo(_keysDown, key, action);
    }
    public static void AddKeyUp(KeyCode key, Action action)
    {
        AddTo(_keysUp, key, action);
    }
    public static void AddAxis(string axis, Action<float> action)
    {
        AddTo(_axises, axis, action);
    }
    public static void AddAxisRaw(string axis, Action<float> action)
    {
        AddTo(_axisesRaw, axis, action);
    }
    #endregion
    #region Remove
    public static void RemoveKey(KeyCode key, Action action)
    {
        RemoveFrom(_keys, key, action);
    }
    public static void RemoveKeyDown(KeyCode key, Action action)
    {
        RemoveFrom(_keysDown, key, action);
    }
    public static void RemoveKeyUp(KeyCode key, Action action)
    {
        RemoveFrom(_keysUp, key, action);
    }
    public static void RemoveAxis(string axis, Action<float> action)
    {
        RemoveFrom(_axises, axis, action);
    }
    public static void RemoveAxisRaw(string axis, Action<float> action)
    {
        RemoveFrom(_axisesRaw, axis, action);
    }
    #endregion
    #endregion

    #region Input Tests
    private void GetAllKeys(Dictionary<KeyCode, List<Action>> keys, Func<KeyCode, bool> func)
    {
        foreach (KeyCode key in keys.Keys)
        {
            if (func(key))
            {
                foreach (Action action in keys[key])
                {
                    action();
                }
            }
        }
    }
    private void GetAllAxises(Dictionary<string, List<Action<float>>> axises, Func<string, float> func)
    {
        foreach (string key in axises.Keys)
        {
            float axis = func(key);
            foreach (Action<float> action in axises[key])
            {
                action(axis);
            }
        }
    }
    #endregion

    void Update()
    {
        GetAllKeys(_keys, Input.GetKey);
        GetAllKeys(_keysDown, Input.GetKeyDown);
        GetAllKeys(_keysUp, Input.GetKeyUp);

        GetAllAxises(_axises, Input.GetAxis);
        GetAllAxises(_axisesRaw, Input.GetAxisRaw);
    }
}