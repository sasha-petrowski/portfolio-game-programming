public enum GrappleState
{
    Off,
    Launched,
    Attached,
    Retracting
}