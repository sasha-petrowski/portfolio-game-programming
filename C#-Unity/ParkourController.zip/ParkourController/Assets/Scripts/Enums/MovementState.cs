public enum MovementState
{
    Grounded,
    Air,
    WallRun,
    WallClimb
}