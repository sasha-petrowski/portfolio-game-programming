using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LayerUtility
{
    public const int TerrainMask = (1 << (int)UnityLayer.Default) + (1 << (int)UnityLayer.Terrain);
    public const int GrappleMask = (1 << (int)UnityLayer.Default) + (1 << (int)UnityLayer.Terrain);
}
public enum UnityLayer
{
    Default = 0,
    TransparentFX = 1,
    IgnoreRaycast = 2,
    Terrain = 3,
    Water = 4,
    UI = 5,
    Entity = 6
}

