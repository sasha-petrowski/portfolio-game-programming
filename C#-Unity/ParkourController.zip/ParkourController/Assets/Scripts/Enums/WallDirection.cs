public enum WallDirection
{
    None,
    Front,
    Left,
    Right
}