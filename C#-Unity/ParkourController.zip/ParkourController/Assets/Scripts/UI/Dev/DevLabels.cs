using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class DevLabels : MonoBehaviour
{
    [SerializeField] PlayerController _player;
    [SerializeField] TextMeshProUGUI _stateText;
    [SerializeField] TextMeshProUGUI _speedText;

    // Update is called once per frame
    void Update()
    {
        UpdateState();
        UpdateSpeed();
    }

    private void UpdateState()
    {
        _stateText.text = $"State : {_player.MovementState}";
    }
    private void UpdateSpeed()
    {
        _speedText.text = $"Speed : {string.Format("{0:0.0}", new Vector2(_player.Rb.velocity.x, _player.Rb.velocity.z).magnitude)} ms";
    }
}
