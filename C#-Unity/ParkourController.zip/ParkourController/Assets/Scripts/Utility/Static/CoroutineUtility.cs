﻿using System.Collections;
using UnityEngine;
public static class CoroutineUtility
{
}
