using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerCounter : MonoBehaviour
{
    public Action OnEnter, OnExit;

    int _count;
    private void OnTriggerEnter(Collider other)
    {
        if(_count == 0)
        {
            OnEnter?.Invoke();
        }
        _count++;
    }
    private void OnTriggerExit(Collider other)
    {
        _count--;
        if (_count == 0)
        {
            OnExit?.Invoke();
        }
    }



    public static implicit operator bool(TriggerCounter tc)
    {
        return tc._count > 0;
    }
}
