using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class CharacterStats
{
    [Header("Movement")]
    public float Gravity = 10f;
    public float HighGravity = 20f;
    public float LowGravity = 5f;

    public float TargetSpeed = 7;
    [Range(0, 1)]
    public float SlowSpeed = 0.5f;

    public float GroundAcceleration = 40;
    public float GroundDrag = 4;

    public float AirAcceleration = 10;
    public float AirDrag = 2;


    [Header("Jumping")]
    public float JumpVelocity = 10;
    public float JumpCooldown = 0.1f;

    [Header("WallRunning")]
    public float WallJumpRebound = 2.5f;
    public float WallJumpBoost = 5f;

    [Header("Grapple & Dash")]
    public float GrappleSpeed = 20;
    public float GrappleForce = 20;
    public float GrappleCooldown = 1;
    [Space]
    public float DashVelocity = 12;
    public float DashUpVelocity = 4;

}
