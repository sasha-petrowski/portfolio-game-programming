﻿using System;
using System.Collections;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public CharacterStats Stat;

    [Header("Refs")]
    public Rigidbody Rb;

    [SerializeField] private TriggerCounter _groundCheck;
    [SerializeField] private Camera _camera;

    [Header("CameraMovement")]
    [SerializeField] private Transform _neck;
    [SerializeField] private Transform _shoulders;
    [SerializeField] private Transform _torso;
    [SerializeField] private Transform _lower;


    public MovementState MovementState = MovementState.Grounded;

    public Vector3 LookUp => _camera.transform.up;
    public Vector3 LookForward => _camera.transform.forward;
    public Vector3 LookRight => _camera.transform.right;

    public WallDirection Wall;
    public bool Grounded => _groundCheck;
    public bool Jumping { get; set; }
    public bool Dashing { get; set; }
    public bool Grappling { get; set; }

    public Action OnTouchGround;
    public Action OnTouchWall; 

    private float _flatSpeed;
    private float _verticalInput;
    private float _horizontalInput;

    private float _cameraPitch;
    private Vector2 _cameraAngle;
    private bool _cameraMoved;


    // Use this for initialization
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        //InputManager subscriptions
        InputManager.AddAxisRaw("Horizontal", OnHorizontalAxis);
        InputManager.AddAxisRaw("Vertical", OnVerticalInput);

        InputManager.AddAxisRaw("Mouse Y", OnMouseY);
        InputManager.AddAxisRaw("Mouse X", OnMouseX);


        // Events Subscription
        _groundCheck.OnEnter += TouchGround;
    }

    private void Update()
    {
        HandleState();
    }

    private void LateUpdate()
    {
        Camera();
    }

    void FixedUpdate()
    {
        Drag();
        Move();
        Gravity();

        _flatSpeed = new Vector2(Rb.velocity.x, Rb.velocity.z).magnitude;
    }

    private void Gravity()
    {
        float gravity;
        if(Grappling || Wall != WallDirection.None)
        {
            gravity = Stat.LowGravity;
        }
        else if (!Grounded && Rb.velocity.y > 0)
        {
            gravity = Stat.Gravity;
        }
        else
        {
            gravity = Stat.HighGravity;
        }
        Rb.AddForce(new Vector3(0, -gravity, 0), ForceMode.Acceleration);
    }

    private void HandleState()
    {
        if (Grounded)
        {
            MovementState = MovementState.Grounded;
        }
        else if(Wall == WallDirection.None)
        {
            MovementState = MovementState.Air;
        }
        else if (Wall == WallDirection.Front)
        {
            MovementState = MovementState.WallClimb;
        }
        else
        {
            MovementState = MovementState.WallRun;
        }
    }

    private void Drag()
    {
        float drag;
        if (Grounded && !Dashing)
        {
            drag = Stat.GroundDrag;
        }
        else
        {
            drag = Stat.AirDrag;
        }
        //reduce drag when going fast (f physics) brrrrrrrrrrrrr
        drag *= Mathf.Clamp01(0.25f + Mathf.Clamp01(1f - (_flatSpeed - Stat.TargetSpeed) / Stat.TargetSpeed));

        Rb.drag = drag;
    }

	private void Move()
    {
        if (Mathf.Approximately(_verticalInput, 0) && Mathf.Approximately(_horizontalInput, 0)) return;

        Vector3 moveDirection = transform.forward * _verticalInput + transform.right * _horizontalInput;
        float acceleration;

        // "stick" to the wall
        if (Wall == WallDirection.Left)
        {
            Rb.AddForce(-transform.right * Stat.WallJumpRebound, ForceMode.Force);
        }
        else if (Wall == WallDirection.Left)
        {
            Rb.AddForce(transform.right * Stat.WallJumpRebound, ForceMode.Force);
        }

        if (Grounded)
        {
            // if on a slope
            if(Physics.Raycast(transform.position, Vector3.down, out RaycastHit hit, 0.25f, LayerUtility.TerrainMask))
            {
                moveDirection = Vector3.ProjectOnPlane(moveDirection, hit.normal);
            }


            // ground speed is limited to TargetSpeed
            float targetSpeed = Stat.TargetSpeed * (Input.GetKey(KeyCode.LeftControl) ? Stat.SlowSpeed : 1f);
            float accelerationMult = Mathf.Clamp01(targetSpeed - _flatSpeed + 0.5f);

            acceleration = Stat.GroundAcceleration * accelerationMult;
        }
        else
        {
            acceleration = Stat.AirAcceleration;
        }


        Rb.AddForce(acceleration * moveDirection, ForceMode.Force);
	}

    private void Camera()
    {
        // pitch can be changed by wallrunning
        // this will eventually be replaced by an animation
        float targetPitch = 0;
        switch (Wall)
        {
            case WallDirection.Left:
                targetPitch = -15f;
                break;
            case WallDirection.Right:
                targetPitch = 15f;
                break;
        }
        _cameraPitch = Mathf.SmoothStep(_cameraPitch, targetPitch, 0.15f);
        if (_cameraPitch - 0.1f < targetPitch && _cameraPitch + 0.1f > targetPitch)
        {
            _cameraPitch = targetPitch;
        }
        _camera.transform.localEulerAngles = new Vector3(0, 0, _cameraPitch);


        if (!_cameraMoved) return;

        transform.rotation = Quaternion.Euler(0, _cameraAngle.x, 0);

        Quaternion fullRot = Quaternion.Euler(_cameraAngle.y, _cameraAngle.x, 0);

        _neck.transform.rotation = fullRot;
        _shoulders.transform.rotation = fullRot;

        _torso.transform.rotation = Quaternion.Euler(_cameraAngle.y * 0.4f, _cameraAngle.x, 0);
        _lower.transform.rotation = Quaternion.Euler(_cameraAngle.y * 0.2f, _cameraAngle.x, 0);
    }


    private void TouchGround()
    {
        OnTouchGround?.Invoke();
    }

    #region On Inputs
    private void OnHorizontalAxis(float value)
    {
        _horizontalInput = value;
    }
    private void OnVerticalInput(float value)
    {
        _verticalInput = value;
    }

    private void OnMouseY(float value)
    {
        _cameraAngle.y = Mathf.Clamp(_cameraAngle.y - value, -85f, 85f);
        if (value != 0)
        {
            _cameraMoved = true;
        }
    }
    private void OnMouseX(float value)
    {
        _cameraAngle.x = (_cameraAngle.x + value) % 360;
        if (value != 0)
        {
            _cameraMoved = true;
        }
    }


    #endregion
}