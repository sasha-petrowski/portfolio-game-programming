using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(PlayerController))]
public class JumpBehaviour : EntityBehaviour
{
    public bool ReadyToJump => (_jumpCooldown && _player.Grounded);

    private bool _jumpCooldown = true;
    private bool _canDoubleJump;

    // buffered things
    private float _bufferedJumpTime = float.MinValue;

    protected override void OnStart()
    {
        base.OnStart();

        _player.OnTouchGround += TouchSurface;
        _player.OnTouchWall += TouchSurface;

        InputManager.AddKeyDown(KeyCode.Space, OnJumpInput);
    }
    private void OnJumpInput()
    {
        if (!TryJump())
        {
            _bufferedJumpTime = Time.time;
        }
    }
    private bool TryJump()
    {
        if (!_jumpCooldown) return false;
        switch (_player.MovementState)
        {
            case MovementState.Grounded:
                if (ReadyToJump)
                {
                    GroundJump();
                    return true;
                }
                break;
            case MovementState.Air:
                if (_canDoubleJump)
                {
                    DoubleJump();
                    return true;
                }
                break;
            case MovementState.WallClimb:
            case MovementState.WallRun:
                WallJump();
                return true;
        }

        return false;
    }
    public void ResetJump()
    {
        _canDoubleJump = true;
    }
    private void TouchSurface()
    {
        ResetJump();
        //generous buffer for jump input so we can bunnyhop
        if (Time.time - _bufferedJumpTime < 0.2f)
        {
            TryJump();
        }
    }
    private void GroundJump()
    {
        Rb.velocity = new Vector3(Rb.velocity.x, Stat.JumpVelocity, Rb.velocity.z);

        StartCoroutine(Cooldown());
    }
    private void WallJump()
    {
        Vector3 wallRedirection = Vector3.zero;
        Vector3 wallBoost = _player.transform.forward;
        switch (_player.Wall)
        {
            case WallDirection.Front:
                wallRedirection = -_player.transform.forward;
                wallBoost = Vector3.zero;
                break;
            case WallDirection.Left:
                wallRedirection = _player.transform.right;
                break;
            case WallDirection.Right:
                wallRedirection = -_player.transform.right;
                break;
        }

        Rb.velocity = new Vector3(Rb.velocity.x, Stat.JumpVelocity, Rb.velocity.z) + wallRedirection * Stat.WallJumpRebound + wallBoost * Stat.WallJumpBoost;

        StartCoroutine(Cooldown());

        
        if (TryGetComponent(out GrappleBehaviour behaviour))
        {
            behaviour.OnJump();
        }
    }
    private void DoubleJump()
    {
        _canDoubleJump = false;
        Rb.velocity = new Vector3(Rb.velocity.x, Stat.JumpVelocity, Rb.velocity.z);

        if (TryGetComponent(out GrappleBehaviour behaviour))
        {
            behaviour.OnJump();
        }
    }
    private IEnumerator Cooldown()
    {
        _jumpCooldown = false;
        _player.Jumping = true;

        yield return new WaitForSeconds(Stat.JumpCooldown);

        _jumpCooldown = true;
        _player.Jumping = false;
    }
}
