using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallBehaviour : EntityBehaviour
{
    public WallDirection Wall { get => _player.Wall; set => _player.Wall = value; }


    private const float WallCheckDistance = 0.7f;

    private bool _front, _right, _left;
    private RaycastHit _frontHit, _rightHit, _leftHit;

    private void Update()
    {
        if (!_player.Grounded && !_player.Jumping && CheckForWall())
        {
            if(Wall == WallDirection.None)
            {
                _player.OnTouchWall.Invoke();
            }

            DetermineWall();
        }
        else
        {
            Wall = WallDirection.None;
        }
    }

    private bool CheckForWall()
    {
        Vector3 from = transform.position + new Vector3(0, 0.5f, 0);
        _front = Physics.Raycast(from, transform.forward, out _frontHit, WallCheckDistance, LayerUtility.TerrainMask);
        _right = Physics.Raycast(from, transform.right, out _rightHit, WallCheckDistance, LayerUtility.TerrainMask);
        _left = Physics.Raycast(from, -transform.right, out _leftHit, WallCheckDistance, LayerUtility.TerrainMask);

        return _front | _right | _left;
    }
    private void DetermineWall()
    {
        if (_front)
        {
            Wall = WallDirection.Front;
        }
        else if (_left && (Wall == WallDirection.Left || !_right))
        {
            Wall = WallDirection.Left;
        }
        else if (_right)
        {
            Wall = WallDirection.Right;
        }
    }
}
