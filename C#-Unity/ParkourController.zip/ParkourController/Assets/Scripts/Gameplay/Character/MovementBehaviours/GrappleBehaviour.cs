using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrappleBehaviour : EntityBehaviour
{
    [Header("Refs")]
    [SerializeField] private GameObject _grappleObject;
    [SerializeField] private Transform _grapple;
    [SerializeField] private Transform _aim;
    [SerializeField] private Transform _origin;
    [SerializeField] private LineRenderer _lineRenderer;

    private bool _cooldown = true;
    private GrappleState _state = GrappleState.Off;

    float _timeAt;
    Vector3 _direction, _aimPos, _basePos;

    private Rigidbody _otherRb;
    private SpringJoint _joint;

    private void Update()
    {
        switch (_state)
        {
            case GrappleState.Launched:
                UpdateLaunched();
                break;
            case GrappleState.Retracting:
                UpdateRetracting();
                break;
        }
    }
    private void UpdateLaunched()
    {
        _basePos = new Vector3(Mathf.SmoothStep(_basePos.x, _aimPos.x, 0.1f), Mathf.SmoothStep(_basePos.y, _aimPos.y, 0.1f), Mathf.SmoothStep(_basePos.z, _aimPos.z, 0.1f));
        Vector3 nextPos = _basePos + _direction * (Time.time - _timeAt) * _player.Stat.GrappleSpeed;

        // if it hits something
        if (Physics.Raycast(_grapple.position, _direction, out RaycastHit hit, (nextPos - _grapple.position).magnitude, LayerUtility.GrappleMask))
        {
            Attach(hit);
        }
        else
        {
            _grapple.position = nextPos;
        }
    }
    private void UpdateRetracting()
    {
        float blend = Mathf.Clamp01((Time.time - _timeAt) / _player.Stat.GrappleCooldown);

        _grapple.position = _origin.position * blend + _basePos * (1f - blend);

        if (blend >= 0.95f)
        {
            Off();
        }
    }

    private void FixedUpdate()
    {
        switch (_state)
        {
            case GrappleState.Attached:
                UpdateAttached();
                break;
        }
    }
    private void UpdateAttached()
    {
        Vector3 direction = (_origin.position - _grapple.position).normalized;

        float forceSplit = _otherRb == null ? 1f : 0.5f;
        Vector3 force = direction * _player.Stat.GrappleForce * forceSplit;

        Rb.AddForce(-force, ForceMode.Force);
        _otherRb?.AddForce(force, ForceMode.Force);

        float distance = (_origin.position - _grapple.position - force * Time.fixedDeltaTime).magnitude;
        _joint.maxDistance = distance;
        if(distance < 2f)
        {
            Retract();
        }
    }

    private void LateUpdate()
    {
        if (_state != GrappleState.Off)
        {
            // Drawline
            _lineRenderer.SetPosition(0, _grapple.position);
            _lineRenderer.SetPosition(1, _origin.position);
        }
        _grappleObject.transform.position = _grapple.position;
        _grappleObject.transform.rotation = _grapple.rotation;
    }


    protected override void OnStart()
    {
        base.OnStart();

        InputManager.AddKeyDown(KeyCode.LeftShift, OnGrappleInput);

        Off();
    }
    private void OnGrappleInput()
    {
        if (_state == GrappleState.Retracting) return;

        if (_cooldown)
        {
            Launch();
        }
        else if (_state != GrappleState.Off)
        {
            Retract();
            StartCoroutine(Dash());
        } 
    }
    private void Launch()
    {
        _state = GrappleState.Launched;
        _cooldown = false;
        _timeAt = Time.time;

        // save stuff for later
        _direction = _aim.forward;
        _aimPos = _aim.position;
        _basePos = _origin.position;

        // set same direction as camera
        _grapple.rotation = _aim.rotation;

        // remove parent so it moves by itself
        _grapple.SetParent(null);

        _lineRenderer.positionCount = 2;
    }
    private void Attach(RaycastHit hit)
    {
        _state = GrappleState.Attached;
        _timeAt = Time.time;

        // attach to grapple to the hit object
        _grapple.SetParent(hit.collider.transform);
        _grapple.position = hit.point;
        _grapple.rotation = Quaternion.LookRotation(hit.normal);

        // save other Rigid Body
        _otherRb = hit.collider.attachedRigidbody;

        _player.Grappling = true;


        // Add impulse towards the grappling hook
        Vector3 direction = (_origin.position - _grapple.position).normalized;

        float forceSplit = _otherRb == null ? 1f : 0.5f;
        Vector3 force = direction * _player.Stat.DashVelocity * forceSplit;

        Rb.AddForce(-force, ForceMode.Impulse);
        _otherRb?.AddForce(force, ForceMode.Impulse);

        // Create joint
        _joint = _player.gameObject.AddComponent<SpringJoint>();
        if(_otherRb != null)
        {
            _joint.autoConfigureConnectedAnchor = true;
            _joint.connectedBody = _otherRb;
        }
        else
        {
            _joint.autoConfigureConnectedAnchor = false;
            _joint.connectedAnchor = hit.point;
        }

        // reset doubleJumps if Attached
        if (TryGetComponent(out JumpBehaviour behaviour))
        {
            behaviour.ResetJump();
        }
    }
    private void Retract()
    {
        _state = GrappleState.Retracting;
        _timeAt = Time.time;

        _basePos = _grapple.position;
        _grapple.rotation = Quaternion.LookRotation((_origin.position - _grapple.position).normalized);
        _grapple.SetParent(null);

        _player.Grappling = false;

        Destroy(_joint);
    }
    private void Off()
    {
        _lineRenderer.positionCount = 0;

        _state = GrappleState.Off;
        _timeAt = Time.time;

        _cooldown = true;

        _grapple.position = _origin.position;
        _grapple.rotation = _origin.rotation;
        _grapple.SetParent(_origin);
    }
    public void OnJump()
    {
        if (! _player.Grounded && _state != GrappleState.Attached) return;
        Retract();
    }
    private IEnumerator Dash()
    {
        _player.Dashing = true;

        yield return null;

        Vector3 dashDirection = _player.Grounded ? Rb.transform.forward : _player.LookForward;
        Vector3 upDirection = _player.Grounded ? Rb.transform.up : _player.LookUp;

        Rb.AddForce(dashDirection * Stat.DashVelocity + upDirection * Stat.DashUpVelocity, ForceMode.Impulse);

        yield return new WaitForSeconds(0.25f);

        _player.Dashing = false;
    }
}
