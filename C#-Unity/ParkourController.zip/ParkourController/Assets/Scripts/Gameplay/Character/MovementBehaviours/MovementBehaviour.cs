using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(PlayerController))]
public class EntityBehaviour : MonoBehaviour
{
    public Rigidbody Rb => _player.Rb;
    public CharacterStats Stat => _player.Stat;

    protected PlayerController _player;

    void Start()
    {
        OnStart();
    }

    protected virtual void OnStart()
    {
        _player = GetComponent<PlayerController>();
    }
}
