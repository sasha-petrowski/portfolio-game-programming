using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    //Ref
    public Rigidbody2D PlayerBody;
    public Animator PlayerAnimator;
    public SpriteRenderer PlayerRenderer;
    public AudioManager AudioManager;

    //Public
    public float MoveForce = 20;

    //Private
    private Vector2 direction = new Vector2(0f, 0f);
    Coroutine coroutine;

    private float axing = 0f;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        var horizontal = (Input.GetKey(KeyCode.D) ? 1f : 0f) - (Input.GetKey(KeyCode.Q) ? 1f : 0f);

        var vertical = (Input.GetKey(KeyCode.Z) ? 1f : 0f) - (Input.GetKey(KeyCode.S) ? 1f : 0f);

        direction = new Vector2(horizontal, vertical);

        if (axing > 1f && Input.GetKey(KeyCode.Space) )
        {
            PlayerAnimator.Play("Axing");
            axing = 0f;
        }
        else axing += Time.deltaTime;
    }

    private void FixedUpdate()
    {
        if (direction.magnitude > 0.05)
        {
            direction.Normalize();
            PlayerBody.AddForce(direction * MoveForce);
            PlayerAnimator.SetBool("Running", true);
            if (coroutine == null)
            {
                coroutine = StartCoroutine(PlayFootsteps());
            }
            if (direction.x > 0)
            {
                PlayerRenderer.flipX = false;
            }
            else if(direction.x < 0)
            {
                PlayerRenderer.flipX = true;
            }
        }
        else
        {
            PlayerAnimator.SetBool("Running", false);
            if (coroutine != null)
            {
                StopCoroutine(coroutine);
                coroutine = null;
            }
        }
    }

    IEnumerator PlayFootsteps()
    {
        while (enabled)
        {
            AudioManager.Instance.FootSteps();
            yield return new WaitForSeconds(0.3f);
        }
    }
}