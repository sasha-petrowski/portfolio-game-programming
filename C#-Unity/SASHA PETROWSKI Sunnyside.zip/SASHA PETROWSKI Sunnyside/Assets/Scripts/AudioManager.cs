using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public AudioClip[] Clips;
    public AudioClip[] Steps;
    public static AudioManager Instance;
    // Start is called before the first frame
    private void Awake()
    {   
        Instance = this;
        PlayMusic("battleThemeA");
    }

    AudioClip GetClip(string name)
    {
        foreach(var item in Clips)
        {
            if (item.name == name) return item;
        }
        return null;
    }

    public void FootSteps()
    {
        AudioClip clip = Steps[Random.Range(0, Steps.Length)];
        if (clip != null)
        {
            AudioObject(clip, false);
        }
    }
    public void Play(string name)
    {
        AudioClip clip = GetClip(name);

        if(clip != null)
        {
            AudioObject(clip, false);
        }
    }
    public void PlayMusic(string name)
    {
        AudioClip clip = GetClip(name);
        if(clip != null)
        {
            AudioObject(clip, true);
        }
    }
    public void AudioObject(AudioClip clip, bool loop)
    {
        GameObject go = new GameObject();
        go.name = clip.name;
        AudioSource source = go.AddComponent<AudioSource>();
        source.clip = clip;
        source.volume = 0.33f;
        if (loop)
        {
            source.loop = true;
        }
        else
        {
            GameObject.Destroy(go, clip.length);
        }
        source.Play();
    }
}