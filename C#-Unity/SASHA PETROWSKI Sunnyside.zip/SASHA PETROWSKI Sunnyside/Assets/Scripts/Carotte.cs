using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Carotte : MonoBehaviour
{
    //ref
    public Sprite[] sprites;
    public SpriteRenderer carotte;
    public SpriteRenderer player;
    public GameObject prefabCarotte;
    //public
    public int stade = 0;    

    //private
    private float growing;

    // Update is called once per frame
    void Update()
    {
        carotte.sprite = sprites[stade];
        if (stade < sprites.Length-1)
        {
            growing += Time.deltaTime;
            if (growing > 5f)
            {
                growing = 0;
                stade ++;
            }
        }else{
            if ( Input.GetKeyDown(KeyCode.E) == true && ((player.transform.position - carotte.transform.position).magnitude < 2.5f))
            {
                stade = 0;
                loot();
            }
        }
    }
    private void loot(){
        GameObject loot = GameObject.Instantiate(prefabCarotte);
        loot.transform.position = new Vector3(carotte.transform.position.x, carotte.transform.position.y, 0);
        var horizontal = (player.transform.position.x < carotte.transform.position.x ? 1f : -1f);
        var vertical =  (player.transform.position.y < carotte.transform.position.y ? 1f : -1f);
        Vector2 direction = new Vector2(horizontal, vertical);
        direction.Normalize();
        loot.GetComponent<Rigidbody2D>().AddForce(direction * 200);
        loot.GetComponent<Loot>().Cible = player.gameObject;
    }
}