using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameTree : MonoBehaviour
{
    //ref
    public Sprite[] sprites;
    public SpriteRenderer tree;
    public SpriteRenderer player;
    public GameObject prefabBranch;
    //public
    public int stade = 0;
    public int resistance = 1;
    

    //private
    private GameObject leaf;
    private float delay_hit;
    private float delay_regrow;
    private bool shaking = false;
    // Start is called before the first frame update
    void Start()
    {
        stade = 0;
        delay_hit = 0;
        delay_regrow = 0;
        tree.sprite = sprites[0];
        leaf = new GameObject();
        leaf.name = "leaf";
        leaf.AddComponent<SpriteRenderer>();
        leaf.GetComponent<SpriteRenderer>().sprite = sprites[3];
        leaf.transform.position = new Vector3(tree.transform.position.x, tree.transform.position.y, 0);
        leaf.GetComponent<SpriteRenderer>().sortingOrder = 20;
    }

    // Update is called once per frame
    void Update()
    {
        tree.sortingOrder = (tree.transform.position.y + 0.25f > player.transform.position.y ? 9 : 11 );
        if (leaf == null)
        {
            delay_regrow += Time.deltaTime;
            if (delay_regrow > 30f)
            {
                stade = 0;
                Start();
            }
        }
        delay_hit += Time.deltaTime;
        if (delay_hit > 1f)
        {
            shaking = false;
            if(leaf != null)
            {
                leaf.transform.position = new Vector3(tree.transform.position.x, tree.transform.position.y, 0);
            }
            if ( ((player.transform.position - tree.transform.position).magnitude < 2.5f) && player.gameObject.GetComponent<Player>().PlayerAnimator.GetCurrentAnimatorStateInfo(0).IsName("Axing"))
            {
                delay_hit = 0f;
                Hit();
            }
        }
        else if (shaking && leaf != null){
            Shake();
        }
    }
    public void Hit()
    {
        if (leaf != null)
        {
            loot();
            if (stade < (1 + resistance))
            {
                shaking = true;
                stade ++;
            }
            else
            {
                GameObject.Destroy(leaf);
                leaf = null;
                tree.sprite = sprites[1];
            }
        }
        else if(stade < (2 + resistance))
        {
            loot();
            stade ++;
            tree.sprite = sprites[2];
        }
    }
    private void loot(){
        GameObject branch = GameObject.Instantiate(prefabBranch);
        branch.transform.position = new Vector3(tree.transform.position.x, tree.transform.position.y, 0);
        var horizontal = (player.transform.position.x < tree.transform.position.x ? 1f : -1f);
        var vertical =  (player.transform.position.y < tree.transform.position.y ? 1f : -1f);
        Vector2 direction = new Vector2(horizontal, vertical);
        direction.Normalize();
        branch.GetComponent<Rigidbody2D>().AddForce(direction * 200);
        branch.GetComponent<Loot>().Cible = player.gameObject;
    }
    private void Shake()
    {
        //shake the leafs
        leaf.transform.position = new Vector3(tree.transform.position.x + (0.05f - delay_hit % 0.1f), tree.transform.position.y, 0);
    }
}