using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skeleton : MonoBehaviour
{
    Vector3 PosDepart;
    public Rigidbody2D skelbody;
    public GameObject Cible;

    public Animator SkelAnimator;

    public float MoveForce = 5;
    //private
    private Vector2 direction;
    private bool dead = true;
    private float resurect = 0;
    private float delay_hit;
    int life = 0;
    void start()
    {
        PosDepart = skelbody.transform.position;
    }

    // Update is called once per frame
    void Update()
    {   
        if(dead){
            SkelAnimator.SetBool("Dead", true);
            resurect += Time.deltaTime;
            if(resurect % 0.1f > 0.09f)
            direction = new Vector2(Random.Range(-resurect, resurect) * resurect * 10, Random.Range(-resurect, resurect) * resurect * 10);
            if(resurect > 15f){
                dead = false;
                life = 3;
                SkelAnimator.SetBool("Dead", false);
                resurect = 0;
            }
        }else{
            if ((Cible.transform.position - this.transform.position).magnitude < 5f){       
                float horizontal = (Cible.transform.position.x > this.transform.position.x ? 1f : -1f);
                float vertical =  (Cible.transform.position.y > this.transform.position.y ? 1f : -1f);
                direction = new Vector2(horizontal, vertical);
                SkelAnimator.SetBool("Walking", true);
            }else{
                SkelAnimator.SetBool("Walking", false);
            }
            delay_hit += Time.deltaTime;
            if (delay_hit > 1f)
            {
                if ( ((Cible.transform.position - this.transform.position).magnitude < 2.5f) && Cible.GetComponent<Player>().PlayerAnimator.GetCurrentAnimatorStateInfo(0).IsName("Axing"))
                {
                    delay_hit = 0f;
                    Hit();
                }
            }
        }
        
    }
    private void FixedUpdate()
    {
        if (direction.magnitude > 0.05 && (dead || SkelAnimator.GetBool("Walking")))
        {
            direction.Normalize();
            skelbody.AddForce(direction * MoveForce);
            this.GetComponent<SpriteRenderer>().flipX = direction.x < 0;
        }
    }

    void Hit(){
        life += -1;
        if(life > 0){
            SkelAnimator.Play("Hurt");
        }else{
            SkelAnimator.Play("Dying");
            dead = true;
        }
    }
}
