using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum lootenum{
    bois,
    poisson,
    carotte
}
public class Loot : MonoBehaviour
{
    public Rigidbody2D lootbody;
    public GameObject Cible;
    public float MoveForce = 20;
    public lootenum what;
    //private
    private Vector2 direction;
    // Update is called once per frame
    void Update()
    {
        if(Cible.transform.position.x + 0.5f > this.transform.position.x && Cible.transform.position.x < 0.5f + this.transform.position.x && Cible.transform.position.y + 0.5f > this.transform.position.y && Cible.transform.position.y < 0.5f + this.transform.position.y){
            looted();
        }else{        
            float horizontal = (Cible.transform.position.x > this.transform.position.x ? 1f : -1f);
            float vertical =  (Cible.transform.position.y > this.transform.position.y ? 1f : -1f);
            direction = new Vector2(horizontal, vertical);
        }
    }
    private void FixedUpdate()
    {
        direction.Normalize();
        lootbody.AddForce(direction * MoveForce);
    }
    private void looted(){
        GameObject.Destroy(this.gameObject);
    }
}
