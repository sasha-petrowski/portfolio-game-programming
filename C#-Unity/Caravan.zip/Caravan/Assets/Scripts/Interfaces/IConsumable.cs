using System;

public interface IConsumable : IInteractable
{
    public ItemCategoryDef[] Type { get; }
    public abstract bool Consume(Creature consumer, Need need);
}