public interface ICancelTarget
{
    public bool CanCancel { get; }
    public void OrderCancel();
}
