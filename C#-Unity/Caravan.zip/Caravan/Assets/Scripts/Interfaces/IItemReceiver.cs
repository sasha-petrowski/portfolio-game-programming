using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IItemReceiver : IInteractable
{
    public bool CanReceive(ItemDef item);
    public int ReserveReceiving(ItemDef item, int quantity);
    public void CancelReceiving(ItemDef item, int quantity);
    public void Receive(ItemDef item, int quantity);


    public bool CanReceive(UniqueItem item);
    public void ReserveReceiving(UniqueItem item);
    public void CancelReceiving(UniqueItem item);
    public void Receive(UniqueItem item);
}
