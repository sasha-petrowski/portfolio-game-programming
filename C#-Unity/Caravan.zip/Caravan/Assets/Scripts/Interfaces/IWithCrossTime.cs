public interface IWithCrossTime
{
    public float CrossTime { get; }
}