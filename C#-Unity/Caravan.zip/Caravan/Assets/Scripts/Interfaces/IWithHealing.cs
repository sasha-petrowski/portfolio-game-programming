using System;

public interface IWithHealing : IConsumable
{
    public int Healing { get; }
}