using System;

public interface IWithNutrition : IConsumable
{
    public float Nutrition { get; }
}