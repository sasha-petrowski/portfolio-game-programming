using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

public interface ITool
{
    public PlayerToolCategory ToolCategory { get; }
    public bool HasSecondaryEffect { get; }
    public void OnSelect();
    public void OnQuit();


    public void PrimaryDown(Vector3 worldPosition);
    public void PrimaryHold(Vector3 worldPosition);
    public void PrimaryUp(Vector3 worldPosition);


    public void SecondaryDown(Vector3 worldPosition);
    public void SecondaryHold(Vector3 worldPosition);
    public void SecondaryUp(Vector3 worldPosition);


    public void TurnRight(Vector3 worldPosition);
    public void TurnLeft(Vector3 worldPosition);

    public void WorldPreview(Vector3 worldPosition);

    public Sprite GetUIIcon();
    public string GetUITooltip();
    public string GetName();
    public void OnMouseEnterUI(PointerEventData data)
    {
        UIManager.Instance.CursorText.SetText(GetUITooltip());
    }
}
