﻿using UnityEngine;
public interface IWithPosition
{
    public Vector2 GetPosition();
}
