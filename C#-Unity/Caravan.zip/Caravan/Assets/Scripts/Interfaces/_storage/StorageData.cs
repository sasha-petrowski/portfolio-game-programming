public class StorageData
{
    public int Space => FreeQuantity + Incoming + Reserved;
    public int Inside => FreeQuantity + Reserved;

    public int FreeQuantity;
    public int Incoming;
    public int Reserved;
}