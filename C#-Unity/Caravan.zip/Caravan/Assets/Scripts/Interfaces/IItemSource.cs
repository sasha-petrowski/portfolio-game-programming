using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IItemSource : IInteractable
{
    public bool CanSource(ItemDef item);
    public void ReserveSource(ItemDef item, int quantity, out int maxQuantity);
    public void CancelSource(ItemDef item, int quantity);
    public Item Take(Creature taker, ItemDef item, int quantity);

}
