using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SelectionTool : ITool
{
    private Thing _lastSelectedThing;
    private List<Thing> _selectedThings = new List<Thing>();
    private Func<Vector2, bool> _secondaryEffect;


    bool _doubleClicked = false;
    float _timeLeftClicked = 0f;

    public bool HasSecondaryEffect => _secondaryEffect != null;
    public PlayerToolCategory ToolCategory => PlayerToolCategory.Dev;

    public void OnSelect()
    {
    }
    public void OnQuit()
    {
        _secondaryEffect = null;

        UIManager.Instance.SelectionMenu.Close();
    }

    public void PrimaryDown(Vector3 worldPosition)
    {
        _selectedThings = ThingManager.Instance.GetThingAt(worldPosition, _selectedThings);
        Thing newSelectedThing;

        if (_selectedThings.Count > 0)
        {
            newSelectedThing = _selectedThings[_selectedThings.Count - 1];
            if (newSelectedThing == _lastSelectedThing)
            {
                if (Time.time - _timeLeftClicked < InputManager.DOUBLE_CLICK_TIME)
                {
                    if (!_doubleClicked)
                    {
                        DoublePrimaryClick();
                    }
                    else
                    {
                        TriplePrimaryClick();
                    }
                }
                else
                {
                    SimplePrimaryClick();
                }
            }
            else
            {
                _lastSelectedThing = newSelectedThing;
                SimplePrimaryClick();
            }

            _secondaryEffect = _lastSelectedThing.GetSecondaryEffect();

            UIManager.Instance.CloseAllMenu();
            UIManager.Instance.SelectionMenu.SetSelected(_lastSelectedThing);
            UIManager.Instance.SelectionMenu.Open();

            _timeLeftClicked = Time.time;
        }
        else
        {
            _lastSelectedThing = null;
            _secondaryEffect = null;

            UIManager.Instance.SelectionMenu.Close();
        }
    }
    private void SimplePrimaryClick()
    {
        _doubleClicked = false;
    }
    private void DoublePrimaryClick()
    {
        _doubleClicked = true;
    }
    private void TriplePrimaryClick()
    {
        _doubleClicked = false;
        GameCamera.Instance.MoveTo(_lastSelectedThing.transform.position.x, _lastSelectedThing.transform.position.y);
    }

    public void SecondaryDown(Vector3 worldPosition) 
    {
        _secondaryEffect(worldPosition);
    }


    public void PrimaryHold(Vector3 worldPosition)
    {
    }
    public void PrimaryUp(Vector3 worldPosition)
    {
    }
    public void SecondaryHold(Vector3 worldPosition)
    {
    }
    public void SecondaryUp(Vector3 worldPosition)
    {
    }
    public void TurnRight(Vector3 worldPosition)
    {
    }
    public void TurnLeft(Vector3 worldPosition)
    {
    }
    public Sprite GetUIIcon() => null;
    public void WorldPreview(Vector3 worldPosition)
    {
    }
    public string GetUITooltip() => "Selection";

    public string GetName() => "Selection";
}
