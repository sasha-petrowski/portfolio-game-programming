using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BuildingPlayerTool : ITool
{
    public BuildingDef BuildingDef;

    public BuildingPlayerTool(BuildingDef def)
    {
        BuildingDef = def;
    }

    #region ITool
    public PlayerToolCategory ToolCategory => PlayerToolCategory.Build;
    public bool HasSecondaryEffect => false;

    protected static List<GameObject> _previews;
    protected static List<AreaPart> _parents;
    protected static TileCoordinate _clickedCoordinate = new TileCoordinate();
    protected static TileCoordinate _hoverCoordinate = new TileCoordinate();

    protected static BuildingArea _clickedArea;
    protected static int _isFacing;

    private void CreatePreview()
    {
        GameObject go = new GameObject("Building Preview", typeof(SpriteRenderer));
        _previews.Add(go);

        go.GetComponent<SpriteRenderer>().sprite = BuildingDef.Sprite;
    }
    public void OnSelect()
    {
        _previews = new List<GameObject>();
        _parents = new List<AreaPart>();

        _isFacing = 0;

        CreatePreview();
    }
    public void OnQuit()
    {
        for (int i = 0; i < _previews.Count; i++)
        {
            GameObject.Destroy(_previews[i].gameObject);
        }
        _previews.Clear();
        _parents.Clear();

        _clickedArea = null;
        _previews = null;
        _parents = null;
    }

    public void PrimaryDown(Vector3 worldPosition)
    {
        _clickedArea = ThingManager.Instance.GetBuildingAreaAt(worldPosition, _clickedArea);
        if(_clickedArea != null)
        {
            _clickedCoordinate = BuildingDef.Shape.PreferedCoordinate(_clickedArea, worldPosition);

            _hoverCoordinate = _clickedCoordinate;

            UpdateParents(worldPosition);
        }
    }
    public void PrimaryHold(Vector3 worldPosition)
    {
        if (_clickedArea != null)
        {
            TileCoordinate hoverTile = BuildingDef.Shape.PreferedCoordinate(_clickedArea, worldPosition);

            if (_hoverCoordinate != hoverTile)
            {
                _hoverCoordinate = hoverTile;
                UpdateParents(worldPosition);
            }
        }
    }
    public void PrimaryUp(Vector3 worldPosition)
    {
        if (_clickedArea != null)
        {
            // try to place blueprints
            for (int i = 0; i < _previews.Count & i < _parents.Count; i++)
            {
                BuildingDef.TryPlaceBlueprint(_parents[i], Caravan.s_PlayerCaravan, _isFacing);
            }

            //destroy old previews
            for (int i = 0; i < _previews.Count; i++)
            {
                GameObject.Destroy(_previews[i].gameObject);
            }

            _previews.Clear();
            _clickedArea = null;
            CreatePreview();
        }
    }

    public void TurnRight(Vector3 worldPosition)
    {
        for(int i = 0; i < _previews.Count; i++)
        {
            BuildingDef.Shape.Rotate(ref _isFacing, 3);
        }
        UpdateParents(worldPosition);
    }
    public void TurnLeft(Vector3 worldPosition)
    {
        for (int i = 0; i < _previews.Count; i++)
        {
            BuildingDef.Shape.Rotate(ref _isFacing, 1);
        }
        UpdateParents(worldPosition);
    }

    public Sprite GetUIIcon() => BuildingDef.Sprite;

    public void WorldPreview(Vector3 worldPosition)
    {
        for (int i = _parents.Count > 0 ? _parents.Count : 1; i < _previews.Count; i++)
        {
            _previews[i].gameObject.SetActive(false);
        }
        if (_clickedArea != null)
        {
            //Debug.Log("there is an area");
            for(int i = 0; i < _parents.Count; i++)
            {
                //Debug.Log("there are _parents");
                _previews[i].gameObject.SetActive(true);
                _previews[i].transform.SetParent(_parents[i].Area.transform);
                BuildingDef.Shape.SnapToPart(_isFacing, _previews[i].transform, _parents[i]);
            }
        }
        else
        {
            Area currentArea = ThingManager.Instance.GetBuildingAreaAt(worldPosition);
            if (currentArea == null) currentArea = World.s_Instance.GetChunkAt(worldPosition);

            if (currentArea != null)
            {
                TileCoordinate coordinate = BuildingDef.Shape.PreferedCoordinate(currentArea, worldPosition);

                AreaPart part = currentArea.GetPart(coordinate.x, coordinate.y, (int)coordinate.direction);

                if (part == null && coordinate.direction != TilePosition.Center) part = currentArea.GetPart(coordinate.x, coordinate.y, (int)TilePosition.Center);
                if (part != null) BuildingDef.Shape.SnapToPart(_isFacing, _previews[0].transform, part);


                _previews[0].GetComponent<SpriteRenderer>().color = part.Area.IsBuildingArea() && BuildingDef.CanInstantiate(part, Caravan.s_PlayerCaravan, _isFacing) ? new Color(1, 1, 1, 0.75f) : new Color(1, 0, 0, 0.75f);
            }
            else
            {
                _previews[0].GetComponent<SpriteRenderer>().color = new Color(1, 0, 0, 0.75f);
                _previews[0].transform.parent = null;
                _previews[0].transform.position = BuildingDef.Shape.PartOffset(_isFacing, null) + worldPosition;
            }
        }
    }
    private void UpdateParents(Vector3 worldPosition)
    {
        if(_clickedArea != null)
        {
            Vector2 local = _clickedArea.WorldToLocal(worldPosition) - new Vector2(0.5f + _clickedCoordinate.x, 0.5f + _clickedCoordinate.y);
            if(InputManager.SpecialKey)
            {
                _parents = BuildingDef.Shape.SpecialParts(_isFacing, _clickedArea, _clickedCoordinate.Index, local);
            }
            else
            {
                _parents = BuildingDef.Shape.PreferedParts(_isFacing, _clickedArea, _clickedCoordinate.Index, local);
            }
            for (int i = _previews.Count; i < _parents.Count; i++)
            {
                CreatePreview();
                BuildingDef.Shape.SnapToPart(_isFacing, _previews[i].transform, _parents[i]);
            }
        }
        /*
        StringBuilder sb = new();
        sb.Append("UpdateParents");
        foreach (var part in _parents)
        {
            sb.Append('\n');

            sb.Append(part?.ToString());
        }

        Debug.Log(sb.ToString());
        */
    }

    public void SecondaryDown(Vector3 worldPosition)
    {
    }
    public void SecondaryHold(Vector3 worldPosition)
    {
    }
    public void SecondaryUp(Vector3 worldPosition)
    {
    }

    public string GetUITooltip() => $"{BuildingDef.name}\n{BuildingDef.Materials.RequiredToString()}";

    public string GetName() => BuildingDef.name;
    #endregion
}
