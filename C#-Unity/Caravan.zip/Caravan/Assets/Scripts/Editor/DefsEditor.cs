using UnityEditor.PackageManager.UI;
using UnityEditor;
using UnityEngine;
using System.Security.Cryptography;

[CustomEditor(typeof(Def), true)]
public class DefsEditor : Editor
{
    public override Texture2D RenderStaticPreview(string assetPath, Object[] subAssets, int width, int height)
    {
        
        Def def = (Def)target;

        if(def != null && def.Sprite != null) 
        {
            return AssetPreview.GetAssetPreview(def.Sprite);
        }
        else return AssetPreview.GetAssetPreview(null);
        
    }

}