using System;
using System.Collections.Generic;
using System.Text;
using Unity.Jobs;
using UnityEngine;

[Serializable]
public class RequiredItemQuantity : RequiredItems
{
    public ItemQuantity[] Required = new ItemQuantity[0];

    private FetchJob _job;

    public override string RequiredToString()
    {
        StringBuilder sb = new StringBuilder();

        foreach (ItemQuantity item in Required)
        {
            sb.AppendLine($" - {item.Quantity}x {item.Name}");
        }

        return sb.ToString();
    }

    public override bool TryFindSource(Creature creature, FetchJob job)
    {
        job.Received = true;
        for (int i = 0; i < Required.Length; i++)
        {
            ItemQuantity required = Required[i];

            //if (Item.StoredQuantity[required.Item] < 0 | Item.WorldQuantity[required.Item] < 0) throw new Exception("Negative values of stored items");

            int fetchedQuantity = 0;
            foreach (ItemQuantity fetched in job.Fetched)
            {
                if (fetched.Item == required.Item)
                {
                    fetchedQuantity = fetched.Quantity;
                    break;
                }
            }
            if (required.Quantity > fetchedQuantity)
            {
                job.Received = false;

                if (Item.StoredQuantity[required.Item] + Item.WorldQuantity[required.Item] > 0)
                {
                    job.TargetDef = required.Item;
                    job.TargetQuantity = Mathf.Min(required.Quantity - fetchedQuantity, required.Item.StackSize);

                    _job = job;
                    return FindPathToSource(creature);
                }
            }
        }
        return false;
    }

    protected bool FindPathToSource(Creature worker)
    {
        return WorldUtility.SpiralChunkSearch(worker, FindItemInChunk, worker);
    }
    private bool FindItemInChunk(Vector2Int chunkIndex, Creature worker)
    {
        if (World.s_Instance.ChunkAreas.TryGetValue(chunkIndex, out ChunkArea area))
        {
            if (FindItemInArea(area, worker)) return true;
            foreach (GiantCreature ge in area.GiantEntities)
            {
                if (FindItemInArea(ge.BuildingArea, worker)) return true;
            }
        }
        return false;
    }
    private bool FindItemInArea(Area area, Creature worker)
    {
        foreach (IStorage storage in area.Storages)
        {
            if (EvaluateSource(storage, worker)) return true;
        }
        foreach (Item item in area.Items)
        {
            if (EvaluateSource(item, worker)) return true;
        }
        return false;
    }
    private bool EvaluateSource(IItemSource source, Creature worker)
    {
        if (_job.FetchTo == null | source == null) return false;

        if (source.CanSource(_job.TargetDef) && _job.SourcePath.FindPath(source, worker) && _job.FetchPath.FindPath(_job.FetchTo, _job.SourcePath.LastTile, worker))
        {
            source.ReserveSource(_job.TargetDef, _job.TargetQuantity, out _job.TargetQuantity);
            _job.Source = source;
            return true;
        }
        return false;
    }

    public override float GetCompletion(List<ItemQuantity> fetched)
    {
        int fetch = 0;
        int total = 0;


        for (int i = 0; i < Required.Length; i++)
        {
            ItemQuantity required = Required[i];

            total += required.Quantity;
            foreach (ItemQuantity item in fetched)
            {
                if (item.Item == required.Item)
                {
                    fetch += item.Quantity;
                    break;
                }
            }
        }

        return fetch / (float)total;
    }
}