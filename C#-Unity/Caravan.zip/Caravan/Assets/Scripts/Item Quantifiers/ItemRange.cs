using System;

[Serializable]
public class ItemRange
{
    public string Name => Item?.name;
    public ItemDef Item;
    public int Min;
    public int Max;
}