using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class RequiredItemNutrition : RequiredItems
{
    public ItemCategoryDef Category;
    public int RequiredNutrition;


    private int _fetchedNutrition;
    private FetchJob _job;

    public override string RequiredToString()
    {
        return $" - {RequiredNutrition}x {Category.name}";
    }

    public override bool TryFindSource(Creature creature, FetchJob job)
    {
        job.Received = true;

        _fetchedNutrition = 0;

        foreach(ItemQuantity fetched in job.Fetched)
        {
            FoodItemDef nutrition = fetched.Item as FoodItemDef;

            _fetchedNutrition += nutrition.Nutrition * fetched.Quantity;


        }

        if (RequiredNutrition > _fetchedNutrition)
        {
            job.Received = false;

            _job = job;
            return TryFindNutrition(creature);
        }
        return false;
    }


    #region Try Find Nutrition
    private bool TryFindNutrition(Creature worker)
    {        
        // Verify food exists on map
        if (Item.WorldCategory[Category] + Item.StoredCategory[Category] <= 0) return false;

        if (worker.Parent.Area.FlooredNutrition > 0)
        {
            foreach (Item item in worker.Parent.Area.Items)
            {
                if (EvaluateItem(item, worker)) return true;
            }
        }
        if (worker.Parent.Area.StoredNutrition > 0)
        {
            foreach (IStorage storage in worker.Parent.Area.Storages)
            {
                if (EvaluateStorage(storage, worker)) return true;
            }
        }

        return WorldUtility.SpiralChunkSearch(worker, FindFoodInArea, worker);
    }
    private bool FindFoodInArea(Vector2Int chunkIndex, Creature worker)
    {
        if (World.s_Instance.ChunkAreas.TryGetValue(chunkIndex, out ChunkArea area))
        {
            if (FindFoodInArea(area, worker)) return true;

            foreach (GiantCreature ge in area.GiantEntities)
            {
                if (ge.BuildingArea != null && FindFoodInArea(ge.BuildingArea, worker)) return true;
            }
        }
        return false;
    }
    private bool FindFoodInArea(Area area, Creature worker)
    {
        if(area == worker.Parent.Area) return false;

        if (area.FlooredNutrition > 0)
        {
            foreach (Item item in area.Items)
            {
                if (EvaluateItem(item, worker)) return true;
            }
        }
        if (area.StoredNutrition > 0)
        {
            foreach (IStorage storage in area.Storages)
            {
                if (EvaluateStorage(storage, worker)) return true;
            }
        }

        return false;
    }
    private bool EvaluateItem(Item item, Creature worker)
    {
        if (!(item is IWithNutrition nutrition)) return false;

        bool contains = false;
        foreach (ItemCategoryDef cat in item.ItemDef.Categories)
        {
            if (cat == Category)
            {
                contains = true;
                break;
            }
        }

        if (contains && item.CanSource(item.ItemDef) && _job.SourcePath.FindPath(item, worker) && _job.FetchPath.FindPath(_job.FetchTo, _job.SourcePath.LastTile, worker))
        {
            int needed = Mathf.Max(Mathf.RoundToInt((RequiredNutrition - _fetchedNutrition) / nutrition.Nutrition), 1);
            item.ReserveSource(item.ItemDef, needed, out _job.TargetQuantity);

            _job.Source = item;
            _job.TargetDef = item.ItemDef;

            return _job.TargetQuantity > 0;
        }

        return false;
    }
    private bool EvaluateStorage(IStorage store, Creature worker)
    {
        foreach (KeyValuePair<ItemDef, StorageData> pair in store.StorageData)
        {
            if (!(pair.Key is FoodItemDef food)) continue;

            bool contains = false;
            foreach (ItemCategoryDef cat in food.Categories)
            {
                if (cat == Category)
                {
                    contains = true;
                    break;
                }
            }
            if (contains && store.CanSource(food) && _job.SourcePath.FindPath(store, worker) && _job.FetchPath.FindPath(_job.FetchTo, _job.SourcePath.LastTile, worker))
            {
                int needed = Mathf.Max(Mathf.RoundToInt((RequiredNutrition - _fetchedNutrition) / food.Nutrition), 1);
                store.ReserveSource(food, needed, out _job.TargetQuantity);

                _job.Source = store;
                _job.TargetDef = food;
                return true;
            }
        }
        return false;
    }
    #endregion

    public override float GetCompletion(List<ItemQuantity> fetched)
    {
        int fetchedNutrition = 0;

        foreach (ItemQuantity item in fetched)
        {
            FoodItemDef nutrition = item.Item as FoodItemDef;

            fetchedNutrition += nutrition.Nutrition * item.Quantity;
        }

        return fetchedNutrition / (float)RequiredNutrition;
    }
}