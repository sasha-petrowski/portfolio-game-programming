using System;
using System.Collections.Generic;
using System.Text;

public abstract class RequiredItems
{
    public abstract string RequiredToString();
    public abstract bool TryFindSource(Creature creature, FetchJob job);

    public abstract float GetCompletion(List<ItemQuantity> fetched);
}