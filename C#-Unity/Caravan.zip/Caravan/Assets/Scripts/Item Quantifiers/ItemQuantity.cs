using System;

[Serializable]
public class ItemQuantity
{
    public string Name => Item?.name;
    public ItemDef Item;
    public int Quantity;

    public ItemQuantity(ItemDef item, int quantity)
    {
        Item = item;
        Quantity = quantity;
    }
}