﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public static class CoroutineUtility
{
    public static IEnumerator LoopAfterFrames(int frames, Action action)
    {
        while (true)
        {
            Debug.Log("loopAfterFrames");
            for (int i = 0; i < frames; i++)
            {
                yield return null;
            }
            action();
        }
    }
    public static IEnumerator DoAfterFrames(int frames, Action action)
    {
        for (int i = 0; i < frames; i++)
        {
            yield return null;
        }
        action();
    }
}