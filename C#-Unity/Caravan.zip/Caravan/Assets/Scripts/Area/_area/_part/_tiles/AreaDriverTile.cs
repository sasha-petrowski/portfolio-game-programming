using UnityEngine;

public class AreaDriverTile : AreaTile
{
    public AreaDriverTile(Area area, int x, int y) : base(area, x, y)
    {
    }

    public bool CanBeUsed()
    {
        return Room != null & (!TryGetWall((int)TilePosition.Top, out AreaWall wall) || wall.CrossTime() >= 0);
    }
}