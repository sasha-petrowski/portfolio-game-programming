using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class AreaPart
{
    public Entity Entity;
    public Area Area => _area;

    protected Area _area;

    public abstract AreaTile GetTile(int direction);
    public abstract AreaWall GetWall(int direction);
    public abstract float CrossTime();

    public bool TryGetTile(int direction, out AreaTile tile)
    {
        tile = GetTile(direction);
        return tile != null;
    }
    public bool TryGetWall(int direction, out AreaWall wall)
    {
        wall = GetWall(direction);
        return wall != null;
    }


    public bool IsEmpty()
    {
        return Entity == null;
    }

    public abstract Vector3 WorldPosition();
    public abstract Vector3 WorldPosition(Vector3 offset);
    public abstract void UpdatePart();

    public abstract List<AreaTile> GetInteractionSpots();
    public abstract AreaTile GetFirstSpot();
}
