﻿using System;
using UnityEngine;

public struct TileCoordinate
{
    public Vector2Int Index => new Vector2Int(x, y);
    public int x;
    public int y;
    public TilePosition direction;

    public static bool operator ==(TileCoordinate lhs, TileCoordinate rhs)
    {
        return lhs.x == rhs.x & lhs.y == rhs.y & lhs.direction == rhs.direction;
    }
    public static bool operator !=(TileCoordinate lhs, TileCoordinate rhs)
    {
        return lhs.x != rhs.x | lhs.y != rhs.y | lhs.direction != rhs.direction;
    }

    public TileCoordinate(Vector2Int index, TilePosition direction)
    {
        this.x = index.x;
        this.y = index.y;
        this.direction = direction;
    }
    public TileCoordinate(int x, int y, TilePosition direction)
    {
        this.x = x;
        this.y = y;
        this.direction = direction;
    }
    public override bool Equals(object obj)
    {
        return obj is TileCoordinate coordinate &&
               x == coordinate.x &&
               y == coordinate.y &&
               direction == coordinate.direction;
    }
    public override int GetHashCode()
    {
        return HashCode.Combine(x, y, direction);
    }
}