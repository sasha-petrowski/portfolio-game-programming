using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AreaWall : AreaPart
{
    public int x;
    public int y;
    public Vector2Int Index { get => new Vector2Int(x, y); }
    private int _side;
    public int Side => _side;


    public AreaWall(Area area, int side, int x, int y)
    {
        _area = area;
        this.x = x;
        this.y = y;
        _side = side;
    }

    public override string ToString()
    {
        return $"Wall : I.{Index}, S.{_side}.{(_side == 0 ? "--" : "|")}";
    }

    public override Vector3 WorldPosition()
    {
        return Area.LocalToWorld(new Vector3(x - (TPE.SideX(_side) * 0.5f), y - (TPE.SideY(_side) * 0.5f), 0));
    }
    public override Vector3 WorldPosition(Vector3 offset)
    {
        return Area.LocalToWorld(new Vector3(x - (TPE.SideX(_side) * 0.5f) + offset.x, y - (TPE.SideY(_side) * 0.5f) + offset.y, offset.z));
    }
    public override AreaWall GetWall(int direction)
    {
        int side = direction % 2;

        if (side == _side)
        {
            return null;
        }

        int wallX = x + TPE.WallX[direction];
        int wallY = y + TPE.WallY[direction];

        if (wallX > Area.Width + TPE.SideX(side) | wallY > Area.Height + TPE.SideY(side))
        {
            return null;
        }
        return Area.Walls[side][wallX, wallY];
    }
    public override AreaTile GetTile(int direction)
    {
        int side = direction % 2;

        if (side != _side)
        {
            return null;
        }

        int tileX = x - TPE.SideX(side) + TPE.WallX[direction];
        int tileY = y - TPE.SideY(side) + TPE.WallY[direction];

        if (tileX < 0 | tileX >= Area.Width | tileY < 0 | tileY >= Area.Height)
        {
            return null;
        }
        return Area.Tiles[tileX, tileY];
    }

    public override void UpdatePart()
    {
        // transmit update to adjacent tiles
        GetTile(0 + _side)?.UpdatePart();
        GetTile(2 + _side)?.UpdatePart();
    }
    public override float CrossTime()
    {
        return Entity?.Def is IWithCrossTime crossTime ? crossTime.CrossTime : 0f;
    }

    public override List<AreaTile> GetInteractionSpots()
    {
        AreaTile a = GetTile(0 + _side);
        AreaTile b = GetTile(2 + _side);

        if (a == null) return new List<AreaTile> { b };
        else if (b == null) return new List<AreaTile> { a };
        else return new List<AreaTile> { a, b };
    }
    public override AreaTile GetFirstSpot()
    {
        AreaTile a = GetTile(0 + _side);
        if (a != null) return a;

        AreaTile b = GetTile(2 + _side);
        return b;
    }
}
