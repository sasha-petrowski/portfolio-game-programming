using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class AreaOutTile : AreaTile
{
    private int[] _directions;
    private AreaTile[] _outTiles;
    public int[] Directions => _directions;
    public AreaTile[] OutTiles => _outTiles;

    public AreaOutTile(Area area, int x, int y, int[] directions) : base(area, x, y)
    {
        _directions = directions;
        _outTiles = new AreaTile[8];
        UpdateOut(false);
    }

    public void UpdateOut(bool callListeners = true)
    {
        bool changed = false;
        bool inpassable = CrossTime() < 0;
        foreach(int direction in _directions)
        {
            AreaTile previous = _outTiles[direction];
            previous?.RemoveLink(this);

            if(inpassable)
            {
                _outTiles[direction] = null;
                changed = changed || previous != null;
                continue;
            }

            if(direction < 4)
            {
                // test the wall on this side
                if (TryGetWall(direction, out AreaWall wall) && wall.CrossTime() < 0)
                {
                    _outTiles[direction] = null;
                    changed = changed || previous != null;
                    continue;
                }
            }
            else if (
                (TryGetWall(direction % 4, out AreaWall aWall)       && aWall.CrossTime() != 0)
                |
                (TryGetWall((direction + 1) % 4, out AreaWall bWall) && bWall.CrossTime() != 0)
                |
                (TryGetTile(direction % 4, out AreaTile cTile)       && cTile.TryGetWall((direction + 1) % 4, out AreaWall cWall) && cWall.CrossTime() != 0)
                |
                (TryGetTile((direction + 1) % 4, out AreaTile dTile) && dTile.TryGetWall(direction % 4, out AreaWall dWall)       && dWall.CrossTime() != 0)
               )
            {
                _outTiles[direction] = null;
                changed = changed || previous != null;
                continue;
            }

            //get the outTile
            AreaTile tile = ChunkArea.GetTile(Area.LocalToWorld(new Vector2(x + TPE.TileX[direction], y + TPE.TileY[direction])));
            _outTiles[direction] = tile;

            if(tile != null && tile.CrossTime() < 0)
            {
                _outTiles[direction] = null;
                changed = changed || previous != null;
                continue;
            }

            if (tile != null && !Area.IsBuildingArea())
            {
                int inverse = TPE.Invert[direction];

                if (direction < 4)
                {
                    // test the wall on the other side
                    if (tile.TryGetWall(inverse, out AreaWall outWall) && outWall.CrossTime() < 0)
                    {
                        _outTiles[direction] = null;
                        changed = changed || previous != null;
                        continue;
                    }
                }
                else
                {
                    int diagA = TPE.Invert[direction % 4];
                    int diagB = TPE.Invert[(direction + 1) % 4];
                    if (
                        (TryGetWall(diagA, out AreaWall aWall) && aWall.CrossTime() != 0)
                        |
                        (TryGetWall(diagB, out AreaWall bWall) && bWall.CrossTime() != 0)
                        |
                        (TryGetTile(diagA, out AreaTile cTile) && cTile.TryGetWall(diagB, out AreaWall cWall) && cWall.CrossTime() != 0)
                        |
                        (TryGetTile(diagB, out AreaTile dTile) && dTile.TryGetWall(diagA, out AreaWall dWall) && dWall.CrossTime() != 0)
                       )
                    {
                        _outTiles[direction] = null;
                        changed = changed || previous != null;
                        continue;
                    }
                }

                if (tile is AreaOutTile outTile)
                {
                    outTile._outTiles[inverse] = this;
                    Room?.AddLink(outTile.Room);
                    changed = changed || previous != tile;
                    continue;
                }
            }
            // else
            changed = changed || previous != tile;
            _outTiles[direction]?.AddLink(this);
        }

        if(changed & callListeners) OnUpdate?.Invoke(this);
    }
    public override bool CanGoTo(AreaTile other)
    {
        if (other == null) return false;

        if (_outTiles.Contains(other)) return true;

        return base.CanGoTo(other);
    }
    public override AreaTile GetTile(int direction)
    {
        if (_outTiles[direction] != null) return _outTiles[direction];

        return base.GetTile(direction);
    }
    public override AreaWall GetWall(AreaTile tile)
    {
        for (int direction = 0; direction < 4; direction++)
        {
            if (_outTiles[direction] == tile)
                return GetWall(direction);
        }
        return base.GetWall(tile);
    }

    public override void UpdatePart()
    {
        UpdateOut(false);

        base.UpdatePart();
    }

    public override void LinkRoom()
    {
        base.LinkRoom();

        foreach (AreaTile other in _outTiles)
        {
            if (other != null) other.Room?.AddLink(Room);
        }
    }
}