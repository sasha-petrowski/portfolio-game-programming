using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class AreaTile : AreaPart
{
    public float PathTime;
    public float PathWeight { get; set; }

    public int x;
    public int y;
    public Vector2Int Index { get => new Vector2Int(x, y);}

    public Room Room;
    public TextMeshPro DebugText;

    protected List<AreaTile> _links;
    public List<AreaTile> Links => _links;

    public Action<AreaTile> OnUpdate;

    public AreaTile(Area area, int x, int y)
    {
        _area = area;
        this.x = x;
        this.y = y;
        /*
        // Tile Indexes
        if(Area.IsBuildingArea())
        {
            DebugText = new GameObject($"{x}-{y}").AddComponent<TextMeshPro>();
            DebugText.transform.SetParent(area.DebugObject.transform);
            DebugText.transform.position = area.LocalToWorld(new Vector2(x, y));
            DebugText.rectTransform.sizeDelta = new Vector2(1, 1);
            DebugText.text = $"{x},{y}";
            DebugText.fontSize = 4;
            DebugText.alignment = TextAlignmentOptions.Center;
        }
        */
    }
    public override string ToString()
    {
        return $"{(Area.IsBuildingArea() ? "Build" : "Chunk")} : I.{Index}";
    }
    public override Vector3 WorldPosition()
    {
        return Area.LocalToWorld(new Vector3(x, y, 0));
    }
    public override Vector3 WorldPosition(Vector3 offset)
    {
        return Area.LocalToWorld(new Vector3(x + offset.x, y + offset.y, offset.z));
    }
    public override AreaWall GetWall(int direction)
    {
        if (_area.Walls == null) return null;

        int side = direction % 2;

        int wallX = x + TPE.WallX[direction];
        int wallY = y + TPE.WallY[direction];

        if (wallX > Area.Width + TPE.SideX(side) | wallY > Area.Height + TPE.SideY(side))
        {
            return null;
        }
        return Area.Walls[side][wallX, wallY];
    }
    public override AreaTile GetTile(int direction)
    {
        int tileX = x + TPE.TileX[direction];
        int tileY = y + TPE.TileY[direction];

        if (tileX < 0 | tileX >= Area.Width | tileY < 0 | tileY >= Area.Height)
        {
            return null;
        }
        return Area.Tiles[tileX, tileY];
    }
    public virtual AreaWall GetWall(AreaTile tile)
    {
        if (tile.Area != Area) return null;
        int relativeX = tile.x - x;
        int relativeY = tile.y - y;

        Vector2Int relative = new Vector2Int(relativeX, relativeY);
        for(int i = 0; i < 4;  i++)
        {
            if(relative == TPE.Direction[i])
            {
                return GetWall(i);
            }
        }
        return null;
    }
    public bool TryGetLinks(out List<AreaTile> links) 
    {
        links = _links;
        return _links != null;
    }
    public void RemoveLink(AreaTile tile)
    {
        if (_links == null) return;
            
        if(_links.Remove(tile)) Room?.RemoveLink(tile.Room);

        if (_links.Count == 0) _links = null;
    }
    public void AddLink(AreaTile tile)
    {
        if (_links == null) _links = new List<AreaTile>();

        _links.Add(tile);

        Room?.AddLink(tile.Room);
    }
    public override float CrossTime()
    {
        return Entity?.Def is IWithCrossTime crossTime ? crossTime.CrossTime : 1f;
    }
    public virtual bool CanGoTo(AreaTile other)
    {
        if(other == null) return false;

        if (CrossTime() < 0 | other.CrossTime() < 0) return false;

        if (_links != null && _links.Contains(other)) return true;

        if (other.Area != Area) return false;

        int relativeX = other.x - x;
        int relativeY = other.y - y;

        Vector2Int relative = new Vector2Int(relativeX, relativeY);
        for (int direction = 0; direction < 4; direction++)
        {
            if (relative == TPE.Direction[direction])
            {
                return !TryGetWall(direction, out AreaWall wall) || !(wall.CrossTime() < 0);
            }
        }
        for (int direction = 4; direction < 8; direction++)
        {
            if (relative == TPE.Direction[direction])
            {
                AreaWall wall;

                return
                    (!other.TryGetWall(direction % 4, out wall) || !(wall.CrossTime() < 0))
                    &
                    (!other.TryGetWall((direction + 1) % 4, out wall) || !(wall.CrossTime() < 0))
                    &
                    (!other.TryGetWall(TPE.Invert[direction % 4], out wall) || !(wall.CrossTime() < 0))
                    &
                    (!other.TryGetWall(TPE.Invert[(direction + 1) % 4], out wall) || !(wall.CrossTime() < 0));
            }
        }
        return false;
    }

    public virtual void LinkRoom()
    {
        if (_links != null)
        {
            foreach (AreaTile other in _links)
            {
                other.Room?.AddLink(Room);
            }
        }
    }

    

    public IEnumerable<AreaTile> CanGoTo()
    {
        for (int direction = 0; direction < 4; direction++)
        {
            if (TryGetTile(direction, out AreaTile tile) && (!TryGetWall(direction, out AreaWall wall) || !(wall.CrossTime() < 0)))
            {
                yield return tile;
            }
        }
        for (int direction = 4; direction < 8; direction++)
        {
            AreaWall wall;
            if (TryGetTile(direction, out AreaTile tile)
                &&
                    ((!TryGetWall(direction % 4, out wall) || !(wall.CrossTime() < 0))
                    &
                    (!TryGetWall((direction + 1) % 4, out wall) || !(wall.CrossTime() < 0))
                    &
                    (!tile.TryGetWall(TPE.Invert[direction % 4], out wall) || !(wall.CrossTime() < 0))
                    &
                    (!tile.TryGetWall(TPE.Invert[(direction + 1) % 4], out wall) || !(wall.CrossTime() < 0))))
            {
                yield return tile;
            }
        }
        if (_links != null)
        {
            foreach (AreaTile tile in _links)
            {
                yield return tile;
            }
        }
    }
    public override void UpdatePart()
    {
        OnUpdate?.Invoke(this);
    }




    public static AreaTile GetEmptyTile(AreaTile from)
    {
        if (from == null) throw new ArgumentNullException("From cannot be null");

        HashSet<AreaTile> visited = new HashSet<AreaTile>();
        LinkedList<AreaTile> toVisit = new LinkedList<AreaTile>();

        toVisit.AddFirst(from);
        visited.Add(from);

        while (toVisit.First != null)
        {
            AreaTile current = toVisit.First.Value;
            toVisit.RemoveFirst();

            if (current.IsEmpty()) return current;

            for (int i = 0; i < 4; i++)
            {
                if (current.TryGetTile(i, out AreaTile side) && visited.Add(side) && (!current.TryGetWall(i, out AreaWall wall) || wall.CrossTime() >= 0))
                {
                    toVisit.AddLast(side);
                }
            }
            if (current._links != null)
            {
                foreach (AreaTile link in current._links)
                {
                    if (visited.Add(link))
                    {
                        toVisit.AddLast(link);
                    }
                }
            }
        }

        Debug.LogWarning("Couldn't find empty tile");
        return null;
    }
    public static AreaTile GetWalkable(AreaTile from, Creature creature)
    {
        if (from == null) throw new ArgumentNullException("From cannot be null");

        HashSet<AreaTile> visited = new HashSet<AreaTile>();
        LinkedList<AreaTile> toVisit = new LinkedList<AreaTile>();

        toVisit.AddFirst(from);
        visited.Add(from);

        while (toVisit.First != null) 
        {
            AreaTile current = toVisit.First.Value;
            toVisit.RemoveFirst();

            if (current.CrossTime() >= 0) return current;

            for (int i = 0; i < 4; i++)
            {
                if (current.TryGetTile(i, out AreaTile side) && visited.Add(side) && (!current.TryGetWall(i, out AreaWall wall) || wall.CrossTime() >= 0))
                {
                    toVisit.AddLast(side);
                }
            }
            if(current._links != null)
            {
                foreach (AreaTile link in current._links)
                {
                    if (visited.Add(link))
                    {
                        toVisit.AddLast(link);
                    }
                }
            }
        }

        Debug.LogWarning("Couldn't find walkable tile");
        return null;
    }

    public override List<AreaTile> GetInteractionSpots()
    {
        return new List<AreaTile> { this };
    }
    public override AreaTile GetFirstSpot()
    {
        return this;
    }
}
