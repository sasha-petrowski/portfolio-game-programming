using UnityEngine;
public enum TilePosition : int
{
    Top = 0,
    Left = 1,
    Bottom = 2,
    Right = 3,
    TopLeft = 4,
    BottomLeft = 5,
    BottomRight = 6,
    TopRight = 7,
    Center = 8
}

public static class TPE
{
    public static readonly int Top         = (int)TilePosition.Top;
    public static readonly int Left        = (int)TilePosition.Left;
    public static readonly int Bottom      = (int)TilePosition.Bottom;
    public static readonly int Right       = (int)TilePosition.Right;
    public static readonly int TopLeft     = (int)TilePosition.TopLeft;
    public static readonly int BottomLeft  = (int)TilePosition.BottomLeft;
    public static readonly int BottomRight = (int)TilePosition.BottomRight;
    public static readonly int TopRight    = (int)TilePosition.TopRight;
    public static readonly int Center      = (int)TilePosition.Center;

    public static int[] Invert =
    {
        (int)TilePosition.Bottom,
        (int)TilePosition.Right,
        (int)TilePosition.Top,
        (int)TilePosition.Left,
        (int)TilePosition.BottomRight,
        (int)TilePosition.TopRight,
        (int)TilePosition.TopLeft,
        (int)TilePosition.BottomLeft,
        (int)TilePosition.Center
    };

    public static readonly Vector2Int[] Direction =
    {
        new Vector2Int( 0,  1), // Top
        new Vector2Int(-1,  0), // Left
        new Vector2Int( 0, -1), // Bottom
        new Vector2Int( 1,  0), // Right
        new Vector2Int(-1,  1), // Top Left
        new Vector2Int(-1, -1), // Bottom Left
        new Vector2Int( 1, -1), // Bottom Right
        new Vector2Int( 1,  1)  // Top Right
    };
    public static readonly int[] TileX =
    {
        0, // Top
       -1, // Left
        0, // Bottom
        1, // Right
       -1, // Top Left
       -1, // Bottom Left
        1, // Bottom Right
        1  // Top Right
    };
    public static readonly int[] TileY =
    {
        1, // Top
        0, // Left
       -1, // Bottom
        0, // Right
        1, // Top Left
       -1, // Bottom Left
       -1, // Bottom Right
        1  // Top Right
    };
    public static readonly int[] WallX =
    {
        0, // Top
        0, // Left
        0, // Bottom
        1, // Right
        0, // Top
        0, // Left
        0, // Bottom
        1, // Right
    };
    public static readonly int[] WallY =
    {
        1, // Top
        0, // Left
        0, // Bottom
        0, // Right
        1, // Top
        0, // Left
        0, // Bottom
        0, // Right
    };

    public static int SideX(int side)
    {
        return 1 * side;
    }
    public static int SideY(int side)
    {
        return 1 - side;
    }
}