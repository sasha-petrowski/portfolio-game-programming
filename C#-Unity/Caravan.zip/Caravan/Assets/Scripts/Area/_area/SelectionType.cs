﻿using System;
using System.Collections.Generic;
using UnityEngine;

public enum SelectionType
{
    Single,
    Line,
    Border,
    Surface
}

public static class STE
{
    public static List<AreaPart> Select(SelectionType type, Area area, Vector2Int start, Vector2 offset, bool wall, int stepX = 1, int stepY = 1)
    {
        switch (type)
        {
            default:
            case SelectionType.Single:
                return Single(area, start, offset, wall);

            case SelectionType.Line:
                return Line(area, start, offset, wall, stepX, stepY);

            case SelectionType.Border:
                return Border(area, start, offset, wall, stepX, stepY);

            case SelectionType.Surface:
                return Surface(area, start, offset, wall, stepX, stepY);
        }
    }
    private static List<AreaPart> Single(Area area, Vector2Int start, Vector2 offset, bool wall)
    {
        if(wall)
        {
            //tests to know the most favored direction
            if (offset.x > offset.y)
            {
                if (offset.x > Mathf.Abs(offset.y))
                    return new List<AreaPart> { area.Tiles[start.x, start.y].GetWall((int)TilePosition.Right) };
                if (offset.y > 0)
                    return new List<AreaPart> { area.Tiles[start.x, start.y].GetWall((int)TilePosition.Top) };
                else
                    return new List<AreaPart> { area.Tiles[start.x, start.y].GetWall((int)TilePosition.Bottom) };
            }
            else
            {
                if (offset.y > Mathf.Abs(offset.x))
                    return new List<AreaPart> { area.Tiles[start.x, start.y].GetWall((int)TilePosition.Top) };
                if (offset.x > 0)
                    return new List<AreaPart> { area.Tiles[start.x, start.y].GetWall((int)TilePosition.Right) };
                else
                    return new List<AreaPart> { area.Tiles[start.x, start.y].GetWall((int)TilePosition.Left) };
            }
        }
        else
        {
            return new List<AreaPart> { area.Tiles[start.x, start.y] };
        }
    }
    private static List<AreaPart> Line(Area area, Vector2Int start, Vector2 offset, bool wall, int stepX, int stepY)
    {

        #region Determine Line direction
        bool horizontal = false;
        if (offset.x > offset.y)
        {
            if (offset.x > Mathf.Abs(offset.y))
                horizontal = true;
        }
        else
        {
            if (offset.y < Mathf.Abs(offset.x))
                horizontal = true;
        }
        #endregion

        #region Determine bounds
        Vector2Int end = new Vector2Int(Mathf.Max(Mathf.Min(start.x + Mathf.RoundToInt(offset.x), area.Width - 1), 0), Mathf.Max(Mathf.Min(start.y + Mathf.RoundToInt(offset.y), area.Width - 1), 0));
        // we squash the bounds on an axis depending of the direction of the line
        if (horizontal)
        {
            end.y = start.y;
        }
        else
        {
            end.x = start.x;
        }
        // set bounds by min max
        if (end.x < start.x)
        {
            int tmp = start.x;
            start.x = end.x;
            end.x = tmp;
        }
        if (end.y < start.y)
        {
            int tmp = start.y;
            start.y = end.y;
            end.y = tmp;
        }
        #endregion

        #region Determine Wall Direction
        int wallDirection = 0;
        if(wall)
        {
            if (horizontal != (start == end))
            {
                if (offset.y > 0)
                    wallDirection = (int)TilePosition.Top;
                else
                    wallDirection = (int)TilePosition.Bottom;
            }
            else
            {
                if (offset.x > 0)
                    wallDirection = (int)TilePosition.Right;
                else
                    wallDirection = (int)TilePosition.Left;
            }
        }
        #endregion

        start = area.ClampIndex(start);
        end   = area.ClampIndex(end);

        #region Select Parts
        List<AreaPart> selected = new List<AreaPart>();
        for (int x = start.x; x <= end.x; x += stepX)
        {
            for(int y = start.y; y <= end.y; y += stepY)
            {
                if(wall)
                {
                    selected.Add(area.Tiles[x, y].GetWall(wallDirection));
                }
                else
                {
                    selected.Add(area.Tiles[x, y]);
                }
            }
        }
        #endregion

        return selected;
    }
    private static List<AreaPart> Border(Area area, Vector2Int start, Vector2 offset, bool wall, int stepX, int stepY)
    {
        SquareBounds(area, ref start, out Vector2Int end, offset);

        List<AreaPart> selected = new List<AreaPart>();

        for (int x = start.x; x <= end.x; x += stepX)
        {
            for (int y = start.y; y <= end.y; y += stepY)
            {
                if (wall)
                {
                    if (x == start.x)
                        selected.Add(area.Tiles[x, y].GetWall(TPE.Left));
                    if (x == end.x)
                        selected.Add(area.Tiles[x, y].GetWall(TPE.Right));
                    if (y == start.y)
                        selected.Add(area.Tiles[x, y].GetWall(TPE.Bottom));
                    if (y == end.y)
                        selected.Add(area.Tiles[x, y].GetWall(TPE.Top));
                }
                else if(x == start.x | x == end.x | y == start.y | y == end.y)
                {
                    selected.Add(area.Tiles[x, y]);
                }
            }
        }

        return selected;
    }
    private static List<AreaPart> Surface(Area area, Vector2Int start, Vector2 offset, bool wall, int stepX, int stepY)
    {
        if(wall) 
            return Border(area, start, offset, wall, stepX, stepY);


        SquareBounds(area, ref start, out Vector2Int end, offset);

        List<AreaPart> selected = new List<AreaPart>();

        for (int x = start.x; x <= end.x; x += stepX)
        {
            for (int y = start.y; y <= end.y; y += stepY)
            {
                selected.Add(area.Tiles[x, y]);
            }
        }

        return selected;
    }
    private static void SquareBounds(Area area, ref Vector2Int start, out Vector2Int end, Vector2 offset)
    {
        #region Determine bounds
        end = new Vector2Int(Mathf.Max(Mathf.Min(start.x + Mathf.RoundToInt(offset.x), area.Width - 1), 0), Mathf.Max(Mathf.Min(start.y + Mathf.RoundToInt(offset.y), area.Width - 1), 0));
        if (end.x < start.x)
        {
            int tmp = start.x;
            start.x = end.x;
            end.x = tmp;
        }
        if (end.y < start.y)
        {
            int tmp = start.y;
            start.y = end.y;
            end.y = tmp;
        }
        #endregion
    }

}