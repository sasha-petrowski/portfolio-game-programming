﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEngine;

public class Room
{
    public Area Area { get; private set; }
    private List<AreaTile> _tiles = new();
    public Dictionary<Room, int> Links = new Dictionary<Room, int>();

    public Color _debugColor;

    public Vector2 AvgIndex;
    private float _tileCount;

    public override string ToString()
    {
        return $"(Room).{_debugColor}";
    }
    public Room(Area area)
    {
        _debugColor = new Color(Random.Range(.1f, 1f), Random.Range(.1f, 1f), Random.Range(.1f, 1f));

        Area = area;
    }

    public void Delete()
    {
        foreach(Room link in Links.Keys)
        {
            link.Links.Remove(this);
        }
    }

    public void AddTile(AreaTile tile)
    {
        //tile.Room?.RemoveTile(tile);

        tile.Room = this;
        _tiles.Add(tile);

        _tileCount++;
        float fraction = 1f / _tileCount;
        AvgIndex = AvgIndex * (1 - fraction) + (Vector2)tile.Index * fraction;

        if (tile.DebugText) tile.DebugText.color = _debugColor;
    }
    private void Merge(Room other)
    {
        foreach (AreaTile tile in other._tiles)
        {
            AddTile(tile);
        }
        foreach (KeyValuePair<Room, int> pair in other.Links)
        {
            AddLink(pair.Key, pair.Value);
        }
        other.Delete();
    }
    public void AddLink(Room room, int count = 1)
    {
        if (room == this | room == null) return;

        if (Links.TryGetValue(room, out int value))
        {
            count += value;
        }

        Links[room] = count;
        room.Links[this] = count;
    }
    public void RemoveLink(Room room, int count = -1)
    {
        if (room == this | room == null) return;

        if (Links.TryGetValue(room, out int value))
        {
            count += value;
        }

        if(count > 0)
        {
            Links[room] = count;
            room.Links[this] = count;
        }
        else
        {
            Links.Remove(room);
            room.Links.Remove(this);
        }
    }

    public static void CalculateRooms(Area area)
    {
        foreach(Room room in area.Rooms)
        {
            room.Delete();
        }
        area.Rooms.Clear();

        for (int x = 0; x < area.Width; x++)
        {
            for (int y = 0; y < area.Height; y++)
            {
                #region Prepare Variables
                AreaTile tile = area.Tiles[x, y];
                tile.Room = null;
                #endregion

                #region Do nothing if tile is unpassable
                if (tile.CrossTime() < 0)
                {
                    if(tile.DebugText != null) tile.DebugText.color = Color.black;
                    continue;
                }
                #endregion

                #region Get and test room and wall on the sides
                //Get
                Room bottom = y == 0 ? null : area.Tiles[x, y - 1].Room;
                Room left = x == 0 ? null : area.Tiles[x - 1, y].Room;


                AreaWall bottomWall = null;
                bool connectBottom = bottom != null 
                    && 
                    (!tile.TryGetWall(TPE.Bottom, out bottomWall) 
                    ||
                    bottomWall.Entity == null);

                AreaWall leftWall = null;
                bool connectLeft =   left   != null 
                    && 
                    (!tile.TryGetWall(TPE.Left, out leftWall) 
                    ||
                    leftWall.Entity == null);
                #endregion

                #region Create and Merge rooms
                // si il y a des connections a gauche & en bas
                if (connectBottom)
                {
                    bottom.AddTile(tile);
                    // si il y a aussi une salle a gauche & c'est pas la meme salle on les merge
                    if (connectLeft && bottom != left)
                    {
                        bottom.Merge(left);
                        area.Rooms.Remove(left);
                    }
                }
                else if (connectLeft)
                {
                    left.AddTile(tile);
                }
                else
                {
                    Room newRoom = new Room(area);
                    area.Rooms.Add(newRoom);
                    newRoom.AddTile(tile);
                }
                #endregion

                #region Link Rooms
                if (tile.Room == null) return;

                if (connectBottom == false && bottom != null && bottom != tile.Room && !(bottomWall.CrossTime() < 0))
                {
                    tile.Room.AddLink(bottom);
                }
                if (connectLeft == false && left != null && left != tile.Room && !(leftWall.CrossTime() < 0))
                {
                    tile.Room.AddLink(left);
                }

                tile.LinkRoom();
                #endregion
            }
        }
    }
    public void OnDrawGizmos()
    {
        var keys = Links.Keys;
        Room[] links = new Room[keys.Count];
        keys.CopyTo(links, 0);

        Gizmos.color = _debugColor;
        foreach (Room link in links)
        {
            Vector3 center = Area.LocalToWorld(AvgIndex);
            Vector3 linkCenter = (center + link.Area.LocalToWorld(link.AvgIndex)) * 0.5f;
            Gizmos.DrawLine(center, linkCenter);

            if (!Links.ContainsKey(link)) continue;

            //Handles.Label((center + linkCenter) * 0.5f, Links[link].ToString());
        }
    }
}
