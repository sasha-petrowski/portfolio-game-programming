
namespace Noises
{
    [System.Serializable]
    public class NoiseLayer
    {
        public float Amplitude = 1;
        public float Scale = 1;

        public float DistordAmplitude;
        public float DistordScale = 1;
    }
}