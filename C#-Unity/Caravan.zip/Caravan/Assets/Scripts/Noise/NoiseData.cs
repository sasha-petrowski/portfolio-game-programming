using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Noises
{
    [CreateAssetMenu(fileName = "NoiseData", menuName = "Noise/NoiseData")]
    public class Noise : ScriptableObject
    {
        private OpenSimplexNoise _simplexNoise;

        public void InitNoise(int seed)
        {
            _simplexNoise = new OpenSimplexNoise(seed);
        }

        public List<NoiseLayer> Layers = new();
        public List<NoiseOperationHolder> Operations = new();

        public float SimplexNoise(float x, float y)
        {

            float noise = 0;
            float layersAmplitude = 0;

            foreach (NoiseLayer layer in Layers)
            {
                float z;
                if (layer.DistordAmplitude != 0) z = (Mathf.PerlinNoise(x / layer.DistordScale, y / layer.DistordScale) -0.5f) * 2 * layer.DistordAmplitude / layer.Scale;
                else z = 0;

                noise += _simplexNoise.Evaluate((x / layer.Scale), (y / layer.Scale), z) * layer.Amplitude;
                layersAmplitude += layer.Amplitude;
            }

            noise = noise / layersAmplitude; // normalize noise for operations

            foreach (NoiseOperationHolder operation in Operations)
            {
                operation.Apply(ref noise);
            }

            return noise * layersAmplitude; // remap noise to normal
        }
    }
}