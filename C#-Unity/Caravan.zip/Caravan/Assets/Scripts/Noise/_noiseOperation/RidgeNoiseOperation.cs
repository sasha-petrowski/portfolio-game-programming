public class RidgeNoiseOperation : NoiseOperation
{
    public float Min = 0;
    public float Max = 1;

    public override void Apply(ref float value)
    {
        if (value >= Max)
        {
            value = Max - (value - Max);
        }
        else if (value < Min)
        {
            value = Min + (Min - value);
        }
    }
}