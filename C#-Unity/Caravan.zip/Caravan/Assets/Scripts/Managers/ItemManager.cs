using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class ItemManager
{
    private class ItemQuantity
    {
        public int All;
        public int AllUnallowed;
        public int Stored;
        public int StoredUnallowed;
    }

    public static int FreeStorageStacks;
    private static Dictionary<ItemDef, ItemQuantity> _allItems = new Dictionary<ItemDef, ItemQuantity>();

    public static bool AnyStorageAvailable()
    {
        return FreeStorageStacks > 0;
    }
    public static void Remove(ItemDef item, bool allowed, bool stored, int quantity)
    {
        if (_allItems.ContainsKey(item))
        {
            ItemQuantity itemQuantity = _allItems[item];
            if (allowed)
            {
                itemQuantity.All -= quantity;
                if (stored)
                {
                    itemQuantity.Stored -= quantity;
                }
            }
            else
            {
                itemQuantity.AllUnallowed -= quantity;
                if (stored)
                {
                    itemQuantity.StoredUnallowed -= quantity;
                }
            }
        }
        else
        {
            Debug.LogError("<b>Error :</b> tried to Remove from unregistered ItemType");
        }
    }

    public static void Add(ItemDef item, bool allowed, bool stored, int quantity)
    {
        if (!_allItems.ContainsKey(item))
        {
            _allItems.Add(item, new ItemQuantity());
        }
        ItemQuantity itemQuantity = _allItems[item];
        if (allowed)
        {
            itemQuantity.All += quantity;
            if (stored)
            {
                itemQuantity.Stored += quantity;
            }
        }
        else
        {
            itemQuantity.AllUnallowed += quantity;
            if (stored)
            {
                itemQuantity.StoredUnallowed += quantity;
            }
        }
    }
    public static void Update(ItemDef item, bool allowed, bool stored, int quantity)
    {
        if (_allItems.ContainsKey(item))
        {
            ItemQuantity itemQuantity = _allItems[item];
            if (allowed)
            {
                itemQuantity.All += quantity;
                itemQuantity.AllUnallowed -= quantity;
                if (stored)
                {
                    itemQuantity.Stored += quantity;
                    itemQuantity.StoredUnallowed -= quantity;
                }
            }
            else
            {
                itemQuantity.All -= quantity;
                itemQuantity.AllUnallowed += quantity;
                if (stored)
                {
                    itemQuantity.Stored -= quantity;
                    itemQuantity.StoredUnallowed += quantity;
                }
            }
        }
        else
        {
            Debug.LogError("<b>Error :</b> tried to Update from unregistered ItemType");
        }
    }
}
