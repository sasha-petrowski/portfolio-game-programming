using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UIElements;

public class InputManager : MonoBehaviour
{
    public const float DOUBLE_CLICK_TIME = 0.5f;
    public static Vector3 MouseWorldPosition { get; private set; }
    public static bool SpecialKey { get; private set; }

    [SerializeField]
    KeyBinding _keyBinding;

    public bool IsOverUI { get; private set; } = false;

    /*  Functions   */
    private void InputCameraDirection(CameraDirection direction)
    {
        if (Input.GetKey(KeyCode.LeftShift))
        {
            GameCamera.Instance.MoveDirection(direction, 2);
        }
        else
        {
            GameCamera.Instance.MoveDirection(direction, 1);
        }
    }

    private void Update()
    {
        /* Update statics */

        MouseWorldPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        SpecialKey = Input.GetKey(_keyBinding.SpecialKey);

        IsOverUI = IfOverUI(Input.mousePosition);

        /* Shortcuts */
        if (Input.GetKeyDown(_keyBinding.CaravanMenu))
        {
            UIManager.Instance.CaravanMenu.Toggle();
        }


        if (Input.GetKeyDown(_keyBinding.DevKey0)) // Dev 0 : Spawn allied humanoid
        {
            if (ThingManager.Instance.TryGetTileAt(MouseWorldPosition, out AreaTile tile) && Def.TryGetDef("Humanoid", out Def def) && def is HumanoidDef humanoid)
            {
                humanoid.TryInstantiate(tile, Caravan.s_PlayerCaravan);
            }
        }
        if (Input.GetKeyDown(_keyBinding.DevKey8)) // Dev 8 : Caravan Devspeed
        {
            Caravan.DevSpeed = !Caravan.DevSpeed;
        }
        if (Input.GetKeyDown(_keyBinding.DevKey9)) // Dev 9 : Path all humanoids to point
        {
            foreach (Humanoid humanoid in Caravan.s_PlayerCaravan.Caravaneers)
            {
                humanoid.DevGoTo(MouseWorldPosition);
            }
        }

        /* Camera */
        if (!IsOverUI && Input.mouseScrollDelta.y != 0.0)
        {
            if (Input.GetKey(KeyCode.LeftShift))
            {
                GameCamera.Instance.ZoomCamera(-Input.mouseScrollDelta.y * 2);
            }
            else
            {
                GameCamera.Instance.ZoomCamera(-Input.mouseScrollDelta.y);
            }
        }
        if (Input.GetKey(_keyBinding.CameraUp))
        {
            InputCameraDirection(CameraDirection.Up);
        }
        else if (Input.GetKey(_keyBinding.CameraDown))
        {
            InputCameraDirection(CameraDirection.Down);
        }
        if (Input.GetKey(_keyBinding.CameraRight))
        {
            InputCameraDirection(CameraDirection.Right);
        }
        else if (Input.GetKey(_keyBinding.CameraLeft))
        {
            InputCameraDirection(CameraDirection.Left);
        }

        /* Clicks */

        if (Input.GetKeyDown(_keyBinding.PrimaryMouse))
        {

            if (IsOverUI)
            {
                //Eventual UI Stuff
            }
            else
            {
                ToolManager.PrimaryDown(MouseWorldPosition);
            }
        }
        else if (Input.GetKey(_keyBinding.PrimaryMouse))
        {
            if (IsOverUI)
            {
                //Eventual UI Stuff
            }
            else
            {
                ToolManager.PrimaryHold(MouseWorldPosition);
            }

        }
        else if (Input.GetKeyUp(_keyBinding.PrimaryMouse))
        {
            if (IsOverUI)
            {
                //Eventual UI Stuff
            }
            else
            {

                ToolManager.PrimaryUp(MouseWorldPosition);
            }
        }

        if (Input.GetKeyDown(_keyBinding.SecondaryMouse))
        {
            if (IsOverUI)
            {
                //Eventual UI Stuff
            }
            else
            {
                ToolManager.SecondaryDown(MouseWorldPosition);
            }
        }


        /* Tool controls */

        if (Input.GetKeyDown(_keyBinding.TurnToolLeft))
        {
            ToolManager.TurnLeft(MouseWorldPosition);
        }
        if (Input.GetKeyDown(_keyBinding.TurnToolRight))
        {
            ToolManager.TurnRight(MouseWorldPosition);
        }
    }


    private bool IfOverUI(Vector3 screenPosition)
    {
        UnityEngine.EventSystems.PointerEventData pointer = new UnityEngine.EventSystems.PointerEventData(UnityEngine.EventSystems.EventSystem.current);
        pointer.position = screenPosition;
        List<UnityEngine.EventSystems.RaycastResult> raycastResults = new List<UnityEngine.EventSystems.RaycastResult>();
        UnityEngine.EventSystems.EventSystem.current.RaycastAll(pointer, raycastResults);

        return raycastResults.Count > 0;
    }
}