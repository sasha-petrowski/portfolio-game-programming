using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "KeyBinding", menuName = "KeyBinding")]
public class KeyBinding : ScriptableObject
{
    [Header("Dev")]
    public KeyCode DevKey0 = KeyCode.Keypad0;
    public KeyCode DevKey1 = KeyCode.Keypad1;
    public KeyCode DevKey2 = KeyCode.Keypad2;
    public KeyCode DevKey3 = KeyCode.Keypad3;
    public KeyCode DevKey4 = KeyCode.Keypad4;
    public KeyCode DevKey5 = KeyCode.Keypad5;
    public KeyCode DevKey6 = KeyCode.Keypad6;
    public KeyCode DevKey7 = KeyCode.Keypad7;
    public KeyCode DevKey8 = KeyCode.Keypad8;
    public KeyCode DevKey9 = KeyCode.Keypad9;

    [Header("Other")]
    public KeyCode SpecialKey = KeyCode.LeftControl;

    [Header("Mouse")]
    public KeyCode PrimaryMouse = KeyCode.Mouse0;
    public KeyCode SecondaryMouse = KeyCode.Mouse1;
    public KeyCode ThirdMouse = KeyCode.Mouse2;

    [Header("Camera")]
    public KeyCode CameraUp = KeyCode.W;
    public KeyCode CameraDown = KeyCode.S;
    public KeyCode CameraRight = KeyCode.D;
    public KeyCode CameraLeft = KeyCode.A;

    [Header("Tool")]
    public KeyCode TurnToolLeft = KeyCode.Q;
    public KeyCode TurnToolRight = KeyCode.E;

    [Header("Shortcuts")]
    public KeyCode CaravanMenu = KeyCode.C;
}
