using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using System;

public class ThingManager : MonoBehaviour
{
    public static ThingManager Instance { get; private set; }

    [Header("Debug")]
    public BuildingArea DefaultBuildingArea;
    
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this);
        }
        else
        {
            Instance = this;
        }
    }
    public bool TryGetTileAt(Vector2 position, out AreaTile tile)
    {
        Area area = GetBuildingAreaAt(position);
        if(area == null)
        {
            area = World.s_Instance.GetChunkAt(position);
        }
        if(area != null)
        {
            Vector2Int index = area.WorldToIndex(position);
            tile = area.GetTile(index.x, index.y);
        }
        else
        {
            tile = null;
        }
        return tile != null;
    }
    public IEnumerator SpawnEntityAt(InstantiableDef thingDef, Vector2 position, Action<Thing> onInstantiate)
    {
        AreaTile tile;
        while(! TryGetTileAt(position, out tile))
        {
            yield return new WaitForSeconds(0.25f);
        }
        SpawnEntityAt(thingDef, tile, onInstantiate);
    }
    public void SpawnEntityAt(InstantiableDef thingDef, AreaPart part, Action<Thing> onInstantiate)
    {
        Thing thing = thingDef.TryInstantiate(part, Caravan.s_PlayerCaravan);

        if (onInstantiate != null) onInstantiate(thing);
    }

    void Start()
    {
        Def def;
        if (Def.TryGetDef("Elephant", out def) && def is GiantAnimalDef giantDef)
        {
            StartCoroutine(SpawnEntityAt(giantDef, new Vector2(0, 0), (Thing thing) =>
            {
                if (!(thing is GiantAnimal newElephant)) return;

                newElephant.Caravan = Caravan.s_PlayerCaravan;

                BuildingArea buildArea = GameObject.Instantiate(DefaultBuildingArea).GetComponent<BuildingArea>();
                buildArea.InitialiseArea(6, 4);
                newElephant.SetBuildingArea(buildArea);
                buildArea.Caravan = Caravan.s_PlayerCaravan;

                if (Def.TryGetDef("Humanoid", out def) && def is HumanoidDef humanoidDef)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        Creature human = (Creature)humanoidDef.TryInstantiate(buildArea.Tiles[0, 0], Caravan.s_PlayerCaravan);
                    }
                }
                if(Def.TryGetDef("Stone Knife", out def) && def is InstantiableDef weaponDef)
                {
                    WeaponItem weapon = (WeaponItem)weaponDef.TryInstantiate(buildArea.Tiles[0, 0], Caravan.s_PlayerCaravan);
                }
                if (Def.TryGetDef("Box", out def) && def is InstantiableDef storageDef)
                {
                    storageDef.TryInstantiate(buildArea.Tiles[1, 2], Caravan.s_PlayerCaravan);
                    storageDef.TryInstantiate(buildArea.Tiles[4, 2], Caravan.s_PlayerCaravan);
                }
                if (Def.TryGetDef("Cooking Table", out def) && def is InstantiableDef cookingDef) cookingDef.TryInstantiate(buildArea.Tiles[2, 2], Caravan.s_PlayerCaravan);

                if (Def.TryGetDef("Wall", out def) && def is InstantiableDef wallDef)
                {
                    wallDef.TryInstantiate(buildArea.Walls[0][1, 3], Caravan.s_PlayerCaravan, 0);
                    wallDef.TryInstantiate(buildArea.Walls[0][2, 3], Caravan.s_PlayerCaravan, 0);
                    wallDef.TryInstantiate(buildArea.Walls[0][3, 3], Caravan.s_PlayerCaravan, 0);
                    wallDef.TryInstantiate(buildArea.Walls[0][4, 3], Caravan.s_PlayerCaravan, 0);
                }
                if (Def.TryGetDef("Bandage", out def) && def is InstantiableDef bandageDef)
                {
                    bandageDef.TryInstantiate(buildArea.Tiles[1, 1], Caravan.s_PlayerCaravan);
                }
                if (Def.TryGetDef("Primitive Workbench", out def) && def is InstantiableDef workbenchDef)
                {
                    workbenchDef.TryInstantiate(buildArea.Tiles[1, 0], Caravan.s_PlayerCaravan);
                }

            }));
        }
    }

    public List<Thing> GetThingAt(Vector2 worldPosition, List<Thing> currentThings)
    {
        if (currentThings.Count > 1)
        {
            int i = currentThings.Count - 1;
            if (currentThings[i - 1].IsHover(worldPosition))
            {
                Thing sibling = currentThings[i - 1].GetChildAt(worldPosition, currentThings[i]);
                currentThings.RemoveAt(i);
                if (sibling != null)
                {
                    currentThings.Add(sibling);
                }
                return currentThings;
            }
        }
        return GetThingAt(worldPosition);
    }

    public List<Thing> GetThingAt(Vector2 worldPosition)
    {
        List<Thing> things = new List<Thing>();
        List<ChunkArea> chunks = World.s_Instance.GetIntersectionAt(worldPosition);
        Thing thing = null;
        for (int i = 0; i < chunks.Count && thing == null; i++)
        {
            thing = ((Area)chunks[i]).GetThingAt(worldPosition, null);
        }
        if(thing != null)
        {
            things.Add(thing);
            thing = thing.GetChildAt(worldPosition, null);
            while (thing != null)
            {
                things.Add(thing);
                thing = thing.GetChildAt(worldPosition, null);
            }
        }
        return things;
    }

    public BuildingArea GetBuildingAreaAt(Vector2 worldPosition, Area currentArea)
    {
        BuildingArea buildingArea;
        if (currentArea != null && currentArea.IsBuildingArea(out buildingArea) && buildingArea.IsHover(worldPosition))
        {
            return buildingArea;
        }
        return GetBuildingAreaAt(worldPosition);
    }
    public Area GetAreaAt(Vector2 worldPosition, Area currentArea)
    {
        BuildingArea buildingArea = GetBuildingAreaAt(worldPosition, currentArea);
        if (buildingArea != null)
        {
            return buildingArea;
        }
        return World.s_Instance.GetChunkAt(worldPosition);
    }
    public BuildingArea GetBuildingAreaAt(Vector2 worldPosition)
    {
        //Debug.Log($"GetBuildingAreaAt(Vector2 {worldPosition})");
        List<ChunkArea> chunks = World.s_Instance.GetIntersectionAt(worldPosition);
        for (int i = 0; i < chunks.Count; i++)
        {
            Area area = chunks[i];
            //Debug.Log($"Chunk : {chunks[i].Index}");
            foreach (GiantCreature giant in area.GiantEntities)
            {
                //Debug.Log($"Giant : {giant.name}");
                if (giant.BuildingArea != null && giant.BuildingArea.IsHover(worldPosition))
                {
                    //Debug.Log($"Return : {giant.BuildingArea.name}");
                    return giant.BuildingArea;
                }
            }
        }
        //Debug.LogWarning($"Found no BuildingArea");
        return null;
    }


    /* OnDrawGizmos ()
        private void OnDrawGizmos()
        {
            if (_buildingAreaSubManager != null && DrawGridsGizmo)
            {
                Vector2 currentMousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                TileCoordinate currentTile;
                if (Input.GetMouseButton(0) && G_selectedArea != null)
                {
                    float sin = Mathf.Sin(_buildingAreaSubManager.areas[G_selectedArea.id].transform.eulerAngles.z * Mathf.Deg2Rad);
                    float cos = Mathf.Cos(_buildingAreaSubManager.areas[G_selectedArea.id].transform.eulerAngles.z * Mathf.Deg2Rad);
                    switch (G_selectionType)
                    {
                        case SelectionType.Line:
                            List<TileCoordinate> lineCoordinates = _buildingAreaSubManager.areas[G_selectedArea.id].LineSelection(G_clickedCoordinate, currentMousePosition);
                            foreach (TileCoordinate tile in lineCoordinates)
                            {
                                DrawGizmoTile(_buildingAreaSubManager.areas[G_selectedArea.id].IndexToPosition(tile.index), tile.tilePosition, cos, sin);
                            }
                            break;

                        case SelectionType.Square:
                            List<TileCoordinate> squareCoordinates = _buildingAreaSubManager.areas[G_selectedArea.id].AreaSelection(G_clickedCoordinate, currentMousePosition, true);
                            foreach (TileCoordinate tile in squareCoordinates)
                            {
                                DrawGizmoTile(_buildingAreaSubManager.areas[G_selectedArea.id].IndexToPosition(tile.index), tile.tilePosition, cos, sin);
                            }
                            break;

                        case SelectionType.Area:
                            List<TileCoordinate> areaCoordinates = _buildingAreaSubManager.areas[G_selectedArea.id].AreaSelection(G_clickedCoordinate, currentMousePosition);
                            foreach (TileCoordinate tile in areaCoordinates)
                            {
                                DrawGizmoTile(_buildingAreaSubManager.areas[G_selectedArea.id].IndexToPosition(tile.index), tile.tilePosition, cos, sin);
                            }
                            break;
                    }
                }
                else if (G_hoverArea != null)
                {
                    float sin = Mathf.Sin(_buildingAreaSubManager.areas[G_hoverArea.id].transform.eulerAngles.z * Mathf.Deg2Rad);
                    float cos = Mathf.Cos(_buildingAreaSubManager.areas[G_hoverArea.id].transform.eulerAngles.z * Mathf.Deg2Rad);

                    currentTile = _buildingAreaSubManager.areas[G_hoverArea.id].GlobalCoordinate(currentMousePosition);
                    DrawGizmoTile(_buildingAreaSubManager.areas[G_hoverArea.id].IndexToPosition(currentTile.index), currentTile.tilePosition, cos, sin);
                }

                foreach (int i in _buildingAreaSubManager.areasId)
                {
                    float sin = Mathf.Sin(_buildingAreaSubManager.areas[i].transform.eulerAngles.z * Mathf.Deg2Rad);
                    float cos = Mathf.Cos(_buildingAreaSubManager.areas[i].transform.eulerAngles.z * Mathf.Deg2Rad);

                    Vector3 position = _buildingAreaSubManager.areas[i].transform.position;
                    float oX;
                    float oY;

                    oY = -_buildingAreaSubManager.areas[i].GetHeight() / 2f;
                    for (int x = 0; x <= _buildingAreaSubManager.areas[i].GetWidth(); x++)
                    {
                        oX = x - _buildingAreaSubManager.areas[i].GetWidth() / 2f;
                        Gizmos.DrawLine(position + new Vector3((oX * cos) - (oY * sin), (oX * sin) + (oY * cos), 0), position + new Vector3((oX * cos) - (-oY * sin), (oX * sin) + (-oY * cos), 0));
                    }

                    oX = -_buildingAreaSubManager.areas[i].GetWidth() / 2f;
                    for (int y = 0; y <= _buildingAreaSubManager.areas[i].GetHeight(); y++)
                    {
                        oY = y - _buildingAreaSubManager.areas[i].GetHeight() / 2f;
                        Gizmos.DrawLine(position + new Vector3((oX * cos) - (oY * sin), (oX * sin) + (oY * cos), 0), position + new Vector3((-oX * cos) - (oY * sin), (-oX * sin) + (oY * cos), 0));
                    }
                }
            }
        }

        /// <summary>
        /// Draw a tile in Gizmo, duh.
        /// </summary>
        /// 
        public void DrawGizmoTile(Vector3 position, TilePosition edge, float cos, float sin)
        {
            float edgeDistance = BuildingArea.DEFAULT_WALL_SELECTION_OFFSET;
            float invEdgeDistance = 1 - edgeDistance;
            float overEdgeDistance = 1 + edgeDistance;
            switch (edge)
            {
                case TilePosition.Center:
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (edgeDistance * sin), (edgeDistance * sin) + (edgeDistance * cos), 0),
                        position + new Vector3((invEdgeDistance * cos) - (invEdgeDistance * sin), (invEdgeDistance * sin) + (invEdgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (invEdgeDistance * sin), (edgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((invEdgeDistance * cos) - (edgeDistance * sin), (invEdgeDistance * sin) + (edgeDistance * cos), 0));
                    Gizmos.DrawLine(
                         position + new Vector3((edgeDistance * cos) - (edgeDistance * sin), (edgeDistance * sin) + (edgeDistance * cos), 0),
                         position + new Vector3((edgeDistance * cos) - (invEdgeDistance * sin), (edgeDistance * sin) + (invEdgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (invEdgeDistance * sin), (edgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((invEdgeDistance * cos) - (invEdgeDistance * sin), (invEdgeDistance * sin) + (invEdgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((invEdgeDistance * cos) - (invEdgeDistance * sin), (invEdgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((invEdgeDistance * cos) - (edgeDistance * sin), (invEdgeDistance * sin) + (edgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((invEdgeDistance * cos) - (edgeDistance * sin), (invEdgeDistance * sin) + (edgeDistance * cos), 0),
                        position + new Vector3((edgeDistance * cos) - (edgeDistance * sin), (edgeDistance * sin) + (edgeDistance * cos), 0));

                    break;
                case TilePosition.Top:
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (invEdgeDistance * sin), (edgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((invEdgeDistance * cos) - (invEdgeDistance * sin), (invEdgeDistance * sin) + (invEdgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (invEdgeDistance * sin), (edgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((0 * cos) - (1 * sin), (0 * sin) + (1 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((invEdgeDistance * cos) - (invEdgeDistance * sin), (invEdgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((1 * cos) - (1 * sin), (1 * sin) + (1 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (overEdgeDistance * sin), (edgeDistance * sin) + (overEdgeDistance * cos), 0),
                        position + new Vector3((invEdgeDistance * cos) - (overEdgeDistance * sin), (invEdgeDistance * sin) + (overEdgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (overEdgeDistance * sin), (edgeDistance * sin) + (overEdgeDistance * cos), 0),
                        position + new Vector3((0 * cos) - (1 * sin), (0 * sin) + (1 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((invEdgeDistance * cos) - (overEdgeDistance * sin), (invEdgeDistance * sin) + (overEdgeDistance * cos), 0),
                        position + new Vector3((1 * cos) - (1 * sin), (1 * sin) + (1 * cos), 0));
                    break;
                case TilePosition.Bottom:
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (edgeDistance * sin), (edgeDistance * sin) + (edgeDistance * cos), 0),
                        position + new Vector3((invEdgeDistance * cos) - (edgeDistance * sin), (invEdgeDistance * sin) + (edgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (edgeDistance * sin), (edgeDistance * sin) + (edgeDistance * cos), 0),
                        position + new Vector3((0 * cos) - (0 * sin), (0 * sin) + (0 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((invEdgeDistance * cos) - (edgeDistance * sin), (invEdgeDistance * sin) + (edgeDistance * cos), 0),
                        position + new Vector3((1 * cos) - (0 * sin), (1 * sin) + (0 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (-edgeDistance * sin), (edgeDistance * sin) + (-edgeDistance * cos), 0),
                        position + new Vector3((invEdgeDistance * cos) - (-edgeDistance * sin), (invEdgeDistance * sin) + (-edgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (-edgeDistance * sin), (edgeDistance * sin) + (-edgeDistance * cos), 0),
                        position + new Vector3((0 * cos) - (0 * sin), (0 * sin) + (0 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((invEdgeDistance * cos) - (-edgeDistance * sin), (invEdgeDistance * sin) + (-edgeDistance * cos), 0),
                        position + new Vector3((1 * cos) - (0 * sin), (1 * sin) + (0 * cos), 0));
                    break;
                case TilePosition.Right:
                    Gizmos.DrawLine(
                        position + new Vector3((invEdgeDistance * cos) - (invEdgeDistance * sin), (invEdgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((invEdgeDistance * cos) - (edgeDistance * sin), (invEdgeDistance * sin) + (edgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((invEdgeDistance * cos) - (invEdgeDistance * sin), (invEdgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((1 * cos) - (1 * sin), (1 * sin) + (1 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((invEdgeDistance * cos) - (edgeDistance * sin), (invEdgeDistance * sin) + (edgeDistance * cos), 0),
                        position + new Vector3((1 * cos) - (0 * sin), (1 * sin) + (0 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((overEdgeDistance * cos) - (invEdgeDistance * sin), (overEdgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((overEdgeDistance * cos) - (edgeDistance * sin), (overEdgeDistance * sin) + (edgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((overEdgeDistance * cos) - (invEdgeDistance * sin), (overEdgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((1 * cos) - (1 * sin), (1 * sin) + (1 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((overEdgeDistance * cos) - (edgeDistance * sin), (overEdgeDistance * sin) + (edgeDistance * cos), 0),
                        position + new Vector3((1 * cos) - (0 * sin), (1 * sin) + (0 * cos), 0));
                    break;
                case TilePosition.Left:
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (invEdgeDistance * sin), (edgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((edgeDistance * cos) - (edgeDistance * sin), (edgeDistance * sin) + (edgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (invEdgeDistance * sin), (edgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((0 * cos) - (1 * sin), (0 * sin) + (1 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((edgeDistance * cos) - (edgeDistance * sin), (edgeDistance * sin) + (edgeDistance * cos), 0),
                        position + new Vector3((0 * cos) - (0 * sin), (0 * sin) + (0 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((-edgeDistance * cos) - (invEdgeDistance * sin), (-edgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((-edgeDistance * cos) - (edgeDistance * sin), (-edgeDistance * sin) + (edgeDistance * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((-edgeDistance * cos) - (invEdgeDistance * sin), (-edgeDistance * sin) + (invEdgeDistance * cos), 0),
                        position + new Vector3((0 * cos) - (1 * sin), (0 * sin) + (1 * cos), 0));
                    Gizmos.DrawLine(
                        position + new Vector3((-edgeDistance * cos) - (edgeDistance * sin), (-edgeDistance * sin) + (edgeDistance * cos), 0),
                        position + new Vector3((0 * cos) - (0 * sin), (0 * sin) + (0 * cos), 0));
                    break;
            }
        }
    */
}
