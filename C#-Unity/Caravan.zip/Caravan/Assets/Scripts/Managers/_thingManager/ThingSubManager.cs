using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThingSubManager<T> where T : Thing
{
    public LinkedList<T> Things;

    public ThingSubManager()
    {
        Things = new LinkedList<T>();
    }

    public void Add(T thing)
    {
        Things.AddLast(thing);
    }
    public void Remove(T thing)
    {
        Things.Remove(thing);
    }

    /// <summary>
    /// Return the first Thing at mouse position.
    /// </summary>
    /// 
    public T GetThingAt(Vector3 mousePosition, T current)
    {
        if (current == null || !current.IsHover(mousePosition))
        {
            foreach (T thing in Things)
            {
                if (thing.IsHover(mousePosition))
                {
                    return thing;
                }
            }
            return null;
        }
        return current;
    }
}
