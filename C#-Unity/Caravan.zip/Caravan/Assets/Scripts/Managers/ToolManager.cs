using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToolManager : MonoBehaviour
{
    private static SelectionTool _selectionTool = new SelectionTool();
    private static ToolManager _instance;

    private ITool _currentTool;

    private void Awake()
    {
        if(_instance == null)
        {
            _instance = this;
        }
        else
        {
            Destroy(this);
        }

        _currentTool = _selectionTool;
        _currentTool.OnSelect();
    }

    private void LateUpdate()
    {
        _currentTool.WorldPreview(Camera.main.ScreenToWorldPoint(Input.mousePosition));
    }


    public static void SelectNewTool(ITool newTool)
    {
        if(newTool != null && _instance._currentTool != newTool)
        {
            _instance._currentTool.OnQuit();
            _instance._currentTool = newTool;
            _instance._currentTool.OnSelect();
        }
        else
        {
            _instance._currentTool.OnQuit();
            _instance._currentTool = _selectionTool;
            _instance._currentTool.OnSelect();
        }
    }


    public static void PrimaryDown(Vector3 worldPosition)
    {
        _instance._currentTool.PrimaryDown(worldPosition);
    }
    public static void PrimaryHold(Vector3 worldPosition)
    {
        _instance._currentTool.PrimaryHold(worldPosition);
    }
    public static void PrimaryUp(Vector3 worldPosition)
    {
        _instance._currentTool.PrimaryUp(worldPosition);
    }


    public static void SecondaryDown(Vector3 worldPosition)
    {
        if (_instance._currentTool.HasSecondaryEffect)
        {
            _instance._currentTool.SecondaryDown(worldPosition);
        }
        else
        {
            SelectNewTool(_selectionTool);
        }
    }


    public static void TurnLeft(Vector3 worldPosition)
    {
        _instance._currentTool.TurnLeft(worldPosition);
    }
    public static void TurnRight(Vector3 worldPosition)
    {
        _instance._currentTool.TurnRight(worldPosition);
    }
}
