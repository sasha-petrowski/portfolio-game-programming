using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public static class JobManager
{
    public static Job TryFindJob(Creature worker)
    {
        if (worker is Humanoid) return TryFindHumanoidJob(worker);

        return null;
    }
    private static Job TryFindHumanoidJob(Creature worker)
    {
        LinkedList < Area > areasWithJob = new LinkedList<Area>();
        WorldUtility.SpiralChunkSearch(worker, AddAreasWithJob, areasWithJob);

        Job job = null;
        //Debug.LogWarning("TryFindJob");
        foreach (int jobType in JTE.Types)
        {
            //Debug.Log((JobTypes)jobType);

            foreach (Area area in areasWithJob)
            {
                //Debug.Log("- JobType : " + JobTypes.TypeToString[jobType]);
                //Debug.Log("Area : " + area);
                List<IJobProvider> providers = area.JobProviderCategories[jobType];
                if (providers.Count > 0)
                {
                    #region Cache sqr_magnitude of distance 
                    float[] magnitudes = new float[providers.Count];
                    for (int i = 0; i < providers.Count; i++)
                    {
                        Vector2 jobPosition = providers[i].GetPosition();
                        magnitudes[i] = (jobPosition.x - worker.transform.position.x) * (jobPosition.x - worker.transform.position.x) + (jobPosition.y - worker.transform.position.y) * (jobPosition.y - worker.transform.position.y);
                    }
                    float bestMagnitude = 0;
                    int closest;
                    #endregion

                    IJobProvider provider;
                    for (int i = 0; i < providers.Count; i++)
                    {
                        #region Sort by distance

                        closest = i;
                        for (int n = i + 1; n < providers.Count; n++)
                        {
                            if (magnitudes[closest] > magnitudes[n])
                            {
                                bestMagnitude = magnitudes[n];
                                closest = n;
                            }
                        }

                        provider = providers[closest];
                        if (i != closest)
                        {
                            magnitudes[closest] = magnitudes[i];
                            magnitudes[i] = bestMagnitude;

                            providers[closest] = providers[i];
                            providers[i] = provider;
                        }
                        #endregion

                        //Debug.Log("Try " + (JobTypes)jobType + " " + provider.GetType());
                        job = provider.TryTakeJob(worker);
                        if (job != null)
                        {
                            //Debug.Log($"<color=green>{worker} -> Found job : {job.GetType()}</color>");
                            return job;
                        }
                    }
                }
            }
        }
        return null;
    }



    private static bool AddAreasWithJob(Vector2Int chunkIndex, LinkedList<Area> list)
    {
        if (World.s_Instance.ChunkAreas.ContainsKey(chunkIndex))
        {
            Area area = World.s_Instance.ChunkAreas[chunkIndex];

            if (area.OpenJobProviders > 0)
            {
                list.AddLast(area);
            }
            foreach (GiantCreature ge in area.GiantEntities)
            {
                if (ge.BuildingArea != null && ge.BuildingArea.OpenJobProviders > 0)
                {
                    list.AddLast(ge.BuildingArea);
                }
            }
        }
        return false;
    }
}
