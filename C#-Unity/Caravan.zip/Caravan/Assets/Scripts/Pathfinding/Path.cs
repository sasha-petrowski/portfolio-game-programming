using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Path
{
    private struct TargetTile : ICollection<AreaTile>
    {
        public TargetTile(AreaTile tile)
        {
            Tile = tile;
        }

        public AreaTile Tile;
        public int Count => 1;
        public bool IsReadOnly => true;
        public bool Contains(AreaTile item)
        {
            return Tile == item;
        }

        #region Not Implemented
        public void Add(AreaTile item)
        {
            throw new NotImplementedException();
        }
        public void Clear()
        {
            throw new NotImplementedException();
        }
        public void CopyTo(AreaTile[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }
        public bool Remove(AreaTile item)
        {
            throw new NotImplementedException();
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
        public IEnumerator<AreaTile> GetEnumerator()
        {
            throw new NotImplementedException();
        }
        #endregion
    }

    #region Fields

    public Func<List<AreaTile>> GetNewTargets;
    private ICollection<AreaTile> _target;
    private Vector3 _targetWorld;

    public AreaTile LastTile => _lastTile;
    private AreaTile _lastTile;
    private AreaTile _firstTile;

    public LinkedList<AreaTile> Tiles;
    private bool _updatePath = false;

    public bool IsFinished;

    private int _deviationCount = 0;

    Dictionary<Area, Vector2Int> _relatives;
    #endregion

    #region FindPath
    public bool FindPath(IInteractable target, Creature creature)
    {
        return FindPath(target.GetInteractionSpots(), creature);
    }
    public bool FindPath(IInteractable target, AreaTile tile, Creature creature)
    {
        return FindPath(target.GetInteractionSpots(), tile, creature);
    }
    public bool FindPath(AreaTile target, Creature creature)
    {
        return FindPath(target, (AreaTile)creature.Parent, creature);
    }
    public bool FindPath(AreaTile target, AreaTile from, Creature creature)
    {
        if (target == null || from == null) return false;

        _deviationCount = 0;
        _updatePath = false;

        _target = new TargetTile(target);
        _firstTile = from;

        _targetWorld = target.WorldPosition();
        _relatives = new Dictionary<Area, Vector2Int>();

        IsFinished = false;

        if (RoomCheck(target.Room) && Astar(out HashSet<AreaTile> path))
        {
            BackTrack(path);

            foreach (AreaTile tile in Tiles)
            {
                tile.OnUpdate += OnTileUpdate;
            }

            return true;
        }
        return false;
    }
    public bool FindPath(List<AreaTile> targets, Creature creature)
    {
        if(targets.Count == 1) return FindPath(targets[0], (AreaTile)creature.Parent, creature);
        else return FindPath(targets, (AreaTile)creature.Parent, creature);
    }
    public bool FindPath(List<AreaTile> targets, AreaTile from, Creature creature)
    {
        if (targets.Count == 1) return FindPath(targets[0], from, creature);
        if (targets.Count == 0 || from == null) return false;


        _deviationCount = 0;
        _updatePath = false;

        _target = targets;
        _firstTile = from;

        IsFinished = false;

        #region RoomCheck
        List<Room> validRooms = new List<Room>();
        foreach(AreaTile tile in targets)
        {
            if(! validRooms.Contains(tile.Room)) validRooms.Add(tile.Room);
        }
        for (int i = validRooms.Count - 1; i >= 0; i--)
        {
            if (!RoomCheck(validRooms[i])) validRooms.RemoveAt(i);
        }
        for (int i = targets.Count - 1; i >= 0; i--)
        {
            if (!validRooms.Contains(targets[i].Room)) targets.RemoveAt(i);
        }

        if (targets.Count == 0) return false;
        #endregion

        _targetWorld = targets[0].WorldPosition();
        _relatives = new Dictionary<Area, Vector2Int>();

        if (Astar(out HashSet<AreaTile> path))
        {
            BackTrack(path);

            foreach (AreaTile tile in Tiles)
            {
                tile.OnUpdate += OnTileUpdate;
            }

            return true;
        }
        return false;
    }
    /*
    private bool FindFirstTile(AreaTile from)
    {
        _firstTile = from as AreaTile;
        if (_firstTile == null)
        {
            // if from is not a tile : loop trough neighbors to get a nearby tile
            for (int i = 0; i < 4; i++)
            {
                if (from.TryGetTile(i, out _firstTile))
                {
                    break;
                }
            }
        }

        return _firstTile != null;
    }
    */
    private bool RoomCheck(Room target)
    {
        if (_firstTile.Room == null | target == null) return false;

        if (_firstTile.Room == target) return true;

        if (_firstTile.Room.Links.Count == 0 | target.Links.Count == 0) return false;

        #region Setup variables
        HashSet<Room> visitedEnd = new HashSet<Room>();
        LinkedList<Room> toVisitEnd = new LinkedList<Room>();

        HashSet<Room> visitedStart = new HashSet<Room>();
        LinkedList<Room> toVisitStart = new LinkedList<Room>();

        visitedStart.Add(_firstTile.Room);
        toVisitStart.AddFirst(_firstTile.Room);

        visitedEnd.Add(target);
        toVisitEnd.AddFirst(target);
        #endregion
        
        while(toVisitStart.First != null & toVisitEnd.First != null)
        {
            var startKeys = toVisitStart.First.Value.Links.Keys;
            Room[] startLinks = new Room[startKeys.Count];
            startKeys.CopyTo(startLinks, 0);
            foreach (Room link in startLinks)
            {
                if ( visitedEnd.Contains(link)) return true;
                if (!visitedStart.Add(link)) continue;

                toVisitStart.AddLast(link);
            }

            var endKeys = toVisitEnd.First.Value.Links.Keys;
            Room[] endLinks = new Room[endKeys.Count];
            endKeys.CopyTo(endLinks, 0);
            foreach (Room link in endLinks)
            {
                if ( visitedStart.Contains(link)) return true;
                if (!visitedEnd.Add(link)) continue;

                toVisitEnd.AddLast(link);
            }

            toVisitStart.RemoveFirst();
            toVisitEnd.RemoveFirst();
        }

        return false;
    }
    private bool Astar(out HashSet<AreaTile> path)
    {
        #region Setup variables
        path = new HashSet<AreaTile>();
        LinkedList<AreaTile> toVisit = new LinkedList<AreaTile>();
        AreaWall[] walls = new AreaWall[4];
        bool[] wallsTest = new bool[4];
        float[] wallsTime = new float[4];
        #endregion

        #region Setup First Tile

        _firstTile.PathTime = 0;
        _firstTile.PathWeight = GetTargetDistance(_firstTile);

        path.Add(_firstTile);

        toVisit.AddFirst(_firstTile);

        #endregion

        while (toVisit.First != null)
        {
            #region Setup variables
            AreaTile current = toVisit.First.Value;
            toVisit.RemoveFirst();
            _lastTile = current;

            #endregion

            #region cache walls
            for (int i = 0; i < 4; i++)
            {
                wallsTime[i] = current.TryGetWall(i, out AreaWall neighborWall) ? neighborWall.CrossTime() : 0;

                walls[i] = neighborWall;

                wallsTest[i] = !(wallsTime[i] < 0);
            }
            #endregion

            // for each neighbors
            for (int i = 0; i < 8; i++)
            {
                #region Test and Add Tile
                if (current.TryGetTile(i, out AreaTile neighborTile))
                {
                    #region Test Wall
                    float wallTime = 0;
                    if (i < 4)
                    {
                        // side walls
                        if (!wallsTest[i]) continue;

                        wallTime = wallsTime[i];

                    }
                    else
                    {
                        // diagonal walls
                        if (!wallsTest[i % 4] | !wallsTest[(i + 1) % 4]) continue;

                        if (
                            !(!neighborTile.TryGetWall(TPE.Invert[i % 4], out AreaWall leftWall) || leftWall.CrossTime() == 0)
                            |
                            !(!neighborTile.TryGetWall(TPE.Invert[(i + 1) % 4], out AreaWall rightWall) || rightWall.CrossTime() == 0)
                           )
                        {
                            continue;
                        }
                    }
                    #endregion

                    float tileTime = neighborTile.CrossTime();
                    if (tileTime < 0) continue;

                    float walkTime = wallTime + tileTime;
                    if(i >= 4)
                    {
                        // longer when moving in diagonal
                        walkTime *= 1.5f;
                    }
                    float neighborTime = current.PathTime + walkTime;

                    if (_target.Contains(neighborTile))
                    {
                        neighborTile.PathTime = neighborTime;
                        _lastTile = neighborTile;

                        return true;
                    }
                    else if (! path.Contains(neighborTile))
                    {
                        neighborTile.PathTime = neighborTime;
                        neighborTile.PathWeight = neighborTime + GetTargetDistance(neighborTile);
                        path.Add(neighborTile);

                        AddToVisit(toVisit, neighborTile);
                    }
                    else if (neighborTime < neighborTile.PathTime)
                    {
                        neighborTile.PathTime = neighborTime;
                        neighborTile.PathWeight = neighborTime + GetTargetDistance(neighborTile);
                    }
                }
                #endregion
            }
            //for each links
            if (current.TryGetLinks(out List<AreaTile> links))
            {
                for(int i =  0; i < links.Count; i++)
                {
                    AreaTile linkedTile = links[i];

                    float tileTime = linkedTile.CrossTime();
                    if (tileTime < 0) continue;

                    float linkTime = current.PathTime + tileTime;

                    if (_target.Contains(linkedTile))
                    {
                        linkedTile.PathTime = linkTime;
                        _lastTile = linkedTile;
                        return true;
                    }
                    else if (!path.Contains(linkedTile))
                    {
                        linkedTile.PathTime = linkTime;
                        linkedTile.PathWeight = linkTime + GetTargetDistance(linkedTile);

                        path.Add(linkedTile);

                        AddToVisit(toVisit, linkedTile);
                    }
                    else if (linkTime < linkedTile.PathTime)
                    {
                        linkedTile.PathTime = linkTime;
                        linkedTile.PathWeight = linkTime + GetTargetDistance(linkedTile);
                    }
                }
            }
        }

        return false;
    }
    private void BackTrack(HashSet<AreaTile> path)
    {
        #region Setup variables
        Tiles = new LinkedList<AreaTile>();

        Tiles.AddFirst(_lastTile);
        AreaTile tile = _lastTile;

        //we allow a bit extra memory (we should normaly use around 8 - 13 but allow up to 16 just in case) (this will crash anyway if i ever add teleporters networks.......)
        AreaTile[] possibleMoves = new AreaTile[16];
        int moveCount;
        bool[] walls = new bool[4];
        #endregion

        while (tile != null & tile != _firstTile)
        {
            moveCount = 0;

            #region cache walls
            for (int i = 0; i < 4; i++)
            {
                walls[i] = !tile.TryGetWall(i, out AreaWall neighborWall) || !(neighborWall.CrossTime() < 0);
                /*
                if (_target.Contains(neighborWall)) return;
                */
            }
            #endregion

            #region Test all directions and links
            // for each neighbors
            for (int i = 0; i < 8; i++)
            {
                #region Test and Add Tile
                if (tile.TryGetTile(i, out AreaTile neighborTile))
                {
                    #region Test Wall
                    if (i < 4)
                    {
                        if (!walls[i]) continue;
                    }
                    else
                    {
                        // diagonal walls
                        if (!walls[i % 4] | !walls[(i + 1) % 4]) continue;

                        if (
                            !(!neighborTile.TryGetWall(TPE.Invert[i % 4], out AreaWall leftWall) || leftWall.CrossTime() == 0)
                            |
                            !(!neighborTile.TryGetWall(TPE.Invert[(i + 1) % 4], out AreaWall rightWall) || rightWall.CrossTime() == 0)
                           )
                        {
                            continue;
                        }
                    }
                    #endregion

                    if (neighborTile == _firstTile)
                    {
                        //Debug.Log($"Found : {neighborTile}");
                        Tiles.AddFirst(neighborTile);
                        return;
                    }
                    
                    if (! path.Contains(neighborTile)) continue;

                    possibleMoves[moveCount] = neighborTile;
                    moveCount++;
                }
                #endregion
            }

            if (tile.TryGetLinks(out List<AreaTile> links))
            {
                foreach (AreaTile linkedTile in links)
                {
                    if (linkedTile == _firstTile)
                    {
                        //Debug.Log($"Found : {neighborTile}");
                        Tiles.AddFirst(linkedTile);
                        return;
                    }

                    if (! path.Contains(linkedTile)) continue;

                    possibleMoves[moveCount] = linkedTile;
                    moveCount++;
                }
            }

            #endregion

            #region Sort possible moves by time
            AreaTile bestMove = possibleMoves[0];

            for (int i = 1; i < moveCount; i++)
            {
                if (bestMove.PathTime > possibleMoves[i].PathTime)
                {
                    bestMove = possibleMoves[i];
                }
            }
            #endregion

            //Debug.Log($"BestMove : {bestMove}");
            Tiles.AddFirst(bestMove);
            tile = bestMove;
        }
    }

    #region Utility Func
    private int GetTargetDistance(AreaTile tile)
    {
        if (!_relatives.TryGetValue(tile.Area, out Vector2Int relative))
        {
            // if we don't have a target index, we assign it
            relative = tile.Area.WorldToIndex(_targetWorld);
            _relatives.Add(tile.Area, relative);
        }
        return Mathf.Abs(relative.x - tile.x) + Mathf.Abs(relative.y - tile.y);
    }
    private float GetTargetDistance(Room room)
    {
        if (!_relatives.TryGetValue(room.Area, out Vector2Int relative))
        {
            // if we don't have a target index, we assign it
            relative = room.Area.WorldToIndex(_targetWorld);
            _relatives.Add(room.Area, relative);
        }
        return Mathf.Abs(relative.x - room.AvgIndex.x) + Mathf.Abs(relative.y - room.AvgIndex.y);
    }
    private void AddToVisit(LinkedList<AreaTile> toVisit, AreaTile tile)
    {
        LinkedListNode<AreaTile> before = null;
        LinkedListNode<AreaTile> next = toVisit.First;
		
		while (before == null & next != null)
		{
			AreaTile other = next.Value;

            if (tile.PathWeight <= other.PathWeight)
			{
				before = next;
			}
            next = next.Next;
		}
        if (next == null)
        {
            //Debug.Log("Add Last");
            toVisit.AddLast(tile);
        }
        else
        {
            //Debug.Log($"Add before : {before.Value}");
            toVisit.AddBefore(before, tile);
        }
    }
    #endregion

    #endregion

    public int FollowPath(Creature creature, int index = 0)
    {
        if (IsFinished) return 1;

        if(creature.Parent.Area == null) return 0;

        if (Tiles.First != null && creature.Parent == Tiles.First.Value) Tiles.RemoveFirst();

        // test if finished
        if (Tiles.First == null || Tiles.Count <= index)
        {
            IsFinished = true;
            return 1;
        }

        if(! creature.CanMove)
        {
            creature.Cooldown();
            return 0;
        }

        #region Update path if needed
        if (_updatePath)
        {
            bool foundPath;

            List<AreaTile> newTargets = GetNewTargets?.Invoke();

            //Debug.Log($"Update path : \n{creature.Parent} > {_path.First.Value}");
            if(creature.Parent is AreaTile creatureTile && creatureTile.CanGoTo(Tiles.First.Value))
            {
                if(newTargets == null)
                {
                    foundPath = FindPath(_lastTile, Tiles.First.Value, creature);
                }
                else
                {
                    foundPath = FindPath(newTargets, Tiles.First.Value, creature);
                }
            }
            else
            {
                if (newTargets == null)
                {
                    foundPath = FindPath(_lastTile, creature);
                }
                else
                {
                    foundPath = FindPath(newTargets, creature);
                }
            }

            if(!foundPath)
            {
                return -1;
            }
        }
        #endregion

        AreaTile next = Tiles.First.Value;
        AreaWall wall = null; 
        if(creature.Parent is AreaTile parentTile)
        {
            wall = parentTile.GetWall(next);
            if (wall == null)
            {
                wall = next.GetWall(parentTile);
            }
        }

        Vector3 relative = next.WorldPosition() - creature.transform.position;

        relative.z = 0;

        float distance = new Vector2(relative.x, relative.y).magnitude;

        float crossTime;
        float wallTime = wall == null ? 0 : wall.CrossTime();

        crossTime = (wallTime + next.CrossTime() + creature.Parent.CrossTime()) / 2f;

        crossTime = Mathf.Max(crossTime, Mathf.Epsilon);

        float step = ((Caravan.DevSpeed ? creature.MoveSpeed * 10 : creature.MoveSpeed) * Time.deltaTime) / crossTime;

        if(next.Area != null && creature.transform.parent != next.Area.transform) creature.transform.SetParent(next.Area.transform);

        creature.transform.eulerAngles = new Vector3(0, 0, Mathf.LerpAngle(creature.transform.eulerAngles.z, Mathf.Atan2(relative.y, relative.x) * Mathf.Rad2Deg - 90, step));

        if (distance <= step)
        {
            creature.transform.position += relative;
            creature.SetParent(next);

            next.OnUpdate -= OnTileUpdate;

            Tiles.RemoveFirst();
        }
        else
        {
            creature.transform.position += relative / distance * step;
        }

        if (creature.Parent?.Area == null || next.Area == null) return -1;

        creature.transform.position = new Vector3(creature.transform.position.x, creature.transform.position.y, Mathf.Min(creature.Parent.Area.transform.position.z, next.Area.transform.position.z) - 2);

        return 0;
    }

    private void OnTileUpdate(AreaTile tile)
    {
        if (!_updatePath)
        {
            if (_deviationCount >= 2 & _deviationCount > Tiles.Count / 8)
            {
                //Debug.Log("Too much deviations compared to path length, recalculating");
                _updatePath = true;
                return;
            }

            LinkedListNode<AreaTile> node = Tiles.Find(tile);
            if(node == null)
            {
                tile.OnUpdate -= OnTileUpdate;
            }
            else
            {
                AreaTile previous = node.Previous?.Value;
                AreaTile next = node.Next?.Value;

                bool connectPrevious = previous == null || tile.CanGoTo(previous);
                bool connectNext     = next == null     || tile.CanGoTo(next);

                //Debug.Log($"Update {tile}\n{(!connectPrevious ? "Previous " + previous + "\n": "")}{(!connectNext ? "Next " + next : "")}");

                if (connectPrevious && connectNext) return;

                if (!connectPrevious)
                {
                    AreaTile previousPrevious = node.Previous.Previous?.Value;
                    if(tile.CanGoTo(previousPrevious))
                    {
                        //Debug.Log("previous previous");
                        connectPrevious = true;
                        previous.OnUpdate -= OnTileUpdate;
                        Tiles.Remove(node.Previous);
                    }
                    else
                    {
                        foreach (AreaTile neighbor in previous.CanGoTo())
                        {
                            if(neighbor != previousPrevious && neighbor.CanGoTo(tile))
                            {
                                //Debug.Log("connect previous's neighbor");
                                _deviationCount++;
                                connectPrevious = true;
                                neighbor.OnUpdate += OnTileUpdate;
                                Tiles.AddBefore(node, neighbor);
                                break;
                            }
                        }
                    }
                }
                if (connectPrevious && !connectNext)
                {
                    AreaTile nextNext = node.Next.Next?.Value;
                    if (tile.CanGoTo(nextNext))
                    {
                        //Debug.Log("next next");
                        connectNext = true;
                        next.OnUpdate -= OnTileUpdate;
                        Tiles.Remove(node.Next);
                    }
                    else
                    {
                        foreach (AreaTile neighbor in next.CanGoTo())
                        {
                            if (neighbor != nextNext && neighbor.CanGoTo(tile))
                            {
                                //Debug.Log("connect next's neighbor");
                                _deviationCount++;
                                connectNext = true;
                                neighbor.OnUpdate += OnTileUpdate;
                                Tiles.AddAfter(node, neighbor);
                                break;
                            }
                        }
                    }
                }

                if(!connectPrevious || !connectNext)
                {
                    Debug.Log("Couln't patch path, Updating all of it\nThis is not a problem, unless it gets spammed");
                    _updatePath = true;
                    return;
                }
            }
        }
    }

    public void OnDrawGizmos()
    {
        if (Tiles?.First == null) return;

        Vector3 previousPos = Tiles.First.Value.WorldPosition();
        LinkedListNode<AreaTile> next = Tiles.First?.Next;

        Gizmos.DrawWireSphere(_lastTile.WorldPosition(), 0.5f);

        int count = Tiles.Count;
        while (next != null)
        {
            if(count % 2 == 0) Gizmos.color = Color.green;
            else Gizmos.color = Color.red;
            count++;

            Vector3 nextPos = next.Value.WorldPosition();

            Gizmos.DrawLine(previousPos, nextPos);
            previousPos = nextPos;

            next = next.Next;
        }

        Gizmos.DrawWireSphere(_lastTile.WorldPosition(), 0.25f);
    }

    public void Free()
    {
        if(Tiles != null)
        {
            foreach (AreaTile tile in Tiles)
            {
                tile.OnUpdate -= OnTileUpdate;
            }
        }
    }
}