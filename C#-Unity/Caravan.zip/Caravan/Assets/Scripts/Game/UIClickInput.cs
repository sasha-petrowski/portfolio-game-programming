using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(Image))]
public class UIClickInput : MonoBehaviour, IPointerDownHandler
{
    public Action<Vector2, float> OnInputDown;


    private Vector2 _direction;
    private float _radAngle;

    private void ClickAt(Vector2 relativePos)
    {                
        float magnitude = relativePos.magnitude;
        _direction = relativePos / magnitude;
        //_centered = magnitude < _magnitudeThreshold;
        _radAngle = MathF.Atan2(_direction.y, _direction.x) - 0.5f * Mathf.PI;

        OnInputDown?.Invoke(_direction, _radAngle);
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        ClickAt(eventData.position - (Vector2)transform.position);
    }
}
