using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum CameraDirection
{
    Up,
    Down,
    Right,
    Left
}
public class GameCamera : MonoBehaviour
{
    public static GameCamera Instance { get; private set; }
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this);
        }
        else
        {
            Instance = this;
        }
    }

    public float cameraSpeed;
    public float zoomSpeed;

    public int minZoom;
    public int maxZoom;

    /*  Functions   */

    public void MoveDirection(CameraDirection direction, int speed)
    {
        float move = speed * cameraSpeed * Time.deltaTime * (Camera.main.orthographicSize / minZoom / 4);
        switch (direction)
        {
            case CameraDirection.Up:
                transform.position = new Vector3(transform.position.x, transform.position.y + move, transform.position.z);
                break;
            case CameraDirection.Down:
                transform.position = new Vector3(transform.position.x, transform.position.y - move, transform.position.z);
                break;
            case CameraDirection.Right:
                transform.position = new Vector3(transform.position.x + move, transform.position.y, transform.position.z);
                break;
            case CameraDirection.Left:
                transform.position = new Vector3(transform.position.x - move, transform.position.y, transform.position.z);
                break;
        }
    }
    public void ZoomCamera(float delta)
    {
        Camera.main.orthographicSize = Mathf.Clamp(Camera.main.orthographicSize + delta * zoomSpeed * (Camera.main.orthographicSize / minZoom / 4), minZoom, maxZoom);

        UIManager.Instance.UpdateSelectionZoomRatio(GetZoomRatio());
    }
    public void MoveTo(float x, float y)
    {
        transform.position = new Vector3(x, y, transform.position.z);
    }
    public float GetZoomRatio()
    {
        return minZoom / Camera.main.orthographicSize;
    }
}