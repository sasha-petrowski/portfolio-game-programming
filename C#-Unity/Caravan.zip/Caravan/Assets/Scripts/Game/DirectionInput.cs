using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(Image))]
public class DirectionInput : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler
{
    public Action<bool, Vector2, float> OnInputUp;
    public Action<Vector2, float> OnValueChanged;

    [SerializeField]
    private Color _centeredColor = Color.gray;
    [SerializeField]
    private Color _normalColor = Color.white;
    private Image _image;


    [SerializeField]
    private RectTransform _parent;
    [SerializeField]
    private float _size = 100;
    [SerializeField]
    private float _magnitudeThreshold = 40;


    private Vector2 _direction;
    private bool _centered;
    [SerializeField]
    private float _radAngle;
    public Vector2 Direction => _direction;
    public bool Centered => _centered;
    public float RadAngle => _radAngle;

    private void Awake()
    {
        _image = GetComponent<Image>();
        _image.color = _centeredColor;
    }

    private void MoveAt(Vector2 relativePos)
    {
        float magnitude = relativePos.magnitude;
        _direction = relativePos / magnitude;
        _centered = magnitude < _magnitudeThreshold;
        _radAngle = MathF.Atan2(_direction.y, _direction.x) - 0.5f * Mathf.PI;

        if (magnitude == 0) Center();
        else
        {
            OnValueChanged?.Invoke(_direction, _radAngle);
            transform.position = (Vector2)_parent.position + _direction * Mathf.Min(_size, magnitude);
        }

        _image.color = _centered ? _centeredColor : _normalColor;
    }
    public void Center()
    {
        transform.position = _parent.position;
        _image.color = _centeredColor;

    }

    public void OnDrag(PointerEventData eventData)
    {
        MoveAt(eventData.position - (Vector2)_parent.position);
    }
    public void OnPointerDown(PointerEventData eventData)
    {
        MoveAt(eventData.position - (Vector2)_parent.position);
    }
    public void OnPointerUp(PointerEventData eventData)
    {
        if (_centered)
        {
            Center();
        }
        else
        {
            transform.position = (Vector2)_parent.position + _direction * _size;
        }
        OnInputUp?.Invoke(Centered, _direction, _radAngle);
    }
}
