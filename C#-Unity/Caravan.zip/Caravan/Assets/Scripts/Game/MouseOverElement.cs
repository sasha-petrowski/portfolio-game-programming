using System;
using UnityEngine;
using UnityEngine.EventSystems;

public class MouseOverElement : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Action<PointerEventData> MouseEnter;
    public Action<PointerEventData> MouseExit;

    public void OnPointerEnter(PointerEventData eventData)
    {
        MouseEnter?.Invoke(eventData);
    }
    public void OnPointerExit(PointerEventData eventData)
    {
        MouseExit?.Invoke(eventData);
    }
}
