using UnityEngine;

public enum WorldDirection : ushort {
	S, SW, W, NW, N, NE, E, SE
}

public static class WorldDirectionExtensions {
	public static Vector2Int Direction(this WorldDirection direction) {
		switch (direction) {
			case WorldDirection.S:
				return new Vector2Int(0, -1);
			case WorldDirection.SW:
				return new Vector2Int(-1, -1);
			case WorldDirection.W:
				return new Vector2Int(-1, 0);
			case WorldDirection.NW:
				return new Vector2Int(-1, 1);
			case WorldDirection.N:
				return new Vector2Int(0, 1);
			case WorldDirection.NE:
				return new Vector2Int(1, 1);
			case WorldDirection.E:
				return new Vector2Int(1, 0);
			case WorldDirection.SE:
				return new Vector2Int(1, -1);
			default:
				return Vector2Int.zero;
		}
	}
}