using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldGenerator : MonoBehaviour
{
    public static WorldGenerator Instance;

    [Header("GameObjects")]
    public Transform viewer;

    [Header("ScriptSettings")]
    public int simultaneousChunksGenerated;

    [Header("Settings")]
    public WorldTerrain WorldTerrain;
    public InstantiableTableDef NaturalResource;
    public InstantiableTableDef Wildlife;
    public InstantiableTableDef RuinWalls;
    public InstantiableTableDef RuinStructures;

    [SerializeField]
    int _worldSize;
    [SerializeField]
    int _seed;

    [Header("Editor Tools")]
    [Min(1)]
    public float EditorWorldScale;
    public bool EditorDrawInColor;
    public bool EditorAutoUpdateWorld;

    public SpriteRenderer EditorWorldRenderer;

    private void OnValidate()
    {
        if (simultaneousChunksGenerated < 1)
            simultaneousChunksGenerated = 1;
    }
    void OnNoiseSettingUpdated()
    {
        if (!Application.isPlaying)
        {
            DrawEditorWorld();
        }
    }
    private Vector2Int _currentChunk;

    private Dictionary<Vector2Int, WorldChunk> _chunks = new Dictionary<Vector2Int, WorldChunk>();
    private List<WorldChunk> _generatingChunks = new List<WorldChunk>();
    private List<WorldChunk> _lastVisibleChunks;
    private HashSet<WorldChunk> _chunksToDespawn;


    // Start is called before the first frame update
    void Start()
    {
        new World();

        if(this != null)
        {
            Instance = this;
        }
        else
        {
            Destroy(this);
            return;
        }
        EditorWorldRenderer.enabled = false;

        WorldSettings.WorldSize = _worldSize;
        WorldSettings.Seed = _seed;

        _lastVisibleChunks = new List<WorldChunk>(WorldSettings.ChunkNumber * WorldSettings.ChunkNumber);
        _chunksToDespawn = new HashSet<WorldChunk>(WorldSettings.ChunkNumber * WorldSettings.ChunkNumber);

        UpdateNoiseSeed();

        UpdateVisibleChunks();
        //GenerateNewWorld();
    }
    private void Update()
    {
        //Test if chunks generation threads are finished
        for (int i = 0; i < _generatingChunks.Count; i++)
        {
            _generatingChunks[i].UpdateGeneration();
            if (_generatingChunks[i].Generated)
            {
                if (_generatingChunks[i].UpdateVisibility(ref _currentChunk))
                {
                    _lastVisibleChunks.Add(_generatingChunks[i]);
                }
                _generatingChunks.RemoveAt(i);
                UpdateVisibleChunks();
            }
        }
        //Update Visible Chunks if moved
        if(_currentChunk != Caravan.s_PlayerCenterChunkIndex)
        {
            _currentChunk = Caravan.s_PlayerCenterChunkIndex;
            UpdateVisibleChunks();
        }
    }
    void UpdateNoiseSeed()
    {
        WorldTerrain.Initialize();
    }
    private void UpdateVisibleChunks()
    {
        for(int i = 0; i < _lastVisibleChunks.Count; i++)
        {
            _lastVisibleChunks[i].SetVisible(false);
            _chunksToDespawn.Add(_lastVisibleChunks[i]);
        }
        _lastVisibleChunks.Clear();
        Vector2Int index = Vector2Int.zero;
        int cb2 = Mathf.RoundToInt(WorldSettings.ChunkNumber / 2);
        for (int x = _currentChunk.x - cb2; x < _currentChunk.x + WorldSettings.ChunkNumber - cb2; x++)
        {
            index.x = x;
            for (int y = _currentChunk.y - cb2; y < _currentChunk.y + WorldSettings.ChunkNumber - cb2; y++)
            {
                index.y = y;
                if (_chunks.ContainsKey(index))
                {
                    if(_chunks[index].Generated)
                    {
                        _lastVisibleChunks.Add(_chunks[index]);
                        if(_chunks[index].UpdateVisibility(ref _currentChunk))
                        {
                            _chunksToDespawn.Remove(_chunks[index]);
                        }
                    }
                }
                else if(_generatingChunks.Count < simultaneousChunksGenerated)
                {
                    _chunks.Add(index, new WorldChunk(index, ChunkArea.InstantiateChunk(index), WorldSettings.ChunkSize, WorldSettings.ChunkSize));
                    _chunksToDespawn.Remove(_chunks[index]);
                    _generatingChunks.Add(_chunks[index]);

                    World.s_Instance.ChunkAreas.Add(index, _chunks[index].ChunkArea);

                    _chunks[index].SetVisible(false);
                }
            }
        }
        foreach(WorldChunk wc in _chunksToDespawn)
        {
            _chunks.Remove(wc.Index);
            World.s_Instance.ChunkAreas.Remove(wc.Index);
            wc.DestroyChunk();
        }
        _chunksToDespawn.Clear();
    }
    public void DrawEditorWorld()
    {
        if (this != null)
        {
            Instance = this;
        }

        WorldSettings.WorldSize = _worldSize;
        WorldSettings.Seed = _seed;

        UpdateNoiseSeed();

        Color[] colorMap = new Color[WorldSettings.ChunkSize * WorldSettings.ChunkSize * WorldSettings.ChunkNumber * WorldSettings.ChunkNumber];

        int cb2 = Mathf.RoundToInt(WorldSettings.ChunkNumber * WorldSettings.ChunkSize / 2);
        for (int x = 0; x < WorldSettings.ChunkSize * WorldSettings.ChunkNumber; x++)
        {
            for (int y = 0; y < WorldSettings.ChunkSize * WorldSettings.ChunkNumber; y++)
            {
                colorMap[x + y * WorldSettings.ChunkSize * WorldSettings.ChunkNumber] = WorldGenerator.Instance.WorldTerrain.GetTerrainAt(Mathf.RoundToInt((x + _currentChunk.x * WorldSettings.ChunkSize - cb2) * EditorWorldScale), Mathf.RoundToInt((y + _currentChunk.y * WorldSettings.ChunkSize - cb2) * EditorWorldScale)).Color;
            }
        }

        //textureSetting.ApplyToMaterial(EditorMaterial);

        
        Texture2D texture = new Texture2D(WorldSettings.ChunkSize * WorldSettings.ChunkNumber, WorldSettings.ChunkSize * WorldSettings.ChunkNumber);
        texture.filterMode = FilterMode.Point;
        texture.SetPixels(colorMap);
        texture.Apply();
        
        
        //EditorWorldRenderer.sharedMaterial.mainTexture = texture;
        
        EditorWorldRenderer.sprite = Sprite.Create(texture, new Rect(0f, 0f, WorldSettings.ChunkSize * WorldSettings.ChunkNumber, WorldSettings.ChunkSize * WorldSettings.ChunkNumber), new Vector2(0.5f, 0.5f), 1 / EditorWorldScale);

        //EditorWorldRenderer.transform.localScale = new Vector3(WorldSettings.ChunkSize * WorldSettings.ChunkNumber * EditorWorldScale.x, WorldSettings.ChunkSize * WorldSettings.ChunkNumber, 1);
    }
}
public static class WorldSettings
{
    public static int WorldSize;
    public static int Seed;

    public static int ChunkNumber = 16;
    public static int ChunkSize = 16;
}
