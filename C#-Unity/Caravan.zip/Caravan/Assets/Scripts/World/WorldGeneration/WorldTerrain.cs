using Noises;
using System;
using System.Collections.Generic;
using UnityEngine;

public class WorldTerrain : ScriptableObject
{
    [SerializeField]
    private List<TileDef> _tiles = new List<TileDef>();
    [SerializeField]
    private List<TileDef> _pathTiles = new List<TileDef>();



    [SerializeField]
    private Noise _tileNoise;
    [SerializeField]
    private Noise _pathNoise;

    private void OnValidate()
    {
        AssignIDs();
    }

    public TileDef GetTerrainAt(float x, float y)
    {
        float path = _pathNoise.SimplexNoise(x, y);
        if (path > 0)
        {
            return _pathTiles[0];
        }

        float value = _tileNoise.SimplexNoise(x, y);
        if (path > -.25f)
        {
            value -= (0.25f + path) * value * value;
        }

        return _tiles[Mathf.Clamp(Mathf.FloorToInt(value * _tiles.Count), 0, _tiles.Count-1)];
    }

    public void Initialize()
    {
        AssignIDs();

        System.Random rnd = new System.Random(WorldSettings.Seed);

        _tileNoise.InitNoise(rnd.Next());
        _pathNoise.InitNoise(rnd.Next());
    }

    private void AssignIDs()
    {
        for (int i = 0; i < _tiles.Count; i++)
        {
            _tiles[i].ID = i;
        }
        for (int i = 0; i < _pathTiles.Count; i++)
        {
            _pathTiles[i].ID = i + _tiles.Count;
        }
    }

    public TileDef GetTerrain(int terrainId)
    {
        if(terrainId < _tiles.Count) return _tiles[terrainId];

        else return _pathTiles[terrainId - _tiles.Count];
    }

    public TileDef GetTile(int id)
    {
        if (id < _tiles.Count) { return _tiles[id]; }
        else return _pathTiles[id - _tiles.Count];
    }
}