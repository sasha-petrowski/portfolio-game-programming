using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Threading;
using TMPro;

public class WorldChunk
{
    private const int Z_OFFSET = 500;

    public ChunkData ChunkData;
    public bool Generated = false;

    public Vector2Int Index;
    public ChunkArea ChunkArea { get; private set; }

    Dictionary<int, MeshData> _meshes;

    Queue<ChunkThreadInfo<ChunkData>> _chunkDataThreadInfoQueue = new Queue<ChunkThreadInfo<ChunkData>>();
    Queue<ChunkThreadInfo<Dictionary<int, MeshData>>> _meshesThreadInfoQueue = new Queue<ChunkThreadInfo<Dictionary<int, MeshData>>>();

    public void DestroyChunk()
    {
        GameObject.Destroy(ChunkArea.gameObject);
    }

    public WorldChunk(Vector2Int coo, ChunkArea chunkArea, int width, int height)
    {
        Index = coo;
        ChunkArea = chunkArea;
        ChunkArea.gameObject.transform.SetParent(WorldGenerator.Instance.transform);
        ChunkArea.gameObject.transform.position = new Vector3(
            coo.x * WorldSettings.ChunkSize,
            coo.y * WorldSettings.ChunkSize,
            0);

        ChunkArea.gameObject.transform.parent = WorldGenerator.Instance.transform;

        ChunkArea.InitialiseArea(width, height);

        RequestChunkData(OnChunkDataReceived);
    }

    public void RequestChunkData(Action<ChunkData> callback)
    {
        ThreadStart threadStart = delegate
        {
            ChunkDataThread(callback);
        };

        new Thread(threadStart).Start();
    }
    void ChunkDataThread(Action<ChunkData> callback)
    {
        ChunkData chunkData = new ChunkData(Index);
        lock (_chunkDataThreadInfoQueue)
        {
            _chunkDataThreadInfoQueue.Enqueue(new ChunkThreadInfo<ChunkData>(callback, chunkData));
        }

    }
    public void OnChunkDataReceived(ChunkData chunkData)
    {
        this.ChunkData = chunkData;
        RequestChunkMeshes(OnChunkMeshesReceived);
    }
    public void RequestChunkMeshes(Action<Dictionary<int, MeshData>> callback)
    {
        ThreadStart threadStart = delegate
        {
            ChunkMeshesThread(callback);
        };
        new Thread(threadStart).Start();
    }
    void ChunkMeshesThread(Action<Dictionary<int, MeshData>> callback)
    {
        Dictionary<int, MeshData> meshes = GenerateMesh();
        lock (_meshesThreadInfoQueue)
        {
            _meshesThreadInfoQueue.Enqueue(new ChunkThreadInfo<Dictionary<int, MeshData>>(callback, meshes));
        }
    }
    public void OnChunkMeshesReceived(Dictionary<int, MeshData> meshes)
    {
        _meshes = meshes;
        foreach (MeshData meshData in _meshes.Values)
        {
            meshData.Build();

            TileDef tile = WorldGenerator.Instance.WorldTerrain.GetTerrain(meshData.terrainId);

            GameObject meshObject = new GameObject(tile.name);
            meshObject.transform.transform.parent = ChunkArea.transform;
            meshObject.transform.localPosition = new Vector3(0, 0, Z_OFFSET - meshData.terrainId);
            //meshObject.transform.localScale = Vector3.one * WorldSettings.ChunkSize;

            // Add a mesh filter and set the mesh to our mesh.
            MeshFilter meshFilterObject = meshObject.AddComponent<MeshFilter>();
            meshFilterObject.mesh = meshData.mesh;

            MeshRenderer meshRendererObject = meshObject.AddComponent<MeshRenderer>();
            if(tile.Material != null)
            {
                meshRendererObject.material = tile.Material;
            }
            else
            {
                meshRendererObject.material = new Material(Shader.Find("Unlit/Texture"));
            }
        }



        ChunkArea.OnGenerated(ChunkData.Tiles);
        Generated = true;
    }

    public void UpdateGeneration()
    {
        if (_chunkDataThreadInfoQueue.Count > 0)
        {
            for (int i = 0; i < _chunkDataThreadInfoQueue.Count; i++)
            {
                lock (_chunkDataThreadInfoQueue)
                {
                    ChunkThreadInfo<ChunkData> threadInfo = _chunkDataThreadInfoQueue.Dequeue();
                    threadInfo.callback(threadInfo.parameter);
                }
            }
        }
        if (_meshesThreadInfoQueue.Count > 0)
        {
            for (int i = 0; i < _meshesThreadInfoQueue.Count; i++)
            {
                lock (_meshesThreadInfoQueue)
                {
                    ChunkThreadInfo<Dictionary<int, MeshData>> threadInfo = _meshesThreadInfoQueue.Dequeue();
                    threadInfo.callback(threadInfo.parameter);
                }
            }
        }
    }
    public bool UpdateVisibility(ref Vector2Int chunkIndex)
    {
        bool visible = (Mathf.Abs(Index.x - chunkIndex.x) < WorldSettings.ChunkNumber) && (Mathf.Abs(Index.y - chunkIndex.y) < WorldSettings.ChunkNumber);
        SetVisible(visible);
        return visible;
    }
    public void SetVisible(bool visible)
    {
        ChunkArea.gameObject.SetActive(visible);
    }

    private Dictionary<int, MeshData> GenerateMesh()
    {
        Dictionary<int, MeshData> meshes = new Dictionary<int, MeshData>();
        List<int> neighboursTerrainId = new List<int>();
        int[] neighboursTerrain = new int[8];

        for(int x = 0; x < WorldSettings.ChunkSize; x++)
        {
            for(int y = 0; y < WorldSettings.ChunkSize; y++)
            {
                neighboursTerrainId.Clear();
                MeshData meshData = this.GetMesh(meshes, ChunkData.Tiles[x, y]); // Get or create a new mesh

                // Get the verticeIndex, it's just the vertice count in our MeshData object.
                int verticeIndex = meshData.vertices.Count;
                meshData.vertices.Add(new Vector3(x, y)); // Vertice 0 (check image)
                meshData.vertices.Add(new Vector3(x, y + 1)); // Vertice 1
                meshData.vertices.Add(new Vector3(x + 1, y + 1)); // Vertice 2
                meshData.vertices.Add(new Vector3(x + 1, y)); // Vertice 3

                meshData.colors.Add(Color.white);
                meshData.colors.Add(Color.white);
                meshData.colors.Add(Color.white);
                meshData.colors.Add(Color.white);

                meshData.AddTriangle(verticeIndex, 0, 1, 2); // TriangleA
                meshData.AddTriangle(verticeIndex, 0, 2, 3); // TriangleB

                for (int i = 0; i < 8; i++)
                { // We have a max of 8 neighbours.
                  // Let's get the neighbours with our Direction utility.
                    neighboursTerrain[i] = ChunkData.Tiles[x, y];
                    Vector2Int target = new Vector2Int(x, y) + ((WorldDirection)i).Direction();
                    if(target.x >= 0 && target.y >= 0 && target.x < WorldSettings.ChunkSize && target.y < WorldSettings.ChunkSize)
                    {
                       int neighbour = ChunkData.Tiles[target.x, target.y];
                       // If the neighbour is not null, we will set neighboursTerrain to the neighbour terrain type.
                       neighboursTerrain[i] = neighbour;
                       if (
                           neighbour != ChunkData.Tiles[x, y] && // We add only if its different than current tile.
                           !neighboursTerrainId.Contains(neighbour) && // If it's not already in the list we add to it.
                           neighbour >= ChunkData.Tiles[x, y] // And we only blend when we're on top.
                       )
                       {
                           neighboursTerrainId.Add(neighbour);
                       }
                    }
                    else
                    {
                        // If its outside the chunk we blend just in case.
                        neighboursTerrain[i] = 0;
                    }
                }

                foreach (int id in neighboursTerrainId)
                {
                    DrawNeigbour(meshes, neighboursTerrain, id, x, y); 
                }
            }
        }
        DrawBlendedEdges(meshes);
        return meshes;
    }

    private void DrawBlendedEdges(Dictionary<int, MeshData> meshes)
    {
        int[] neighboursTerrain = new int[8];
        int id;

        neighboursTerrain[0] = -1;
        neighboursTerrain[1] = -1;
        neighboursTerrain[2] = -1;
        neighboursTerrain[3] = -1;
        neighboursTerrain[4] = -1;
        neighboursTerrain[5] = -1;
        neighboursTerrain[6] = -1;
        neighboursTerrain[7] = -1;

        //Bottom
        for (int x = 0; x < WorldSettings.ChunkSize; x++)
        {
            neighboursTerrain[4] = ChunkData.Tiles[x, 0];
            id = neighboursTerrain[4];
            if (x > 0)
            {
                neighboursTerrain[3] = ChunkData.Tiles[x - 1, 0];
            }
            if (x < WorldSettings.ChunkSize - 1)
            {
                neighboursTerrain[5] = ChunkData.Tiles[x + 1, 0];
            }

            DrawNeigbour(meshes, neighboursTerrain, id, x, -1);
            if (id < neighboursTerrain[3])
            {
                DrawNeigbour(meshes, neighboursTerrain, neighboursTerrain[3], x, -1);
            }
            if (id < neighboursTerrain[5])
            {
                DrawNeigbour(meshes, neighboursTerrain, neighboursTerrain[5], x, -1);
            }
            neighboursTerrain[3] = -1;
            neighboursTerrain[5] = -1;
        }
        neighboursTerrain[4] = -1;

        //Top
        for (int x = 0; x < WorldSettings.ChunkSize; x++)
        {
            neighboursTerrain[0] = ChunkData.Tiles[x, WorldSettings.ChunkSize - 1];
            id = neighboursTerrain[0];
            if (x > 0)
            {
                neighboursTerrain[1] = ChunkData.Tiles[x - 1, WorldSettings.ChunkSize - 1];
            }
            if (x < WorldSettings.ChunkSize - 1)
            {
                neighboursTerrain[7] = ChunkData.Tiles[x + 1, WorldSettings.ChunkSize - 1];
            }

            DrawNeigbour(meshes, neighboursTerrain, id, x, WorldSettings.ChunkSize);
            if (id < neighboursTerrain[1])
            {
                DrawNeigbour(meshes, neighboursTerrain, neighboursTerrain[1], x, WorldSettings.ChunkSize);
            }
            if (id < neighboursTerrain[7])
            {
                DrawNeigbour(meshes, neighboursTerrain, neighboursTerrain[7], x, WorldSettings.ChunkSize);
            }
            neighboursTerrain[1] = -1;
            neighboursTerrain[7] = -1;
        }
        neighboursTerrain[0] = -1;

        //Left
        for (int y = 0; y < WorldSettings.ChunkSize; y++)
        {
            neighboursTerrain[6] = ChunkData.Tiles[0, y];
            id = neighboursTerrain[6];
            if (y > 0)
            {
                neighboursTerrain[7] = ChunkData.Tiles[0, y - 1];
            }
            if (y < WorldSettings.ChunkSize - 1)
            {
                neighboursTerrain[5] = ChunkData.Tiles[0, y + 1];
            }

            DrawNeigbour(meshes, neighboursTerrain, id, -1, y);
            if (id < neighboursTerrain[7])
            {
                DrawNeigbour(meshes, neighboursTerrain, neighboursTerrain[7], -1, y);
            }
            if (id < neighboursTerrain[5])
            {
                DrawNeigbour(meshes, neighboursTerrain, neighboursTerrain[5], -1, y);
            }
            neighboursTerrain[7] = -1;
            neighboursTerrain[5] = -1;
        }
        neighboursTerrain[6] = -1;

        //Right
        for (int y = 0; y < WorldSettings.ChunkSize; y++)
        {
            neighboursTerrain[2] = ChunkData.Tiles[WorldSettings.ChunkSize - 1, y];
            id = neighboursTerrain[2];
            if (y > 0)
            {
                neighboursTerrain[1] = ChunkData.Tiles[WorldSettings.ChunkSize - 1, y - 1];
            }
            if (y < WorldSettings.ChunkSize - 1)
            {
                neighboursTerrain[3] = ChunkData.Tiles[WorldSettings.ChunkSize - 1, y + 1];
            }
            DrawNeigbour(meshes, neighboursTerrain, id, WorldSettings.ChunkSize, y);
            if (id < neighboursTerrain[1])
            {
                DrawNeigbour(meshes, neighboursTerrain, neighboursTerrain[1], WorldSettings.ChunkSize, y);
            }
            if (id < neighboursTerrain[3])
            {
                DrawNeigbour(meshes, neighboursTerrain, neighboursTerrain[3], WorldSettings.ChunkSize, y);
            }
            neighboursTerrain[1] = -1;
            neighboursTerrain[3] = -1;
        }
        neighboursTerrain[2] = -1;

        //Bottom left
        neighboursTerrain[5] = ChunkData.Tiles[0, 0];
        DrawNeigbour(meshes, neighboursTerrain, ChunkData.Tiles[0, 0], -1, -1);
        neighboursTerrain[5] = -1;
        
        //Top left
        neighboursTerrain[7] = ChunkData.Tiles[0, WorldSettings.ChunkSize - 1];
        DrawNeigbour(meshes, neighboursTerrain, ChunkData.Tiles[0, WorldSettings.ChunkSize - 1], -1, WorldSettings.ChunkSize);
        neighboursTerrain[7] = -1;
        
        //Top right
        neighboursTerrain[3] = ChunkData.Tiles[WorldSettings.ChunkSize - 1, 0];
        DrawNeigbour(meshes, neighboursTerrain, ChunkData.Tiles[WorldSettings.ChunkSize - 1, 0], WorldSettings.ChunkSize, -1);
        neighboursTerrain[3] = -1;
        
        //Bottom right
        neighboursTerrain[1] = ChunkData.Tiles[WorldSettings.ChunkSize - 1, WorldSettings.ChunkSize - 1];
        DrawNeigbour(meshes, neighboursTerrain, ChunkData.Tiles[WorldSettings.ChunkSize - 1, WorldSettings.ChunkSize - 1], WorldSettings.ChunkSize, WorldSettings.ChunkSize);
        neighboursTerrain[1] = -1;
    }

    private void DrawNeigbour(Dictionary<int, MeshData> meshes, int[] neighboursTerrain, int id, int x, int y)
    {
        MeshData meshData = GetMesh(meshes, id);
        int verticeIndex = meshData.vertices.Count;
        Color[] cols = new Color[4];

        meshData.vertices.Add(new Vector3(x, y)); //0
        meshData.vertices.Add(new Vector3(x + 1, y)); //1
        meshData.vertices.Add(new Vector3(x, y + 1)); //2
        meshData.vertices.Add(new Vector3(x + 1, y + 1)); //3

        for (int i = 0; i < cols.Length; i++)
        {
            cols[i] = Color.clear;
        }
        for (int i = 0; i < 8; i++)
        {
            if (id == neighboursTerrain[i])
            {
                switch (i)
                {
                    //Corners
                    case 1: // South West
                        cols[0] = Color.white;
                        break;
                    case 3: // North West
                        cols[2] = Color.white;
                        break;
                    case 5: // North East
                        cols[3] = Color.white;
                        break;
                    case 7: // South East
                        cols[1] = Color.white;
                        break;

                    //Sides
                    case 0: // South
                        cols[1] = Color.white;
                        cols[0] = Color.white;
                        break;
                    case 2:  // West
                        cols[0] = Color.white;
                        cols[2] = Color.white;
                        break;
                    case 4: // North
                        cols[2] = Color.white;
                        cols[3] = Color.white;
                        break;
                    case 6: // East
                        cols[3] = Color.white;
                        cols[1] = Color.white;
                        break;
                }
            }
        }
        meshData.colors.AddRange(cols);
        meshData.AddTriangle(verticeIndex, 3, 1, 0);
        meshData.AddTriangle(verticeIndex, 0, 2, 3);
    }

    public MeshData GetMesh(Dictionary<int, MeshData> meshes, int tileId)
    {
        if (meshes.ContainsKey(tileId))
        {
            return meshes[tileId];
        }
        meshes.Add(tileId, new MeshData(tileId));
        return meshes[tileId];
    }
    struct ChunkThreadInfo<T>
    {
        public readonly Action<T> callback;
        public readonly T parameter;

        public ChunkThreadInfo(Action<T> callback, T parameter)
        {
            this.callback = callback;
            this.parameter = parameter;
        }
    }
}

public struct ChunkData
{
    public int[,] Tiles;

    public ChunkData(Vector2Int chunkPosition)
    {
        Tiles = new int[WorldSettings.ChunkSize, WorldSettings.ChunkSize];
        for (int x = 0; x < WorldSettings.ChunkSize; x++)
        {
            for (int y = 0; y < WorldSettings.ChunkSize; y++)
            {
                TileDef tile = WorldGenerator.Instance.WorldTerrain.GetTerrainAt(x + chunkPosition.x * WorldSettings.ChunkSize, y + chunkPosition.y * WorldSettings.ChunkSize);

                Tiles[x, y] = tile.ID;
            }
        }
    }
}