﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
public static class WorldUtility
{
    public static Vector2Int ChunkIndexAt(Vector2 worldPosition)
    {
        return new Vector2Int(Mathf.FloorToInt(worldPosition.x / WorldSettings.ChunkSize), Mathf.FloorToInt(worldPosition.y / WorldSettings.ChunkSize));
    }

    public static Vector2Int IntersectionIndexAt(Vector2 worldPosition)
    {
        return new Vector2Int(Mathf.FloorToInt((worldPosition.x + (WorldSettings.ChunkSize / 2)) / WorldSettings.ChunkSize), Mathf.FloorToInt((worldPosition.y + (WorldSettings.ChunkSize / 2)) / WorldSettings.ChunkSize));
    }


    public static bool SpiralChunkSearch(bool ignoreFirst, Vector2Int startIndex, Func<Vector2Int, bool> searchFunction)
    {
        return GridUtility.NaiveSpiralSearch(ignoreFirst, startIndex, Caravan.s_PlayerCenterChunkIndex, WorldSettings.ChunkNumber, WorldSettings.ChunkNumber, searchFunction);
    }

    public static bool SpiralChunkSearch<T>(bool ignoreFirst, Vector2Int startIndex, Func<Vector2Int, T, bool> searchFunction, T arg)
    {/*
        Debug.Log(
            $"ignoreFirst {ignoreFirst}\n" +
            $"startIndex {startIndex}\n" +
            $"CenterChunkIndex {Caravan.s_PlayerCenterChunkIndex}\n" +
            $"WorldSettings.ChunkNumber{WorldSettings.ChunkNumber}\n" +
            $"searchFunction {searchFunction.Method.Name}\n" +
            $"arg {arg}\n");
        */
        return GridUtility.NaiveSpiralSearch(ignoreFirst, startIndex, Caravan.s_PlayerCenterChunkIndex, WorldSettings.ChunkNumber, WorldSettings.ChunkNumber, searchFunction, arg);
    }

    public static bool SpiralChunkSearch<T>(Entity from, Func<Vector2Int, T, bool> searchFunction, T arg)
    {
        ChunkArea chunk;
        if (from.Parent.Area is BuildingArea buildArea)
        {
            if (buildArea.GiantEntity == null) return false;

            chunk = buildArea.GiantEntity.Parent.Area as ChunkArea;
        }
        else
        {
            chunk = from.Parent.Area as ChunkArea;
        }

        return GridUtility.NaiveSpiralSearch(false, chunk.ChunkIndex, Caravan.s_PlayerCenterChunkIndex, WorldSettings.ChunkNumber, WorldSettings.ChunkNumber, searchFunction, arg);
    }
    public static bool SpiralChunkSearch(Entity from, Func<Vector2Int, bool> searchFunction)
    {
        ChunkArea chunk;
        if (from.Parent.Area is BuildingArea buildArea)
        {
            chunk = buildArea.GiantEntity.Parent.Area as ChunkArea;
        }
        else
        {
            chunk = from.Parent.Area as ChunkArea;
        }

        return GridUtility.NaiveSpiralSearch(false, chunk.ChunkIndex, Caravan.s_PlayerCenterChunkIndex, WorldSettings.ChunkNumber, WorldSettings.ChunkNumber, searchFunction);
    }
}
