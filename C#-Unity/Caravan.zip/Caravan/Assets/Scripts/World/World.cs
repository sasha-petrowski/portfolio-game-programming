﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
public class World
{
    public static World s_Instance { get; private set; }

    private static readonly Vector2Int[] ChunkIntersectionTransform = { new Vector2Int(0, 0), new Vector2Int(1, 1), new Vector2Int(1, 0), new Vector2Int(0, 1) };


    public Dictionary<Vector2Int, ChunkArea> ChunkAreas;


    public World()
    {
        if (s_Instance == null)
        {
            s_Instance = this;
        }
        else
        {
            Debug.LogError("Error : World : s_Instance is already set : Creation of a second unallowed World");
        }

        ChunkAreas = new Dictionary<Vector2Int, ChunkArea>(WorldSettings.ChunkSize * WorldSettings.ChunkSize);

    }


    public AreaTile GetTileAt(Vector2Int index)
    {
        Vector2Int chunkindex = index / WorldSettings.ChunkSize;

        if (index.x < 0 && index.x % WorldSettings.ChunkSize != 0) chunkindex.x--;
        if (index.y < 0 && index.y % WorldSettings.ChunkSize != 0) chunkindex.y--;

        //Debug.Log($"worldI.{index}, chunkI.{chunkindex}, tileI.{new Vector2Int((WorldSettings.ChunkSize + (index.x % WorldSettings.ChunkSize)) % WorldSettings.ChunkSize, (WorldSettings.ChunkSize + (index.y % WorldSettings.ChunkSize)) % WorldSettings.ChunkSize)}");

        ChunkArea area = GetChunkAtIndex(chunkindex);
        if(area == null) return null;

        return area.Tiles[(WorldSettings.ChunkSize + (index.x % WorldSettings.ChunkSize)) % WorldSettings.ChunkSize, (WorldSettings.ChunkSize + (index.y % WorldSettings.ChunkSize)) % WorldSettings.ChunkSize];
    }
    public ChunkArea GetChunkAt(Vector2 worldPosition)
    {
        return GetChunkAtIndex(WorldUtility.ChunkIndexAt(worldPosition));
    }
    public ChunkArea GetChunkAtIndex(Vector2Int chunkIndex)
    {
        if (ChunkAreas.ContainsKey(chunkIndex))
            return ChunkAreas[chunkIndex];
        return null;
    }

    public List<ChunkArea> GetIntersectionAt(Vector2 worldPosition)
    {
        return GetIntersectionAtIndex(WorldUtility.IntersectionIndexAt(worldPosition));
    }
    public List<ChunkArea> GetIntersectionAtIndex(Vector2Int index)
    {
        List<ChunkArea> chunks = new List<ChunkArea>(4);

        for (int i = 0; i < ChunkIntersectionTransform.Length; i++)
        {
            if (ChunkAreas.ContainsKey(index - ChunkIntersectionTransform[i]))
            {
                chunks.Add(ChunkAreas[index - ChunkIntersectionTransform[i]]);
            }
        }
        return chunks;
    }
}
