﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Unity.VisualScripting;

public static class CaravanUtility
{
    public static BuildingArea GetClosestBuildingArea(Caravan caravan, Vector2 worldPosition)
    {
        float bestMagnitude = float.MaxValue;
        BuildingArea bestArea = null;
        foreach (GiantCreature giant in caravan.GiantEntities)
        {
            if (giant.BuildingArea != null)
            {
                float magnitude = (worldPosition.x - giant.transform.position.x) * (worldPosition.x - giant.transform.position.x) + (worldPosition.y - giant.transform.position.y) * (worldPosition.y - giant.transform.position.y);
                if (bestMagnitude > magnitude)
                {
                    bestMagnitude = magnitude;
                    bestArea = giant.BuildingArea;
                }
            }
        }
        return bestArea;
    }


    public static BuildingArea[] GetClosestBuildingAreas(Caravan caravan, Vector2 worldPosition)
    {
        BuildingArea[] areaArray = new BuildingArea[caravan.BuildingAreas.Count];
        float[] magnitudes = new float[caravan.BuildingAreas.Count];

        LinkedListNode<BuildingArea> area = caravan.BuildingAreas.First;
        for (int i = 0; i < caravan.BuildingAreas.Count; i++)
        {
            areaArray[i] = area.Value;
            magnitudes[i] = (worldPosition.x - areaArray[i].transform.position.x) * (worldPosition.x - areaArray[i].transform.position.x) + (worldPosition.y - areaArray[i].transform.position.y) * (worldPosition.y - areaArray[i].transform.position.y);
            area = area.Next;
        }

        if (areaArray.Length > 0)
        {
            float tmp_m;
            BuildingArea tmp_a;
            for (int i = 0; i < areaArray.Length; i++)
            {
                for (int n = i + 1; n < areaArray.Length; n++)
                {
                    // Sort by distance
                    if (magnitudes[i] > magnitudes[n])
                    {
                        tmp_m = magnitudes[i];
                        tmp_a = areaArray[i];

                        magnitudes[i] = magnitudes[n];
                        areaArray[i] = areaArray[n];

                        magnitudes[n] = tmp_m;
                        areaArray[n] = tmp_a;
                    }
                }
            }
        }
        return areaArray;
    }
    public static IEnumerable<Area> ClosestBuildingAreas(Caravan caravan, Vector2 from)
    {
        BuildingArea[] areaArray = new BuildingArea[caravan.BuildingAreas.Count];
        float[] magnitudes = new float[caravan.BuildingAreas.Count];

        LinkedListNode<BuildingArea> current = caravan.BuildingAreas.First;
        BuildingArea area;
        int index = 0;
        while (current != null)
        {
            area = current.Value;
            areaArray[index] = area;
            magnitudes[index] = (from - (Vector2)area.transform.position).sqrMagnitude;
            //(from.x - area.transform.position.x) * (from.x - area.transform.position.x) + (from.y - area.transform.position.y) * (from.y - area.transform.position.y);

            index++;
            current = current.Next;
        }

        if (areaArray.Length > 0)
        {
            float bestMagnitude;
            for (int i = 0; i < areaArray.Length; i++)
            {
                index = i;
                bestMagnitude = magnitudes[i];
                for (int n = i + 1; n < areaArray.Length; n++)
                {
                    // set best by distance
                    if (bestMagnitude > magnitudes[n])
                    {
                        bestMagnitude = magnitudes[n];
                        index = n;
                    }
                }

                // Sort by distance

                area = areaArray[index];

                yield return area; // enumerate next closest

                magnitudes[index] = magnitudes[i];
                areaArray[index] = areaArray[i];

                magnitudes[i] = bestMagnitude;
                areaArray[i] = area;
            }
        }
    }
}
