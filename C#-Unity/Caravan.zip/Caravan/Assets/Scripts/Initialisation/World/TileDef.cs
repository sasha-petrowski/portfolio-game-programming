using UnityEngine;


[CreateAssetMenu(fileName = "Tile", menuName = "Defs/World/Tile")]
public class TileDef : ScriptableObject
{
    [HideInInspector]
    public int ID;


    public Color Color = Color.white;
    public Material Material;

    [Min(0)]
    [SerializeField]
    private int _entityChance;

    [SerializeField]
    private InstantiableDef[] _entities = new InstantiableDef[0];

    public bool EntityChance() => _entities.Length > 0 & _entityChance > 0 && Random.Range(0, 100) <= _entityChance;
    public InstantiableDef GetRandomEntity() => _entities[Random.Range(0, _entities.Length)];
}