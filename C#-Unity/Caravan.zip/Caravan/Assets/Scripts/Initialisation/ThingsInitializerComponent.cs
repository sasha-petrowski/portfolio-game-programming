﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class ThingsInitializerComponent : MonoBehaviour
{
    private void Awake()
    {
        ThingsInitializer.QuickInitDefs();
        Destroy(this);
    }
}