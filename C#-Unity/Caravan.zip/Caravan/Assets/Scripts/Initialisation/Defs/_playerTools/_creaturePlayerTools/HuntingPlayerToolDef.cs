public class HuntingPlayerToolDef : CreaturePlayerToolDef
{
    public override PlayerToolCategory ToolCategory => PlayerToolCategory.Order;

    protected override bool IsCreatureValid(Creature creature)
    {
        if (creature == null) return false;

        foreach (JobTarget target in creature.JobTargets)
        {
            if (target.CanAddJob() & target is HuntingJobTarget) return true;
        }
        return false;
    }
    protected override void ApplyTo(Creature creature)
    {
        if (creature == null) return;

        foreach (JobTarget target in creature.JobTargets)
        {
            if (target.CanAddJob() & target is HuntingJobTarget)
            {
                target.AddJob(creature);
                return;
            }
        }
    }
    public override string GetUITooltip() => name;
}