using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Linq;

[CreateAssetMenu(fileName = "Gather Tool", menuName = "Defs/Player/Tools/Orders/Gather")]
public class GatherPlayerToolDef : ZonePlayerToolDef
{
    [Header("Gather Tool")]
    public GatherJobTargetDef JobTargetDef;

    public override PlayerToolCategory ToolCategory => PlayerToolCategory.Order;

    protected override bool IsPartValid(AreaPart part)
    {
        if (part.Entity == null) return false;

        foreach (JobTarget target in part.Entity.JobTargets)
        {
            if(target.CanAddJob() && target is GatherJobTarget gather && gather.TargetDefs.Contains(JobTargetDef)) return true;
        }
        return false;
    }
    protected override void ApplyAt(AreaPart part)
    {
        if (part.Entity == null) return;

        foreach (JobTarget target in part.Entity.JobTargets)
        {
            if (target.CanAddJob() && target is GatherJobTarget gather && gather.TargetDefs.Contains(JobTargetDef))
            {
                target.AddJob(part.Entity);
                return;
            }
        }
    }
    public override string GetUITooltip() => name;
}
