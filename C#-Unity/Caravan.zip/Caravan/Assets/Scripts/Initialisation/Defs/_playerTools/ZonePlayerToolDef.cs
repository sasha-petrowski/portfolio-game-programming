using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public abstract class ZonePlayerToolDef : PlayerToolDef
{
    [SerializeField]
    private bool _tiles = true;

    [SerializeField]
    private bool _walls = false;

    [SerializeField]
    private bool _oncePerEntity = true;

    [SerializeField]
    private bool _onlyBuildingAreas;

    [SerializeField]
    private Sprite _zoneSprite;

    #region ITool
    protected static GameObject _preview;
    protected static GameObject _zonePreview;
    protected static List<GameObject> _previews;
    protected static Vector2Int _clickedCoordinate;
    protected static Vector2Int _hoverCoordinate;

    protected static Area _clickedArea;

    public override Sprite GetUIIcon() => Sprite;

    private void CreatePreview()
    {
        GameObject go = new GameObject("Zone Preview", typeof(SpriteRenderer));
        _previews.Add(go);

        go.GetComponent<SpriteRenderer>().sprite = Sprite;
        go.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 0.75f);
    }

    public override void OnSelect()
    {
        _preview = new GameObject("Player Tool Preview", typeof(SpriteRenderer));
        _preview.GetComponent<SpriteRenderer>().sprite = Sprite;
        _preview.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 0.75f);

        _zonePreview = new GameObject("Player Tool Zone", typeof(SpriteRenderer));
        _zonePreview.GetComponent<SpriteRenderer>().sprite = _zoneSprite;
        _zonePreview.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 0.75f);
        _zonePreview.GetComponent<SpriteRenderer>().drawMode = SpriteDrawMode.Sliced;

        _previews = new List<GameObject>();
        CreatePreview();
    }
    public override void OnQuit()
    {
        Destroy(_preview);
        Destroy(_zonePreview);

        for (int i = 0; i < _previews.Count; i++)
        {
            GameObject.Destroy(_previews[i].gameObject);
        }
        _previews.Clear();

        _clickedArea = null;
        _previews = null;
    }

    public override void PrimaryDown(Vector3 worldPosition)
    {
        //Debug.Log("Blueprint : Primary DOWN");

        _clickedArea = ThingManager.Instance.GetBuildingAreaAt(worldPosition, _clickedArea);
        if(!_onlyBuildingAreas & _clickedArea == null) 
        {
            _clickedArea = World.s_Instance.GetChunkAt(worldPosition);
        }
        if(_clickedArea != null)
        {
            _clickedCoordinate = _clickedArea.WorldToIndex(worldPosition);

            _hoverCoordinate = _clickedCoordinate;
        }
    }
    public override void PrimaryHold(Vector3 worldPosition)
    {
        if (_clickedArea != null)
        {
            Vector2Int hoverTile = _clickedArea.WorldToIndex(worldPosition);
            if(_clickedArea.IsBuildingArea())
            {
                hoverTile = _clickedArea.ClampIndex(hoverTile);
            }

            if (_hoverCoordinate != hoverTile)
            {
                _hoverCoordinate = hoverTile;
            }
        }
    }
    public override void PrimaryUp(Vector3 worldPosition)
    {
        //Debug.Log("Blueprint : Primary UP");

        if (_clickedArea != null)
        {
            HashSet<Entity> onlyOnce = new HashSet<Entity>();

            foreach (AreaPart part in ValidParts())
            {
                if(!_oncePerEntity || onlyOnce.Add(part.Entity)) ApplyAt(part);
            }

            //destroy old previews
            for (int i = 0; i < _previews.Count; i++)
            {
                GameObject.Destroy(_previews[i].gameObject);
            }
            _previews.Clear();

            CreatePreview();

            _clickedArea = null;
        }
    }
    public override void WorldPreview(Vector3 worldPosition)
    {
        _preview.transform.position = worldPosition;
        _zonePreview.SetActive(_clickedArea != null);
        int i = 0;
        if (_clickedArea != null)
        {
            _zonePreview.transform.SetLocalPositionAndRotation(_clickedArea.LocalToWorld((Vector2)(_clickedCoordinate + _hoverCoordinate) / 2f) + new Vector3(0, 0, -1), _clickedArea.transform.rotation);
            _zonePreview.GetComponent<SpriteRenderer>().size = new Vector2(Mathf.Abs(_clickedCoordinate.x - _hoverCoordinate.x) + 1, Mathf.Abs(_clickedCoordinate.y - _hoverCoordinate.y) + 1);

            foreach (AreaPart part in ValidParts())
            {
                if(_previews.Count <=  i) CreatePreview();

                _previews[i].gameObject.SetActive(true);
                _previews[i].transform.SetParent(part.Area.transform);
                _previews[i].transform.position = part.WorldPosition() + new Vector3(0, 0, -10);

                i++;
            }
        }

        for (; i < _previews.Count; i++)
        {
            _previews[i].gameObject.SetActive(false);
        }
    }
    private IEnumerable<AreaPart> ValidParts()
    {
        if(_clickedArea != null)
        {
            Vector2Int from = _clickedCoordinate;
            Vector2Int end = _hoverCoordinate;

            if (_clickedArea.IsBuildingArea())
            {
                end.x = Mathf.Clamp(end.x, 0, _clickedArea.Width - 1);
                end.y = Mathf.Clamp(end.y, 0, _clickedArea.Height - 1);
            }

            if (from.x > end.x)
            {
                int tmp = from.x;
                from.x = end.x;
                end.x = tmp;
            }
            if (from.y > end.y)
            {
                int tmp = from.y;
                from.y = end.y;
                end.y = tmp;
            }

            if (_clickedArea.IsBuildingArea())
            {
                for (int x = from.x; x <= end.x; x++)
                {
                    for (int y = from.y; y <= end.y; y++)
                    {
                        if (_tiles && IsPartValid(_clickedArea.Tiles[x, y])) yield return _clickedArea.Tiles[x, y];

                    }
                }
                if (_walls)
                {
                    AreaWall[,] horizontal = _clickedArea.Walls[0];
                    for (int x = from.x; x <= end.x; x++)
                    {
                        for (int y = from.y; y <= end.y + 1; y++)
                        {
                            if (IsPartValid(horizontal[x, y])) yield return horizontal[x, y];
                        }
                    }

                    AreaWall[,] vertical = _clickedArea.Walls[1];
                    for (int x = from.x; x <= end.x + 1; x++)
                    {
                        for (int y = from.y; y <= end.y; y++)
                        {
                            if (IsPartValid(vertical[x, y])) yield return vertical[x, y];
                        }
                    }
                }
            }
            else if(_clickedArea is ChunkArea rootChunk)
            {
                for (int x = from.x; x <= end.x; x++)
                {
                    for (int y = from.y; y <= end.y; y++)
                    {
                        if(_tiles)
                        {
                            AreaTile tile = World.s_Instance.GetTileAt((rootChunk.ChunkIndex * WorldSettings.ChunkSize) + new Vector2Int(x, y));

                            if (tile != null && IsPartValid(tile)) yield return tile;
                        }
                    }
                }
            }
        }
    }
    protected abstract bool IsPartValid(AreaPart part);
    protected abstract void ApplyAt(AreaPart part);
    #endregion

}
