using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

[CreateAssetMenu(fileName = "Haul Tool", menuName = "Defs/Player/Tools/Orders/Hauling")]
public class HaulingPlayerToolDef : ZonePlayerToolDef
{
    public override PlayerToolCategory ToolCategory => PlayerToolCategory.Order;

    protected override bool IsPartValid(AreaPart part)
    {
        if(part.Entity == null) return false;

        foreach (JobTarget target in part.Entity.JobTargets)
        {
            if (target.CanAddJob() & target is HaulingJobTarget) return true;
        }
        return false;
    }
    protected override void ApplyAt(AreaPart part)
    {
        if (part.Entity == null) return;

        foreach (JobTarget target in part.Entity.JobTargets)
        {
            if (target.CanAddJob() & target is HaulingJobTarget)
            {
                target.AddJob(part.Entity);
                return;
            }
        }
    }
    public override string GetUITooltip() => name;
}
