using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

[CreateAssetMenu(fileName = "Cancel Tool", menuName = "Defs/Player/Tools/Orders/Cancel")]
public class CancelPlayerToolDef : ZonePlayerToolDef
{
    public override PlayerToolCategory ToolCategory => PlayerToolCategory.Order;

    protected override bool IsPartValid(AreaPart part)
    {
        return part.Entity is ICancelTarget target && target.CanCancel;
    }
    protected override void ApplyAt(AreaPart part)
    {
        (part.Entity as ICancelTarget).OrderCancel();
    }
    public override string GetUITooltip() => name;
}
