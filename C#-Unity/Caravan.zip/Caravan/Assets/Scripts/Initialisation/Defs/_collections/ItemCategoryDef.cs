using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "Item Category", menuName = "Defs/Categories/Item")]
public class ItemCategoryDef : Def
{
    [HideInInspector]
    public List<ItemDef> Items = new List<ItemDef>();

    public override bool LoadDef()
    {
        if (base.LoadDef())
        {
            Item.WorldCategory.Add(this, 0);
            Item.StoredCategory.Add(this, 0);
            return true;
        }
        return false;
    }
}