using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;


[CreateAssetMenu(fileName = "Instantiable Table", menuName = "Defs/Tables/Instantiable")]
public class InstantiableTableDef : Def
{
    [System.Serializable]
    private class TableElement
    {
        public InstantiableDef Def;
        public int QuantityMin = 1;
        public int QuantityMax = 1;


        public int RandomQuantity => Random.Range(QuantityMin, QuantityMax + 1);
    }

    [SerializeField]
    private TableElement[] _elements = new TableElement[0];

    private void OnValidate()
    {
        foreach (var element in _elements)
        {
            element.QuantityMin = Mathf.Max(0, element.QuantityMin);
            element.QuantityMax = Mathf.Max(element.QuantityMin, element.QuantityMax);
        }
    }


    public void RandomInstantiate(AreaPart part, Caravan caravan = null)
    {
        TableElement element = _elements[Random.Range(0, _elements.Length)];

        element.Def.TryInstantiate(part, caravan, element.RandomQuantity);
    }

    public InstantiableDef GetRandom(out int quantity)
    {
        if (_elements.Length == 0)
        {
            quantity = 0;
            return null;
        }

        TableElement element = _elements[Random.Range(0, _elements.Length)];
        quantity = element.RandomQuantity;
        return element.Def;
    }
}
