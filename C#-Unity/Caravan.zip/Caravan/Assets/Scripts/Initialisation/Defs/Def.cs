using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using UnityEditor;
using UnityEngine;


public abstract class Def : ScriptableObject
{
    [Header("Def")]
    public Sprite Sprite;


    private static Dictionary<string, Def> _allDefs = new Dictionary<string, Def>();

    public static bool TryGetDef(string name, out Def def)
    {
        if(_allDefs.TryGetValue(name, out def))
        {
            return true;
        }
        Debug.LogError($"Couldn't find Thing : \"{name}\"");
        return false;
    }
    public virtual bool LoadDef()
    {
        if (!_allDefs.TryAdd(name, this))
        {
            Debug.LogError($"Error while loading Def : Two things cannot have the same name : ( {name} )");
            return false;
        }
        return true;
    }
}
