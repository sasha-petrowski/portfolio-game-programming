using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public abstract class PlayerToolDef : Def, ITool
{
    [Header("Player Tool")]
    public string DisplayName;


    public override bool LoadDef()
    {
        if(base.LoadDef())
        {
            ToolMenu.AddTool(this);
            return true;
        }
        return false;
    }

    #region ITool

    public abstract PlayerToolCategory ToolCategory { get; }
    public abstract void OnQuit();
    public abstract void OnSelect();
    public abstract Sprite GetUIIcon();
    public abstract void WorldPreview(Vector3 worldPosition);
    public abstract string GetUITooltip();


    public string GetName() => DisplayName;



    public virtual bool HasSecondaryEffect => false;
    public virtual void PrimaryDown(Vector3 worldPosition)
    {
    }
    public virtual void PrimaryHold(Vector3 worldPosition)
    {
    }
    public virtual void PrimaryUp(Vector3 worldPosition)
    {
    }
    public virtual void SecondaryDown(Vector3 worldPosition)
    {
    }
    public virtual void SecondaryHold(Vector3 worldPosition)
    {
    }
    public virtual void SecondaryUp(Vector3 worldPosition)
    {
    }
    public virtual void TurnLeft(Vector3 worldPosition)
    {
    }
    public virtual void TurnRight(Vector3 worldPosition)
    {
    }

    #endregion
}