using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class CraftDef : Def
{
    [Header("Craft")]
    public float CraftTime = 10;
    [SerializeReference]
    [Instantiable(type: typeof(RequiredItems))]
    public RequiredItems Materials;

    public abstract ItemDef MainProduct { get; }

    public virtual void OnFinishCraft(Creature crafter, List<ItemQuantity> ingredients, List<UniqueItem> uItems)
    {
        foreach(UniqueItem uItem in uItems)
        {
            uItem.Destroy();
        }
    }



    public virtual CraftingJob AddCraftTo(WorkbenchBuilding workbench)
    {
        return new CraftingJob(workbench, this);
    }
}
