using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Craft", menuName = "Defs/Crafts/Craft")]
public class ItemCraftDef : CraftDef
{
    [Header("Item Craft")]
    public ItemQuantity Result;

    private void OnValidate()
    {
        if (Result != null && Result.Item != null) { Sprite = Result.Item.Sprite; }
    }

    public override ItemDef MainProduct => Result.Item;

    public override void OnFinishCraft(Creature crafter, List<ItemQuantity> ingredients, List<UniqueItem> uItems)
    {
        AreaTile spot = crafter.Parent as AreaTile;
        bool hauling = false;
        int quantity = Result.Quantity;
        // haul or drop items
        while (quantity > 0)
        {
            if (hauling)
            {
                Item item = (Item)Result.Item.TryInstantiate(AreaTile.GetEmptyTile(spot), null, Mathf.Min(quantity, Result.Item.StackSize));
                quantity -= Result.Item.StackSize;
                item?.Entity?.AddHaulingJob();
            }
            else
            {
                Item item = Result.Item.InstantiateHauled(crafter, crafter.Caravan, Mathf.Min(quantity, Result.Item.StackSize));
                quantity -= Result.Item.StackSize;

                if (new HaulingJob(item).TryTakeJob(crafter) == null)
                {
                    item.Drop();
                    item.Entity.AddHaulingJob();
                }
                else hauling = true;
            }
        }


        base.OnFinishCraft(crafter, ingredients, uItems);
    }
}
