using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Butcher", menuName = "Defs/Crafts/Butcher")]
public class ButcherCraftDef : CraftDef
{
    [Header("Butcher")]
    public float Efficiency = 1;

    [SerializeField]
    private ItemDef _mainProduct;

    public override ItemDef MainProduct => _mainProduct;

    public override void OnFinishCraft(Creature crafter, List<ItemQuantity> ingredients, List<UniqueItem> uItems)
    {
        AreaTile spot = crafter.Parent as AreaTile;
        bool hauling = false;

        foreach(UniqueItem uItem in uItems)
        {
            if(uItem is CorpseItem corpse)
            {
                foreach (ItemRange range in corpse.Creature.CreatureDef.ButcherYield)
                {
                    int quantity = (int)(Random.Range(range.Min, range.Max) * Efficiency);

                    // haul or drop items
                    while (quantity > 0)
                    {
                        if (hauling)
                        {
                            Item item = (Item)range.Item.TryInstantiate(AreaTile.GetEmptyTile(spot), null, Mathf.Min(quantity, range.Item.StackSize));
                            quantity -= range.Item.StackSize;
                            item?.Entity?.AddHaulingJob();
                        }
                        else
                        {
                            Item item = range.Item.InstantiateHauled(crafter, crafter.Caravan, Mathf.Min(quantity, range.Item.StackSize));
                            quantity -= range.Item.StackSize;

                            if (new HaulingJob(item).TryTakeJob(crafter) == null)
                            {
                                item.Drop();
                                item.Entity.AddHaulingJob();
                            }
                            else hauling = true;
                        }
                    }
                }
            }
        }

        base.OnFinishCraft(crafter, ingredients, uItems);
    }

    public override CraftingJob AddCraftTo(WorkbenchBuilding workbench)
    {
        return new ButcherCraftJob(workbench, this);
    }
}
