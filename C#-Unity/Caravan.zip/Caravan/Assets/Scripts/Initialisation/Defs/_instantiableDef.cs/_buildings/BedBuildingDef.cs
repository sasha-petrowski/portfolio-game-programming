using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

[CreateAssetMenu(fileName = "Bed", menuName = "Defs/Instantiable/Buildings/Bed")]
public class BedBuildingDef : BuildingDef
{
    [Header("Bed")]
    public float RestFactor = 1;

    public override Type InstantiateType => typeof(BedBuilding);
    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int direction)
    {
        BedBuilding building = thing as BedBuilding;

        building.RestFactor = RestFactor;

        base.Instantiate(thing, part, caravan, direction);
    }
}
