using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

[CreateAssetMenu(fileName = "Resource", menuName = "Defs/Instantiable/Resource/Resource")]
public class ResourceEntityDef : EntityDef, IWithCrossTime
{
    [Header("Resource")]
    [SerializeField]
    public float _crossTime = 1;
    public float CrossTime => _crossTime;

    public Sprite[] SpriteVariation;

    public ItemQuantity[] Drops = new ItemQuantity[0];

    public GatherJobTargetDef[] GatherTypes = new GatherJobTargetDef[0];

    public bool RandomOffset = true;

    private void OnValidate()
    {
        if(_crossTime <= 0) _crossTime = -1;
    }

    public override bool CanInstantiate(AreaPart part, Caravan caravan, int direction)
    {
        return part.IsEmpty();
    }
    public override Type InstantiateType => typeof(ResourceEntity);


    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int direction)
    {
        ResourceEntity resource = thing as ResourceEntity;

        resource.ResourceDef = this;

        // Add Gather job targets
        resource.TryAddTarget(new GatherJobTarget(GatherTypes));


        base.Instantiate(thing, part, caravan, direction);

        if(SpriteVariation != null && SpriteVariation.Length > 1) 
        { 
            thing.GetComponent<SpriteRenderer>().sprite = SpriteVariation[UnityEngine.Random.Range(0, SpriteVariation.Length)];
        }

        if(CrossTime < 0) part.UpdatePart();
    }
}
