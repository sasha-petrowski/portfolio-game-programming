using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class GiantDef : CreatureDef
{
    [Header("Giant")]
    public int Width = 2;
    public int Height = 4;

    public Vector2Int MaxAreaSize = new Vector2Int(7, 5);
    public Vector2 AreaOffset = new Vector2Int(0, -1);

    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int value)
    {
        base.Instantiate(thing, part, caravan, value);

        GiantCreature creature = thing as GiantCreature;

        creature.GiantDef = this;
    }
}
