using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Item", menuName = "Defs/Instantiable/Items/Item")]
public class ItemDef : InstantiableDef
{
    [Header("Item")]
    public bool ShowItemCount = true;
    public int StackSize;
    public ItemCategoryDef[] Categories = new ItemCategoryDef[0];

    public override bool LoadDef()
    {
        if(base.LoadDef())
        {
            Item.WorldQuantity.Add(this, 0);
            Item.StoredQuantity.Add(this, 0);
            return true;
        }
        return false;
    }

    public override bool CanInstantiate(AreaPart part, Caravan caravan, int quantity)
    {
        return part is AreaTile & part.IsEmpty();
    }
    public override Type InstantiateType => typeof(Item);
    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int quantity)
    {
        base.Instantiate(thing, part, caravan, quantity);

        Item item = thing as Item;

        item.ItemDef = this;
        item.Quantity = quantity <= 0 ? StackSize : quantity;
        item.Caravan = caravan;

        item.SpawnAsEntity((AreaTile)part);
    }
    public virtual Item InstantiateHauled(Creature hauler, Caravan caravan, int quantity)
    {
        GameObject go = new GameObject(name, typeof(SpriteRenderer), InstantiateType);

        Item item = go.GetComponent<Item>();
        item.ItemDef = this;
        item.Quantity = quantity <= 0 ? StackSize : quantity;
        item.Caravan = caravan;

        SpriteRenderer renderer = go.GetComponent<SpriteRenderer>();
        renderer.sprite = Sprite;

        item.Take(hauler, this, quantity);

        return item;
    }
}
