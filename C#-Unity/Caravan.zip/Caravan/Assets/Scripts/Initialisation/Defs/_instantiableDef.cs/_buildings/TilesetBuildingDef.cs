using System;
using UnityEngine;

[CreateAssetMenu(fileName = "Tile", menuName = "Defs/Instantiable/Buildings/Tile")]
public class TilesetBuildingDef : BuildingDef
{
    [Header("Tile")]
    public Sprite All;
    public Sprite Bottom;
    public Sprite Top;
    public Sprite Left;
    public Sprite Right;
    [Space]
    public Sprite BottomLeft;
    public Sprite BottomRight;
    public Sprite TopLeft;
    public Sprite TopRight;
    [Space]
    public Sprite TopBottom;
    public Sprite LeftRight;
    [Space]
    public Sprite ThreeBottom;
    public Sprite ThreeTop;
    public Sprite ThreeLeft;
    public Sprite ThreeRight;

    private void OnValidate()
    {
        if(Shape == null || Shape.GetType() != typeof(TileBuilding)) Shape = new TileBuilding();
        if (_crossTime <= 0) _crossTime = -1;
    }

    public override Type InstantiateType => typeof(TilesetBuilding);
}
