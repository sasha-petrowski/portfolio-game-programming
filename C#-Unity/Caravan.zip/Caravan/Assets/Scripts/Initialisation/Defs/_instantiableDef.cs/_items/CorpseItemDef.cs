using System;
using UnityEngine;

[CreateAssetMenu(fileName = "CorpseType", menuName = "Defs/Instantiable/Corpse Type")]
public class CorpseItemDef : ItemDef
{
    public override Type InstantiateType => typeof(CorpseItem);

    public override bool CanInstantiate(AreaPart part, Caravan caravan, int quantity)
    {
        Debug.LogWarning("Cannot directly instantiate CorpseItem");
        return false;
    }
}