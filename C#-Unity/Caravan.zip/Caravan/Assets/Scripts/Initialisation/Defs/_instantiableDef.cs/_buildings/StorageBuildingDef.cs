using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

[CreateAssetMenu(fileName = "Storage", menuName = "Defs/Instantiable/Buildings/Storage")]
[System.Serializable]
public class StorageBuildingDef : BuildingDef
{
    [Header("Storage")]
    [SerializeField]
    private int _capacity = 8;

    public override Type InstantiateType => typeof(StorageBuilding);
    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int direction)
    {
        StorageBuilding building = thing as StorageBuilding;

        building.Capacity = _capacity;

        base.Instantiate(thing, part, caravan, direction);
    }
}
