using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;


public abstract class EntityDef : InstantiableDef
{
    [Header("Entity")]
    public int MaxHealth = 100;

    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int value)
    {
        base.Instantiate(thing, part, caravan, value);

        Entity entity = thing as Entity;

        entity.Caravan = caravan;

        entity.Health = MaxHealth;

        entity.SpawnAt(part);
    }
}
