using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class CreatureDef : EntityDef
{
    [Header("Creature")]
    public CorpseItemDef CorpseDef;
    public Sprite DeathSprite;

    public float MoveSpeed = 5;

    public float BodySize = 1;
    public float CorpseNutrition = 250;
    public List<ItemRange> ButcherYield = new List<ItemRange>();
    public List<NeedDef> Needs = new List<NeedDef>();

    public ParticleSystem SleepParticles;

    public Vector3 CooldownOffset = new Vector3(0, 0, -1);
    public Sprite CooldownSprite;

    public ItemCategoryDef HealingCategory;


    public override bool CanInstantiate(AreaPart part, Caravan caravan, int value)
    {
        return part is AreaTile & part.CrossTime() >= 0;
    }
    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int value)
    {
        base.Instantiate(thing, part, caravan, value);

        Creature creature = thing as Creature;

        creature.CreatureDef = this;

        creature.MoveSpeed = MoveSpeed;


        foreach (NeedDef need in Needs)
        {
            need.AddTo(creature);
        }


        creature.SleepParticules = GameObject.Instantiate(SleepParticles.gameObject, creature.transform).GetComponent<ParticleSystem>();

        creature.CooldownSprite = new GameObject("cooldown").AddComponent<SpriteRenderer>();
        creature.CooldownSprite.sprite = CooldownSprite;
        creature.CooldownSprite.transform.parent = creature.transform;
        creature.CooldownSprite.transform.localPosition = CooldownOffset;
        creature.CooldownSprite.transform.rotation = creature.transform.rotation;
        creature.CooldownSprite.enabled = false;


        creature.SpawnAt(part);
    }

    public void TryInstantiateCorpse(AreaTile areaTile)
    {

    }
}
