using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Giant Animal", menuName = "Defs/Instantiable/Creatures/Giant Animal")]
public class GiantAnimalDef : GiantDef
{
    public override Type InstantiateType => typeof(GiantAnimal);
    public override bool CanInstantiate(AreaPart part, Caravan caravan, int value)
    {
        return part is AreaTile;
    }
}
