using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;


public abstract class InstantiableDef : Def
{
    public Thing TryInstantiate(AreaPart part, Caravan caravan = null, int value = 0)
    {
        if (part != null && CanInstantiate(part, caravan, value))
        {
            Thing thing = new GameObject(EntityName, typeof(SpriteRenderer), InstantiateType).GetComponent<Thing>();

            Instantiate(thing, part, caravan, value);

            return thing;
        }
        return null;
    }
    public Thing TryInstantiate(Vector2 position, Caravan caravan = null, int value = 0)
    {
        if(ThingManager.Instance.TryGetTileAt(position, out var tile) && CanInstantiate(tile, caravan, value))
        {
            Thing thing = new GameObject(EntityName, typeof(SpriteRenderer), InstantiateType).GetComponent<Thing>();

            Instantiate(thing, tile, caravan, value);

            return thing;
        }
        return null;
    }

    public abstract Type InstantiateType { get; }
    public virtual string EntityName => name;
    public virtual void Instantiate(Thing thing, AreaPart part, Caravan caravan, int value)
    {
        thing.Caravan = caravan;

        SpriteRenderer renderer = thing.GetComponent<SpriteRenderer>();
        renderer.sprite = Sprite;
    }
    public abstract bool CanInstantiate(AreaPart part, Caravan caravan, int value);
}
