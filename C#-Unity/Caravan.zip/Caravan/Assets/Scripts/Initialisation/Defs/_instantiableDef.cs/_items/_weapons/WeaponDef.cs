using System;
using UnityEngine;

public abstract class WeaponDef : ItemDef
{
    [Header("Weapon")]
    [Min(0f)]
    public float AttackCooldown = 1;
    [Min(1)]
    public int AttackDamage = 15;
    [Space]
    [Min(0f)]
    public float AttackAnimation = 0.5f;
    [Space]
    public Quaternion SheathedRotation;
    public Vector2 SheathedPosition = new Vector2(0f, -.4f);
    [Space]
    public Quaternion DrawnRotation;
    public Vector2 DrawnPosition = new Vector2(.5f, .25f);
    [Space]
    public Quaternion AttackRotation;
    public Vector2 AttackPosition = new Vector2(.25f, .75f);

    [HideInInspector]
    public float DPS;

    public override abstract Type InstantiateType { get; }

    private void OnValidate()
    {
        DPS = AttackDamage / AttackCooldown;
    }
}