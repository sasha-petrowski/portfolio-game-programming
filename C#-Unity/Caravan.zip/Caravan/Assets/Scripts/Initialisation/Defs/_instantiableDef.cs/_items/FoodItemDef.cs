using System;
using UnityEngine;

[CreateAssetMenu(fileName = "Food", menuName = "Defs/Instantiable/Items/Food")]
public class FoodItemDef : ItemDef
{
    [Header("Food")]
    public int Nutrition = 5;


    public override Type InstantiateType => typeof(FoodItem);
    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int quantity)
    {
        FoodItem food = thing as FoodItem;

        food.FoodDef = this;

        base.Instantiate(thing, part, caravan, quantity);
    }

    public override Item InstantiateHauled(Creature hauler, Caravan caravan, int quantity)
    {
        FoodItem food = base.InstantiateHauled(hauler, caravan, quantity) as FoodItem;

        food.FoodDef = this;

        return food;
    }
}