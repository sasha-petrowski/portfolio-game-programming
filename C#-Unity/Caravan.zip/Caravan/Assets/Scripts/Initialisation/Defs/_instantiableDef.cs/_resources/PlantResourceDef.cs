using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

[CreateAssetMenu(fileName = "Plant", menuName = "Defs/Instantiable/Resource/Plant")]
public class PlantResourceDef : ResourceEntityDef
{
    [Header("Plant")]
    public float Nutrition = 5;

    public ItemCategoryDef[] NutritionType = new ItemCategoryDef[0];

    public override Type InstantiateType => typeof(PlantResourceEntity);

    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int direction)
    {
        PlantResourceEntity resource = thing as PlantResourceEntity;

        resource.PlantResourceDef = this;

        base.Instantiate(thing, part, caravan, direction);
    }
}
