using System;
using UnityEngine;

[CreateAssetMenu(fileName = "Melee Weapon", menuName = "Defs/Instantiable/Items/Weapons/Melee")]
public class MeleeWeaponDef : WeaponDef
{
    public override Type InstantiateType => typeof(MeleeWeapon);

    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int quantity)
    {
        MeleeWeapon weapon = thing as MeleeWeapon;

        weapon.MeleeWeaponDef = this;

        base.Instantiate(thing, part, caravan, quantity);
    }
    public override Item InstantiateHauled(Creature hauler, Caravan caravan, int quantity)
    {
        MeleeWeapon weapon = base.InstantiateHauled(hauler, caravan, quantity) as MeleeWeapon;

        weapon.MeleeWeaponDef = this;

        return weapon;
    }
}