using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

[CreateAssetMenu(fileName = "Building", menuName = "Defs/Instantiable/Buildings/Building")]
public class BuildingDef : EntityDef, IWithCrossTime
{
    [Header("Building")]
    [SerializeField]
    private bool _createBuildingTool = true;

    public bool CanRotate;
    public float BuildTime = 1;

    [SerializeField]
    public float _crossTime = 1;
    public float CrossTime => _crossTime;

    [SerializeReference]
    [Instantiable(type: typeof(BuildingShape))]
    public BuildingShape Shape;

    public RequiredItemQuantity Materials;

    public override bool LoadDef()
    {
        if(base.LoadDef())
        {
            if(_createBuildingTool) ToolMenu.AddTool(new BuildingPlayerTool(this));

            return true;
        }
        return false;
    }
    private void OnValidate()
    {
        if(_crossTime <= 0) _crossTime = -1;
    }

    public override bool CanInstantiate(AreaPart part, Caravan caravan, int direction)
    {
        if (Shape.EachPartFrom(direction, (AreaPart part) => (part.IsEmpty()), part)) return true;
        else return false;
    }
    public override Type InstantiateType => typeof(Building);
    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int direction)
    {
        Building building = thing as Building;

        building.BuildingDef = this;
        building.IsFacing = direction;


        base.Instantiate(thing, part, caravan, direction);


        Room.CalculateRooms(part.Area);

        if (CrossTime < 0) part.UpdatePart();
    }
    private Thing InstantiateBlueprint(AreaPart part, Caravan caravan, int direction)
    {
        GameObject go = new GameObject($"{name} Blueprint", typeof(SpriteRenderer), typeof(Blueprint));

        Blueprint blueprint = go.GetComponent<Blueprint>();
        blueprint.BuildingDef = this;
        blueprint.Caravan = caravan;
        blueprint.IsFacing = direction;
        blueprint.SpawnAt(part);

        SpriteRenderer renderer = go.GetComponent<SpriteRenderer>();
        renderer.sprite = Sprite;
        renderer.color = Color.cyan;

        return blueprint;
    }
    public Thing TryPlaceBlueprint(AreaPart part, Caravan caravan, int direction)
    {
        if(Materials.Required.Length == 0) return TryInstantiate(part, caravan, direction);

        if (part != null && CanInstantiate(part, caravan, direction))
        {
            return InstantiateBlueprint(part, caravan, direction);
        }
        return null;
    }
}
