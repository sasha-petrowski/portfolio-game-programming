using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Animal", menuName = "Defs/Instantiable/Creatures/Animal")]
public class AnimalDef : CreatureDef
{
    [Header("Animal")]
    public bool IsPredator = false;
    public override Type InstantiateType => typeof(Animal);

}
