using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Humanoid", menuName = "Defs/Instantiable/Creatures/Humanoid")]
public class HumanoidDef : CreatureDef
{
    [Header("Humanoid")]
    public Vector3 BGOffset = new Vector3(0, 0.5f, -1);
    public SpriteRenderer ProgressBG;
    public Vector3 SliderOffset = new Vector3(0, 0.5f, -2);
    public SpriteRenderer ProgressSlider;

    public override Type InstantiateType => typeof(Humanoid);

    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int value)
    {
        Humanoid humanoid = thing as Humanoid;

        humanoid.ProgressBG = GameObject.Instantiate(ProgressBG.gameObject, BGOffset, Quaternion.identity, humanoid.transform).GetComponent<SpriteRenderer>();
        humanoid.ProgressSlider = GameObject.Instantiate(ProgressSlider.gameObject, SliderOffset, Quaternion.identity, humanoid.transform).GetComponent<SpriteRenderer>();

        base.Instantiate(thing, part, caravan, value);
    }
}
