using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

[CreateAssetMenu(fileName = "Workbench", menuName = "Defs/Instantiable/Buildings/Workbench")]
public class WorkbenchBuildingDef : BuildingDef
{
    [Header("Workbench")]
    public CraftDef[] Crafts = new CraftDef[0];

    public override Type InstantiateType => typeof(WorkbenchBuilding);
    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int direction)
    {
        WorkbenchBuilding building = thing as WorkbenchBuilding;

        building.WorkbenchDef = this;

        base.Instantiate(thing, part, caravan, direction);
    }
}
