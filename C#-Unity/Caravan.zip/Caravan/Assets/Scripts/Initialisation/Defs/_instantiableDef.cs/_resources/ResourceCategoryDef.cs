using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

[CreateAssetMenu(fileName = "Resource Category", menuName = "Defs/Instantiable/Resource/Category")]
public class ResourceCategoryDef : InstantiableDef
{
    [Header("Resource Category")]
    public ResourceEntityDef[] Resources = new ResourceEntityDef[0];


    private int _index;

    public override bool CanInstantiate(AreaPart part, Caravan caravan, int direction)
    {
        return Resources[_index].CanInstantiate(part, caravan, direction);
    }
    public override Type InstantiateType => Resources[_index].InstantiateType;
    public override string EntityName => Resources[_index].EntityName;

    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int direction)
    {
        Resources[_index].Instantiate(thing, part, caravan, direction);

        _index = UnityEngine.Random.Range(0, Resources.Length);
    }
}
