using System;
using UnityEngine;

[CreateAssetMenu(fileName = "Healing", menuName = "Defs/Instantiable/Items/Healing")]
public class HealingItemDef : ItemDef
{
    [Header("Healing")]
    public int Healing = 10;


    public override Type InstantiateType => typeof(HealingItem);
    public override void Instantiate(Thing thing, AreaPart part, Caravan caravan, int quantity)
    {
        HealingItem food = thing as HealingItem;

        food.HealDef = this;

        base.Instantiate(thing, part, caravan, quantity);
    }

    public override Item InstantiateHauled(Creature hauler, Caravan caravan, int quantity)
    {
        HealingItem food = base.InstantiateHauled(hauler, caravan, quantity) as HealingItem;

        food.HealDef = this;

        return food;
    }
}