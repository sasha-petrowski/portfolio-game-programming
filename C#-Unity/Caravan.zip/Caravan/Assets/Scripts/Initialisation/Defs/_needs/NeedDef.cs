using System;
using UnityEngine;


public abstract class NeedDef : Def
{
    public string SmallName = "Need";
    public float MaxNeed = 100;
    public float NeedThreshold = 10;
    public float Loss = 1;


    protected abstract Type NeedType { get; }
    protected abstract void InitialiseNeed(Need need);


    public void AddTo(Creature creature)
    {
        Need need = Activator.CreateInstance(NeedType) as Need;

        InitialiseNeed(need);

        creature.Needs.Add(need);
    }
}