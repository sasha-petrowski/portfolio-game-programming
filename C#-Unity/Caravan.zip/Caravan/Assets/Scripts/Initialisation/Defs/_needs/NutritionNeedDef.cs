using System;
using UnityEngine;


[CreateAssetMenu(fileName = "Nutrition Need", menuName = "Defs/Need/Nutrition")]
public class NutritionNeedDef : NeedDef
{
    public float StarvationHealthLoss = 1;
    public float HealthRegen = 1;

    public ItemCategoryDef FoodCategory;

    protected override Type NeedType => typeof(NutritionNeed);
    protected override void InitialiseNeed(Need need)
    {
        NutritionNeed nutritionNeed = need as NutritionNeed;

        nutritionNeed.Def = this;
        nutritionNeed.Satisfaction = MaxNeed / 2f;
    }
}