using System;
using UnityEngine;


[CreateAssetMenu(fileName = "Hunter Nutrition Need", menuName = "Defs/Need/Hunter Nutrition")]
public class HunterNutritionNeedDef : NutritionNeedDef
{
    protected override Type NeedType => typeof(HunterNutritionNeed);
}