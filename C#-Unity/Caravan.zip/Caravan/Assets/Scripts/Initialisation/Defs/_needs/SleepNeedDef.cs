using System;
using UnityEngine;


[CreateAssetMenu(fileName = "Sleep Need", menuName = "Defs/Need/Sleep")]
public class SleepNeedDef : NeedDef
{
    public float SleepGain = 1;
    public float HealthGain = 0.1f;
    public float GroundRestFactor = 0.6666f;
    public float Drowsiness = 10;
    public float DrowsinessFactor = 0.5f;

    public float HealthRegen { get; internal set; }

    protected override Type NeedType => typeof(SleepNeed);
    protected override void InitialiseNeed(Need need)
    {
        SleepNeed sleepNeed = need as SleepNeed;

        sleepNeed.Def = this;
        sleepNeed.Satisfaction = MaxNeed / 2;
    }
}