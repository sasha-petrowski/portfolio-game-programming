using UnityEngine;

[CreateAssetMenu(fileName = "Hauling Job Target", menuName = "Defs/Player/Job Targets/Hauling")]
public class HaulingJobTargetDef : JobTargetDef
{
    public override bool LoadDef()
    {
        if(base.LoadDef())
        {
            if (HaulingJobTarget.s_TargetDef != null) Debug.LogWarning("Loaded multiple Defs for same Jobtarget");
            HaulingJobTarget.s_TargetDef = this;

            return true;
        }
        return false;
    }
}