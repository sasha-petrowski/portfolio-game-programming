using UnityEngine;

[CreateAssetMenu(fileName = "Deconstruct Job Target", menuName = "Defs/Player/Job Targets/Deconstruct")]
public class DeconstructJobTargetDef : JobTargetDef
{
    public override bool LoadDef()
    {
        if(base.LoadDef())
        {
            if (DeconstructJobTarget.s_TargetDef != null) Debug.LogWarning("Loaded multiple Defs for same Jobtarget");
            DeconstructJobTarget.s_TargetDef = this;

            return true;
        }
        return false;
    }
}