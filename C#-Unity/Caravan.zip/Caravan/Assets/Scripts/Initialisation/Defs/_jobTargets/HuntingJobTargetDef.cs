using UnityEngine;

[CreateAssetMenu(fileName = "Hunting Job Target", menuName = "Defs/Player/Job Targets/Hunting")]
public class HuntingJobTargetDef : JobTargetDef
{
    public override bool LoadDef()
    {
        if(base.LoadDef())
        {
            if (HuntingJobTarget.s_TargetDef != null) Debug.LogWarning("Loaded multiple Defs for same Jobtarget");
            HuntingJobTarget.s_TargetDef = this;

            return true;
        }
        return false;
    }
}