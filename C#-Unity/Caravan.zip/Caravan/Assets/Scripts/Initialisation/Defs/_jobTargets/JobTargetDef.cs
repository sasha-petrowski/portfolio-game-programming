using UnityEngine;

public abstract class JobTargetDef : Def
{
    [Header("Job Target")]
    public string MenuName;
}