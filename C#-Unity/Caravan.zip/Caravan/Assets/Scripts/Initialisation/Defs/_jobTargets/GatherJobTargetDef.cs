using UnityEngine;

[CreateAssetMenu(fileName = "Gather Job Target", menuName = "Defs/Player/Job Targets/Gather")]
public class GatherJobTargetDef : JobTargetDef
{
}