using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

[CreateAssetMenu(fileName = "Spawning Tool", menuName = "Defs/Dev/Tools/Spawn")]
public class SpawnToolDef : PlayerToolDef
{
    public bool SpawnInPlayerCaravan = false;
    public InstantiableDef ToSpawn;

    #region ITool
    public override PlayerToolCategory ToolCategory => PlayerToolCategory.Dev;

    protected static GameObject _preview;
    protected static AreaTile _parent;

    private void CreatePreview()
    {
        _preview = new GameObject("Spawn Preview", typeof(SpriteRenderer));

        _preview.GetComponent<SpriteRenderer>().sprite = ToSpawn.Sprite;
    }
    public override void OnSelect()
    {
        CreatePreview();
    }
    public override void OnQuit()
    {
        Destroy(_preview);
        _parent = null;
    }

    public override void PrimaryUp(Vector3 worldPosition)
    {
        Area area = ThingManager.Instance.GetAreaAt(worldPosition, null);
        if (area != null)
        {
            Vector2Int index = area.ClampSnapIndex(area.WorldToIndex(worldPosition));

            _parent = area.Tiles[index.x, index.y];
        }

        if(_parent != null )
        {
            AreaTile tile = AreaTile.GetEmptyTile(_parent);

            ToSpawn.TryInstantiate(tile, (SpawnInPlayerCaravan ? Caravan.s_PlayerCaravan : null), 0);
        }
    }

    public override Sprite GetUIIcon() => ToSpawn.Sprite;

    public override void WorldPreview(Vector3 worldPosition)
    {
        Area area = ThingManager.Instance.GetAreaAt(worldPosition, null);
        if (area != null)
        {
            Vector2Int index = area.ClampSnapIndex(area.WorldToIndex(worldPosition));

            _parent = area.Tiles[index.x, index.y];
        }

        if (_parent != null)
        {
            _preview.transform.position = _parent.WorldPosition() + new Vector3(0, 0, -1);
        }
        else
        {
            _preview.transform.position = worldPosition;
        }
    }

    public override string GetUITooltip()
    {
        if (ToSpawn is ItemDef itemDef) return $"Spawn {itemDef.StackSize}x {itemDef.name}";

        return name;
    }
    #endregion
}
