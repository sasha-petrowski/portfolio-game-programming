﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public static class ThingsInitializer
{
    private static bool _initialized = false;

    public static void QuickInitDefs()
    {
        if(_initialized) return;

        foreach (ItemCategoryDef reset in Resources.LoadAll<ItemCategoryDef>(""))
        {
            if (reset != null) reset.Items.Clear();
        }
        foreach (Def def in Resources.LoadAll<Def>(""))
        {
            if (def != null) def.LoadDef();
        }

        _initialized = true;
    }
    public static IEnumerator InitializeDefs(Slider slider, TextMeshProUGUI text)
    {
        if (!_initialized)
        {
            foreach (ItemCategoryDef reset in Resources.LoadAll<ItemCategoryDef>(""))
            {
                if (reset != null) reset.Items.Clear();
            }

            Def[] allDefs = Resources.LoadAll<Def>("");
            slider.value = 0;
            slider.maxValue = allDefs.Length;
            bool error = false;

            foreach (Def def in allDefs)
            {
                if (def != null)
                {
                    slider.value++;
                    text.text = $"Loading : {def}";

                    yield return new WaitForSeconds(0.01f);

                    try
                    {
                        def.LoadDef();
                    }
                    catch (Exception e)
                    {
                        text.text = e.ToString();
                        text.color = Color.red;
                        error = true;
                        break;
                    }
                }
            }

            if (!error)
            {
                _initialized = true;
                SceneManager.LoadScene("Main");
            }

        }
    }
}