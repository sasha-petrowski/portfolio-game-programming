using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GizmoTests : MonoBehaviour
{/*
    public Vector2 r0, R;

    public float Rs, Ys;

    [Header("Debug")]
    public float distance;
    public Vector2 intersection;
    */

    public Vector2Int CenterIndex;
    public Vector2Int StartIndex;

    Vector2Int _lastPosition;
    Vector2Int _currentPosition;
    Vector2Int _chunkOffset = new Vector2Int(16, 16);
    bool DrawSpiralGizmos(Vector2Int index)
    {
        _currentPosition = index * WorldSettings.ChunkSize + _chunkOffset;
        Gizmos.color = Color.red;
        Gizmos.DrawLine((Vector2)_currentPosition, (Vector2)_lastPosition);

        Gizmos.color = Color.white;
        if (Application.isPlaying && ThingManager.Instance != null)
        {
            // Do something
            Gizmos.color = Color.blue;
        }
        Gizmos.DrawWireCube((Vector2)_currentPosition, 0.75f * WorldSettings.ChunkSize * Vector3.one);

        _lastPosition = _currentPosition;
        return false;
    }

    private void OnDrawGizmos()
    {
        _currentPosition = StartIndex * WorldSettings.ChunkSize + _chunkOffset;
        _lastPosition = _currentPosition;

        Gizmos.color = Color.blue;
        int worldLenght = WorldSettings.ChunkNumber * WorldSettings.ChunkSize;
        Gizmos.DrawLine(new Vector3(worldLenght, 0, 0), new Vector3(-worldLenght, 0, 0));
        Gizmos.DrawLine(new Vector3(0, worldLenght, 0), new Vector3(0, -worldLenght, 0));
        Gizmos.DrawWireCube((Vector2)CenterIndex * WorldSettings.ChunkSize, new Vector3(worldLenght, worldLenght, 0));


        if (ThingManager.Instance != null)
        {
            GridUtility.NaiveSpiralSearch(false, Caravan.s_PlayerCenterChunkIndex, CenterIndex, WorldSettings.ChunkNumber, WorldSettings.ChunkNumber, DrawSpiralGizmos);
        }
        else
        {
            GridUtility.NaiveSpiralSearch(false, StartIndex, CenterIndex, WorldSettings.ChunkNumber, WorldSettings.ChunkNumber, DrawSpiralGizmos);
        }


        //Vector2 y0 = transform.position;
        /*
        float lambda = (r0.x - y0.x) / (Ys * Y.x - Rs * R.x);
        Vector2 intersection = (r0 + Rs * lambda * R);

        Gizmos.color = Color.red;
        Gizmos.DrawSphere(r0, 1);
        Gizmos.DrawLine(r0, r0 + R * lambda * 2);

        Gizmos.color = Color.yellow;
        Gizmos.DrawSphere(y0, 1);
        Gizmos.DrawLine(y0, y0 + Y * lambda * 4);

        Gizmos.color = Color.green;
        Gizmos.DrawSphere(intersection, 1);
        */

        /*
        distance = Vector2.Distance(r0, y0);

        intersection = r0 + R * (Rs * (Rs / Ys) * (distance / Ys));

        Gizmos.color = Color.red;
        Gizmos.DrawSphere(r0, 1);
        Gizmos.DrawLine(r0, r0 + R * 10);

        Gizmos.color = Color.yellow;
        Gizmos.DrawSphere(y0, 1);
        Gizmos.DrawLine(y0, intersection);

        Gizmos.color = Color.green;
        Gizmos.DrawSphere(intersection, 0.5f);
        */
    }
}
