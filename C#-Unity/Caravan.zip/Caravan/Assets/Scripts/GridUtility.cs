﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public static class GridUtility
{


    public static bool NaiveSpiralSearch(bool ignoreFirst, Vector2Int startIndex, Vector2Int centerIndex, int width, int height, Func<Vector2Int, bool> searchFunction)
    {
        Vector2Int spiralIndex = Vector2Int.zero;
        Vector2Int direction = new Vector2Int(1, 0);

        int t = Mathf.Max(Mathf.Abs(startIndex.x - centerIndex.x), Mathf.Abs(startIndex.y - centerIndex.y)) * 2 + Mathf.Max(width, height);
        int maxI = t * t - 1;
        if (!ignoreFirst && searchFunction(startIndex))
        {
            return true;
        }
        for (int i = 0; i < maxI; i++)
        {
            //Debug.DrawRay(new Vector3(startIndex.x - spiralIndex.x + 0.5f, startIndex.y - spiralIndex.y + 0.5f) * WorldSettings.ChunkSize, new Vector3(-direction.x, -direction.y) * WorldSettings.ChunkSize);
            spiralIndex += direction;
            if (searchFunction(startIndex - spiralIndex))
            {
                return true;
            }
            if ((spiralIndex.x == spiralIndex.y) || ((spiralIndex.x < 0) && (spiralIndex.x == -spiralIndex.y)) || ((spiralIndex.x > 0) && (spiralIndex.x == 1 - spiralIndex.y)))
            {
                t = direction.x;
                direction.x = -direction.y;
                direction.y = t;
            }
        }
        return false;
    }
    public static bool NaiveSpiralSearch<T>(bool ignoreFirst, Vector2Int startIndex, Vector2Int centerIndex, int width, int height, Func<Vector2Int, T, bool> searchFunction, T arg)
    {
        Vector2Int spiralIndex = Vector2Int.zero;
        Vector2Int direction = new Vector2Int(1, 0);

        int t = Mathf.Max(Mathf.Abs(startIndex.x - centerIndex.x), Mathf.Abs(startIndex.y - centerIndex.y)) * 2 + Mathf.Max(width, height);
        int maxI = t * t - 1;
        if (!ignoreFirst && searchFunction(startIndex, arg))
        {
            return true;
        }
        for (int i = 0; i < maxI; i++)
        {
            spiralIndex += direction;
            if (searchFunction(startIndex - spiralIndex, arg))
            {
                return true;
            }
            if ((spiralIndex.x == spiralIndex.y) || ((spiralIndex.x < 0) && (spiralIndex.x == -spiralIndex.y)) || ((spiralIndex.x > 0) && (spiralIndex.x == 1 - spiralIndex.y)))
            {
                t = direction.x;
                direction.x = -direction.y;
                direction.y = t;
            }
        }
        return false;
    }


    public static bool VerifiedSpiralSearch(bool ignoreFirst, Vector2Int startIndex, Vector2Int centerIndex, int width, int height, Func<Vector2Int, bool, bool> searchFunction)
    {
        Vector2Int max = centerIndex + new Vector2Int(width / 2 - 1, height / 2 - 1);
        Vector2Int min = centerIndex - new Vector2Int(width / 2, height / 2);
        Vector2Int spiralIndex = Vector2Int.zero;
        Vector2Int direction = new Vector2Int(1, 0);
        Vector2Int chunkIndex;

        int t = Mathf.Max(Mathf.Abs(startIndex.x - centerIndex.x), Mathf.Abs(startIndex.y - centerIndex.y)) * 2 + Mathf.Max(width, height);
        int maxI = t * t - 1;
        if (!ignoreFirst)
        {
            searchFunction(startIndex, true);
        }
        for (int i = 0; i < maxI; i++)
        {
            spiralIndex += direction;
            chunkIndex = startIndex - spiralIndex;
            if (searchFunction(centerIndex, (min.x <= chunkIndex.x) && (chunkIndex.x <= max.x) && (min.y <= chunkIndex.y) && (chunkIndex.y <= max.y)))
            {
                return true;
            }
            if ((spiralIndex.x == spiralIndex.y) || ((spiralIndex.x < 0) && (spiralIndex.x == -spiralIndex.y)) || ((spiralIndex.x > 0) && (spiralIndex.x == 1 - spiralIndex.y)))
            {
                t = direction.x;
                direction.x = -direction.y;
                direction.y = t;
            }
        }
        return false;
    }
}