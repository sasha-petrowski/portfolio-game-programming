using System;
using UnityEngine;


public class InstantiableAttribute : PropertyAttribute
{
    public Type Type;

    public InstantiableAttribute(Type type)
    {
        Type = type;
    }
}