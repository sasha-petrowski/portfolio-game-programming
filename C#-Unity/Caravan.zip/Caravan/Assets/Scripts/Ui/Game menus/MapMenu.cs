using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class MapMenu : GameMenu
{
    [SerializeField]
    private int _mapSize = 256;

    [SerializeField]
    private Image _map;
    [SerializeField]
    private UIClickInput _clickInput;
    [SerializeField]
    private DirectionInput _directionInput;

    private float _mapMagnitude = 0;
    private Texture2D _mapTexture;

    #region Menu
    protected override void OnOpen()
    {
        Time.timeScale = 0;
        CreateMapPreview();
    }
    protected override void OnClose()
    {
        Time.timeScale = 1;
    }
    #endregion

    private void Start()
    {
        _clickInput.OnInputDown += OnMapInput;
    }

    private void OnMapInput(Vector2 direction, float radAngle)
    {
        Caravan.s_PlayerCaravan.DirectionInput(false, direction, radAngle);
        _directionInput.Center();
    }

    private void CreateMapPreview()
    {
        Color[] colorMap = new Color[_mapSize * _mapSize];

        _mapMagnitude = new Vector2((_mapSize / 2) * WorldSettings.ChunkSize, 0).sqrMagnitude;
        int index = 0;
        for (int j = 0; j < _mapSize; j++)
        {
            for (int i = 0; i < _mapSize; i++)
            {
                int x = (i - _mapSize / 2) * WorldSettings.ChunkSize;
                int y = (j - _mapSize / 2) * WorldSettings.ChunkSize;

                Vector2Int chunkIndex = new Vector2Int(x + Caravan.s_PlayerCenterChunkIndex.x * WorldSettings.ChunkSize, y + Caravan.s_PlayerCenterChunkIndex.y * WorldSettings.ChunkSize);


                if (new Vector2(x, y).sqrMagnitude < _mapMagnitude)
                {
                    ChunkContent chunkContent = new ChunkContent(ChunkArea.GetChunkID(chunkIndex / WorldSettings.ChunkSize));

                    if (chunkContent.HasRuin) colorMap[index] = Color.red;

                    else colorMap[index] = WorldGenerator.Instance.WorldTerrain.GetTerrainAt(chunkIndex.x, chunkIndex.y).Color;
                }
                index++;
            }
        }

        _mapTexture = new Texture2D(_mapSize, _mapSize);
        _mapTexture.filterMode = FilterMode.Bilinear;
        _mapTexture.SetPixels(colorMap);
        _mapTexture.Apply();

        _map.sprite = Sprite.Create(_mapTexture, new Rect(0.0f, 0.0f, _mapSize, _mapSize), new Vector2(0, 0), 1); ;
    }
}