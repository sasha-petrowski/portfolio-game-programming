using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;
using UnityEngine.EventSystems;

public class SelectionMenu : GameMenu
{
    public GameObject select;

    [System.Serializable]
    struct BarUi
    {
        public Slider bar;
        public Image fill;
        public TMP_Text name;
    }

    [SerializeField]
    private TMP_Text _selectionName;
    [SerializeField]
    private TMP_Text _selectionDescription;
    [SerializeField]
    private TMP_Text _selectionLesserDescription;
    [SerializeField]
    private GameObject _selectionBarContainer;
    [SerializeField]
    private BarUi[] _selectionBars;


    [Header("Sub Menus")]
    [SerializeField]
    private RectTransform _subMenusParent;
    [SerializeField]
    private CraftingMenu _craftingMenu;
    [SerializeField]
    private Button _cancelButton;
    [SerializeField]
    private Button _jobTargetButtonPrefab;
    [SerializeField]
    private Sprite _cancelSprite;

    private Dictionary<JobTarget, GameObject> _jobTargets = new Dictionary<JobTarget, GameObject>();
    private SelectionForm _selectionForm = new SelectionForm();
    private Thing _selected;

    private void Awake()
    {
        select.SetActive(false);
    }
    private void LateUpdate()
    {
        if(gameObject.activeSelf)
        {
            UpdateSelected();
        }
    }
    internal void SetSelected(Thing selected)
    {
        _selected = selected;

        _selected.OnSelect(_selectionForm);

        select.SetActive(true);
        //select.transform.parent = selected.transform;
        select.transform.position = selected.transform.position;
        select.transform.rotation = selected.transform.rotation;

        UpdateSelectedZoomRatio(GameCamera.Instance.GetZoomRatio());

        _selectionName.gameObject.SetActive(_selectionForm.Name != null);
        _selectionDescription.gameObject.SetActive(_selectionForm.Description != null);
        _selectionLesserDescription.gameObject.SetActive(_selectionForm.LesserDescription != null);

        if (_selectionForm.BarValues != null && _selectionForm.BarValues.Length > 0)
        {
            _selectionBarContainer.SetActive(true);
            for (int i = 0; i < _selectionBars.Length; i++)
            {
                _selectionBars[i].bar.gameObject.SetActive(i < _selectionForm.BarValues.Length);
            }
        }
        else
        {
            _selectionBarContainer.SetActive(false);
        }

        #region Context sub-menus
        if (selected is WorkbenchBuilding workbench)
        {
            _craftingMenu.gameObject.SetActive(true);
            _craftingMenu.Initialize(workbench);
        }
        else
        {
            _craftingMenu.gameObject.SetActive(false);
        }

        _cancelButton.gameObject.SetActive(selected is ICancelTarget);

        #region JobTargets
        foreach (GameObject go in _jobTargets.Values)
        {
            Destroy(go);
        }
        _jobTargets.Clear();

        if (selected is Entity entity)
        {
            foreach (JobTarget target in entity.JobTargets)
            {
                GameObject go = GameObject.Instantiate(_jobTargetButtonPrefab.gameObject, _subMenusParent);

                go.GetComponent<MouseOverElement>().MouseEnter += (PointerEventData data) => UIManager.Instance.CursorText.SetText(target.Def.MenuName);

                _jobTargets.Add(target, go);
            }
        }
        #endregion
        #endregion
    }
    public void UpdateSelected()
    {
        if (_selected == null) return;

        select.transform.position = _selected.transform.position;
        select.transform.rotation = _selected.transform.rotation;

        _selected.OnSelect(_selectionForm);
        /*
         * NAME
         */
        _selectionName.text = _selectionForm.Name;
        /*
         * DESCRIPTION
         */
        _selectionDescription.text = _selectionForm.Description;
        /*
         * LESSER DESCRIPTION
         */
        _selectionLesserDescription.text = _selectionForm.LesserDescription;
        /*
         * BARS
         */
        if (_selectionForm.BarValues != null)
        {
            for (int i = 0; i < _selectionForm.BarValues.Length; i++)
            {
                _selectionBars[i].name.text = _selectionForm.BarNames[i];
                _selectionBars[i].bar.value = _selectionForm.BarValues[i] / _selectionForm.BarMax[i];
                _selectionBars[i].fill.color = _selectionForm.BarColors[i];
            }
        }

        if (_craftingMenu.isActiveAndEnabled) _craftingMenu.UpdateUI();
        foreach (KeyValuePair<JobTarget, GameObject> pair in _jobTargets)
        {
            JobTarget target = pair.Key;
            Entity entity = _selected as Entity;
            Button button = pair.Value.GetComponent<Button>();

            button.onClick.RemoveAllListeners();

            if (target.CanAddJob())
            {
                pair.Value.GetComponent<Image>().sprite = target.Def.Sprite;
                button.onClick.AddListener(() => target.AddJob(entity));
            }
            else
            {
                pair.Value.GetComponent<Image>().sprite = _cancelSprite;
                button.onClick.AddListener(() => target.RemoveJob(entity));
            }
        }

        if (UnityEngine.Random.Range(0, 60) == 0) // this uptades the selection menus every 60 frames AVG, it's shit but it works better than every frames
        {
            gameObject.SetActive(false);
            gameObject.SetActive(true);
        }
    }
    public void ActiveSelected(bool active)
    {
        select.SetActive(active);
    }
    public void UpdateSelectedZoomRatio(float zoomRatio)
    {
        Vector2 mult = Vector2.one;
        if (zoomRatio * _selectionForm.SelectSize.x < 1 && zoomRatio * _selectionForm.SelectSize.y < 1)
        {
            zoomRatio = ((1 / (_selectionForm.SelectSize.x > _selectionForm.SelectSize.y ? _selectionForm.SelectSize.x : _selectionForm.SelectSize.y)) + zoomRatio * 2) / 3;
            mult.x = zoomRatio * _selectionForm.SelectSize.x;
            mult.y = zoomRatio * _selectionForm.SelectSize.y;
        }
        else if (zoomRatio * _selectionForm.SelectSize.x < 1)
        {
            mult.x = zoomRatio * _selectionForm.SelectSize.x;
        }
        else if (zoomRatio * _selectionForm.SelectSize.y < 1)
        {
            mult.y = zoomRatio * _selectionForm.SelectSize.y;
        }
        select.transform.localScale = Vector3.one / zoomRatio;
        select.GetComponent<SpriteRenderer>().size = new Vector2((_selectionForm.SelectSize.x + 0.25f) * zoomRatio / mult.x, (_selectionForm.SelectSize.y + 0.25f) * zoomRatio / mult.y);
    }

    protected override void OnOpen()
    {
        select.SetActive(true);
    }
    protected override void OnClose()
    {
        select.SetActive(false);
    }

    public void OnCancelButton()
    {
        if (_selected is ICancelTarget cancelable) cancelable.OrderCancel();

        Close();
    }
}


public class SelectionForm
{
    public string Name;
    public string Description;
    public string LesserDescription;
    public string[] BarNames;
    public float[] BarValues;
    public float[] BarMax;
    public Color[] BarColors;
    public Vector2 SelectSize;

    public void Update(string name, string description, string lesserDescription, string[] barNames, float[] barValues, float[] barMax, Color[] barColors, Vector2 selectSize)
    {
        Name = name;
        Description = description;
        LesserDescription = lesserDescription;
        BarNames = barNames;
        BarValues = barValues;
        BarMax = barMax;
        BarColors = barColors;
        SelectSize = selectSize;
    }
}