using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Minimap : MonoBehaviour
{
    [SerializeField]
    private int _mapSize = 256;
    [SerializeField]
    private int _pixelSize = 8;

    [SerializeField]
    private DirectionInput _directionInput;
    [SerializeField]
    private Image _minimap;

    private int _mapIndex = 0;
    private float _mapMagnitude = 0;
    private Texture2D _mapTexture;

    private void Start()
    {
        _directionInput.OnInputUp += Caravan.s_PlayerCaravan.DirectionInput;
        _directionInput.OnValueChanged += Caravan.s_PlayerCaravan.SetDirection;

        InitMapPreview();
    }
    private void Update()
    {
        UpdateMapPreview();
    }
    private void InitMapPreview()
    {
        Color[] colorMap = new Color[_mapSize * _mapSize];

        _mapMagnitude = new Vector2((_mapSize / 2) * _pixelSize, 0).sqrMagnitude;

        _mapTexture = new Texture2D(_mapSize, _mapSize);
        _mapTexture.filterMode = FilterMode.Bilinear;
        _mapTexture.SetPixels(colorMap);
        _mapTexture.Apply();

        _minimap.sprite = Sprite.Create(_mapTexture, new Rect(0.0f, 0.0f, _mapSize, _mapSize), new Vector2(0, 0), 1); ;
    }
    private void UpdateMapPreview()
    {
        for (int i = 0; i < _mapSize; i++)
        {
            int x = (i - _mapSize / 2) * _pixelSize;
            int y = (_mapIndex - _mapSize / 2) * _pixelSize;

            if (new Vector2(x, y).sqrMagnitude < _mapMagnitude) _mapTexture.SetPixel(i, _mapIndex, WorldGenerator.Instance.WorldTerrain.GetTerrainAt(x + (int)(Caravan.s_PlayerCaravan.CaravanCenter.position.x / _pixelSize) * _pixelSize, y + (int)(Caravan.s_PlayerCaravan.CaravanCenter.position.y / _pixelSize) * _pixelSize).Color);
        }
        _mapIndex = (_mapIndex + 1) % _mapSize;

        if(_mapIndex == 0 ) _mapTexture.Apply();
    }
}
