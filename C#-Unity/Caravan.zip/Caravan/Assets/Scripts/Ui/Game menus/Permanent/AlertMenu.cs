using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class AlertMenu : MonoBehaviour
{
    [SerializeField]
    private GameObject _alertPrefab;

    public GameObject CreateAlert(string text, Func<Vector2> getPosition)
    {
        GameObject alert = GameObject.Instantiate(_alertPrefab, transform);
        if(getPosition != null)
        {
            alert.GetComponent<Button>().onClick.AddListener(() => {
                Vector2 position = getPosition();
                Camera.main.transform.position = new Vector3(position.x, position.y, Camera.main.transform.position.z);
            });
        }

        alert.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = text;

        return alert;
    }
}