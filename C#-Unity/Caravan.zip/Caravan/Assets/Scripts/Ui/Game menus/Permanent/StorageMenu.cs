using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class StorageMenu : MonoBehaviour
{
    private Dictionary<ItemDef, TextMeshProUGUI> _itemTexts = new();

    [SerializeField]
    private GameObject _itemPrefab;

    public void UpdateItem(ItemDef item)
    {
        if(item.ShowItemCount)
        {
            int quantity = Item.StoredQuantity[item];

            if (_itemTexts.TryGetValue(item, out TextMeshProUGUI text))
            {
                text.text = quantity.ToString();
            }
            else CreateItem(item, quantity);
        }
    }
    private void CreateItem(ItemDef item, int quantity)
    {
        GameObject go = GameObject.Instantiate(_itemPrefab, transform);

        Image image = go.GetComponent<Image>();
        image.sprite = item.Sprite;

        TextMeshProUGUI text = go.transform.GetChild(0).GetComponent<TextMeshProUGUI>();
        text.text = quantity.ToString();

        _itemTexts[item] = text;
    }
}