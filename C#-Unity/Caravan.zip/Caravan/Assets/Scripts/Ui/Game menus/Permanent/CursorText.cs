using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

[RequireComponent(typeof(TextMeshProUGUI))]
public class CursorText : MonoBehaviour
{
    private TextMeshProUGUI _text;

    private float _textVisible = 0;

    private void Awake()
    {
        _text = GetComponent<TextMeshProUGUI>();
    }

    public void SetText(string text)
    {
        _text.text = text;

        _textVisible = 2f;
    }

    private void LateUpdate()
    {
        if (_textVisible <= 0) _text.text = null;
        else
        {
            _textVisible -= Time.unscaledDeltaTime;
            _text.color = new Color(1, 1, 1, _textVisible);
            transform.position = Input.mousePosition;
        }
    }
}