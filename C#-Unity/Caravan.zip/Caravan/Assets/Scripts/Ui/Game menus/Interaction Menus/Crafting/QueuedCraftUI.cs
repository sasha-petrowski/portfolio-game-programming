using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class QueuedCraftUI : MonoBehaviour
{
    [SerializeField]
    private Image _icon;
    [SerializeField]
    private TextMeshProUGUI _name;
    [SerializeField]
    private TextMeshProUGUI _quantity;

    private CraftingJob _craft;
    public void Initialize(CraftingJob craft)
    {
        _craft = craft;

        _icon.sprite = craft.Craft.MainProduct.Sprite;
        _name.text = craft.Craft.name;

        WriteQuantity();
    }

    public void WriteQuantity()
    {
        int stored = Item.StoredQuantity[_craft.Craft.MainProduct];
        int target = _craft.CraftQuantity;

        _quantity.color = stored >= target ? Color.gray : Color.white;
        _quantity.text = $"{stored} / {target}";
    }
    public void AddQuantity()
    {
        _craft.CraftQuantity++;
        WriteQuantity();
    }
    public void RemoveQuantity()
    {
        _craft.CraftQuantity = Mathf.Max(_craft.CraftQuantity - 1, 0);
        WriteQuantity();
    }
    public void DeleteCraft()
    {
        Destroy(gameObject);

        _craft.DeleteJob();
    }
}
