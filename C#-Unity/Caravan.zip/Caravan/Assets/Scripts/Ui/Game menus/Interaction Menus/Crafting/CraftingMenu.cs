using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Jobs;
using UnityEngine;

public class CraftingMenu : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField]
    private RectTransform _craftQueue;
    [SerializeField]
    private RectTransform _newCrafts;

    [Header("Prefabs")]
    [SerializeField]
    private QueuedCraftUI _queuedPrefab;
    [SerializeField]
    private CraftUI _newPrefab;

    public void Initialize(WorkbenchBuilding workbench)
    {
        foreach (Transform child in _craftQueue)
        {
            Destroy(child.gameObject);
        }
        foreach (Transform child in _newCrafts)
        {
            Destroy(child.gameObject);
        }
        foreach (CraftingJob job in workbench.Crafts)
        {
            CreateCraft(job);
        }
        foreach (CraftDef craft in workbench.WorkbenchDef.Crafts)
        {
            GameObject go = GameObject.Instantiate(_newPrefab.gameObject, _newCrafts);
            go.GetComponent<CraftUI>().Initialize(craft, workbench, this);
        }
    }
    public void CreateCraft(CraftingJob job)
    {
        GameObject go = GameObject.Instantiate(_queuedPrefab.gameObject, _craftQueue);
        go.GetComponent<QueuedCraftUI>().Initialize(job);
    }
    public void UpdateUI()
    {
        foreach (Transform child in _craftQueue)
        {
            if (child.gameObject.TryGetComponent(out QueuedCraftUI ui)) ui.WriteQuantity();
        }
    }
}
