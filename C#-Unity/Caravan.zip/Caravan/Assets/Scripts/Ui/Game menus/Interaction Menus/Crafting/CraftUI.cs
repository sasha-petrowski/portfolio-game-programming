using System.Collections;
using System.Collections.Generic;
using System.Text;
using TMPro;
using Unity.Jobs;
using UnityEngine;
using UnityEngine.UI;

public class CraftUI : MonoBehaviour
{
    [SerializeField]
    private Image _icon;
    [SerializeField]
    private TextMeshProUGUI _name;
    [SerializeField]
    private TextMeshProUGUI _materials;

    private CraftDef _craft;
    private WorkbenchBuilding _workbench;
    private CraftingMenu _menu;

    public void Initialize(CraftDef craft, WorkbenchBuilding workbench, CraftingMenu menu)
    {
        _craft = craft;
        _workbench = workbench;
        _menu = menu;

        _icon.sprite = craft.MainProduct.Sprite;
        _name.text = craft.name;

        WriteIngredients();
    }

    public void WriteIngredients()
    {
        _materials.text = _craft.Materials.RequiredToString();
    }

    public void AddToBench()
    {
        CraftingJob job = _craft.AddCraftTo(_workbench);

        _menu.CreateCraft(job);
    }
}
