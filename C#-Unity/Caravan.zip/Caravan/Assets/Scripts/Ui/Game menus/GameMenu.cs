using UnityEngine;

public abstract class GameMenu : MonoBehaviour
{
    public void Open()
    {
        if (gameObject.activeSelf) return; // don't open if already open
        
        gameObject.SetActive(true);
        OnOpen();
    }
    public void Close()
    {
        if (! gameObject.activeSelf) return; // don't close if already closed

        gameObject.SetActive(false);
        OnClose();
    }
    public void Toggle()
    {
        if(gameObject.activeSelf)
        {
            gameObject.SetActive(false);
            OnClose();
        }
        else if (! gameObject.activeSelf)
        {
            gameObject.SetActive(true);
            OnOpen();
        }
    }

    protected abstract void OnOpen();
    protected abstract void OnClose();
}