using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEditor;
using static UnityEngine.GridBrushBase;

public enum PlayerToolCategory
{
    Dev = 0,
    Order = 1,
    Build = 2,

    Length = 3
}

public class ToolMenu : GameMenu
{
    private static List<ITool> s_Tools = new();

    [Header("Refs")]
    [SerializeField]
    private RectTransform _categoryParent;
    [SerializeField]
    private GameObject _categoryPrefab;
    [SerializeField]
    private GameObject _categoryButtonPrefab;
    [SerializeField]
    private GameObject _toolSelectorPrefab;

    private GameObject[] _categories;

    protected override void OnClose()
    {
    }
    protected override void OnOpen()
    {
    }

    private void Start()
    {
        CreateCategories();
    }
    private void CreateCategories()
    {
        _categories = new GameObject[(int)PlayerToolCategory.Length];

        for (int i = 0; i < (int)PlayerToolCategory.Length; i++)
        {
            Button catButton = GameObject.Instantiate(_categoryButtonPrefab, transform).GetComponent<Button>();
            GameObject category = GameObject.Instantiate(_categoryPrefab, _categoryParent);
            category.name = ((PlayerToolCategory)i).ToString();
            catButton.name = $"Button : {category.name}";


            _categories[i] = category;


            catButton.onClick.AddListener(() =>
            {
                CloseAllMenusExept(category);
                Toggle(category);
            });

            catButton.gameObject.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = category.name;
        }

        foreach(ITool tool in s_Tools)
        {
            // Add selector button inside parent category
            GameObject selector = GameObject.Instantiate(_toolSelectorPrefab, _categories[(int)tool.ToolCategory].transform);

            // Update Onclick
            selector.GetComponent<Button>().onClick.AddListener(() => ToolManager.SelectNewTool(tool));

            // Update Mouse Hover
            selector.GetComponent<MouseOverElement>().MouseEnter += tool.OnMouseEnterUI;

            // Update Preview
            // Update Preview
            selector.transform.GetChild(0).gameObject.GetComponent<Image>().sprite = tool.GetUIIcon();

            string displayName = tool.GetName();
            if(displayName == "")
            {
                selector.transform.GetChild(1).gameObject.SetActive(false);
            }
            else
            {
                selector.transform.GetChild(1).gameObject.transform.GetChild(0).gameObject.GetComponent<TextMeshProUGUI>().text = displayName;
            }
        }

        CloseAllCategory();
    }
    private void CloseAllCategory()
    {
        foreach (GameObject cat in _categories)
        {
            cat.SetActive(false);
        }
    }
    public void CloseAllMenusExept(GameObject exeption)
    {
        foreach (GameObject cat in _categories)
        {
            if (cat != exeption) cat.SetActive(false);
        }
    }
    private void Toggle(GameObject cat)
    {
        cat.SetActive(!cat.activeSelf);
    }
    public static void AddTool(ITool tool)
    {
        s_Tools.Add(tool);
    }
}
