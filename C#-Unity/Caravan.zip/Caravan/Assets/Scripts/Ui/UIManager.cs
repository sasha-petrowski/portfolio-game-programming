using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;



public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }
    
    [Header("Menus")]
    public CaravanMenu CaravanMenu;
    public MapMenu MapMenu;
    public SelectionMenu SelectionMenu;
    public ToolMenu ToolMenu;

    [Header("Permanent Menus")]
    public Minimap Minimap;
    public AlertMenu AlertMenu;
    public StorageMenu StorageMenu;
    public CursorText CursorText;

    [SerializeField]
    private List<GameMenu> _allMenus;

    private void OnValidate()
    {
        if (_allMenus == null) return;

        if (CaravanMenu != null && !_allMenus.Contains(CaravanMenu)) _allMenus.Add(CaravanMenu);
        if (MapMenu != null && !_allMenus.Contains(MapMenu)) _allMenus.Add(MapMenu);
        if (SelectionMenu != null && !_allMenus.Contains(SelectionMenu)) _allMenus.Add(SelectionMenu);
        if (ToolMenu != null && !_allMenus.Contains(ToolMenu)) _allMenus.Add(ToolMenu);
    }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(this);
        }
    }
    private void Start()
    {
        CloseAllMenu();
    }

    public void UpdateSelectionZoomRatio(float zoomRatio)
    {
        SelectionMenu.UpdateSelectedZoomRatio(zoomRatio);
    }

    public void CloseAllMenu()
    {
        foreach (GameMenu menu in _allMenus)
        {
            menu.Close();
        }
    }
    public void CloseAllMenusExept(GameMenu exeption)
    {
        foreach (GameMenu menu in _allMenus)
        {
            if(menu != exeption) menu.Close();
        }
    }
}