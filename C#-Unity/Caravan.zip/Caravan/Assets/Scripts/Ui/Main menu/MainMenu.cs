using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{
    [Header("Menu")]
    [SerializeField]
    private GameObject _buttonLayout;

    #region Play
    [Header("Loading")]
    [SerializeField]
    private Slider _loadingBar;
    [SerializeField]
    private TextMeshProUGUI _loadingText;
    [SerializeField]
    private float _loadTime;

    public void OnPlayButtonDown()
    {
        _loadingBar.value = 0;
        _loadingBar.gameObject.SetActive(true);
        _buttonLayout.SetActive(false);

        StartCoroutine(ThingsInitializer.InitializeDefs(_loadingBar, _loadingText));
    }
    #endregion

    #region Interactive Background
    [Header("Background")]
    [SerializeField]
    private GameObject _menuBG;
    [SerializeField]
    private Area _areaPrefab;
    [SerializeField]
    private CreatureDef _nomadDef;

    private void Start()
    {
        CreateBackground();
    }
    private void CreateBackground()
    {
        Area newArea = GameObject.Instantiate(_areaPrefab.gameObject).GetComponent<Area>();
        newArea.transform.SetParent(_menuBG.transform);
        newArea.InitialiseArea(13, 7);
        newArea.Caravan = Caravan.s_PlayerCaravan;

        for (int i = 0; i < 2; i++)
        {
            Humanoid nomad = (Humanoid)_nomadDef.TryInstantiate(newArea.Tiles[newArea.Width / 2, newArea.Height / 2], Caravan.s_PlayerCaravan);
        }
        
        Humanoid cursorNomad = (Humanoid)_nomadDef.TryInstantiate(newArea.Tiles[newArea.Width / 2, newArea.Height / 2], Caravan.s_PlayerCaravan);
        cursorNomad.GetComponent<SpriteRenderer>().color = new Color(.75f, .75f, .75f);

        cursorNomad.MoveSpeed *= 2;

        new GoToCursorJob(newArea).TryTakeJob(cursorNomad);
    }

    private class GoToCursorJob : Job
    {
        private Area _area;
        private Path _targetPath;
        public AreaTile TargetTile { get; protected set; }


        public override int JobType => -1;
        public override Vector2 GetPosition()
        {
            return Vector2.zero;
        }
        public GoToCursorJob(Area area) : base()
        {
            _area = area;
            _targetPath = new Path();
        }
        protected override void OnTakeJob(Creature worker)
        {
            base.OnTakeJob(worker);

            Vector2Int cursorIndex = _area.ClampSnapIndex(_area.WorldToIndex(Camera.main.ScreenToWorldPoint(Input.mousePosition)));
            TargetTile = _area.Tiles[cursorIndex.x, cursorIndex.y];
            _targetPath.FindPath(TargetTile, worker);

            _jobStep = JobStep_GoToCursor;
        }
        public override void OnLeaveJob(Creature worker)
        {
            _targetPath?.Free();
            base.OnLeaveJob(worker);
        }
        public override void OnFinishJob(Creature worker)
        {
            _targetPath?.Free();
            base.OnFinishJob(worker);
        }

        #region JobSteps
        protected virtual bool JobStep_GoToCursor(Creature worker)
        {
            Vector2Int cursorIndex = _area.ClampSnapIndex(_area.WorldToIndex(Camera.main.ScreenToWorldPoint(Input.mousePosition)));
            AreaTile tile = _area.Tiles[cursorIndex.x, cursorIndex.y];
            if(TargetTile != tile)
            {
                Path newPath = new Path();
                if (newPath.FindPath(tile, worker))
                {
                    _targetPath.Free();
                    _targetPath = newPath;
                }
            }

            if (_targetPath.FollowPath(worker) == -1) OnLeaveJob(worker);


            return false;
        }
        #endregion

        public override void OnDrawGizmos()
        {
            if (_targetPath != null) _targetPath.OnDrawGizmos();
        }
    }
    #endregion
}
