using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : Thing, IItemSource
{
    public static Dictionary<ItemDef, int> WorldQuantity = new Dictionary<ItemDef, int>();
    public static Dictionary<ItemDef, int> StoredQuantity = new Dictionary<ItemDef, int>();

    public static Dictionary<ItemCategoryDef, int> WorldCategory = new Dictionary<ItemCategoryDef, int>();
    public static Dictionary<ItemCategoryDef, int> StoredCategory = new Dictionary<ItemCategoryDef, int>();

    public int Reserved;
    public int Quantity = 1;
    public ItemDef ItemDef;
    public Creature HauledBy;
    public ItemEntity Entity;


    public override string ToString()
    {
        return $"{Quantity}x {base.ToString()}";
    }

    public Item Split(int quantity, bool haulChild = false)
    {
        Quantity -= quantity;

        Item newItem;

        if (Entity == null)
        {
            newItem = ItemDef.TryInstantiate(transform.position, Caravan, quantity) as Item;
        }
        else
        {
            newItem = ItemDef.TryInstantiate(Entity.Parent, Caravan, quantity) as Item;
        }

        if (haulChild) newItem?.Entity.AddHaulingJob();


        return newItem;
    }
    /*
    public bool Merge(Item other, int quantity)
    {
        int remainingSpace = ItemDef.StackSize - Quantity;

        if(remainingSpace <= 0) return false;

        quantity = Mathf.Clamp(quantity, 0, remainingSpace);

        Quantity += quantity;
        other.Quantity -= quantity;

        if (other.Quantity <= 0) other.Destroy();

        return true;
    }
    */
    public virtual bool Drop()
    {
        Reserved = 0;

        if (HauledBy == null | Entity != null) return false;

        SpawnAsEntity(AreaTile.GetEmptyTile(HauledBy.Parent as AreaTile));

        HauledBy = null;

        return true;
    }
    public ItemEntity SpawnAsEntity(AreaTile tile)
    {
        if(gameObject == null) return null;

        ItemEntity entity = gameObject.AddComponent<ItemEntity>();
        entity.Caravan = Caravan;
        entity.SpawnAt(tile);
        entity.SetItem(this);

        return entity;
    }

    #region ItemSource
    public bool CanSource(ItemDef item)
    {
        return ItemDef == item & Reserved == 0 & HauledBy == null;
    }
    public void ReserveSource(ItemDef item, int quantity, out int maxQuantity)
    {
        if (Reserved > 0)
        {
            maxQuantity = 0;
        }
        else
        {
            maxQuantity = Mathf.Min(quantity, Quantity);
            Reserved += maxQuantity;

            if(Entity != null) Entity.Reserved = true;
        }
    }
    public void CancelSource(ItemDef item, int quantity)
    {
        Reserved -= quantity;
        if(Reserved == 0 && Entity != null) Entity.Reserved = false;
    }
    public virtual Item Take(Creature taker, ItemDef item, int quantity)
    {
        if(_destroyed) return null;

        Reserved = 0;

        bool haulChild = false;

        if(Entity != null)
        {
            Entity.Reserved = false;
            foreach (JobTarget target in Entity.JobTargets)
            {
                if(target is HaulingJobTarget)
                {
                    haulChild = target.Job != null;
                    break;
                }
            }
            Entity.Take();
        }
        if (quantity < Quantity) Split(Quantity - quantity, haulChild);

        HauledBy = taker;
        transform.SetParent(taker.transform);
        transform.SetLocalPositionAndRotation(new Vector3(0, 0.5f, -1), Quaternion.identity);

        return this;
    }

    public List<AreaTile> GetInteractionSpots() => Entity.Parent.GetInteractionSpots();
    public AreaTile GetFirstSpot() => Entity.Parent.GetFirstSpot();
    #endregion

    #region Item to Storage
    public virtual bool CanBeStored(IItemReceiver s)
    {
        return s.CanReceive(ItemDef);
    }
    public virtual int ReserveStorage(IItemReceiver storage)
    {
        return storage.ReserveReceiving(ItemDef, Quantity);
    }
    public virtual void EnterStorage(IItemReceiver storage)
    {
        storage?.Receive(ItemDef, Quantity);
        Destroy();
    }
    public virtual void CancelStorage(IStorage storage, int haulQuantity)
    {
        storage.CancelReceiving(ItemDef, haulQuantity);
    }

    protected override void AddReferences()
    {
    }

    protected override void RemoveReferences()
    {
    }
    #endregion
}
