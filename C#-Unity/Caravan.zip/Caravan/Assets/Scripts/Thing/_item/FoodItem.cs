using System;
using UnityEngine;

public class FoodItem : Item, IWithNutrition
{
    public FoodItemDef FoodDef;
    public float Nutrition => FoodDef.Nutrition;

    public ItemCategoryDef[] Type => FoodDef.Categories;

    public bool Consume(Creature eater, Need need)
    {
        int needed = Mathf.Min(Mathf.RoundToInt((need.NeedDef.MaxNeed - need.Satisfaction) / Nutrition), Quantity);

        need.Satisfaction = Mathf.Min(need.Satisfaction + needed * Nutrition, need.NeedDef.MaxNeed);

        if (Entity != null)
        {
            #region Bake Items quantity
            Item.WorldQuantity[ItemDef] -= needed;
            foreach (ItemCategoryDef cat in ItemDef.Categories)
            {
                Item.WorldCategory[cat] -= needed;
            }
            Entity.Parent.Area.FlooredNutrition -= needed * FoodDef.Nutrition;
            #endregion

        }
        Quantity -= needed;

        if (Quantity <= 0) Destroy();

        return Quantity > 0;
    }

    public override void OnSelect(SelectionForm selectionForm)
    {
        selectionForm.Update(this.ToString(), $"Nutrition : {FoodDef.Nutrition}", null, null, null, null, null, Vector2.one);
    }
}