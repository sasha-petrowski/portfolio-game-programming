using UnityEngine;

public class UniqueItem : Item
{
    public IStorage Storage;
    public override string ToString()
    {
        return $"{name} ({GetType()})";
    }




    public override bool CanBeStored(IItemReceiver s)
    {
        return s.CanReceive(this);
    }
    public override int ReserveStorage(IItemReceiver storage)
    {
        storage.ReserveReceiving(this);
        return 1;
    }
    public override void EnterStorage(IItemReceiver storage)
    {
        Storage = (IStorage)storage;

        storage?.Receive(this);
        GetComponent<SpriteRenderer>().enabled = false;
        transform.parent = null;
    }
    public virtual void ExitStorage(IItemSource storage)
    {
        GetComponent<SpriteRenderer>().enabled = true;
        Storage = null;
    }
    public override void CancelStorage(IStorage storage, int haulQuantity)
    {
        storage.CancelReceiving(this);
    }
}