using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class CorpseItem : UniqueItem, IWithNutrition
{
    public static List<CorpseItem> AllCorpses = new List<CorpseItem>();


    public ItemCategoryDef[] Type => ItemDef.Categories;

    public Creature Creature;
    public float MissingParts = 0;

    public float Nutrition => Creature.CreatureDef.CorpseNutrition * (1-MissingParts);


    public bool Consume(Creature consumer, Need need)
    {
        float maxNutrition = Mathf.Min(need.NeedDef.MaxNeed - need.Satisfaction, Nutrition);

        //Debug.Log("Eating "+name+" : " + maxNutrition + " / " + Nutrition);
        need.Satisfaction += maxNutrition;

        MissingParts += maxNutrition / Creature.CreatureDef.CorpseNutrition;

        if (Entity != null) Entity.Parent.Area.FlooredNutrition -= maxNutrition;

        if (Nutrition < 1)
        {
            Entity?.Destroy();
            Destroy();
            return false;
        }
        else return true;
    }

    protected override void AddReferences()
    {
        base.AddReferences();
        CorpseItem.AllCorpses.Add(this);
    }
    protected override void RemoveReferences()
    {
        base.RemoveReferences();
        CorpseItem.AllCorpses.Remove(this);
    }

    public override void OnSelect(SelectionForm selectionForm)
    {
        base.OnSelect(selectionForm);

        selectionForm.LesserDescription += $"Missing body parts : {(int)(MissingParts * 100)}%";
    }
}