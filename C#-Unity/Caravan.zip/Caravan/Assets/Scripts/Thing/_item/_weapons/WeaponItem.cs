using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class WeaponItem : UniqueItem
{
    private bool _drawn;
    private bool _animated;
    public abstract WeaponDef WeaponDef { get; }

    public void Equip(Creature holder)
    {
        if (HauledBy == null) Take(holder, ItemDef, 1);
        else if (HauledBy != holder)
        {
            Debug.LogWarning($"{holder} tried to take {this} while hauldedBy {HauledBy}");
            return;
        }

        Reserved = 1;

        if (holder.Weapon != null) holder.Weapon.Drop();
        holder.Weapon = this;

        SheathWeapon();
    }
    public void SheathWeapon()
    {
        if(!_animated)
        {
            transform.localPosition = WeaponDef.SheathedPosition;
            transform.localRotation = WeaponDef.SheathedRotation;
        }
        _drawn = false;
    }
    public void DrawWeapon()
    {
        if (!_animated)
        {
            transform.localPosition = WeaponDef.DrawnPosition;
            transform.localRotation = WeaponDef.DrawnRotation;
        }
        _drawn = true;
    }
    public void AttackAnimation()
    {
        StartCoroutine(AttackAnimationCoroutine());
    }
    private IEnumerator AttackAnimationCoroutine()
    {
        _animated = true;

        float time = 0;

        while(time < WeaponDef.AttackAnimation)
        {
            time += Caravan.DevSpeed ? Time.deltaTime * 10 : Time.deltaTime;

            float lerp = (time / WeaponDef.AttackAnimation) * 2f;
            if(lerp > 1) lerp = 2 - lerp;

            transform.localPosition = Vector2.Lerp(WeaponDef.DrawnPosition, WeaponDef.AttackPosition, lerp);
            transform.localRotation = Quaternion.Lerp(WeaponDef.DrawnRotation, WeaponDef.AttackRotation, lerp);

            yield return null;
        }

        _animated = false;

        if (_drawn)
        {
            // Set position to drawn
            transform.localPosition = WeaponDef.DrawnPosition;
            transform.localRotation = WeaponDef.DrawnRotation;
        }
        else
        {
            // Set position to Sheathed
            transform.localPosition = WeaponDef.SheathedPosition;
            transform.localRotation = WeaponDef.SheathedRotation;
        }
    }
    public override Item Take(Creature taker, ItemDef item, int quantity)
    {
        Item thing = base.Take(taker, item, quantity);
        if(thing != null) RemoveFromFreeWeapons();

        return null;
    }
    public override bool Drop()
    {
        if(base.Drop())
        {
            AddToFreeWeapons();
            return true;
        }
        return false;
    }
    
    protected override void AddReferences()
    {
        base.AddReferences();

        AddToFreeWeapons();
    }
    protected override void RemoveReferences()
    {
        base.RemoveReferences();

        RemoveFromFreeWeapons();
    }

    public override void EnterStorage(IItemReceiver storage)
    {
        base.EnterStorage(storage);

        AddToFreeWeapons();
    }
    public override void ExitStorage(IItemSource storage)
    {
        base.ExitStorage(storage);

        RemoveFromFreeWeapons();
    }


    private void AddToFreeWeapons()
    {
        if (Caravan == null) return;

        if (Caravan.FreeWeapons.Contains(this)) return;

        LinkedListNode<WeaponItem> current = Caravan.FreeWeapons.First;

        while (current != null)
        {
            WeaponItem item = current.Value;
            if (WeaponDef.DPS > item.WeaponDef.DPS)
            {
                Caravan.FreeWeapons.AddBefore(current, this);
                return;
            }

            current = current.Next;
        }
        // only if it's the weapon with the least DPS
        Caravan.FreeWeapons.AddLast(this);
    }
    private void RemoveFromFreeWeapons()
    {
        if (Caravan == null) return;

        Caravan.FreeWeapons.Remove(this);
    }
}