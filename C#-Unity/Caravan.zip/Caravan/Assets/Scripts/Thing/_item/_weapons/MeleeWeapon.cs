public class MeleeWeapon : WeaponItem
{
    public MeleeWeaponDef MeleeWeaponDef;
    public override WeaponDef WeaponDef => MeleeWeaponDef;
}