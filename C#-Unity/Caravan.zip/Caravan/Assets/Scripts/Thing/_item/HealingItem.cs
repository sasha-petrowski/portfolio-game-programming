using System;
using UnityEngine;

public class HealingItem : Item, IWithHealing
{
    public HealingItemDef HealDef;
    public int Healing => HealDef.Healing;
    public ItemCategoryDef[] Type => HealDef.Categories;

    public bool Consume(Creature consumer, Need noneed)
    {
        if(noneed != null) Debug.LogWarning("Warning : need should be null as it is not needed");



        int needed = Mathf.Min(Mathf.RoundToInt((consumer.Def.MaxHealth - consumer.Health - consumer.Regeneration) / Healing), Quantity);

        consumer.Regeneration += needed * Healing;

        if (Entity != null)
        {
            #region Bake Items quantity
            Item.WorldQuantity[ItemDef] -= needed;
            foreach (ItemCategoryDef cat in ItemDef.Categories)
            {
                Item.WorldCategory[cat] -= needed;
            }
            #endregion
        }
        Quantity -= needed;

        if (Quantity <= 0) Destroy();

        return Quantity > 0;
    }

    public override void OnSelect(SelectionForm selectionForm)
    {
        selectionForm.Update(this.ToString(), $"Healing : {HealDef.Healing}%", null, null, null, null, null, Vector2.one);
    }
}