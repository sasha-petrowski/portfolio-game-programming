using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Animal : SmallCreature
{
    public override void TickUpdate()
    {
        base.TickUpdate();
    }

    protected override void AddReferences()
    {
        base.AddReferences();

        TryAddTarget(new HuntingJobTarget());
    }
    protected override void RemoveReferences()
    {
        base.RemoveReferences();
    }
    public override void OnSelect(SelectionForm selectionForm)
    {
        base.OnSelect(selectionForm);
    }
}
