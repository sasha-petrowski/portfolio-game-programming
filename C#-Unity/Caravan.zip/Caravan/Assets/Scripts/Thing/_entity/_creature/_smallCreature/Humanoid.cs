using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Humanoid : SmallCreature
{
    public SpriteRenderer ProgressBG;
    public SpriteRenderer ProgressSlider;

    protected override void AddReferences()
    {
        base.AddReferences();
        Caravan.Caravaneers.AddLast(this);
    }
    protected override void RemoveReferences()
    {
        base.RemoveReferences();
        Caravan.Caravaneers.Remove(this);
    }
    public override Func<Vector2, bool> GetSecondaryEffect()
    {
        return DevGoTo;
    }

    public bool DevGoTo(Vector2 worldPosition)
    {
        Area targetArea = ThingManager.Instance.GetAreaAt(worldPosition, Parent.Area);
        if(targetArea != null)
        {
            Vector2Int index = targetArea.WorldToIndex(worldPosition);
            if (CurrentJob != null)
            {
                CurrentJob.OnLeaveJob(this);
            }
            new GoToJob(targetArea.GetTile(index.x, index.y)).TryTakeJob(this);
        }
        return CurrentJob != null;
    }
}
