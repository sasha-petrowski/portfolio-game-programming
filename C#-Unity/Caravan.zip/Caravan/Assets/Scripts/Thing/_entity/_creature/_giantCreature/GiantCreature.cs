using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

public abstract class GiantCreature : Creature
{
    private const float GIANT_TURN_SPEED = 0.1f;

    public GiantDef GiantDef;

    public BuildingArea BuildingArea { get; private set; }

    private AreaDriverTile[] _driverTiles;
    private DrivingJob _drivingJob;

    protected override void AddReferences()
    {
        Caravan.GiantEntities.AddLast(this);
    }
    protected override void RemoveReferences()
    {
        base.RemoveReferences();
        Caravan.GiantEntities.Remove(this);
    }
    public int FollowPath()
    {
        transform.eulerAngles = new Vector3(0, 0, Mathf.LerpAngle(transform.eulerAngles.z, Caravan.MoveAngle * Mathf.Rad2Deg, (Caravan.DevSpeed ? MoveSpeed * 10 : MoveSpeed) * Time.deltaTime * GIANT_TURN_SPEED));

        transform.position += (Caravan.DevSpeed ? MoveSpeed * 10 : MoveSpeed) * Time.deltaTime * (Caravan.MoveDirection + transform.up) / 2f;

        BuildingArea?.UpdateTransform();

        AreaTile tile = ChunkArea.GetTile(transform.position);
        SetParent(tile);

        return 0;
    }
    public override void TickUpdate()
    {
    }

    public void SetBuildingArea(BuildingArea buildingArea)
    {
        BuildingArea = buildingArea;
        buildingArea.GiantEntity = this;
        buildingArea.transform.SetParent(transform);
        buildingArea.transform.localPosition = (Vector3)GiantDef.AreaOffset + new Vector3(0, 0, -1);
        buildingArea.UpdateTransform();

        #region Assign driver tile(s)
        int driverX = buildingArea.Width / 2;
        int driverY = buildingArea.Height - 1;

        if (buildingArea.Width % 2 == 0) // Even Width
        {
            _driverTiles = new AreaDriverTile[2] { buildingArea.Tiles[driverX - 1, driverY] as AreaDriverTile, buildingArea.Tiles[driverX, driverY] as AreaDriverTile };
        }
        else // Uneven
        {
            _driverTiles = new AreaDriverTile[1] { buildingArea.Tiles[driverX, driverY] as AreaDriverTile };
        }
        #endregion

        // provide Jobs
        _drivingJob = new DrivingJob(this);
        buildingArea.AddJobProvider(_drivingJob);
    }
    public override bool IsHover(Vector2 worldPosition)
    {
        float sin = Mathf.Sin(transform.eulerAngles.z * Mathf.Deg2Rad);
        float cos = Mathf.Cos(transform.eulerAngles.z * Mathf.Deg2Rad);

        Vector2 local = worldPosition - (Vector2)transform.position;

        local = new Vector2(
            (local.x * cos) + (local.y * sin),
          -((local.x * sin) - (local.y * cos)));

        return Mathf.Pow(local.x / (GiantDef.Width / 2f), 2f) + Mathf.Pow(local.y / (GiantDef.Height / 2f), 2f) < 1;
    }
    public override Thing GetChildAt(Vector2 worldPosition, Thing ignoreThing)
    {
        if (BuildingArea != ignoreThing && BuildingArea != null && BuildingArea.IsHover(worldPosition))
        {
            return BuildingArea;
        }
        return null;
    }
    public override void EnterArea(Area newArea)
    {
        base.EnterArea(newArea);

        newArea.GiantEntities.AddLast(this);
    }
    public override void LeaveArea(Area oldArea)
    {
        base.LeaveArea(oldArea);

        Parent.Area.GiantEntities.Remove(this);
    }
    public List<AreaTile> GetFreeDriverTiles()
    {
        List<AreaTile> free = new List<AreaTile>();
        foreach (AreaDriverTile driverTile in _driverTiles)
        {
            if (driverTile.CanBeUsed()) free.Add(driverTile);
        }
        return free;
    }
    private void OnDrawGizmosSelected()
    {
        Vector3 areaPosition = transform.position + (Vector3)(transform.localToWorldMatrix * GiantDef.AreaOffset);
        Gizmos.DrawCube(areaPosition, Vector3.one * 0.25f);
        Gizmos.DrawWireCube(areaPosition, (Vector3Int)GiantDef.MaxAreaSize);
    }
    private void OnDrawGizmos()
    {
        if(_driverTiles != null)
        {
            foreach (AreaDriverTile driverTile in GetFreeDriverTiles())
            {
                Gizmos.color = Color.Lerp(driverTile.Room._debugColor, Color.clear, 0.25f);

                Gizmos.DrawCube(driverTile.WorldPosition(), Vector3.one);
            }
        }
    }

    #region DrivingSpots Alert
    private GameObject _drivingAlert;

    public void VerifyDrivingSpot()
    {
        List<AreaTile> drivingSpots = GetFreeDriverTiles();

        if(_drivingAlert == null && (drivingSpots == null || drivingSpots.Count == 0))
        {
            _drivingAlert = UIManager.Instance.AlertMenu.CreateAlert("Driving spot is occupied", () => _driverTiles[0].WorldPosition());
        }
        else if(_drivingAlert != null)
        {
            Destroy(_drivingAlert);
        }
    }
    #endregion

    public override void OnSelect(SelectionForm selectionForm)
    {
        base.OnSelect(selectionForm);

        selectionForm.SelectSize = new Vector2(GiantDef.Width, GiantDef.Height);
    }
}
