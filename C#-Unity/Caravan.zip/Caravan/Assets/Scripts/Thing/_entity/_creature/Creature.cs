using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Assertions;

public abstract class Creature : Entity
{
    public static List<Creature> AllCreatures = new List<Creature>();


    private HealingJob _healingJob;
    public Job CurrentJob;
    public List<Need> Needs = new List<Need>();

    public float MoveSpeed;

    public ParticleSystem SleepParticules;
    public SpriteRenderer CooldownSprite;

    private float _attackCooldown;
    private int _dangerTick;
    private int _dangerIndex;

    public int Regeneration;
    public float _regenerationDelta;

    public WeaponItem Weapon;

    public CreatureDef CreatureDef;
    public override EntityDef Def => CreatureDef;

    public bool CanMove => _attackCooldown <= 0;

    private void Update()
    {
        TickRegenerate();
        TickDanger();
        TickUpdate();
        TickNeeds();
    }
    public void TickRegenerate()
    {
        if (Regeneration == 0)
        {
            if(Caravan == Caravan.s_PlayerCaravan && _healingJob == null && Health < CreatureDef.MaxHealth - CreatureDef.MaxHealth / 4)
            {
                _healingJob = new HealingJob(this);

                Parent.Area.AddJobProvider(_healingJob);
            }
            return;
        }
        else if(_healingJob != null)
        {
            Parent.Area.RemoveJobProvider(_healingJob);
            _healingJob = null;
        }

        _regenerationDelta += (Caravan.DevSpeed ? (Time.deltaTime * 10) : Time.deltaTime);

        if(_regenerationDelta > 1)
        {
            if (Health + 1 >= Def.MaxHealth) Regeneration = 0;
            else Regeneration--;

            _regenerationDelta -= 1;
            HealDamage(1);
        }
    }
    public void TickDanger()
    {
        if (Caravan == null || Caravan.DangerSources.Count == 0 || CurrentJob is DangerJob) return;

        // check every ten frames to lower processing
        _dangerTick = (_dangerTick + 1) % 10;
        if (_dangerTick == 0)
        {
            _dangerIndex = (_dangerIndex + 1) % Caravan.DangerSources.Count;
            Entity danger = Caravan.DangerSources[_dangerIndex];

            if( Vector2.SqrMagnitude(danger.transform.position - transform.position) < 100 /* 10*10 */ )
            {
                new FightDangerJob(danger).TryTakeJob(this);
            }
        }
    }
    public override void TickUpdate()
    {
        base.TickUpdate();
        if(Parent.CrossTime() < 0)
        {
            AreaTile tile = AreaTile.GetWalkable(Parent as AreaTile, this);
            if(tile != null)
            {
                SnapToPart(tile);
                SetParent(tile);
            }
        }


        if (CurrentJob != null)
        {
            CurrentJob.DoJob(this);
        }
        else
        {
            foreach(Need need in Needs)
            {
                if (need.TryTakeJob(this) != null) break;
            }

            if (CurrentJob == null)
            {
                FindBetterWeapon();
            }

            if (CurrentJob == null)
            {
                CurrentJob = JobManager.TryFindJob(this);
            }

            if (CurrentJob == null)
            {
                CurrentJob = new WanderJob().TryTakeJob(this);
            }
        }
    }
    public void TickNeeds()
    {
        foreach (Need need in Needs)
        {
            need.TickNeed(this);
        }
    }
    private void FindBetterWeapon()
    {
        if (Caravan == null) return;

        foreach (WeaponItem item in Caravan.FreeWeapons)
        {
            if (Weapon != null && Weapon.WeaponDef.DPS >= item.WeaponDef.DPS) return;

            if (item.Reserved == 0)
            {
                /*
                if (Weapon != null) Debug.Log($"Current : {Weapon.WeaponDef} {Weapon.WeaponDef.DPS} : Other : {item.WeaponDef} {item.WeaponDef.DPS} : Test : {Weapon.WeaponDef.DPS >= item.WeaponDef.DPS}");
                else Debug.Log(item);
                */
                CurrentJob = new TakeWeaponJob(item).TryTakeJob(this);
                if (CurrentJob != null) return;
            }
            else
            {
                Debug.Log(item + " is reserved");
            }
        }
    }
    public override bool IsHover(Vector2 worldPosition)
    {
        return 0.5f > (worldPosition.x - transform.position.x) * (worldPosition.x - transform.position.x) + (worldPosition.y - transform.position.y) * (worldPosition.y - transform.position.y);
    }

    private void OnDrawGizmos()
    {
        // Self 
        float selfRadAngle = transform.eulerAngles.z * Mathf.Deg2Rad;
        Gizmos.DrawLine(transform.position, transform.position + new Vector3(-Mathf.Sin(selfRadAngle) * 10, Mathf.Cos(selfRadAngle) * 10, 0));
        
        if(CurrentJob != null)
        {
            CurrentJob.OnDrawGizmos();
        }
    }
    protected override void AddReferences()
    {
        base.AddReferences();

        AllCreatures.Add(this);
    }
    protected override void RemoveReferences()
    {
        CooldownSprite.enabled = false;

        AllCreatures.Remove(this);

        base.RemoveReferences();

        if (CurrentJob != null) CurrentJob.OnLeaveJob(this);
        CurrentJob = null;
    }

    public override void EnterArea(Area newArea)
    {
        base.EnterArea(newArea);

        newArea.Creatures.AddLast(this);
        if (_healingJob != null) newArea.AddJobProvider(_healingJob);
    }
    public override void LeaveArea(Area oldArea)
    {
        base.LeaveArea(oldArea);

        oldArea.Creatures.Remove(this);
        if (_healingJob != null) oldArea.RemoveJobProvider(_healingJob);
    }
    public override void SnapToPart(AreaPart part)
    {
        transform.SetParent(part.Area.transform);
        transform.SetPositionAndRotation(part.WorldPosition() + new Vector3(0, 0, -2), part.Area.transform.rotation);
    }
    public override void HealDamage(int heal)
    {
        base.HealDamage(heal);

        if(Regeneration > 0) GetComponent<SpriteRenderer>().color = new Color(1 - (Regeneration / 4) / (float)Def.MaxHealth, (Health + Regeneration) / (float)Def.MaxHealth, Health / (float)Def.MaxHealth, 1);
    }

    public override void OnSelect(SelectionForm selectionForm)
    {
        string[] barNames = new string[1 + Needs.Count];
        float[] barValues = new float[1 + Needs.Count];
        float[] barMax = new float[1 + Needs.Count];
        Color[] barColors = new Color[1 + Needs.Count];

        barNames[0] = "Health";
        barValues[0] = Health;
        barMax[0] = Def.MaxHealth;
        barColors[0] = new Color(1 - Health / Def.MaxHealth, Health / Def.MaxHealth, 0, 1);

        for (int i = 1; i < Needs.Count + 1; i++)
        {
            Need need = Needs[i - 1];

            barNames[i] = need.NeedDef.SmallName;
            barValues[i] = need.Satisfaction;
            barMax[i] = need.NeedDef.MaxNeed;
            barColors[i] = new Color(1 - need.Satisfaction / need.NeedDef.MaxNeed, need.Satisfaction / need.NeedDef.MaxNeed, 0, 1);
        }

        selectionForm.Update(
            name,
            "A creature entity",
            CurrentJob?.ToString(),
            barNames,
            barValues,
            barMax,
            barColors,
            new Vector2(1, 1));
    }

    public void Fight(Entity target)
    {
        Cooldown();

        if (_attackCooldown <= 0 && ! target.IsDead)
        {
            //Default values
            float cooldown = 1;
            int damage = 15;

            if(Weapon != null)
            {
                cooldown = Weapon.WeaponDef.AttackCooldown;
                damage = Weapon.WeaponDef.AttackDamage;

                Weapon.AttackAnimation();
            }

            target.TakeDamage(damage);
            _attackCooldown = cooldown;
        }
    }
    public void Cooldown()
    {
        _attackCooldown -= Caravan.DevSpeed ? Time.deltaTime * 10 : Time.deltaTime;
        CooldownSprite.enabled = _attackCooldown > 0;
        if( _attackCooldown > 0 ) 
        {
            CooldownSprite.transform.localScale = Vector2.one * _attackCooldown * 3;
        }
    }

    public void OnDeath()
    {

        Debug.Assert(enabled, "Error : Dying while dead");

        RemoveReferences();
        enabled = false;

        GetComponent<SpriteRenderer>().sprite = CreatureDef.DeathSprite;
        GetComponent<SpriteRenderer>().color = Color.white;

        #region Create a corpse Item
        AreaTile tile = AreaTile.GetEmptyTile(Parent as AreaTile);

        CorpseItem item = gameObject.AddComponent<CorpseItem>();

        item.ItemDef = CreatureDef.CorpseDef;
        item.Creature = this;
        item.Caravan = Caravan;
        item.Quantity = 1;

        item.SpawnAsEntity(tile);
        #endregion
    }
}
