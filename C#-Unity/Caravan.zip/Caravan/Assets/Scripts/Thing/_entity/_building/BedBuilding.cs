using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class BedBuilding : Building
{
    public float RestFactor;

    public Creature Sleeper;

    protected override void AddReferences()
    {
        Caravan.Beds.Add(this);
    }
    protected override void RemoveReferences()
    {
        base.RemoveReferences();

        Caravan.Beds.Remove(this);
    }

    public override void OnSelect(SelectionForm selectionForm)
    {
        selectionForm.Update(
            name,
            "A bed",
            $"Rest effectiveness : {RestFactor * 100}%",
            null,
            null,
            null,
            null,
            BuildingDef.Shape.GetSize(IsFacing));
    }
}
