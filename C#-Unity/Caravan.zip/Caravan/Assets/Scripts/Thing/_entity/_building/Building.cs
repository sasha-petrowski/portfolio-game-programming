using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class Building : Entity
{
    public BuildingDef BuildingDef;

    public override EntityDef Def => BuildingDef;

    [HideInInspector]
    public int IsFacing = 0;

    public override void SpawnAt(AreaPart part)
    {
        base.SpawnAt(part);
        BuildingDef.Shape.EachPartFrom(IsFacing, ReserveTile, part);
    }
    protected override void AddReferences()
    {
        base.AddReferences();
        TryAddTarget(new DeconstructJobTarget());
    }
    protected override void RemoveReferences()
    {
        if (Parent != null)
        {
            BuildingDef.Shape.EachPartFrom(IsFacing, FreeTile, Parent);

            if (_deconstructJob != null)
            {
                Parent.Area.RemoveJobProvider(_deconstructJob);
            }
            if (BuildingDef.CrossTime < 0) Room.CalculateRooms(Parent.Area);
        }
        base.RemoveReferences();
    }
    private bool ReserveTile(AreaPart part)
    {
        part.Entity = this;
        part.UpdatePart();
        return true;
    }
    private bool FreeTile(AreaPart part)
    {
        if (part.Entity == this)
        {
            part.Entity = null;
            part.UpdatePart();
        }
        return true;
    }
    public override void SnapToPart(AreaPart part)
    {
        transform.SetParent(part.Area.transform);

        BuildingDef.Shape.SnapToPart(IsFacing, transform, part);
    }


    public override List<AreaTile> GetInteractionSpots()
    {
        if(BuildingDef.CrossTime < 0)
        {
            return (Parent as AreaTile)?.CanGoTo().ToList();
        }
        return base.GetInteractionSpots();
    }
    public override AreaTile GetFirstSpot()
    {
        if (BuildingDef.CrossTime < 0)
        {
            return (Parent as AreaTile)?.CanGoTo().First();
        }
        return base.GetFirstSpot();
    }

    public override void OnSelect(SelectionForm selectionForm)
    {
        selectionForm.Update(
            name,
            null,
            null,
            null,
            null,
            null,
            null,
            BuildingDef.Shape.GetSize(IsFacing));
    }

    #region IDeconstructTarget
    public DeconstructJob _deconstructJob;
    public void OrderDeconstruct()
    {
        if (BuildingDef.Materials.Required.Length == 0) Destroy();
        else if (_deconstructJob == null)
        {
            _deconstructJob = new DeconstructJob(this);
            Parent.Area.AddJobProvider(_deconstructJob);
        }
    }
    #endregion
}
