using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class WorkbenchBuilding : Building, IJobProvider
{
    public WorkbenchBuildingDef WorkbenchDef;

    public List<CraftingJob> Crafts => _jobs;
    private List<CraftingJob> _jobs = new List<CraftingJob>();

    public CraftingJob ReservedJob;

    public override void EnterArea(Area newArea)
    {
        base.EnterArea(newArea);

        newArea.AddJobProvider(this);
    }
    public override void LeaveArea(Area oldArea)
    {
        base.LeaveArea(oldArea);

        oldArea.RemoveJobProvider(this);
    }

    protected override void RemoveReferences()
    {
        base.RemoveReferences();

        if (_jobs != null)
        {
            for (int i = _jobs.Count - 1; i >= 0; i--)
            {
                _jobs[i].DeleteJob();
            }
            _jobs = null;
        }
    }

    #region IJobProvider
    public int JobType => (int)JobTypes.Craft;

    public Job TryTakeJob(Creature taker)
    {
        if (ReservedJob != null) return null;

        foreach(CraftingJob job in _jobs)
        {
            if (job.TryTakeJob(taker) != null) return job;
        }

        return null;
    }
    public Vector2 GetPosition()
    {
        return transform.position;
    }
    #endregion


    public override void OnSelect(SelectionForm selectionForm)
    {
        StringBuilder lesserDescription = new StringBuilder();

        foreach (CraftingJob job in _jobs)
        {
            lesserDescription.Append(job.Craft.name);

            if (job.Received) lesserDescription.AppendLine($" : Progress : {Mathf.RoundToInt(100 * job.CraftTime / job.Craft.CraftTime)}%");
            else
            {
                lesserDescription.AppendLine($" : Gathering : {Mathf.RoundToInt(100f * job.RequiredItems.GetCompletion(job.Fetched))}%");
            }
        }

        selectionForm.Update(
            name,
            "A workbench",
            lesserDescription.ToString(),
            null,
            null,
            null,
            null,
            BuildingDef.Shape.GetSize(IsFacing));
    }
}
