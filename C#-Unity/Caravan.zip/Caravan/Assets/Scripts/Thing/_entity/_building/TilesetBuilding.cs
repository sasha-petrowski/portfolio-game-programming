using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Unity.VisualScripting;
using UnityEngine;

public class TilesetBuilding : Building
{
    [Flags]
    private enum Sides
    {
        Top = 1 << 1,
        Left = 1 << 2,
        Bottom = 1 << 3,
        Right = 1 << 4,

        All = Top + Left + Bottom + Right,

        ThreeTop = Top + Left + Right,
        ThreeLeft = Top + Left + Bottom,
        ThreeBottom = Left + Bottom + Right,
        ThreeRight = Top + Bottom + Right,

        BottomLeft = Bottom + Left,
        BottomRight = Bottom + Right,
        TopLeft = Top + Left,
        TopRight = Top + Right,

        TopBottom = Top + Bottom,
        LeftRight = Left + Right,


    }

    private Sides _sides;

    public override void SetParent(AreaPart part, bool spawn = false)
    {
        base.SetParent(part, spawn);

        for (int i = 0; i < 4; i++)
        {
            if (part.TryGetWall(i, out AreaWall wall) && wall.CrossTime() < 0) continue;

            if (part.TryGetTile(i, out AreaTile other) && other.Entity != null && other.Entity is TilesetBuilding neighbor)
            {
                neighbor._sides += 1 << ((i + 2) % 4 + 1);
                neighbor.UpdateTileset();

                _sides += 1 << (i + 1);
            }
        }

        UpdateTileset();
    }
    protected override void RemoveReferences()
    {
        base.RemoveReferences();

        for (int i = 0; i < 4; i++)
        {
            if (Parent.TryGetWall(i, out AreaWall wall) && wall.CrossTime() < 0) continue;

            if (Parent.TryGetTile(i, out AreaTile other) && other.Entity != null && other.Entity is TilesetBuilding neighbor)
            {
                neighbor._sides -= 1 << ((i + 2) % 4 + 1);
                neighbor.UpdateTileset();
            }
        }
    }

    private void UpdateTileset()
    {
        if (! (Def is TilesetBuildingDef def) || ! TryGetComponent(out SpriteRenderer renderer)) return;

        if (_sides.HasFlag(Sides.All)) renderer.sprite = def.All;

        else if (_sides.HasFlag(Sides.ThreeTop)) renderer.sprite = def.ThreeTop;
        else if (_sides.HasFlag(Sides.ThreeBottom)) renderer.sprite = def.ThreeBottom;
        else if (_sides.HasFlag(Sides.ThreeLeft)) renderer.sprite = def.ThreeLeft;
        else if (_sides.HasFlag(Sides.ThreeRight)) renderer.sprite = def.ThreeRight;

        else if (_sides.HasFlag(Sides.TopLeft)) renderer.sprite = def.TopLeft;
        else if (_sides.HasFlag(Sides.TopRight)) renderer.sprite = def.TopRight;
        else if (_sides.HasFlag(Sides.BottomLeft)) renderer.sprite = def.BottomLeft;
        else if (_sides.HasFlag(Sides.BottomRight)) renderer.sprite = def.BottomRight;

        else if (_sides.HasFlag(Sides.TopBottom)) renderer.sprite = def.TopBottom;
        else if (_sides.HasFlag(Sides.LeftRight)) renderer.sprite = def.LeftRight;

        else if (_sides.HasFlag(Sides.Top)) renderer.sprite = def.Top;
        else if (_sides.HasFlag(Sides.Bottom)) renderer.sprite = def.Bottom;
        else if (_sides.HasFlag(Sides.Right)) renderer.sprite = def.Right;
        else if (_sides.HasFlag(Sides.Left)) renderer.sprite = def.Left;
    }

    public override void OnSelect(SelectionForm selectionForm)
    {
        base.OnSelect(selectionForm);
        selectionForm.LesserDescription += $"\n{_sides}";
    }
}
