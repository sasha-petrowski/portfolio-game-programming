using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RectangleBuilding : TileBuilding
{
    [SerializeField]
    private int _width = 1;
    [SerializeField]
    public int _height = 1;



    public override List<AreaPart> SpecialParts(int direction, Area area, Vector2Int start, Vector2 offset)
    {
        if (direction % 2 == 0)
        {
            return STE.Select(_specialCoordinateSelectionType, area, start, offset, false, _width, _height);
        }
        else
        {
            return STE.Select(_specialCoordinateSelectionType, area, start, offset, false, _height, _width);
        }
    }
    public override List<AreaPart> PreferedParts(int direction, Area area, Vector2Int start, Vector2 offset)
    {
        if (direction % 2 == 0)
        {
            return STE.Select(_coordinateSelectionType, area, start, offset, false, _width, _height);
        }
        else
        {
            return STE.Select(_coordinateSelectionType, area, start, offset, false, _height, _width);
        }
    }
    public override bool EachPartFrom(int direction, Func<AreaPart, bool> test, AreaPart from)
    {
        AreaTile fromTile = from as AreaTile;
        if (fromTile == null) return false;


        int startX = fromTile.x;
        int startY = fromTile.y;

        int endX;
        int endY;

        if (direction % 2 == 0)
        {
            endX = fromTile.x + _width - 1;

            endY = fromTile.y + _height - 1;
        }
        else
        {
            endX = fromTile.x + _height - 1;

            endY = fromTile.y + _width - 1;
        }


        if ((startX < 0 | endX >= from.Area.Width | startY < 0 | endY >= from.Area.Height)) // if out of bounds
        {
            //Debug.LogError("Building Out of bounds");
            return false;
        }
        for (int x = startX; x <= endX; x++)
        {
            for (int y = startY; y <= endY; y++)
            {
                AreaTile tile = from.Area.GetTile(x, y);

                if (!test(tile)) return false;

                if (x != startX && tile.TryGetWall((int)TilePosition.Left, out AreaWall leftWall))
                {
                    if (!test(leftWall)) return false;
                }

                if (y != startY && tile.TryGetWall((int)TilePosition.Bottom, out AreaWall topWall))
                {
                    if (!test(topWall)) return false;
                }
            }
        }
        return true;
    }
    public override Vector3 PartOffset(int direction, AreaPart part)
    {
        if (direction % 2 == 0)
        {
            return new Vector3((_width - 1) / 2f, (_height - 1) / 2f, -1);
        }
        else
        {
            return new Vector3((_height - 1) / 2f, (_width - 1) / 2f, -1);
        }
    }
    public override Vector2 GetSize(int direction)
    {
        if (direction % 2 == 0)
        {
            return new Vector2(_width, _height);
        }
        else
        {
            return new Vector2(_height, _width);
        }
    }
}
