using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;
using System;
using Unity.Jobs;

public class Blueprint : Entity, ICancelTarget
{
    public float BuildTime;

    public BuildingDef BuildingDef;
    public override EntityDef Def => BuildingDef;


    private BuildingJob _buildJob;

    public int IsFacing = 0;

    public override void SpawnAt(AreaPart part)
    {
        base.SpawnAt(part);
        BuildingDef.Shape.EachPartFrom(IsFacing, ReserveTile, part);

        _buildJob = new BuildingJob(this);
        part.Area.AddJobProvider(_buildJob);
    }
    protected override void AddReferences()
    {
    }
    protected override void RemoveReferences()
    {
        if (Parent != null)
        {
            Parent.Area.RemoveJobProvider(_buildJob);
            BuildingDef.Shape.EachPartFrom(IsFacing, FreeTile, Parent);
        }
        base.RemoveReferences();
    }
    private bool ReserveTile(AreaPart part)
    {
        part.Entity = this;
        part.UpdatePart();
        return true;
    }
    private bool FreeTile(AreaPart part)
    {
        if(part.Entity == this)
        {
            part.Entity = null;
            part.UpdatePart();
        }
        return true;
    }
    public override void SnapToPart(AreaPart part)
    {
        transform.SetParent(part.Area.transform);
        BuildingDef.Shape.SnapToPart(IsFacing, transform, part);
    }
    public void Build()
    {
        Destroy();

        BuildingDef.TryInstantiate(Parent, Caravan, IsFacing);
    }
    public override void OnSelect(SelectionForm selectionForm)
    {
        StringBuilder lesserDescription = new StringBuilder();

        for (int i = 0; i < BuildingDef.Materials.Required.Length; i++)
        {
            ItemQuantity material = BuildingDef.Materials.Required[i];

            int fetchedQuantity = 0;
            foreach (ItemQuantity fetched in _buildJob.Fetched)
            {
                if (fetched.Item == material.Item)
                {
                    fetchedQuantity = fetched.Quantity;
                    break;
                }
            }

            lesserDescription.Append($"{fetchedQuantity} / {material.Quantity} {material.Name}\n");
        }

        string[] barNames = new string[1];
        float[] barValues = new float[1];
        float[] barMax = new float[1];
        Color[] barColors = new Color[1];

        barNames[0] = "Progress";
        barValues[0] = BuildTime;
        barMax[0] = BuildingDef.BuildTime;
        barColors[0] = new Color(0.25f, 0.25f, 0.25f, 1);

        selectionForm.Update(
            name,
            $"The Blueprint of a {BuildingDef.name}",
            lesserDescription.ToString(),
            barNames,
            barValues,
            barMax,
            barColors,
            BuildingDef.Shape.GetSize(IsFacing));
    }

    #region ICancelTarget
    public bool CanCancel => true;


    public void OrderCancel()
    {
        _buildJob.DeleteJob();
        Destroy();
    }
    #endregion
}
