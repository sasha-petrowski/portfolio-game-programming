using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;

public class WallBuilding : BuildingShape
{
    public override TileCoordinate PreferedCoordinate(Area area, Vector3 worldPosition)
    {
        return area.WallOnlyCoordinate(worldPosition);
    }
    public override List<AreaPart> SpecialParts(int direction, Area area, Vector2Int start, Vector2 offset)
    {
        return STE.Select(_specialCoordinateSelectionType, area, start, offset, true);
    }
    public override List<AreaPart> PreferedParts(int direction, Area area, Vector2Int start, Vector2 offset)
    {
        return STE.Select(_coordinateSelectionType, area, start, offset, true);
    }

    public override bool EachPartFrom(int direction, Func<AreaPart, bool> test, AreaPart from)
    {
        AreaWall fromWall = from as AreaWall;
        if (fromWall == null) return false;

        return test(fromWall);
    }
    public override void SnapToPart(int direction, Transform building, AreaPart part)
    {
        int side = 0;
        if (part is AreaWall wallPart)
        {
            side = wallPart.Side;
        }

        building.transform.rotation = part.Area.transform.rotation;
        building.transform.Rotate(new Vector3(0, 0, side * 90 + direction * 180));

        building.transform.position = part.WorldPosition(PartOffset(direction, part));
    }
    public override void Rotate(ref int direction, int by)
    {
        direction = (direction + by) % 2;
    }
    public override Vector3 PartOffset(int direction, AreaPart part)
    {
        return new Vector3(0, 0, -1);
    }

    public override Vector2 GetSize(int direction)
    {
        if (direction % 2 == 0)
        {
            return new Vector2(1, 0.25f);
        }
        else
        {
            return new Vector2(0.25f, 1);
        }
    }
}
