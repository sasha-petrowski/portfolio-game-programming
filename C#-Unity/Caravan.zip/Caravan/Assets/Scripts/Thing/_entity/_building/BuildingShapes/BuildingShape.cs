using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class BuildingShape
{
    [SerializeField]
    protected SelectionType _coordinateSelectionType;
    [SerializeField]
    protected SelectionType _specialCoordinateSelectionType;

    public abstract Vector2 GetSize(int direction);

    public abstract TileCoordinate PreferedCoordinate(Area area, Vector3 worldPosition);
    public abstract List<AreaPart> SpecialParts(int direction, Area area, Vector2Int start, Vector2 end);
    public abstract List<AreaPart> PreferedParts(int direction, Area area, Vector2Int start, Vector2 end);

    public abstract bool EachPartFrom(int direction, Func<AreaPart, bool> test, AreaPart from);

    public abstract void Rotate(ref int direction, int by);
    public abstract void SnapToPart(int direction, Transform building, AreaPart part);
    public abstract Vector3 PartOffset(int direction, AreaPart part);

}
