using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;

public class StorageBuilding : Building, IStorage
{
    [HideInInspector]
    public int Capacity;
    private int _fullStacks;
    private int _startedStacks;

    private Dictionary<ItemDef, StorageData> _storageData = new Dictionary<ItemDef, StorageData>();
    public Dictionary<ItemDef, StorageData> StorageData => _storageData;


    private List<UniqueItem> _uniqueItems = new List<UniqueItem>();
    public List<UniqueItem> UniqueItems => _uniqueItems;

    public override void EnterArea(Area newArea)
    {
        base.EnterArea(newArea);
        newArea.Storages.AddLast(this);

        ItemManager.FreeStorageStacks += (Capacity - _fullStacks);
    }
    public override void LeaveArea(Area oldArea)
    {
        base.LeaveArea(oldArea);
        oldArea.Storages.Remove(this);

        ItemManager.FreeStorageStacks -= (Capacity - _fullStacks);
    }

    protected override void RemoveReferences()
    {
        base.RemoveReferences();

        DropItems();
    }
    private void DropItems()
    {
        AreaTile spot = Parent as AreaTile;
        // Drop items in storage
        foreach (KeyValuePair<ItemDef, StorageData> pair in _storageData)
        {
            int quantity = pair.Value.Inside;

            #region Bake Items quantity
            Item.StoredQuantity[pair.Key] -= pair.Value.Inside;
            foreach (ItemCategoryDef cat in pair.Key.Categories)
            {
                Item.StoredCategory[cat] -= pair.Value.Inside;
            }
            UIManager.Instance.StorageMenu.UpdateItem(pair.Key);

            if (pair.Key is FoodItemDef food) Parent.Area.StoredNutrition -= quantity * food.Nutrition;
            #endregion


            while (quantity > 0)
            {
                Item item = (Item)pair.Key.TryInstantiate(AreaTile.GetEmptyTile(spot), Caravan, Mathf.Min(quantity, pair.Key.StackSize));
                quantity -= pair.Key.StackSize;
                item?.Entity?.AddHaulingJob();
            }
        }
        foreach (UniqueItem uItem in _uniqueItems)
        {
            #region Bake Items quantity
            Item.StoredQuantity[uItem.ItemDef] -= 1 - uItem.Reserved;
            foreach (ItemCategoryDef cat in uItem.ItemDef.Categories)
            {
                Item.StoredCategory[cat] -= 1 - uItem.Reserved;
            }
            UIManager.Instance.StorageMenu.UpdateItem(uItem.ItemDef);

            if (uItem is IWithNutrition food) Parent.Area.StoredNutrition -= food.Nutrition;
            #endregion

            uItem.Storage = null;
            uItem.Reserved = 0;
            uItem.GetComponent<SpriteRenderer>().enabled = true;
            uItem.SpawnAsEntity(AreaTile.GetEmptyTile(spot));
            uItem.Entity.AddHaulingJob();
        }
        _storageData.Clear();
    }

    public override void OnSelect(SelectionForm selectionForm)
    {
        StringBuilder lesserDescription = new StringBuilder();

        float stacksInside = 0;
        foreach (UniqueItem item in _uniqueItems)
        {
            stacksInside += 1;
            lesserDescription.AppendLine(item.name);
        }
        foreach (KeyValuePair<ItemDef, StorageData> pair in _storageData)
        {
            stacksInside += pair.Value.Inside / (float)pair.Key.StackSize;
            lesserDescription.Append($"[f.{pair.Value.FreeQuantity} r.{pair.Value.Reserved} i.{pair.Value.Incoming}] {pair.Value.Inside}x ({(pair.Value.Inside / pair.Key.StackSize)} stack) {pair.Key.name}\n");
        }

        string[] barNames = new string[1];
        float[] barValues = new float[1];
        float[] barMax = new float[1];
        Color[] barColors = new Color[1];

        barNames[0] = $"Space {(int)stacksInside}/{Capacity}";
        barValues[0] = stacksInside;
        barMax[0] = Capacity;
        barColors[0] = new Color(0.25f, 0.25f, 0.25f, 1);

        selectionForm.Update(
            name,
            $"A storage capable of holding {Capacity} stacks",
            lesserDescription.ToString(),
            barNames,
            barValues,
            barMax,
            barColors,
            BuildingDef.Shape.GetSize(IsFacing));
    }

    //IStorage

    #region IItemReceiver
    public bool CanReceive(ItemDef item)
    {// more capacity than stacks & ( less started stacks than capacity || started stack is of item's type )
        return Capacity > _fullStacks && ((Capacity > _fullStacks + _startedStacks) || (_storageData.TryGetValue(item, out StorageData storage) && storage.Space > item.StackSize * (storage.Space / item.StackSize)));
    }
    public int ReserveReceiving(ItemDef item, int quantity)
    {
        int maxQuantity;

        if (! _storageData.TryGetValue(item, out StorageData storedItem))
        {// if this kind of item didn't have a storage data, create one
            storedItem = new StorageData();
            _storageData.Add(item, storedItem);
        }

        int stacks = storedItem.Space / item.StackSize; // ammount of stakcs of this item
        int overflow = storedItem.Space - stacks * item.StackSize; // how many of thoses items are in a started stack

        if (overflow > 0) _startedStacks--;

        // if there is more than one stack free no need to stop stack overflow
        if(Capacity - _fullStacks - _startedStacks > 1)
        {
            maxQuantity = quantity;
        }
        else
        {
            maxQuantity = Mathf.Min(quantity, item.StackSize - overflow);
        }

        storedItem.Incoming += maxQuantity;

        overflow = storedItem.Space - stacks * item.StackSize;

        if(overflow >= item.StackSize)
        {
            _fullStacks++;
            ItemManager.FreeStorageStacks--;
        }
        if(overflow % item.StackSize > 0) _startedStacks++;

        return maxQuantity;
    }
    public void Receive(ItemDef item, int quantity)
    {
        if (!_storageData.TryGetValue(item, out StorageData storedItem))
        {
            throw new System.Exception($"StorageData for itemType \"{item}\" has not been initialized");
        }
        storedItem.Incoming -= quantity;
        storedItem.FreeQuantity += quantity;

        #region Bake Items quantity
        Item.StoredQuantity[item] += quantity;
        foreach (ItemCategoryDef cat in item.Categories)
        {
            Item.StoredCategory[cat] += quantity;
        }
        UIManager.Instance.StorageMenu.UpdateItem(item);

        if (item is FoodItemDef food) Parent.Area.StoredNutrition += quantity * food.Nutrition;
        #endregion
    }
    public void CancelReceiving(ItemDef item, int quantity)
    {
        if (!_storageData.TryGetValue(item, out StorageData storedItem))
        {
            throw new System.Exception($"StorageData for itemType \"{item}\" has not been initialized");
        }

        int stacks = storedItem.Space / item.StackSize; // ammount of stakcs of this item
        int overflow = storedItem.Space - stacks * item.StackSize; // how many of thoses items are in a started stack

        // remove storage of this itemtype
        _fullStacks -= stacks;
        ItemManager.FreeStorageStacks += stacks;
        if (overflow > 0) _startedStacks--;

        // edit quantity
        storedItem.Incoming -= quantity;

        stacks = storedItem.Space / item.StackSize; // ammount of stakcs of this item
        overflow = storedItem.Space - stacks * item.StackSize; // how many of thoses items are in a started stack

        _fullStacks += stacks;
        ItemManager.FreeStorageStacks -= stacks;
        if (overflow > 0) _startedStacks++;

        if (storedItem.Space == 0) _storageData.Remove(item);
    }



    public bool CanReceive(UniqueItem item)
    {
        return _fullStacks + _startedStacks < Capacity;
    }

    public void ReserveReceiving(UniqueItem item)
    {
        _fullStacks++;
        ItemManager.FreeStorageStacks--;
    }

    public void CancelReceiving(UniqueItem item)
    {
        _fullStacks--;
        ItemManager.FreeStorageStacks++;
    }

    public void Receive(UniqueItem item)
    {
        _uniqueItems.Add(item);
        item.Reserved = 0;

        #region Bake Items quantity
        Item.StoredQuantity[item.ItemDef] += 1;
        foreach (ItemCategoryDef cat in item.ItemDef.Categories)
        {
            Item.StoredCategory[cat] += 1;
        }
        UIManager.Instance.StorageMenu.UpdateItem(item.ItemDef);

        if (item is IWithNutrition food) Parent.Area.StoredNutrition += food.Nutrition;
        #endregion
    }
    #endregion

    #region IItemSource
    public bool CanSource(ItemDef item)
    {
        // if there are stored items of this type return true.
        if(_storageData.ContainsKey(item)) return true;
        // if any of the items are of this Def return true.
        else foreach(UniqueItem uItem in _uniqueItems) if(uItem.Reserved == 0 && uItem.ItemDef == item) return true;
        // else there are none
        return false;
    }
    public void ReserveSource(ItemDef item, int quantity, out int maxQuantity)
    {
        if (_storageData.TryGetValue(item, out StorageData storedItem))
        {
            maxQuantity = Mathf.Min(quantity, storedItem.FreeQuantity);

            storedItem.FreeQuantity -= maxQuantity;
            storedItem.Reserved += maxQuantity;

            #region Bake Items nutrition
            if (item is FoodItemDef food) Parent.Area.StoredNutrition -= maxQuantity * food.Nutrition;
            #endregion
        }
        else
        {
            maxQuantity = 1;
            foreach (UniqueItem uItem in _uniqueItems)
            {
                if (uItem.Reserved == 0 && uItem.ItemDef == item)
                {
                    uItem.Reserved = 1;

                    #region Bake Items nutrition
                    if (uItem is IWithNutrition food) Parent.Area.StoredNutrition -= food.Nutrition;
                    #endregion
                    break;
                }
            }
        }
        #region Bake Items quantity
        Item.StoredQuantity[item] -= maxQuantity;
        foreach (ItemCategoryDef cat in item.Categories)
        {
            Item.StoredCategory[cat] -= maxQuantity;
        }
        UIManager.Instance.StorageMenu.UpdateItem(item);
        #endregion
    }

    public void CancelSource(ItemDef item, int quantity)
    {
        if (_storageData.TryGetValue(item, out StorageData storedItem))
        {
            storedItem.FreeQuantity += quantity;
            storedItem.Reserved -= quantity;

            #region Bake Items nutrition
            if (item is FoodItemDef food) Parent.Area.StoredNutrition += quantity * food.Nutrition;
            #endregion
        }
        else
        {
            foreach (UniqueItem uItem in _uniqueItems)
            {
                if (uItem.Reserved == 1 && uItem.ItemDef == item)
                {
                    uItem.Reserved = 0;

                    #region Bake Items nutrition
                    if (uItem is IWithNutrition food) Parent.Area.StoredNutrition += quantity * food.Nutrition;
                    #endregion
                    break;
                }
            }
        }

        #region Bake Items quantity
        Item.StoredQuantity[item] += quantity;
        foreach (ItemCategoryDef cat in item.Categories)
        {
            Item.StoredCategory[cat] += quantity;
        }
        UIManager.Instance.StorageMenu.UpdateItem(item);
        #endregion
    }

    public Item Take(Creature taker, ItemDef item, int quantity)
    {
        if (_storageData.TryGetValue(item, out StorageData storedItem))
        {
            int stacks = storedItem.Space / item.StackSize; // ammount of stacks of this item
            int overflow = storedItem.Space - stacks * item.StackSize; // how many of thoses items are in a started stack

            // remove storage of this itemtype
            _fullStacks -= stacks;
            ItemManager.FreeStorageStacks += stacks;
            if (overflow > 0) _startedStacks--;

            // edit quantity
            storedItem.Reserved -= quantity;

            stacks = storedItem.Space / item.StackSize; // ammount of stakcs of this item
            overflow = storedItem.Space - stacks * item.StackSize; // how many of thoses items are in a started stack

            _fullStacks += stacks;
            ItemManager.FreeStorageStacks -= stacks;
            if (overflow > 0) _startedStacks++;

            if (storedItem.Space == 0) _storageData.Remove(item);

            return item.InstantiateHauled(taker, Caravan, quantity);
        }
        else
        {
            for(int i = 0; i < _uniqueItems.Count; i++)
            {
                UniqueItem uItem = _uniqueItems[i];

                if (uItem.Reserved == 1 && uItem.ItemDef == item)
                {
                    _uniqueItems.RemoveAt(i);

                    uItem.HauledBy = taker;
                    uItem.transform.SetParent(taker.transform);
                    uItem.transform.SetLocalPositionAndRotation(new Vector3(0, 0.5f, -1), Quaternion.identity);

                    uItem.ExitStorage(this);

                    _fullStacks -= 1;
                    ItemManager.FreeStorageStacks++;


                    return uItem;
                }
            }
        }

        Debug.LogError($"Error : Storage didn't return an item ({quantity}x {item})");
        return null;
    }
    #endregion
}
