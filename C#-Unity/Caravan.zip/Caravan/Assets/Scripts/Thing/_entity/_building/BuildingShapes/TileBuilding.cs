using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using UnityEngine;

public class TileBuilding : BuildingShape
{
    public override TileCoordinate PreferedCoordinate(Area area, Vector3 worldPosition)
    {
        return area.GridOnlyCoordinate(worldPosition);
    }
    public override List<AreaPart> SpecialParts(int direction, Area area, Vector2Int start, Vector2 offset)
    {
        return STE.Select(_specialCoordinateSelectionType, area, start, offset, false);
    }
    public override List<AreaPart> PreferedParts(int direction, Area area, Vector2Int start, Vector2 offset)
    {
        return STE.Select(_coordinateSelectionType, area, start, offset, false);
    }

    public override bool EachPartFrom(int direction, Func<AreaPart, bool> test, AreaPart from)
    {
        AreaTile fromTile = from as AreaTile;
        if (fromTile == null) return false;

        return test(fromTile);
    }
    public override void Rotate(ref int direction, int by)
    {
        direction = (direction + by) % 4;
    }
    public override void SnapToPart(int direction, Transform building, AreaPart part)
    {
        building.rotation = part.Area.transform.rotation;
        building.Rotate(new Vector3(0, 0, direction * 90));

        building.position = part.WorldPosition(PartOffset(direction, part));
    }

    public override Vector3 PartOffset(int direction, AreaPart part)
    {
        return new Vector3(0, 0, -1);
    }
    public override Vector2 GetSize(int direction)
    {
        return Vector2.one;
    }

}
