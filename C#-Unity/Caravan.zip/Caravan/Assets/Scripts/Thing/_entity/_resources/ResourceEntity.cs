﻿using UnityEngine;

public class ResourceEntity : Entity
{
    public ResourceEntityDef ResourceDef;
    public override EntityDef Def => ResourceDef;

    public override void SnapToPart(AreaPart part)
    {
        if (!ResourceDef.RandomOffset)
        {
            base.SnapToPart(part);
            return;
        }

        transform.SetParent(part.Area.transform);
        transform.SetPositionAndRotation(part.WorldPosition() + new Vector3(Random.Range(-0.2f, 0.2f), Random.Range(-0.2f, 0.2f), -1), part.Area.transform.rotation);
    }

    public override void SetParent(AreaPart part, bool spawn = false)
    {
        base.SetParent(part, spawn);

        if(part != null) part.Entity = this;
    }
}
