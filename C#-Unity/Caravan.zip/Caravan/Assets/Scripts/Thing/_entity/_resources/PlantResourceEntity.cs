﻿using System;
using UnityEngine;

public class PlantResourceEntity : ResourceEntity, IWithNutrition
{
    public float Nutrition => PlantResourceDef.Nutrition;
    public ItemCategoryDef[] Type => PlantResourceDef.NutritionType;

    public PlantResourceDef PlantResourceDef;


    public bool Consume(Creature consumer, Need need)
    {
        int needed = 1;

        need.Satisfaction = Mathf.Min(need.Satisfaction + needed * Nutrition, need.NeedDef.MaxNeed);

        Destroy();

        return false;
    }

    public override void EnterArea(Area newArea)
    {
        base.EnterArea(newArea);

        #region Bake quantities
        foreach (ItemCategoryDef cat in PlantResourceDef.NutritionType)
        {
            Item.WorldCategory[cat] += 1;
        }
        newArea.FlooredNutrition += Nutrition;
        #endregion
    }

    public override void LeaveArea(Area oldArea)
    {
        base.LeaveArea(oldArea);

        #region Bake quantities
        foreach (ItemCategoryDef cat in PlantResourceDef.NutritionType)
        {
            Item.WorldCategory[cat] -= 1;
        }
        oldArea.FlooredNutrition -= Nutrition;
        #endregion
    }
}
