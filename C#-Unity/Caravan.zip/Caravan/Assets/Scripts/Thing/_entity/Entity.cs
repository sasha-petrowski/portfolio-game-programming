﻿using System;
using System.Collections.Generic;
using UnityEngine;

public abstract class Entity : Thing, IInteractable
{
    public AreaPart Parent => _parent;

    public abstract EntityDef Def { get; }

    private AreaPart _parent;

    public List<JobTarget> JobTargets = new List<JobTarget>();

    public bool IsDead => Health <= 0;
    public int Health;

    public bool Reserved;

    public T TryAddTarget<T>(T target) where T : JobTarget
    {
        foreach (var t in JobTargets)
        {
            if (t is T) return t as T;
        }
        JobTargets.Add(target);

        return target;
    }

    public virtual void EnterArea(Area newArea)
    {
        if (newArea == null)
        {
            Destroy();
            return;
        }
        transform.SetParent(newArea.transform);

        foreach (JobTarget target in JobTargets)
        {
            if (target.Job != null) newArea.AddJobProvider(target.Job);
        }
    }
    public virtual void LeaveArea(Area oldArea)
    {
        foreach (JobTarget target in JobTargets)
        {
            if (target.Job != null)
            {
                oldArea.RemoveJobProvider(target.Job);
            }
        }
    }
    public virtual void SetParent(AreaPart part, bool spawn = false)
    {
        if (part != null)
        {
            if(spawn)
            {
                EnterArea(part.Area);
            }
            else if (part.Area != _parent.Area)
            {
                LeaveArea(_parent.Area);
                EnterArea(part.Area);
            }
            _parent = part;
        }
    }
    public virtual void SpawnAt(AreaPart part)
    {
        SetParent(part, true);
        SnapToPart(part);
    }
    public virtual void SnapToPart(AreaPart part)
    {
        transform.SetParent(part.Area.transform);
        transform.SetPositionAndRotation(part.WorldPosition() + new Vector3(0, 0, -1), part.Area.transform.rotation);
    }
    protected override void AddReferences()
    {
    }
    protected override void RemoveReferences()
    {
        if(Parent != null) LeaveArea(Parent.Area);


        foreach (JobTarget target in JobTargets)
        {
            target.RemoveJob(this);
        }
    }

    #region IInteractable

    public virtual List<AreaTile> GetInteractionSpots() => Parent.GetInteractionSpots();
    public virtual AreaTile GetFirstSpot() => Parent.GetFirstSpot();
    #endregion

    #region Damage

    public bool TakeDamage(int damage)
    {
        if (Health < 0) return true;

        Health -= damage;

        if (Health <= 0)
        {

            Health = -1;
            if(this is Creature creature)
            {
                creature.OnDeath();
            }
            else
            {
                Destroy();
            }
            return true;
        }
        else
        {
            GetComponent<SpriteRenderer>().color = new Color(1, Health / (float)Def.MaxHealth, Health / (float)Def.MaxHealth, 1);
        }

        return false;
    }
    public virtual void HealDamage(int heal)
    {
        Health = Mathf.Clamp(Health + heal, 0, Def.MaxHealth);

        GetComponent<SpriteRenderer>().color = new Color(1, Health / (float)Def.MaxHealth, Health / (float)Def.MaxHealth, 1);
    }

    #endregion
}