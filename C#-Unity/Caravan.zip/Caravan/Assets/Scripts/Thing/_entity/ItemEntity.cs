﻿using System;
using UnityEngine;

public class ItemEntity : Entity
{
    public Item Item => _item;

    public override EntityDef Def => null;

    private Item _item;

    protected override void AddReferences()
    {
        base.AddReferences();
        TryAddTarget(new HaulingJobTarget());
    }
    public void SetItem(Item item)
    {
        if (Parent == null) throw new Exception("Must first spawn ItemEntity before setting the Item");

        if (item == null)
        {
            Destroy(this);
            return;
        }

        _item = item;
        Caravan = item.Caravan;

        _item.transform.parent = transform;
        _item.transform.position = transform.position;
        _item.Entity = this;

        Parent.Area.Items.AddFirst(_item);

        #region Bake items quantities
        Item.WorldQuantity[_item.ItemDef] += _item.Quantity;

        foreach (ItemCategoryDef cat in _item.ItemDef.Categories)
        {
            Item.WorldCategory[cat] += _item.Quantity;
        }
        if (_item is IWithNutrition nutrition) Parent.Area.FlooredNutrition += _item.Quantity * nutrition.Nutrition;
        #endregion

    }
    public override void SetParent(AreaPart part, bool spawn = false)
    {
        base.SetParent(part, spawn);

        if(part != null) part.Entity = this;
    }
    public override void LeaveArea(Area oldArea)
    {
        base.LeaveArea(oldArea);

        if (_item != null)
        {
            oldArea.Items.Remove(_item);

            #region Bake Items quantity
            Item.WorldQuantity[_item.ItemDef] -= _item.Quantity;
            foreach (ItemCategoryDef cat in _item.ItemDef.Categories)
            {
                Item.WorldCategory[cat] -= _item.Quantity;
            }

            if (_item is IWithNutrition nutrition) oldArea.FlooredNutrition -= _item.Quantity * nutrition.Nutrition;
            #endregion
        }
    }
    public override string ToString()
    {
        return _item.ToString();
    }
    public void Take()
    {
        Parent.Entity = null;
        _item.Entity = null;

        Parent.Area.Items.Remove(_item);
        
        #region Bake Items quantity
        Item.WorldQuantity[_item.ItemDef] -= _item.Quantity;
        foreach (ItemCategoryDef cat in _item.ItemDef.Categories)
        {
            Item.WorldCategory[cat] -= _item.Quantity;
        }

        if (_item is IWithNutrition nutrition) Parent.Area.FlooredNutrition -= _item.Quantity * nutrition.Nutrition;
        #endregion

        _item = null;

        RemoveReferences();
        Destroy(this);
    }

    public override void OnSelect(SelectionForm selectionForm)
    {
        _item.OnSelect(selectionForm);
    }

    public HaulingJob AddHaulingJob()
    {
        HaulingJobTarget target = TryAddTarget(new HaulingJobTarget());
        return (target.CanAddJob() ? target.AddJob(this) : target.Job) as HaulingJob;
    }
}
