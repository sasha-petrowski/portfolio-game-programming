using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class BuildingArea : Area
{
    private const int SELECTION_NUMBER_OF_BAR = 1;

    public GiantCreature GiantEntity;

    #region Transform Refresh & Cache
    private float _sin;
    private float _cos;
    public void UpdateTransform()
    {
        if (transform.hasChanged == true)
        {
            transform.hasChanged = false;

            #region Sin & Cos
            _sin = Mathf.Sin(transform.eulerAngles.z * Mathf.Deg2Rad);
            _cos = Mathf.Cos(transform.eulerAngles.z * Mathf.Deg2Rad);
            #endregion

            #region Update OutTile's position
            if (_outTiles != null)
            {
                foreach (AreaOutTile outTile in _outTiles)
                {
                    outTile.UpdateOut();
                }
            }

            #endregion
        }
    }
    #endregion

    #region Area
    public override void InitialiseArea(int width, int height)
    {
        base.InitialiseArea(width, height);

        GetComponent<SpriteRenderer>().size = new Vector2(width + 1, height + 1);

        transform.hasChanged = true;
        UpdateTransform();
    }
    protected override void InitialiseTiles()
    {
        #region Instantiate Wall Parts
        Walls = new List<AreaWall[,]>(2)
        {
            new AreaWall[Width, Height + 1],
            new AreaWall[Width + 1, Height]
        };

        AreaWall[,] horizontal = Walls[0];
        for (int x = 0; x < Width; x++)
        {
            for (int y = 0; y <= Height; y++)
            {
                horizontal[x, y] = new AreaWall(this, 0, x, y);
            }
        }

        AreaWall[,] vertical = Walls[1];
        for (int x = 0; x <= Width; x++)
        {
            for (int y = 0; y < Height; y++)
            {
                vertical[x, y] = new AreaWall(this, 1, x, y);
            }
        }
        #endregion

        #region Instantiate Tiles
        Tiles = new AreaTile[Width, Height];
        int outI = 0;

        int rightDriver = Width / 2;
        int leftDriver;
        AreaOutTile[] outTiles;

        if (Width % 2 == 0) // Even Width
        {
            outTiles = new AreaOutTile[(Width + Height) * 2 - 4 - 2];
            leftDriver = rightDriver - 1;
        }
        else // Uneven
        {
            outTiles = new AreaOutTile[(Width + Height) * 2 - 4 - 1];
            leftDriver = rightDriver;
        }

        for (int x = 0; x < Width; x++)
        {
            for (int y = 0; y < Height; y++)
            {
                AreaTile tile;
                if (y == Height - 1)
                { // Top
                    if(x == leftDriver | x == rightDriver)
                    {
                        tile = new AreaDriverTile(this, x, y);
                    }
                    else if (x == 0)
                    { // Top left
                        // don't go out in front of the driverTile
                        if(x + 1 == leftDriver) tile = new AreaOutTile(this, x, y, new int[] { TPE.Left, TPE.Top, TPE.TopLeft, TPE.BottomLeft});
                        else  tile = new AreaOutTile(this, x, y, new int[] { TPE.Left, TPE.Top, TPE.TopLeft, TPE.BottomLeft, TPE.TopRight });
                    }
                    else if (x == Width - 1)
                    { // Top right
                        // don't go out in front of the driverTile
                        if (x - 1 == leftDriver) tile = new AreaOutTile(this, x, y, new int[] { TPE.Right, TPE.Top, TPE.BottomRight, TPE.TopRight });
                        else tile = new AreaOutTile(this, x, y, new int[] { TPE.Right, TPE.Top, TPE.TopLeft, TPE.BottomRight, TPE.TopRight });
                    }
                    else
                    { // Top
                        // don't go out in front of the driverTile
                        if (x + 1 == leftDriver) tile = new AreaOutTile(this, x, y, new int[] { TPE.Top, TPE.TopLeft });
                        else if (x - 1 == leftDriver) tile = new AreaOutTile(this, x, y, new int[] { TPE.Top, TPE.TopRight });
                        else tile = new AreaOutTile(this, x, y, new int[] { TPE.Top, TPE.TopLeft, TPE.TopRight });
                    }
                }
                else if(y == 0)
                {
                    if (x == 0)
                    { // Bottom left
                        tile = new AreaOutTile(this, x, y, new int[] { TPE.Left, TPE.Bottom, TPE.TopLeft, TPE.BottomLeft, TPE.BottomRight });
                    }
                    else if (x == Width - 1)
                    { // Bottom right
                        tile = new AreaOutTile(this, x, y, new int[] { TPE.Right, TPE.Bottom, TPE.BottomRight, TPE.BottomLeft, TPE.TopRight });
                    }
                    else
                    { // Bottom
                        tile = new AreaOutTile(this, x, y, new int[] { TPE.Bottom, TPE.BottomLeft, TPE.BottomRight });
                    }
                }
                else if (x == 0)
                { // left
                    tile = new AreaOutTile(this, x, y, new int[] { TPE.Left, TPE.TopLeft, TPE.BottomLeft });
                }
                else if (x == Width - 1)
                { // right
                    tile = new AreaOutTile(this, x, y, new int[] { TPE.Right, TPE.BottomRight, TPE.TopRight });
                }
                else
                { // not a border
                    tile = new AreaTile(this, x, y);
                }

                if (tile is AreaOutTile outTile)
                {
                    outTile.UpdateOut(false);
                    outTiles[outI] = outTile;
                    outI++;
                }

                Tiles[x, y] = tile;
            }
        }
        _outTiles = outTiles;
        #endregion
    }
    public override bool IsBuildingArea()
    {
        return true;
    }
    public override bool IsBuildingArea(out BuildingArea area)
    {
        area = this;
        return true;
    }
    #endregion


    protected override void AddReferences()
    {
        Caravan.BuildingAreas.AddLast(this);
    }
    protected override void RemoveReferences()
    {
        Caravan.BuildingAreas.Remove(this);
    }
    public override Thing GetChildAt(Vector2 worldPosition, Thing ignoreThing)
    {
        return GetThingAt(worldPosition, ignoreThing);
    }
    /// <summary>
    /// Return True if worldPosition is inside the buildingArea
    /// </summary>
    /// 
    public override bool IsHover(Vector2 worldPosition)
    {
        Vector2 index = WorldToLocal(worldPosition);
        return (Mathf.FloorToInt(index.x) >= 0 && Mathf.FloorToInt(index.x) < Width) && (Mathf.FloorToInt(index.y) >= 0 && Mathf.FloorToInt(index.y) < Height);
    }
    /// <summary>
    /// Return the world position of the tile at index.
    /// </summary>
    /// 
    public override Vector3 LocalToWorld(Vector3 local)
    {
        UpdateTransform();

        return new Vector3(
            ((local.x + 0.5f - Width / 2f) * _cos) - ((local.y + 0.5f - Height / 2f) * _sin),
            ((local.x + 0.5f - Width / 2f) * _sin) + ((local.y + 0.5f - Height / 2f) * _cos),
            local.z) + transform.position;
    }
    /// <summary>
    /// Return the local position of a world position.
    /// </summary>
    /// 
    public override Vector2 WorldToLocal(Vector3 worldPosition)
    {
        UpdateTransform();

        float x = Width / 2f + (((worldPosition.x - transform.position.x) * _cos) + ((worldPosition.y - transform.position.y) * _sin));
        float y = Height / 2f - (((worldPosition.x - transform.position.x) * _sin) - ((worldPosition.y - transform.position.y) * _cos));

        return new Vector2(x, y);
    }
    public override void OnSelect(SelectionForm selectionForm)
    {
        string[] barNames = new string[SELECTION_NUMBER_OF_BAR];
        float[] barValues = new float[SELECTION_NUMBER_OF_BAR];
        float[] barMax = new float[SELECTION_NUMBER_OF_BAR];
        Color[] barColors = new Color[SELECTION_NUMBER_OF_BAR];

        barNames[0] = "HP";
        //todo Health
        barValues[0] = 100;
        barMax[0] = 100;
        barColors[0] = new Color(0.75f, 0.75f, 0.75f, 1);

        selectionForm.Update(
            name,
            null,
            null,
            barNames,
            barValues,
            barMax,
            barColors,
            new Vector2(Width, Height));
    }

    protected void OnDrawGizmos()
    {
        /*
        foreach (AreaOutTile outTile in _outTiles)
        {
            if (outTile.Room != null) Gizmos.color = outTile.Room._debugColor;
            else Gizmos.color = Color.black;

            Vector3 position = outTile.WorldPosition();

            foreach (AreaTile otherOutTile in outTile.OutTiles)
            {
                if (otherOutTile != null)
                {
                    Gizmos.DrawLine(position, otherOutTile.WorldPosition());
                    Gizmos.DrawWireSphere(otherOutTile.WorldPosition(), 0.25f);
                }
            }
        }
        foreach (AreaTile tile in Tiles)
        {
            if(tile is AreaDriverTile)
            {
                if (tile.Room != null) Gizmos.color = Color.Lerp(tile.Room._debugColor, Color.clear, 0.25f);
                else Gizmos.color = new Color(.5f, 0, .5f, .75f);

                Vector3 position = tile.WorldPosition();

                Gizmos.DrawCube(position, Vector3.one);
            }
        }
        */
    }
    
}