﻿using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;

public struct ChunkContent
{
    public bool HasRuin;
    public bool HasWildlife;

    public ChunkContent(int chunkID)
    {
        System.Random chunkRandom = new System.Random(chunkID);

        HasRuin = chunkRandom.NextDouble() < 1f / 50f;
        HasWildlife = chunkRandom.NextDouble() < 1f / 50f;
    }
}

public class ChunkArea : Area
{
    public Color Gizmos_Color;

    public Vector2Int ChunkIndex;
    public int ChunkID;

    private ChunkContent _chunkContent;

    public override string ToString()
    {
        return $"{base.ToString()}-{ChunkIndex}";
    }

    public static ChunkArea InstantiateChunk(Vector2Int chunkIndex)
    {
        ChunkArea chunk = new GameObject($"Chunk - {chunkIndex}").AddComponent<ChunkArea>();

        chunk.Gizmos_Color = new Color(Mathf.Abs(chunkIndex.x) % 2, Mathf.Abs(chunkIndex.y + 1) % 2, 1);
        chunk.ChunkIndex = chunkIndex;
        chunk.ChunkID = GetChunkID(chunkIndex);

        chunk._chunkContent = new ChunkContent(chunk.ChunkID);

        // no quest around spawn
        if (Mathf.Abs(chunkIndex.x) <= 5 && Mathf.Abs(chunkIndex.y) <= 5) chunk._chunkContent.HasRuin = false;

        return chunk;
    }
    public static int GetChunkID(Vector2Int index)
    {
        //int id = index.GetHashCode() + (index.x | index.y) * WorldSettings.Seed;
        //Debug.Log($"{index} : {id}");
        return index.GetHashCode() + (index.x | index.y) * WorldSettings.Seed;
    }
    public override Vector3 LocalToWorld(Vector3 local)
    {
        return new Vector3(local.x + 0.5f + ChunkIndex.x * WorldSettings.ChunkSize, local.y + 0.5f + ChunkIndex.y * WorldSettings.ChunkSize, local.z);
    }
    public static Vector3 IndexToPosition(Vector2Int index)
    {
        return new Vector3(index.x * WorldSettings.ChunkSize, index.y * WorldSettings.ChunkSize, 0);
    }
    public override Vector2 WorldToLocal(Vector3 worldPosition)
    {
        return new Vector2(worldPosition.x - ChunkIndex.x * WorldSettings.ChunkSize, worldPosition.y - ChunkIndex.y * WorldSettings.ChunkSize);
    }
    public static AreaTile GetTile(Vector3 worldPosition)
    {
        ChunkArea area = World.s_Instance?.GetChunkAt(worldPosition);
        if(area != null)
        {
            Vector2Int index = area.WorldToIndex(worldPosition);
            return area.GetTile(index.x, index.y);
        }
        return null;
    }
    public void OnGenerated(int[,] tilesID)
    {
        
        if (_chunkContent.HasRuin)
        {
            InstantiableDef ruinWall = WorldGenerator.Instance.RuinWalls.GetRandom(out int baseSize);

            int ammount = Random.Range(3, 6);
            //Create four walls
            for(int i = 0; i < ammount; i++)
            {
                int horizontal = Random.Range(0, 2);
                int vertical = 1 - horizontal;

                // of size +/- that of base size
                int size = Mathf.Clamp(baseSize + Random.Range(-2, 3), 2, WorldSettings.ChunkSize - 4);

                int x = Random.Range(2, WorldSettings.ChunkSize - size * horizontal - 2);
                int y = Random.Range(2, WorldSettings.ChunkSize - size * vertical - 2);

                for(int n = 0; n < size; n++)
                {
                    ruinWall.TryInstantiate(Tiles[x, y]);
                    
                    x += horizontal;
                    y += vertical;
                }
            }
        }   
        

        for(int x = 0; x < Width; x++)
        {
            for (int y = 0; y < Height; y++)
            {
                if (Tiles[x, y].Entity != null) continue;

                TileDef tile = WorldGenerator.Instance.WorldTerrain.GetTile(tilesID[x, y]);

                if(tile.EntityChance())
                {
                    tile.GetRandomEntity().TryInstantiate(Tiles[x, y]);
                }
            }
        }

        if (_chunkContent.HasWildlife)
        {
            InstantiableDef animalDef = WorldGenerator.Instance.Wildlife.GetRandom(out int quantity);
            
            for(int i = 0; i < quantity; i++)
            {
                animalDef.TryInstantiate(Tiles[Random.Range(0, Width), Random.Range(0, Height)]);
            }
        }
    }

    protected override void AddReferences()
    {
    }

    protected override void RemoveReferences()
    {
    }
}