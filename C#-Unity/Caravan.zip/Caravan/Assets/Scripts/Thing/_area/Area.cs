﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public abstract class Area : Thing
{
    public const float DEFAULT_WALL_SELECTION_OFFSET = 0.2f;

    public int Width;
    public int Height;
    public int OpenJobProviders;
    public List<IJobProvider>[] JobProviderCategories;
    public LinkedList<Creature> Creatures = new LinkedList<Creature>();
    public LinkedList<GiantCreature> GiantEntities = new LinkedList<GiantCreature>();
    public LinkedList<IStorage> Storages = new LinkedList<IStorage>();
    public LinkedList<Item> Items = new LinkedList<Item>();

    public float StoredNutrition;
    public float FlooredNutrition;

    protected AreaOutTile[] _outTiles;
    public AreaTile[,] Tiles;
    public List<AreaWall[,]> Walls;

    public List<Room> Rooms = new List<Room>();

    public virtual void InitialiseArea(int width, int height)
    {
        if (width < 2 || height < 2) throw new Exception("Area size is too small (need to be at least 2x2)");

        Width = width;
        Height = height;

        JobProviderCategories = new List<IJobProvider>[JTE.Types.Count];
        foreach (int jobType in JTE.Types)
        {
            JobProviderCategories[jobType] = new List<IJobProvider>();
        }

        InitialiseTiles();

        Room.CalculateRooms(this);
    }
    protected virtual void InitialiseTiles()
    {
        #region Instantiate Tiles
        Tiles = new AreaTile[Width, Height];
        AreaOutTile[] outTiles = new AreaOutTile[(Width + Height) * 2 - 4];
        int outI = 0;
        for (int x = 0; x < Width; x++)
        {
            for (int y = 0; y < Height; y++)
            {
                AreaTile tile;
                if (x == 0)
                { // left
                    if (y == 0)
                    { // Bottom
                        tile = new AreaOutTile(this, x, y, new int[] { TPE.Left, TPE.Bottom, TPE.TopLeft, TPE.BottomLeft, TPE.BottomRight});
                    }
                    else if (y == Height - 1)
                    { // Top
                        tile = new AreaOutTile(this, x, y, new int[] { TPE.Left, TPE.Top, TPE.TopLeft, TPE.BottomLeft, TPE.TopRight });
                    }
                    else
                    {
                        tile = new AreaOutTile(this, x, y, new int[] { TPE.Left, TPE.TopLeft, TPE.BottomLeft });
                    }
                }
                else if (x == Width - 1)
                { // Right
                    if (y == 0)
                    { // Bottom
                        tile = new AreaOutTile(this, x, y, new int[] { TPE.Right, TPE.Bottom, TPE.BottomRight, TPE.BottomLeft, TPE.TopRight });
                    }
                    else if (y == Height - 1)
                    { // Top
                        tile = new AreaOutTile(this, x, y, new int[] { TPE.Right, TPE.Top, TPE.TopLeft, TPE.BottomRight, TPE.TopRight });
                    }
                    else
                    {
                        tile = new AreaOutTile(this, x, y, new int[] { TPE.Right, TPE.BottomRight, TPE.TopRight });
                    }
                }
                else if (y == 0)
                { // Bottom
                    tile = new AreaOutTile(this, x, y, new int[] { TPE.Bottom, TPE.BottomLeft, TPE.BottomRight });
                }
                else if (y == Height - 1)
                { // Top
                    tile = new AreaOutTile(this, x, y, new int[] { TPE.Top, TPE.TopLeft, TPE.TopRight });
                }
                else
                { // not a border
                    tile = new AreaTile(this, x, y);
                }

                if(tile is AreaOutTile outTile)
                {
                    outTile.UpdateOut(false);
                    outTiles[outI] = outTile;
                    outI++;
                }

                Tiles[x, y] = tile;
            }
        }
        _outTiles = outTiles;
        #endregion
    }

    public override bool IsHover(Vector2 worldPosition)
    {
        Vector2Int index = WorldToIndex(worldPosition);
        return InBounds(index.x, index.y);
    }
    public bool InBounds(int x, int y)
    {
        return x >= 0 & y >= 0 & x < Width & y < Height;
    }

    public void AddJobProvider(IJobProvider provider)
    {
        if (provider == null || JobProviderCategories[provider.JobType].Contains(provider)) return;

        OpenJobProviders++;
        JobProviderCategories[provider.JobType].Add(provider);
    }
    public void RemoveJobProvider(IJobProvider provider)
    {
        if (provider == null) throw new Exception("Job provider was null");

        if(JobProviderCategories[provider.JobType].Remove(provider)) OpenJobProviders--;
    }
    /// <summary>
    /// Return the world position of the tile at index.
    /// </summary>
    /// 
    public abstract Vector3 LocalToWorld(Vector3 local);

    /// <summary>
    /// Return the local position of a world position.
    /// </summary>
    /// 
    public abstract Vector2 WorldToLocal(Vector3 worldPosition);
    /// <summary>
    /// Return a Snaped and Clamped index.
    /// </summary>
    /// 
    public Vector2Int ClampIndex(Vector2Int index)
    {
        return new Vector2Int(Mathf.Clamp(index.x, 0, Width - 1), Mathf.Clamp(index.y, 0, Height - 1));
    }
    /// <summary>
    /// Return a Snaped and Clamped index.
    /// </summary>
    /// 
    public Vector2Int ClampSnapIndex(Vector2 index)
    {
        return new Vector2Int(Mathf.Clamp(Mathf.FloorToInt(index.x), 0, Width - 1), Mathf.Clamp(Mathf.FloorToInt(index.y), 0, Height - 1));
    }

    /// <summary>
    /// Return a snaped index.
    /// </summary>
    /// 
    public Vector2Int SnapIndex(Vector2 index)
    {
        return new Vector2Int(Mathf.FloorToInt(index.x), Mathf.FloorToInt(index.y));
    }

    /// <summary>
    /// Return the edge closest to the unsnaped index.
    /// </summary>
    /// 
    public TilePosition IndexToEdgeDirection(Vector2 index, float selectionOffset)
    {
        float oX = (index.x > Width) ? 1 + index.x - Width : (index.x < 0) ? index.x : index.x % 1;
        float oY = (index.y > Height) ? 1 + index.y - Height : (index.y < 0) ? index.y : index.y % 1;

        if (oX > 1 - selectionOffset)
        {
            if (oY > oX)
                return TilePosition.Top;
            else if (oY <= 1 - oX)
                return TilePosition.Bottom;
            else
                return TilePosition.Right;
        }
        else if (oX <= selectionOffset)
        {
            if (oY < oX)
                return TilePosition.Bottom;
            else if (oY >= 1 - oX)
                return TilePosition.Top;
            else
                return TilePosition.Left;
        }
        if (oY > 1 - selectionOffset)
        {
            if (oX > oY)
                return TilePosition.Left;
            else if (oX <= 1 - oY)
                return TilePosition.Right;
            else
                return TilePosition.Top;
        }
        else if (oY <= selectionOffset)
        {
            if (oX < oY)
                return TilePosition.Right;
            else if (oX >= 1 - oY)
                return TilePosition.Left;
            else
                return TilePosition.Bottom;
        }
        else
        {
            return TilePosition.Center;
        }
    }

    /// <summary>
    /// Return the TileCoordinate at worldPosition with it's edge being Center.
    /// </summary>
    /// 
    public TileCoordinate GridOnlyCoordinate(Vector2 worldPosition)
    {
        return new TileCoordinate(ClampSnapIndex(WorldToLocal(worldPosition)), TilePosition.Center);
    }

    /// <summary>
    /// Return the TileCoordinate at worldPosition with it's edge never being Center.
    /// </summary>
    /// 
    public TileCoordinate WallOnlyCoordinate(Vector2 worldPosition)
    {
        Vector2 index = WorldToLocal(worldPosition);
        //Debug.Log($"{edgeDirection} {(index.x, index.y)} {(oX, oY)}");
        return new TileCoordinate(ClampSnapIndex(index), IndexToEdgeDirection(index, 0.5f));
    }

    /// <summary>
    /// Return the TileCoordinate at worldPosition.
    /// </summary>
    /// 
    public TileCoordinate GlobalCoordinate(Vector2 worldPosition)
    {
        Vector2 index = WorldToLocal(worldPosition);
        //Debug.Log($"{(index.x, index.y)}");
        return new TileCoordinate(ClampSnapIndex(index), IndexToEdgeDirection(index, DEFAULT_WALL_SELECTION_OFFSET));
    }

    /// <summary>
    /// Return the local unClamped index of a world position.
    /// </summary>
    /// 
    public Vector2Int WorldToIndex(Vector2 worldPosition)
    {
        return SnapIndex(WorldToLocal(worldPosition));
    }

    /// <summary>
    /// Return the local position of the tile or wall at Coordinate.
    /// </summary>
    /// 
    public Vector3 CoordinateToLocalPosition(TileCoordinate tileCoordinate)
    {
        Vector3 localPosition = new Vector3(tileCoordinate.x - Width / 2f + 0.5f, tileCoordinate.y - Height / 2f + 0.5f, 0);
        switch (tileCoordinate.direction)
        {
            case TilePosition.Top:
                localPosition.y += 0.5f;
                break;
            case TilePosition.Bottom:
                localPosition.y -= 0.5f;
                break;
            case TilePosition.Right:
                localPosition.x += 0.5f;
                break;
            case TilePosition.Left:
                localPosition.x -= 0.5f;
                break;
            case TilePosition.Center:
                break;
            default:
                break;
        }
        return localPosition;
    }

    /*GET SET*/
    public AreaTile GetTile(int x, int y)
    {
        return InBounds(x, y) ? Tiles[x, y] : null;
    }
    public AreaPart GetPart(int x, int y, int direction)
    {
        if(!InBounds(x, y))
        {
            return null;
        }
        if (direction > 4)
        {
            //just return the tile
            return Tiles[x, y];
        }
        else
        {
            //return the wall on the right direction on the right side
            return Tiles[x, y].GetWall(direction);
        }
    }



    public virtual bool IsBuildingArea()
    {
        return false;
    }
    public virtual bool IsBuildingArea(out BuildingArea area)
    {
        area = null;
        return false;
    }

    public Thing GetThingAt(Vector2 worldPosition, Thing ignoreThing)
    {
        //Debug.Log("GetThingAt " + this);
        foreach (Entity entity in Creatures)
        {
            if (entity != ignoreThing && entity.IsHover(worldPosition))
            {
                return entity;
            }
        }

        foreach (GiantCreature giant in GiantEntities)
        {
            if (giant != ignoreThing && giant.IsHover(worldPosition))
            {
                return giant;
            }
            else if (giant.BuildingArea != ignoreThing && giant.BuildingArea != null && giant.BuildingArea.IsHover(worldPosition))
            {
                return giant.BuildingArea;
            }
        }

        TileCoordinate coordinate = GlobalCoordinate(worldPosition);

        AreaPart part   = GetPart(coordinate.x, coordinate.y, (int)coordinate.direction);
        Thing tileThing = part?.Entity;

        return tileThing != ignoreThing ? tileThing : null;
    }
    private void OnDestroy()
    {
        foreach (Room room in Rooms)
        {
            room.Delete();
        }
    }
    /*
    protected virtual void OnDrawGizmos()
    {
        foreach(Room room in Rooms)
        {
            room.OnDrawGizmos();
        }
        if (Rooms[0] != null) Gizmos.color = Rooms[0]._debugColor;

        Vector3 tl = LocalToWorld(new Vector2(0, Height - 1));
        Vector3 tr = LocalToWorld(new Vector2(Width - 1, Height - 1));
        Vector3 br = LocalToWorld(new Vector2(Width - 1 , 0));
        Vector3 bl = LocalToWorld(new Vector2(0, 0));

        Gizmos.DrawLine(tl, tr);
        Gizmos.DrawLine(tr, br);
        Gizmos.DrawLine(br, bl);
        Gizmos.DrawLine(bl, tl);
    }
    */
    

}