using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Thing : MonoBehaviour
{
    public Caravan Caravan;
    protected bool _destroyed = false;
    private void Start()
    {
        AddReferences();
    }
    private void OnDestroy()
    {
        if (!_destroyed)
        {
            _destroyed = true;
            RemoveReferences();
        }
    }
    public void Destroy()
    {
        _destroyed = true;
        RemoveReferences();

        Destroy(gameObject);
        Destroy(this);
    }
    protected abstract void AddReferences();
    protected abstract void RemoveReferences();
    public virtual void TickUpdate()
    {
    }
    /// <summary>
    /// Return True if worldPosition is inside the buildingArea
    /// </summary>
    /// 
    public virtual bool IsHover(Vector2 worldPosition)
    {
        return 0.5f >= (Mathf.Pow(worldPosition.x - transform.position.x, 2) + Mathf.Pow(worldPosition.y - transform.position.y, 2));
    }

    public virtual Thing GetChildAt(Vector2 worldPosition, Thing ignoreThing)
    {
        return null;
    }

    public virtual void OnSelect(SelectionForm selectionForm)
    {
        selectionForm.Update(this.ToString(), null, null, null, null, null, null, Vector2.one);
    }

    public virtual Func<Vector2, bool> GetSecondaryEffect()
    {
        return null;
    }
}
