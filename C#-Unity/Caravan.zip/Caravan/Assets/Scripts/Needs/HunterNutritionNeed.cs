using System.Collections.Generic;
using UnityEngine;

public class HunterNutritionNeed : NutritionNeed
{
    protected Creature _target;
    protected AreaTile _targetTile;
    protected Path _targetPath = new Path();
    private GameObject _huntingAlert;
    private Caravan _dangerCaravan;
    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);

        // don't go futher if _target is null, target is null when foraging and not hunting
        if (_target == null) return;

        _jobStep = JobStep_GoToTarget;

        // Alert when the player's characters are being hunted.
        if(_target.Health > 0 && _target.Caravan == Caravan.s_PlayerCaravan) _huntingAlert = UIManager.Instance.AlertMenu.CreateAlert("Nomad is being hunted", () => worker.transform.position);
        // Add hunter to danger sources of target's faction.
        if (_target.Caravan != null)
        {
            _dangerCaravan = _target.Caravan;
            _target.Caravan.DangerSources.Add(worker);
        }
    }

    protected override bool TryFindFood(Creature worker)
    {
        if(base.TryFindFood(worker)) return true;

        return TryFindHuntingTarget(worker);
    }

    private bool TryFindHuntingTarget(Creature worker)
    {
        // else there is no food laying around
        int N = Mathf.Min(10, Creature.AllCreatures.Count);
        List<Creature> targets = new List<Creature>();

        Creature creature;

        for (int i = 0; i < N; i++) // randomly select a few creatures to hunt
        {
            creature = Creature.AllCreatures[Random.Range(0, Creature.AllCreatures.Count)];

            if (creature == worker | (creature.Def is AnimalDef animalDef && animalDef.IsPredator)) continue;
            if (worker is SmallCreature && creature is GiantCreature) continue;

            targets.Add(creature);
        }

        if (targets.Count == 0) return false;


        for (int i = 0; i < targets.Count; i++)
        {
            // take closest amongst random candidates
            float bestDistance = Vector2.SqrMagnitude(worker.transform.position - targets[i].transform.position);
            int target = i;
            for (int n = i + 1; n < targets.Count; n++)
            {
                float distance = Vector2.SqrMagnitude(worker.transform.position - targets[n].transform.position);

                if (bestDistance > distance)
                {
                    bestDistance = distance;
                    target = n;
                }
            }

            creature = targets[target];
            targets[target] = targets[i];

            if(_targetPath.FindPath(creature, worker))
            {
                _target = creature;
                //Debug.Log("Predator hunting " + _target);

                return true;
            }
        }

        return false;
    }

    public override void OnLeaveJob(Creature worker)
    {
        GameObject.Destroy(_huntingAlert);
        if (_dangerCaravan != null) _dangerCaravan.DangerSources.Remove(worker);

        _target = null;
        _targetPath.Free();

        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        GameObject.Destroy(_huntingAlert);
        if (_dangerCaravan) _dangerCaravan.DangerSources.Remove(worker);

        _target = null;
        _targetPath.Free();

        base.OnFinishJob(worker);
    }

    #region JobSteps
    protected bool JobStep_GoToTarget(Creature worker)
    {
        if(_target == null) OnLeaveJob(worker);
        else if(_targetPath.LastTile != _target.Parent && !_targetPath.FindPath(_target, worker)) OnLeaveJob(worker);
        else if (_targetPath.IsFinished)
        {
            if (_targetPath.LastTile == _target.Parent)
            {
                _targetTile = _targetPath.LastTile;
                _targetPath.Free();
                _jobStep = JobStep_KillTarget;
            }
            else if (!_targetPath.FindPath(_target, worker)) OnLeaveJob(worker);
        }
        else if (_targetPath.FollowPath(worker, 1) == -1) OnLeaveJob(worker);

        return false;
    }
    protected bool JobStep_KillTarget(Creature worker)
    {
        if (_target == null) OnLeaveJob(worker);
        // this is temporary until implementation of Death and Combat
        else if (_targetTile == _target.Parent)
        {
            worker.Fight(_target);
            bool targetIsDead = _target.Health < 0;

            if (targetIsDead && _target.TryGetComponent(out CorpseItem corpse)) corpse.Consume(worker, this);

            return targetIsDead;
        }
        else if (_targetPath.FindPath(_target, worker)) // find path to target if not on same tile
        {
            _jobStep = JobStep_GoToTarget;
        }
        else OnLeaveJob(worker);

        return false;
    }
    #endregion

}