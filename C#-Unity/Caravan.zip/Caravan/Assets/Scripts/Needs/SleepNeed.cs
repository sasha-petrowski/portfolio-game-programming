using System.Collections.Generic;
using UnityEngine;

public class SleepNeed : Need
{
    public override NeedDef NeedDef => Def;


    public SleepNeedDef Def;

    private Path _bedPath = new Path();
    private BedBuilding _bed;

    private float _healthRegen;


    public override int JobType => -1;
    public override Vector2 GetPosition()
    {
        return Vector2.zero;
    }
    public override void TickNeed(Creature creature)
    {
        if(_jobStep != JobStep_Sleep)
        {
            float delta = Caravan.DevSpeed ? Time.deltaTime * 10 : Time.deltaTime;
            // rest loss
            Satisfaction -= delta * Def.Loss;
        }
        // Drowsyness
        //if (Satisfaction < Def.Drowsiness) //something = Def.DrowsinessFactor;
    }

    protected override bool TakeJobCondition(Creature worker)
    {
        return Satisfaction < Def.NeedThreshold;
    }

    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);

        _jobStep = JobStep_TryFindBed;
    }

    public override void OnLeaveJob(Creature worker)
    {
        _bedPath.Free();

        if (_bed != null)
        {
            _bed.Sleeper = null;
            _bed = null;
        }

        worker.SleepParticules.Stop();

        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        _bedPath.Free();

        if(_bed != null)
        {
            _bed.Sleeper = null;
            _bed = null;
        }

        worker.SleepParticules.Stop();

        base.OnFinishJob(worker);
    }

    #region Jobsteps

    private bool JobStep_TryFindBed(Creature worker)
    {
        if (worker.Caravan != null)
        {
            List<BedBuilding> beds = worker.Caravan.Beds;

            BedBuilding tmp;
            int best;
            float bestDistance;
            float distance;

            for (int i = 0; i < beds.Count; i++)
            {
                if (beds[i].Sleeper != null) continue;

                best = i;
                bestDistance = float.MaxValue;
                for (int n = i + 1; n < beds.Count; n++)
                {
                    if (beds[n].Sleeper != null) continue;

                    distance = Vector2.SqrMagnitude(worker.transform.position - beds[n].transform.position);
                    if (distance < bestDistance)
                    {
                        best = n;
                        bestDistance = distance;
                    }
                }

                tmp = beds[best];
                beds[best] = beds[i];
                beds[i] = tmp;

                if (_bedPath.FindPath(tmp, worker))
                {
                    _bed = tmp;
                    _bed.Sleeper = worker;
                    _jobStep = JobStep_GotoBed;
                    return false;
                }
            }
        }

        _jobStep = JobStep_TryFindEmptyTile;
        return false;
    }
    private bool JobStep_TryFindEmptyTile(Creature worker)
    {
        Area targetArea;
        if (worker.Caravan == null || worker.Parent.Area.IsBuildingArea())
        {
            targetArea = worker.Parent.Area;
        }
        else
        {
            targetArea = CaravanUtility.GetClosestBuildingArea(worker.Caravan, worker.transform.position);
        }
        int randX = Random.Range(0, targetArea.Width);
        int randY = Random.Range(0, targetArea.Height);

        AreaTile targetTile = targetArea.Tiles[randX, randY];

        if (_bedPath.FindPath(targetTile, worker))
        {
            _jobStep = JobStep_GotoBed;
        }
        return false;
    }
    private bool JobStep_GotoBed(Creature worker)
    {
        if (_bedPath.IsFinished)
        {
            worker.SleepParticules.transform.rotation = Quaternion.identity;
            worker.SleepParticules.Play();
            _jobStep = JobStep_Sleep;
        }

        else if (_bedPath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    private bool JobStep_Sleep(Creature worker)
    {
        float delta = Caravan.DevSpeed ? Time.deltaTime * 10 : Time.deltaTime;

        Satisfaction += delta * Def.SleepGain * (_bed == null ? Def.GroundRestFactor : _bed.RestFactor);

        #region Regen whiule sleeping
        _healthRegen += delta * Def.HealthRegen * (_bed == null ? Def.GroundRestFactor : _bed.RestFactor);
        if (_healthRegen > 1)
        {
            _healthRegen -= 1;
            worker.HealDamage(1);
        }
        #endregion

        return Satisfaction >= Def.MaxNeed;
    }


    #endregion
}