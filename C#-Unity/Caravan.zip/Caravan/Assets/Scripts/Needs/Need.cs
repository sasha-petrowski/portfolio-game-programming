public abstract class Need : Job
{
    public abstract NeedDef NeedDef { get; }

    public float Satisfaction;

    public abstract void TickNeed(Creature creature);
}