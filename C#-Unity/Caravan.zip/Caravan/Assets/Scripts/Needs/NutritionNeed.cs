using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class NutritionNeed : Need
{
    public override NeedDef NeedDef => Def;
    public NutritionNeedDef Def;

    private Path _foodPath = new Path();

    private IInteractable _target;

    private int _targetQuantity;
    private ItemDef _itemDef;

    float _starvationLoss, _healthRegen;

    public override int JobType => -1;
    public override Vector2 GetPosition()
    {
        return Vector2.zero;
    }
    public override void TickNeed(Creature creature)
    {
        float delta = Caravan.DevSpeed ? Time.deltaTime * 10 : Time.deltaTime;

        // Nutrition loss
        Satisfaction -= delta * Def.Loss;

        // Starvation Health loss
        if (Satisfaction < 0)
        {
            _starvationLoss += delta * Def.StarvationHealthLoss;
            if(_starvationLoss > 1)
            {
                _starvationLoss -= 1;
                creature.TakeDamage(1);
            }
        }
        else
        {
            _healthRegen += delta * Def.HealthRegen;
            if (_healthRegen > 1)
            {
                _healthRegen -= 1;
                creature.HealDamage(1);
            }
        }
    }

    protected override bool TakeJobCondition(Creature worker)
    {
        return Satisfaction < Def.NeedThreshold && TryFindFood(worker);
    }

    #region Try Find Food
    private bool TryFindFoodNear(Creature worker)
    {
        // Verify food exists on map
        if (Item.WorldCategory[Def.FoodCategory] + Item.StoredCategory[Def.FoodCategory] <= 0) return false;

        //Debug.Log($"World nutrition : {Item.WorldCategory[Def.FoodCategory]} + Stored : {Item.StoredCategory[Def.FoodCategory]}");


        if (worker.Parent.Area.FlooredNutrition > 0)
        {
            foreach (AreaTile tile in worker.Parent.Area.Tiles)
            {
                if (EvaluateEntity(tile.Entity, worker)) return true;
            }
        }
        if (worker.Parent.Area.StoredNutrition > 0)
        {
            foreach (IStorage storage in worker.Parent.Area.Storages)
            {
                if (EvaluateStorage(storage, worker)) return true;
            }
        }

        foreach (GiantCreature giant in worker.Parent.Area.GiantEntities)
        {
            if (FindFoodInArea(giant.BuildingArea, worker)) return true;
        }

        return false;
    }
    protected virtual bool TryFindFood(Creature worker)
    {
        //Debug.Log($"Found {Item.WorldCategory[Def.FoodCategory] + Item.StoredCategory[Def.FoodCategory]} of {Def.FoodCategory}");

        // Verify food exists on map
        if (Item.WorldCategory[Def.FoodCategory] + Item.StoredCategory[Def.FoodCategory] <= 0) return false;

        if (worker.Parent.Area.FlooredNutrition > 0)
        {
            foreach (AreaTile tile in worker.Parent.Area.Tiles)
            {
                if (EvaluateEntity(tile.Entity, worker)) return true;
            }
        }
        if (worker.Parent.Area.StoredNutrition > 0)
        {
            foreach (IStorage storage in worker.Parent.Area.Storages)
            {
                if (EvaluateStorage(storage, worker)) return true;
            }
        }

        return WorldUtility.SpiralChunkSearch(worker, FindFoodInArea, worker);
    }
    private bool FindFoodInArea(Vector2Int chunkIndex, Creature worker)
    {
        if (World.s_Instance.ChunkAreas.ContainsKey(chunkIndex))
        {
            Area area = World.s_Instance.ChunkAreas[chunkIndex];

            if (FindFoodInArea(area, worker)) return true;

            foreach (GiantCreature ge in area.GiantEntities)
            {
                if (ge.BuildingArea != null && FindFoodInArea(ge.BuildingArea, worker)) return true;
            }
        }
        return false;
    }
    private bool FindFoodInArea(Area area, Creature worker)
    {
        if (area == worker.Parent.Area) return false;

        if(area.IsBuildingArea() && area.Caravan != worker.Caravan) return false;

        if (area.FlooredNutrition > 0)
        {
            foreach (AreaTile tile in area.Tiles)
            {
                if (EvaluateEntity(tile.Entity, worker)) return true;
            }
        }
        if (area.StoredNutrition > 0)
        {
            foreach (IStorage storage in area.Storages)
            {
                if (EvaluateStorage(storage, worker)) return true;
            }
        }

        return false;
    }
    private bool EvaluateEntity(Entity entity, Creature worker)
    {
        if (entity == null || entity.Reserved) return false;

        if (entity is IWithNutrition nutrition && nutrition.Type.Contains(Def.FoodCategory))
        {
            //Debug.Log(entity);
            if (_foodPath.FindPath(entity, worker))
            {
                //Debug.LogWarning("Evaluating item for food");

                entity.Reserved = true;
                _targetQuantity = 1;

                _target = nutrition;

                return true;
            }
        }
        else if(entity is ItemEntity item && item.Item is IWithNutrition nutri && nutri.Type.Contains(Def.FoodCategory))
        {
            if (_foodPath.FindPath(entity, worker))
            {
                int needed = Mathf.Max(Mathf.RoundToInt((Def.MaxNeed - Satisfaction) / nutri.Nutrition), 1);

                _itemDef = item.Item.ItemDef;
                item.Item.ReserveSource(_itemDef, needed, out _targetQuantity);

                _target = nutri;

                return _targetQuantity > 0;
            }
        }


        return false;
    }
    private bool EvaluateStorage(IStorage store, Creature worker)
    {
        //Debug.LogWarning("Evaluating storage for food");
        foreach (KeyValuePair<ItemDef, StorageData> pair in store.StorageData)
        {
            if (!(pair.Key is FoodItemDef food)) continue;

            bool contains = false;
            foreach (ItemCategoryDef cat in food.Categories)
            {
                if (cat == Def.FoodCategory)
                {
                    contains = true;
                    break;
                }
            }

            //Debug.Log("Item is food");
            if (contains && store.CanSource(food) && _foodPath.FindPath(store, worker))
            {
                int needed = Mathf.Max(Mathf.RoundToInt((Def.MaxNeed - Satisfaction) / food.Nutrition), 1);

                store.ReserveSource(food, needed, out _targetQuantity);

                //Debug.Log($"Need : {needed}, avail : {_targetQuantity}");

                //Debug.Log($"Reserving storage : {_targetQuantity}x {food}");

                _target = store;
                _itemDef = food;
                return _targetQuantity > 0;
            }
        }
        //Debug.Log("no food");
        return false;
    }
    #endregion

    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);

        _jobStep = JobStep_GotoFood;
    }
    public override void OnLeaveJob(Creature worker)
    {
        _foodPath.Free();

        if (_target is IItemSource source) source.CancelSource(_itemDef, _targetQuantity);
        else if (_target is Entity entity) entity.Reserved = false;

        _itemDef = null;
        _target = null;
        _targetQuantity = 0;


        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        _foodPath.Free();
        
        _itemDef = null;
        _target = null;
        _targetQuantity = 0;

        base.OnFinishJob(worker);
    }

    #region Jobsteps
    
    private bool JobStep_GotoFood(Creature worker)
    {
        if (_target == null) OnLeaveJob(worker);

        else if (_foodPath.IsFinished)
        {
            if (_target is IItemSource source)
            {
                Item item = source.Take(worker, _itemDef, _targetQuantity);

                if (item is IWithNutrition nutrition && nutrition.Consume(worker, this)) item.Drop();
                else item.Drop();
            }

            else if (_target is IWithNutrition nutrition && nutrition.Consume(worker, this) && _target is Item item) item.Drop();
            else if (_target is Item itm) itm.Drop();

            if (Satisfaction < (Def.MaxNeed - Def.NeedThreshold) && TryFindFoodNear(worker)) return false;

            else return true;
        }

        else if (_foodPath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    
    #endregion
}