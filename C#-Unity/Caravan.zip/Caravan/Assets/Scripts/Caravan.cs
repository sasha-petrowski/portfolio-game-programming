using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Caravan : MonoBehaviour
{
    public static Caravan s_PlayerCaravan { get; private set; }
    public static Vector2Int s_PlayerCenterChunkIndex { get; private set; }

    public LinkedList<WeaponItem> FreeWeapons = new LinkedList<WeaponItem>();


    [SerializeField]
    private bool _isPlayerCaravan;
    public bool IsPlayerCaravan { get => _isPlayerCaravan; }

    public Transform CaravanCenter;
    [HideInInspector]
    public Vector2Int CenterChunkIndex { get; private set; } = Vector2Int.zero;

    public List<Entity> DangerSources = new List<Entity>();


    public LinkedList<GiantCreature> GiantEntities { get; private set; } = new LinkedList<GiantCreature>();
    public LinkedList<BuildingArea> BuildingAreas { get; private set; } = new LinkedList<BuildingArea>();
    public LinkedList<Humanoid> Caravaneers { get; private set; } = new LinkedList<Humanoid>();


    public bool FullyDriven => GiantsDriven == GiantEntities.Count;

    public List<BedBuilding> Beds = new List<BedBuilding>();

    public int GiantsDriven = 0;

    [HideInInspector]
    public bool IsMoving;
    public float MoveAngle;
    public Vector3 MoveDirection;

    public static bool DevSpeed;

    private void Awake()
    {
        if (_isPlayerCaravan)
        {
            if(s_PlayerCaravan == null)
            {
                s_PlayerCaravan = this;
            }
            else
            {
                Debug.LogError("Error : s_PlayerCaravan is already set : Creation of a second unallowed PlayerCaravan");
            }
        }
    }

    private void LateUpdate()
    {
        int n = 0;
        Vector3 count = Vector3.zero;
        foreach (GiantCreature giant in GiantEntities)
        {
            n++;
            count.x += giant.transform.position.x;
            count.y += giant.transform.position.y;
        }
        if(n > 0)
        {
            CaravanCenter.position = count / n;
            CenterChunkIndex = WorldUtility.ChunkIndexAt(CaravanCenter.position);
            if (_isPlayerCaravan)
            {
                s_PlayerCenterChunkIndex = CenterChunkIndex;
            }
        }
    }
    public void DirectionInput(bool centered, Vector2 direction, float angle)
    {
        IsMoving = !centered;
        MoveDirection = direction;
        MoveAngle = angle;
    }
    public void SetDirection(Vector2 direction, float angle)
    {
        MoveAngle = angle;
        MoveDirection = direction;
    }
}
