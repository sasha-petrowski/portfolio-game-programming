public abstract class JobTarget
{
    public abstract JobTargetDef Def { get; }
    public abstract Job Job { get; }

    public bool TryAddJob(Entity target, out Job job)
    {
        if(CanAddJob())
        {
            job = AddJob(target);
            return true;
        }
        else
        {
            job = null;
            return false;
        }
    }
    public abstract bool CanAddJob();
    public abstract Job AddJob(Entity target);
    public abstract void RemoveJob(Entity target);
}