public class HuntingJobTarget : JobTarget
{
    public static JobTargetDef s_TargetDef;

    private HuntingJob _job;
    public override Job Job => _job;
    public override JobTargetDef Def => s_TargetDef;

    public override Job AddJob(Entity target)
    {
        _job = new HuntingJob(target as Animal);
        target.Parent.Area.AddJobProvider(_job);

        return _job;
    }
    public override bool CanAddJob()
    {
        return _job == null;
    }
    public override void RemoveJob(Entity target)
    {
        if (_job == null) return;

        target.Parent.Area.RemoveJobProvider(_job);
        _job = null;
    }
}