using UnityEngine;

public class HaulingJobTarget : JobTarget
{
    public static JobTargetDef s_TargetDef;

    private HaulingJob _job;
    public override Job Job => _job;

    public override JobTargetDef Def => s_TargetDef;

    public override Job AddJob(Entity target)
    {
        //Debug.Log(target);
        //Debug.Log((target as ItemEntity).Item);

        _job = new HaulingJob((target as ItemEntity).Item);
        target.Parent.Area.AddJobProvider(_job);

        return _job;
    }

    public override bool CanAddJob()
    {
        return _job == null;
    }

    public override void RemoveJob(Entity target)
    {
        if (_job == null) return;

        target.Parent.Area.RemoveJobProvider(_job);
        _job = null;
    }
}