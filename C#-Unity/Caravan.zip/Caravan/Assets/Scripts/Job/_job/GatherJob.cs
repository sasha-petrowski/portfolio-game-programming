﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class GatherJob : Job
{
    protected Path _targetPath;
    private ResourceEntity _resource;

    float _gatherTime;

    public override int JobType => (int)JobTypes.Gather;

    public GatherJob(ResourceEntity resource) : base()
    {
        _resource = resource;
        _targetPath = new Path();
        _gatherTime = 1;
    }
    protected override bool TakeJobCondition(Creature worker)
    {
        return base.TakeJobCondition(worker) && _targetPath.FindPath(_resource.GetInteractionSpots(), worker);
    }
    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);

        _jobStep = JobStep_GoToTarget;
    }
    public override void OnLeaveJob(Creature worker)
    {
        _targetPath?.Free();
        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        _resource.Destroy();

        #region Drop
        AreaTile spot = _resource.GetFirstSpot();
        // Drop items in storage
        foreach (ItemQuantity material in _resource.ResourceDef.Drops)
        {
            int quantity = material.Quantity;

            while (quantity > 0)
            {
                Item item = (Item)material.Item.TryInstantiate(AreaTile.GetEmptyTile(spot), null, Mathf.Min(quantity, material.Item.StackSize));
                quantity -= material.Item.StackSize;
                item?.Entity?.AddHaulingJob();
            }
        }
        #endregion

        _targetPath?.Free();
        base.OnFinishJob(worker);
    }
    #region JobSteps
    protected virtual bool JobStep_GoToTarget(Creature worker)
    {
        if (_resource == null) OnLeaveJob(worker);
        else if (_targetPath.IsFinished)
        {
            _jobStep = JobStep_Gather;
        }
        else if (_targetPath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    protected virtual bool JobStep_Gather(Creature worker)
    {
        _gatherTime -= Time.deltaTime;
        if( _gatherTime < 0 )
        {
            return true;
        }

        return false;
    }
    #endregion
    public override Vector2 GetPosition()
    {
        return _resource.transform.position;
    }

    public override void OnDrawGizmos()
    {
        if (_targetPath != null) _targetPath.OnDrawGizmos();
    }
}