using System;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public abstract class LongTermJob : Job
{
    private const int REPLACETICKS = 500;
    int _replaceTicks;

    public override void DoJob(Creature worker)
    {
        _replaceTicks++;
        if (_replaceTicks >= REPLACETICKS)
        {
            foreach(Need need in worker.Needs)
            {
                // leave job if needs are below half the threshold
                if (need.Satisfaction < need.NeedDef.NeedThreshold / 2 && need.TryTakeJob(worker) != null) return;
            }
        }

        base.DoJob(worker);
    }
}