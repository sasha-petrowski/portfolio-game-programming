using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using UnityEngine;

public class DrivingJob : LongTermJob
{
    public GiantCreature Giant;
    private Path _driverPath = new Path();
    private bool _driving = false;

    #region Jobprovider
    public override int JobType => (int)JobTypes.Drive;
    public override Vector2 GetPosition()
    {
        return Giant.transform.position;
    }
    #endregion


    public DrivingJob(GiantCreature giant) : base()
    {
        Giant = giant;
        _driverPath.GetNewTargets = Giant.GetFreeDriverTiles;
    }
    protected override bool TakeJobCondition(Creature worker)
    {
        if(base.TakeJobCondition(worker) & Giant.Caravan.IsMoving)
        {
            List<AreaTile> driverTiles = Giant.GetFreeDriverTiles();
            return driverTiles.Count > 0 && _driverPath.FindPath(driverTiles, worker);
        }
        return false;
    }
    #region End the job
    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);
        _jobStep = JobStep_GoToDrivingSpot;
    }
    public override void OnFinishJob(Creature worker)
    {
        base.OnFinishJob(worker);

        if(_driving)
        {
            _driving = false;
            Giant.Caravan.GiantsDriven--;
        }
    }
    public override void OnLeaveJob(Creature worker)
    {
        base.OnLeaveJob(worker);

        if (_driving)
        {
            _driving = false;
            Giant.Caravan.GiantsDriven--;
        }
    }
    #endregion

    #region JobSteps
    protected bool JobStep_GoToDrivingSpot(Creature worker)
    {
        if (!Giant.Caravan.IsMoving) return true;

        if (_driverPath.IsFinished || _driverPath.FollowPath(worker) == 1)
        {
            _driving = true;
            Giant.Caravan.GiantsDriven++;

            _jobStep = JobStep_DriveGiant;
        }
        return false;
    }
    protected bool JobStep_DriveGiant(Creature worker)
    {
        if(! Giant.Caravan.IsMoving) return true;

        if (Giant.Caravan.FullyDriven) Giant.FollowPath();

        return false;
    }
    #endregion
}
