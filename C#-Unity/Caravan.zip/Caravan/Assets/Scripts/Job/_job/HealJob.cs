﻿using System;
using System.Collections.Generic;
using System.Linq;
using Unity.Jobs;
using UnityEngine;

public class HealingJob : Job
{
    public Creature Patient;
    public IItemSource Source;

    public Path SourcePath = new Path();
    public Path PatientPath = new Path();

    private Item _item;
    public ItemDef TargetDef;
    public int TargetQuantity;

    public override int JobType => (int)JobTypes.Heal;

    public HealingJob(Creature patient)
    {
        if (patient == null) throw new ArgumentNullException("patient cannot be null.");

        Patient = patient;
    }
    protected override bool TakeJobCondition(Creature worker)
    {
        return base.TakeJobCondition(worker) && TryFindHeal(worker);
    }
    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);

        _jobStep = JobStep_TakeItem;
    }
    public override void OnLeaveJob(Creature worker)
    {
        if(_item != null) _item.Drop();
        _item = null;

        if (Source != null) Source.CancelSource(TargetDef, TargetQuantity);
        Source = null;



        SourcePath?.Free();
        PatientPath?.Free();

        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        SourcePath?.Free();
        PatientPath?.Free();

        base.OnFinishJob(worker);
    }

    #region Try Find Nutrition
    private bool TryFindHeal(Creature worker)
    {
        // Verify food exists on map
        if (Item.WorldCategory[worker.CreatureDef.HealingCategory] + Item.StoredCategory[worker.CreatureDef.HealingCategory] <= 0) return false;

        foreach (Item item in worker.Parent.Area.Items)
        {
            if (EvaluateItem(item, worker)) return true;
        }
        foreach (IStorage storage in worker.Parent.Area.Storages)
        {
            if (EvaluateStorage(storage, worker)) return true;
        }

        return WorldUtility.SpiralChunkSearch(worker, FindFoodInArea, worker);
    }
    private bool FindFoodInArea(Vector2Int chunkIndex, Creature worker)
    {
        if (World.s_Instance.ChunkAreas.TryGetValue(chunkIndex, out ChunkArea area))
        {
            if (FindFoodInArea(area, worker)) return true;

            foreach (GiantCreature ge in area.GiantEntities)
            {
                if (ge.BuildingArea != null && FindFoodInArea(ge.BuildingArea, worker)) return true;
            }
        }
        return false;
    }
    private bool FindFoodInArea(Area area, Creature worker)
    {
        if (area == worker.Parent.Area) return false;

        foreach (Item item in area.Items)
        {
            if (EvaluateItem(item, worker)) return true;
        }
        foreach (IStorage storage in area.Storages)
        {
            if (EvaluateStorage(storage, worker)) return true;
        }

        return false;
    }
    private bool EvaluateItem(Item item, Creature worker)
    {
        if (!(item is IWithHealing healing)) return false;

        
        if (item.ItemDef.Categories.Contains(worker.CreatureDef.HealingCategory) && item.CanSource(item.ItemDef) && SourcePath.FindPath(item, worker) && (Patient == worker || PatientPath.FindPath(Patient, SourcePath.LastTile, worker)))
        {
            int needed = Mathf.Max(Mathf.RoundToInt((Patient.CreatureDef.MaxHealth - Patient.Health - Patient.Regeneration) / healing.Healing), 1);
            item.ReserveSource(item.ItemDef, needed, out TargetQuantity);

            Source = item;
            TargetDef = item.ItemDef;

            return TargetQuantity > 0;
        }

        return false;
    }
    private bool EvaluateStorage(IStorage store, Creature worker)
    {
        foreach (KeyValuePair<ItemDef, StorageData> pair in store.StorageData)
        {
            if (!(pair.Key is HealingItemDef healing)) continue;

            if (healing.Categories.Contains(worker.CreatureDef.HealingCategory) && store.CanSource(healing) && SourcePath.FindPath(store, worker) && (Patient == worker || PatientPath.FindPath(Patient, SourcePath.LastTile, worker)))
            {
                int needed = Mathf.Max(Mathf.RoundToInt((Patient.CreatureDef.MaxHealth - Patient.Health - Patient.Regeneration) / healing.Healing), 1);
                store.ReserveSource(healing, needed, out TargetQuantity);

                Source = store;
                TargetDef = healing;

                return TargetQuantity > 0;
            }
        }
        return false;
    }
    #endregion

    #region JobSteps
    protected bool JobStep_TakeItem(Creature worker)
    {
        if (Source == null) OnLeaveJob(worker);

        else if (SourcePath.IsFinished)
        {
            _item = Source.Take(worker, TargetDef, TargetQuantity);
            Source = null;

            if(Patient == worker) _jobStep = JobStep_Heal;
            else _jobStep = JobStep_HaulToPatient;
        }
        else if (SourcePath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    protected bool JobStep_HaulToPatient(Creature worker)
    {
        if (Patient == null | _item == null) OnLeaveJob(worker);
        else if (PatientPath.IsFinished)
        {
            if(Patient.Parent == PatientPath.LastTile) _jobStep = JobStep_Heal;
            else if(PatientPath.FindPath(Patient, worker)) _jobStep = JobStep_HaulToPatient;
            else OnLeaveJob(worker);
        }
        else if (PatientPath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    protected bool JobStep_Heal(Creature worker)
    {
        if (Patient == null | _item == null)
        {
            OnLeaveJob(worker);
            return false;
        }

        if (_item is IWithHealing healing && healing.Consume(Patient, null)) _item.Drop();
        else _item.Drop();

        return true;
    }
    #endregion

    public override Vector2 GetPosition()
    {
        return Patient.transform.position;
    }
}