﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class HaulingJob : Job
{
    private Item _item;
    private IStorage _storage;

    private Path _itemPath;
    private Path _storagePath;

    private int _haulQuantity;


    public HaulingJob(Item itemToHaul) : base()
    {
        if(itemToHaul == null) throw new ArgumentNullException("itemToHaul cannot be null.");

        _item = itemToHaul;
        _itemPath = new Path();
        _storagePath = new Path();
    }
    protected override bool TakeJobCondition(Creature worker)
    {
        /*
        bool cBase = base.TakeJobCondition(worker);
        bool cAnyStorage = ItemManager.AnyStorageAvailable();
        bool cHauledBy = _itemToHaul.HauledBy == worker;
        bool cPathItem = !cHauledBy ? _itemToHaul.HauledBy == null && _itemPath.FindPath((AreaTile)_itemToHaul.Entity.Parent, worker) : true;
        bool cPathStore = FindPathToStorage(worker);
        Debug.Log(
            $"Base conditions : {cBase}\n" +

            $"----- AnyStorage : {cAnyStorage}\n" +

            $"----- Hauledby : {cHauledBy}\n" +

            $"-- Path -> Item : {cPathItem}\n" +

            $"- Path -> Store : {cPathStore}\n");
        return cBase && cAnyStorage && (cHauledBy || cPathItem) && cPathStore;
        */
        return _item.Reserved == 0 && base.TakeJobCondition(worker) && ItemManager.AnyStorageAvailable() && (_item.HauledBy == null && _itemPath.FindPath((AreaTile)_item.Entity.Parent, worker) || _item.HauledBy == worker) && FindPathToStorage(worker);
    }
    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);
        if(_item.HauledBy == worker)
        {
            _jobStep = JobStep_HaulToStorage;
        }
        else
        {
            _jobStep = JobStep_TakeItem;
        }
    }

    public override void OnLeaveJob(Creature worker)
    {
        if(_item != null)
        {
            _item.Drop();
            _item.Entity.AddHaulingJob();
            _item.CancelStorage(_storage, _haulQuantity);
        }

        _itemPath?.Free();
        _storagePath?.Free();

        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        _item.EnterStorage(_storage);

        _itemPath?.Free();
        _storagePath?.Free();

        base.OnFinishJob(worker);
    }
    #region FindPathToStorage    
    protected bool FindPathToStorage(Creature worker)
    {
        foreach(BuildingArea area in CaravanUtility.ClosestBuildingAreas(worker.Caravan, _item.transform.position))
        {
            if (SearchAreaForStoragePath(area, worker)) return true;
        }
        return false;
    }
    protected virtual bool SearchAreaForStoragePath(Area area, Creature worker)
    {
        //Debug.LogWarning($"Looking for storages in : {area}");
        if (area.Storages.Count > 0)
        {
            //Sort storages in List by most important, closest and not full then see if it can path to it.
            List<IStorage> storageList = new List<IStorage>(area.Storages.Count);
            foreach (IStorage s in area.Storages)
            {
                if (_item.CanBeStored(s)) storageList.Add(s);
            }

            if (storageList.Count > 0)
            {
                //Debug.Log($"Found {storageList.Count} potential storages in {area}");
                float[] magnitudes = new float[storageList.Count];
                for (int i = 0; i < storageList.Count; i++)
                {
                    Vector2 storagePos = storageList[i].GetFirstSpot().WorldPosition();
                    magnitudes[i] = (storagePos.x - _item.transform.position.x) * (storagePos.x - _item.transform.position.x) + (storagePos.y - _item.transform.position.y) * (storagePos.y - _item.transform.position.y);
                }
                float tmp_m;
                IStorage tmp_s;
                for (int i = 0; i < storageList.Count; i++)
                {
                    for (int n = i + 1; n < storageList.Count; n++)
                    {
                        // Sort by distance
                        if (magnitudes[i] > magnitudes[n])
                        {
                            tmp_m = magnitudes[i];
                            tmp_s = storageList[i];

                            magnitudes[i] = magnitudes[n];
                            storageList[i] = storageList[n];

                            magnitudes[n] = tmp_m;
                            storageList[n] = tmp_s;
                        }
                    }
                    //Debug.Log($"Reserving storage : {storageList[i]}");

                    AreaTile itemTile = (AreaTile)_item.Entity?.Parent;
                    if (itemTile == null) itemTile = (AreaTile)worker.Parent;

                    if (_storagePath.FindPath(storageList[i], itemTile, worker))
                    {
                        //Debug.Log("<color=yellow> Can Path to Storage returning True</color>");
                        _storage = storageList[i];
                        _haulQuantity = _item.ReserveStorage(_storage);
                        _item.ReserveSource(_item.ItemDef, _haulQuantity, out int tmp);
                        return true;
                    }
                }
            }
        }
        return false;
    }
    #endregion

    #region JobSteps
    protected bool JobStep_TakeItem(Creature worker)
    {
        if (_item == null) OnLeaveJob(worker);

        else if (_itemPath.IsFinished)
        {
            // find appropriate storage
            _item.Take(worker, _item.ItemDef, _haulQuantity);
            _jobStep = JobStep_HaulToStorage;
        }

        else if (_itemPath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    protected bool JobStep_HaulToStorage(Creature worker)
    {
        if (_storagePath.IsFinished) return true;

        if (_storagePath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    #endregion

    #region JobProvider
    public override int JobType => (int)JobTypes.Haul;
    public override Vector2 GetPosition()
    {
        return _item.transform.position;
    }
    #endregion

    public void DestroyJob()
    {
        _storage?.CancelReceiving(_item.ItemDef, _haulQuantity);
        _item.CancelSource(_item.ItemDef, _haulQuantity);
        _item = null;
    }
}