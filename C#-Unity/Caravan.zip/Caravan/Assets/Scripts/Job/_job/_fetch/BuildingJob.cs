﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class BuildingJob : FetchJob, IJobProvider
{
    private Blueprint _blueprint;
    public BuildingJob(Blueprint blueprint) : base(blueprint, blueprint.BuildingDef.Materials)
    {
        _blueprint = blueprint;
    }

    public override int JobType => (int)JobTypes.Build;
    public override Vector2 GetPosition() => _blueprint.transform.position;


    protected override bool ReceivedJobCondition(Creature worker)
    {
        return FetchPath.FindPath(_blueprint, worker);
    }

    protected override void OnEverythingReceived(Creature worker)
    {
        _jobStep = JobStep_Build;
    }
    protected override void OnTakeJobWhenReceived(Creature worker)
    {
        _jobStep = JobStep_GotoBlueprint;
    }
    public override void OnLeaveJob(Creature worker)
    {
        if (worker is Humanoid humanoid)
        {
            humanoid.ProgressBG.enabled = false;
            humanoid.ProgressSlider.enabled = false;
        }
        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        if (worker is Humanoid humanoid)
        {
            humanoid.ProgressBG.enabled = false;
            humanoid.ProgressSlider.enabled = false;
        }

        base.OnFinishJob(worker);

        _blueprint.Build();
    }
    #region Jobsteps
    protected bool JobStep_GotoBlueprint(Creature worker)
    {
        if (_blueprint == null) OnLeaveJob(worker);

        if (FetchPath.IsFinished)
        {
            _jobStep = JobStep_Build;
        }
        else if (FetchPath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    protected bool JobStep_Build(Creature worker)
    {
        if (_blueprint == null)
        {
            OnLeaveJob(worker);
            return false;
        }

        if (worker is Humanoid humanoid)
        {
            humanoid.ProgressBG.enabled = true;
            humanoid.ProgressSlider.enabled = true;

            humanoid.ProgressBG.size = new Vector2(PROGRESSBARSIZE, 1);
            humanoid.ProgressSlider.size = new Vector2(PROGRESSBARSIZE * _blueprint.BuildTime / _blueprint.BuildingDef.BuildTime, 1);
        }

        _blueprint.BuildTime += Time.deltaTime;
        return _blueprint.BuildTime >= _blueprint.BuildingDef.BuildTime;
    }
    #endregion
}