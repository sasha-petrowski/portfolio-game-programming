﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class CraftingJob : FetchJob
{
    private WorkbenchBuilding _workbench;

    public CraftDef Craft => _craftDef;
    private CraftDef _craftDef;

    public int CraftQuantity = 16;
    public float CraftTime = 0;

    public override int JobType => (int)JobTypes.Craft;
    public override Vector2 GetPosition()
    {
        return FetchTo.GetFirstSpot().WorldPosition();
    }
    public CraftingJob(WorkbenchBuilding workbench, CraftDef craft) : base(workbench, craft.Materials)
    {
        _workbench = workbench;
        _craftDef = craft;

        _workbench.Crafts.Add(this);
    }



    protected override bool TakeJobCondition(Creature worker)
    {
        return CraftQuantity > Item.StoredQuantity[_craftDef.MainProduct] && base.TakeJobCondition(worker);
    }

    protected override bool ReceivedJobCondition(Creature worker)
    {
        return FetchPath.FindPath(_workbench.Parent as AreaTile, worker);
    }
    protected override void OnTakeJobWhenReceived(Creature worker)
    {
        _jobStep = JobStep_GotoBench;
    }
    protected override void OnEverythingReceived(Creature worker)
    {
        _jobStep = JobStep_Craft;
    }
    protected override void OnTakeJob(Creature worker)
    {
        _workbench.ReservedJob = this;
        base.OnTakeJob(worker);
    }
    public override void OnLeaveJob(Creature worker)
    {
        if (worker is Humanoid humanoid)
        {
            humanoid.ProgressBG.enabled = false;
            humanoid.ProgressSlider.enabled = false;
        }

        if (_workbench != null) _workbench.ReservedJob = null;
        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        if(worker is Humanoid humanoid)
        {
            humanoid.ProgressBG.enabled = false;
            humanoid.ProgressSlider.enabled = false;
        }

        _workbench.ReservedJob = null;

        CraftTime = 0;

        _craftDef.OnFinishCraft(worker, Fetched, UniqueItems);

        base.OnFinishJob(worker);
    }

    #region JobSteps
    protected bool JobStep_GotoBench(Creature worker)
    {
        if (_workbench == null) OnLeaveJob(worker);

        if (FetchPath.IsFinished)
        {
            _jobStep = JobStep_Craft;
        }
        else if (FetchPath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    protected bool JobStep_Craft(Creature worker)
    {
        if (_workbench == null)
        {
            OnLeaveJob(worker);
            return false;
        }

        if (worker is Humanoid humanoid)
        {
            humanoid.ProgressBG.enabled = true;
            humanoid.ProgressSlider.enabled = true;

            humanoid.ProgressBG.size = new Vector2(PROGRESSBARSIZE, 1);
            humanoid.ProgressSlider.size = new Vector2(PROGRESSBARSIZE * CraftTime / _craftDef.CraftTime, 1);
        }

        CraftTime += Time.deltaTime * (Caravan.DevSpeed ? 10 : 1);
        return CraftTime >= _craftDef.CraftTime;
    }
    #endregion

    public override void DeleteJob()
    {
        _workbench.Crafts.Remove(this);

        if (_workbench.ReservedJob == this) _workbench.ReservedJob = null;
        _workbench = null;

        base.DeleteJob();
    }
}