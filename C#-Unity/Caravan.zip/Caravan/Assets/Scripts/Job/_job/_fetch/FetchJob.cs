﻿using System;
using System.Collections.Generic;
using UnityEngine;

public abstract class FetchJob : Job
{
    public IInteractable FetchTo;
    public IItemSource Source;

    public Path SourcePath = new Path();
    public Path FetchPath = new Path();

    public List<ItemQuantity> Fetched = new List<ItemQuantity>();
    public List<UniqueItem> UniqueItems = new List<UniqueItem>();

    public ItemDef TargetDef;
    public int TargetQuantity;

    public bool Received = false;



    private Item _item;
    private RequiredItems _required;



    public RequiredItems RequiredItems => _required;

    public FetchJob(IInteractable fetchTo, RequiredItems required)
    {
        if (fetchTo == null) throw new ArgumentNullException("fetchTo cannot be null.");

        FetchTo = fetchTo;

        _required = required;
    }
    protected override bool TakeJobCondition(Creature worker)
    {
        return base.TakeJobCondition(worker) && ((Received && ReceivedJobCondition(worker)) || FindNextTarget(worker));
    }
    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);
        if (Received)
        {
            OnTakeJobWhenReceived(worker);
        }
        else
        {
            _jobStep = JobStep_TakeItem;
        }
    }
    protected abstract bool ReceivedJobCondition(Creature worker);
    protected abstract void OnTakeJobWhenReceived(Creature worker);
    protected abstract void OnEverythingReceived(Creature worker);

    public override void OnLeaveJob(Creature worker)
    {
        if(_item != null) _item.Drop();
        _item = null;
        if (Source != null) Source.CancelSource(TargetDef, TargetQuantity);
        Source = null;

        SourcePath?.Free();
        FetchPath?.Free();

        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        Received = false;
        SourcePath?.Free();
        FetchPath?.Free();

        Fetched.Clear();
        UniqueItems.Clear();

        base.OnFinishJob(worker);
    }

    #region Find next item
    protected bool FindNextTarget(Creature worker)
    {
        if(_required.TryFindSource(worker, this))
        {
            if (Received)
            {
                OnEverythingReceived(worker);
                return false;
            }
            return true;
        }
        return false;
    }
    #endregion

    #region JobSteps
    protected bool JobStep_TakeItem(Creature worker)
    {
        if (Source == null) OnLeaveJob(worker);

        else if (SourcePath.IsFinished)
        {
            _item = Source.Take(worker, TargetDef, TargetQuantity);
            Source = null;

            _jobStep = JobStep_HaulToReceiver;
        }
        else if (SourcePath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    protected bool JobStep_HaulToReceiver(Creature worker)
    {
        if (FetchTo == null | _item == null) OnLeaveJob(worker);
        else if (FetchPath.IsFinished)
        {
            bool added = false;
            for (int i = 0; i < Fetched.Count; i++)
            {
                if (Fetched[i].Item == _item.ItemDef)
                {
                    Fetched[i].Quantity += _item.Quantity;
                    added = true;
                    break;
                }
            }
            if (!added) Fetched.Add(new ItemQuantity(_item.ItemDef, _item.Quantity));

            if(_item is UniqueItem uItem) UniqueItems.Add(uItem);

            _item.EnterStorage(null);
            _item = null;

            if(FindNextTarget(worker))
            {
                _jobStep = JobStep_TakeItem;
            }
            else if(!Received)
            {
                OnLeaveJob(worker);
            }
        }
        else if (FetchPath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    #endregion

    public virtual void DeleteJob()
    {
        AreaTile spot = FetchTo.GetFirstSpot();
        // Drop items in storage
        foreach (ItemQuantity fetched in Fetched)
        {
            int quantity = fetched.Quantity;

            while (quantity > 0)
            {
                Item item = (Item)fetched.Item.TryInstantiate(AreaTile.GetEmptyTile(spot), null, Mathf.Min(quantity, fetched.Item.StackSize));
                quantity -= fetched.Item.StackSize;
                item?.Entity?.AddHaulingJob();
            }
        }
        
        Source = null;
        FetchTo = null;
    }
}