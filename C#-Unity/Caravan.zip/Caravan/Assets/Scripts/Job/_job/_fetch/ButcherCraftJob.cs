﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using Unity.Jobs;
using UnityEngine;

public class ButcherCraftJob : CraftingJob
{
    public ButcherCraftJob(WorkbenchBuilding workbench, CraftDef craft) : base(workbench, craft)
    {
    }
}