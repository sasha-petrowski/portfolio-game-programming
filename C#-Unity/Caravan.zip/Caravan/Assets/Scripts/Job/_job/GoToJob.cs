﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class GoToJob : Job
{
    protected Path _targetPath;
    public AreaTile TargetTile { get; protected set; }

    public override int JobType => (int)JobTypes.Drive;
    public override Vector2 GetPosition()
    {
        return TargetTile.WorldPosition();
    }

    public GoToJob(AreaTile targetTile) : base()
    {
        TargetTile = targetTile;

        _targetPath = new Path();
    }
    protected override bool TakeJobCondition(Creature worker)
    {
        return base.TakeJobCondition(worker) && _targetPath.FindPath(TargetTile, worker);
    }
    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);

        _jobStep = JobStep_GoToTarget;
    }
    public override void OnLeaveJob(Creature worker)
    {
        _targetPath?.Free();
        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        _targetPath?.Free();
        base.OnFinishJob(worker);
    }
    #region JobSteps
    protected virtual bool JobStep_GoToTarget(Creature worker)
    {
        if (TargetTile == worker.Parent) return true;

        if(_targetPath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    #endregion

    public override void OnDrawGizmos()
    {
        if (_targetPath != null) _targetPath.OnDrawGizmos();
    }
}