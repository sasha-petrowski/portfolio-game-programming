﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class HuntingJob : Job
{
    protected Creature _target;
    protected AreaTile _targetTile;
    protected Path _targetPath;

    #region JobProvider
    public override int JobType => (int)JobTypes.Hunting;
    public override Vector2 GetPosition() => _target.transform.position;
    #endregion

    public HuntingJob(Creature target) : base()
    {
        _target = target;

        _targetPath = new Path();
    }
    protected override bool TakeJobCondition(Creature worker)
    {
        return base.TakeJobCondition(worker) && _targetPath.FindPath(_target, worker);
    }
    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);

        _jobStep = JobStep_GoToTarget;

        if (worker.Weapon != null) worker.Weapon.DrawWeapon();
    }
    public override void OnLeaveJob(Creature worker)
    {
        if (worker is Humanoid humanoid)
        {
            humanoid.ProgressBG.enabled = false;
            humanoid.ProgressSlider.enabled = false;
        }
        if (worker.Weapon != null) worker.Weapon.SheathWeapon();

        _targetPath?.Free();
        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        if (worker is Humanoid humanoid)
        {
            humanoid.ProgressBG.enabled = false;
            humanoid.ProgressSlider.enabled = false;
        }
        if (worker.Weapon != null) worker.Weapon.SheathWeapon();

        _targetPath?.Free();
        base.OnFinishJob(worker);

        if(_target != null && _target.TryGetComponent(out ItemEntity corpse))
        {
            corpse.AddHaulingJob().TryTakeJob(worker);
        }
    }

    #region JobSteps
    protected bool JobStep_GoToTarget(Creature worker)
    {
        if (_target == null) OnLeaveJob(worker);
        else if (_targetPath.IsFinished)
        {
            if (_targetPath.LastTile == _target.Parent)
            {
                _targetTile = _targetPath.LastTile;
                _targetPath.Free();
                _jobStep = JobStep_KillTarget;
            }
            else if (!_targetPath.FindPath(_target, worker)) OnLeaveJob(worker);
        }
        else if (_targetPath.FollowPath(worker, 1) == -1) OnLeaveJob(worker);

        return false;
    }
    protected bool JobStep_KillTarget(Creature worker)
    {
        if (_target == null) OnLeaveJob(worker);
        // this is temporary until implementation of Death and Combat
        else if (_targetTile == _target.Parent)
        {
            worker.Fight(_target);
            bool targetIsDead = _target.Health < 0;

            #region Progress bar is Health bar
            if (worker is Humanoid humanoid)
            {
                humanoid.ProgressBG.enabled = true;
                humanoid.ProgressSlider.enabled = true;

                humanoid.ProgressBG.size = new Vector2(PROGRESSBARSIZE, 1);
                humanoid.ProgressSlider.size = new Vector2(PROGRESSBARSIZE * _target.Health / _target.Def.MaxHealth, 1);
            }
            #endregion

            return targetIsDead;
        }
        else if(_targetPath.FindPath(_target, worker)) // find path to target if not on same tile
        {
            #region Close progress bars
            if (worker is Humanoid humanoid)
            {
                humanoid.ProgressBG.enabled = false;
                humanoid.ProgressSlider.enabled = false;
            }
            #endregion

            _jobStep = JobStep_GoToTarget;
        }
        else OnLeaveJob(worker);

        return false;
    }
    #endregion

    public override void OnDrawGizmos()
    {
        if (_targetPath != null) _targetPath.OnDrawGizmos();
    }

}