﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class TakeWeaponJob : Job
{
    private WeaponItem _weapon;

    private Path _targetPath;

    public TakeWeaponJob(WeaponItem weapon) : base()
    {
        if(weapon == null) throw new ArgumentNullException("weapon cannot be null.");

        _weapon = weapon;
        _targetPath = new Path();
    }
    protected override bool TakeJobCondition(Creature worker)
    {
        return _weapon.Reserved == 0 && base.TakeJobCondition(worker) && FindPathToWeapon(worker);
    }
    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);

        if (_weapon.Storage != null) _weapon.Storage.ReserveSource(_weapon.ItemDef, 1, out int reserved);
        else _weapon.ReserveSource(_weapon.ItemDef, 1, out int reserve);

        _jobStep = JobStep_GotoWeapon;
    }
    public override void OnLeaveJob(Creature worker)
    {
        _targetPath?.Free();

        if (_weapon.Storage != null) _weapon.Storage.CancelSource(_weapon.ItemDef, 1);
        else _weapon.CancelSource(_weapon.ItemDef, 1);

        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        _targetPath?.Free();

        base.OnFinishJob(worker);
    }

    private bool FindPathToWeapon(Creature worker)
    {
        if (_weapon.Storage != null)
        {
            return _targetPath.FindPath(_weapon.Storage, worker);
        }
        else //if on the ground
        {
            return _targetPath.FindPath(_weapon, worker);
        }
    }
    private bool TryTakeWeapon(Creature worker)
    {
        WeaponItem weapon = _weapon;
        if (_weapon.Storage != null) weapon = (WeaponItem)_weapon.Storage.Take(worker, _weapon.WeaponDef, 1);

        if (weapon != null)
        {
            WeaponItem oldWeapon = worker.Weapon;
            weapon.Equip(worker);

            if(oldWeapon != null) { oldWeapon.Entity?.AddHaulingJob(); }
            return true;
        }

        return false;
    }

    #region JobSteps
    protected bool JobStep_GotoWeapon(Creature worker)
    {
        if (_weapon == null) OnLeaveJob(worker);

        else if (_targetPath.IsFinished)
        {
            if(TryTakeWeapon(worker))
            {
                return true;
            }
            else OnLeaveJob(worker);
        }

        else if (_targetPath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    #endregion

    #region JobProvider
    public override int JobType => (int)JobTypes.Haul;
    public override Vector2 GetPosition()
    {
        return _weapon.transform.position;
    }
    #endregion
}