﻿using System;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class FightDangerJob : DangerJob
{
    private Path _targetPath;
    private AreaTile _targetTile;

    protected override string AlertText => "Nomad is Fighting";

    public FightDangerJob(Entity danger) : base(danger)
    {
        _targetPath = new Path();
    }

    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);

        _jobStep = JobStep_FindPath;

        if (worker.Weapon != null) worker.Weapon.DrawWeapon();
    }

    public override void OnLeaveJob(Creature worker)
    {
        base.OnLeaveJob(worker);

        if (worker.Weapon != null) worker.Weapon.SheathWeapon();
    }
    public override void OnFinishJob(Creature worker)
    {
        base.OnLeaveJob(worker);

        if (worker.Weapon != null) worker.Weapon.SheathWeapon();
    }

    #region JobSteps
    protected bool JobStep_FindPath(Creature worker)
    {
        if (_danger == null || _danger.IsDead) OnLeaveJob(worker);
        else if (_targetPath.FindPath(_danger, worker)) _jobStep = JobStep_GoToTarget;

        return false;
    }
    protected bool JobStep_GoToTarget(Creature worker)
    {
        if (_danger == null || _danger.IsDead) OnLeaveJob(worker);
        else if (_targetPath.LastTile != _danger.Parent) _jobStep = JobStep_FindPath;
        else if (_targetPath.IsFinished)
        {
            if (_targetPath.LastTile == _danger.Parent)
            {
                _targetTile = _targetPath.LastTile;
                _targetPath.Free();
                _jobStep = JobStep_KillTarget;
            }
            else if (!_targetPath.FindPath(_danger, worker)) OnLeaveJob(worker);
        }
        else if (_targetPath.FollowPath(worker, 1) == -1) OnLeaveJob(worker);

        return false;
    }
    protected bool JobStep_KillTarget(Creature worker)
    {
        if (_danger == null || _danger.IsDead) OnLeaveJob(worker);

        else if (_targetTile == _danger.Parent)
        {
            worker.Fight(_danger);

            return _danger.IsDead;
        }
        else if (_targetPath.FindPath(_danger, worker)) // find path to target if not on same tile
        {
            _jobStep = JobStep_GoToTarget;
        }
        else OnLeaveJob(worker);

        return false;
    }
    #endregion
}