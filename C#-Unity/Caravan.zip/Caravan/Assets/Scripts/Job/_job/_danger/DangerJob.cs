﻿using System;
using System.Collections.Generic;
using UnityEngine;

public abstract class DangerJob : Job
{
    protected Entity _danger;
    private GameObject _dangerAlert;

    #region JobProvider
    public override int JobType => (int)JobTypes.Hunting;
    public override Vector2 GetPosition() => _danger.transform.position;
    #endregion

    protected abstract string AlertText { get; }

    public DangerJob(Entity danger) : base()
    {
        _danger = danger;
    }
    protected override void OnTakeJob(Creature worker)
    {
        Debug.LogWarning("Take danger job");
        base.OnTakeJob(worker);

        if(worker.Caravan == Caravan.s_PlayerCaravan) _dangerAlert = UIManager.Instance.AlertMenu.CreateAlert(AlertText, () => worker.transform.position);
    }
    public override void OnLeaveJob(Creature worker)
    {
        Debug.Log("Leave danger");
        GameObject.Destroy(_dangerAlert);


        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        Debug.Log("Leave danger");
        GameObject.Destroy(_dangerAlert);


        base.OnFinishJob(worker);
    }
}