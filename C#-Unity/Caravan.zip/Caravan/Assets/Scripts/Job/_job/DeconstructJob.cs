﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class DeconstructJob : Job
{
    protected Path _targetPath;
    private Building _building;

    float _deconstructTime;

    public override int JobType => (int)JobTypes.Build;

    public DeconstructJob(Building building) : base()
    {
        _building = building;
        _targetPath = new Path();
        _deconstructTime = 1;
    }
    protected override bool TakeJobCondition(Creature worker)
    {
        return base.TakeJobCondition(worker) && _targetPath.FindPath(_building.GetInteractionSpots(), worker);
    }
    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);

        _jobStep = JobStep_GoToTarget;
    }
    public override void OnLeaveJob(Creature worker)
    {
        _targetPath?.Free();
        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        _building.Destroy();

        #region Drop half the materials
        AreaTile spot = worker.GetFirstSpot();
        // Drop items in storage
        foreach (ItemQuantity material in _building.BuildingDef.Materials.Required)
        {
            int quantity = material.Quantity / 2;

            while (quantity > 0)
            {
                Item item = (Item)material.Item.TryInstantiate(AreaTile.GetEmptyTile(spot), null, Mathf.Min(quantity, material.Item.StackSize));
                quantity -= material.Item.StackSize;
                item?.Entity?.AddHaulingJob();
            }
        }
        #endregion

        _targetPath?.Free();
        base.OnFinishJob(worker);
    }
    #region JobSteps
    protected virtual bool JobStep_GoToTarget(Creature worker)
    {
        if (_building == null) OnLeaveJob(worker);
        else if (_targetPath.IsFinished)
        {
            _jobStep = JobStep_Deconstruct;
        }
        else if (_targetPath.FollowPath(worker) == -1) OnLeaveJob(worker);

        return false;
    }
    protected virtual bool JobStep_Deconstruct(Creature worker)
    {
        _deconstructTime -= Time.deltaTime;
        if( _deconstructTime < 0 )
        {
            return true;
        }

        return false;
    }
    #endregion
    public override Vector2 GetPosition()
    {
        return _building.transform.position;
    }

    public override void OnDrawGizmos()
    {
        if (_targetPath != null) _targetPath.OnDrawGizmos();
    }
}