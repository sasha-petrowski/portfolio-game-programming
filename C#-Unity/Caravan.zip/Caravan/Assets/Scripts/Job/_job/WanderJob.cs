﻿using System.Collections.Generic;
using UnityEngine;

public class WanderJob : Job
{
    private const float MAX_STANDING_TIME = 2f;
    private const float MIN_STANDING_TIME = 0.5f;

    private const int N_WANDER_BEFORE_SEARCH = 5;

    private float _timeStopStanding;
    private int _nWander;

    private Path _wanderPath;

    public override int JobType => -1;
    public override Vector2 GetPosition()
    {
        return Vector2.zero;
    }
    public WanderJob() : base()
    {
    }
    public override void OnLeaveJob(Creature worker)
    {
        _wanderPath?.Free();
        base.OnLeaveJob(worker);
    }
    public override void OnFinishJob(Creature worker)
    {
        _wanderPath?.Free();
        base.OnFinishJob(worker);
    }
    protected override void OnTakeJob(Creature worker)
    {
        base.OnTakeJob(worker);
        _nWander = 0;
        UpdateStandingTime();
        _jobStep = JobStep_Standing;
    }

    #region JobSteps
    protected bool JobStep_Standing(Creature worker)
    {
        if (_timeStopStanding <= Time.time)
        {
            _wanderPath = new Path();
            _jobStep = JobStep_TryFindNextWanderPath;
        }
        return false;
    }
    protected bool JobStep_TryFindNextWanderPath(Creature worker)
    {
        Area targetArea;
        if (worker.Caravan == null || worker.Parent.Area.IsBuildingArea())
        {
            targetArea = worker.Parent.Area;
        }
        else
        {
            targetArea = CaravanUtility.GetClosestBuildingArea(worker.Caravan, worker.transform.position);
        }
        int randX = Random.Range(0, targetArea.Width);
        int randY = Random.Range(0, targetArea.Height);

        AreaTile targetTile = targetArea.GetTile(randX, randY);

        if (_wanderPath.FindPath(targetTile, worker))
        {
            _jobStep = JobStep_Wandering;
        }
        return false;
    }
    protected bool JobStep_Wandering(Creature worker)
    {
        if (_wanderPath.FollowPath(worker) != 0)
        {
            _nWander++;
            if(_nWander >= N_WANDER_BEFORE_SEARCH) return true;
            else
            {
                UpdateStandingTime();
                _jobStep = JobStep_Standing;
            }
        }
        return false;
    }
    protected bool JobStep_TryFindOtherJob(Creature worker)
    {
        JobManager.TryFindJob(worker);
        if (worker.CurrentJob != this)
        {
            return true;
        }
        UpdateStandingTime();
        _jobStep = JobStep_Standing;
        return false;
    }

    private void UpdateStandingTime()
    {
        _timeStopStanding = Time.time + Random.Range(MIN_STANDING_TIME, MAX_STANDING_TIME);
    }
    #endregion
    public override void OnDrawGizmos()
    {
        if (_wanderPath != null) _wanderPath.OnDrawGizmos();
    }
}