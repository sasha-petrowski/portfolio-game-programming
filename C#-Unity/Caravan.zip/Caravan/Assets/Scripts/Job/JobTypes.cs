﻿using System;
using System.Collections;
using System.Collections.Generic;


public enum JobTypes
{
    Heal = 0,
    Drive = 1,
    Build = 2,
    Craft = 3,
    Hunting = 4,
    Haul = 5,
    Gather = 6,
}

public static class JTE
{
    public static List<int> Types = new List<int>{
        (int)JobTypes.Heal,
        (int)JobTypes.Drive,
        (int)JobTypes.Build,
        (int)JobTypes.Craft,
        (int)JobTypes.Hunting,
        (int)JobTypes.Haul,
        (int)JobTypes.Gather,
    };

    public static Dictionary<string, int> StringToType = new Dictionary<string, int>
    {
        { JobTypes.Heal.ToString(), (int)JobTypes.Heal },
        { JobTypes.Drive.ToString(), (int)JobTypes.Drive },
        { JobTypes.Build.ToString(), (int)JobTypes.Build },
        { JobTypes.Craft.ToString(), (int)JobTypes.Craft },
        { JobTypes.Hunting.ToString(), (int)JobTypes.Hunting },
        { JobTypes.Haul.ToString(), (int)JobTypes.Haul },
        { JobTypes.Gather.ToString(), (int)JobTypes.Gather },
    };

    public static Dictionary<int, string> TypeToString = new Dictionary<int, string>
    {
        { (int)JobTypes.Heal, JobTypes.Heal.ToString() },
        { (int)JobTypes.Drive, JobTypes.Drive.ToString() },
        { (int)JobTypes.Build, JobTypes.Build.ToString() },
        { (int)JobTypes.Craft, JobTypes.Craft.ToString() },
        { (int)JobTypes.Hunting, JobTypes.Hunting.ToString()},
        { (int)JobTypes.Haul, JobTypes.Haul.ToString() },
        { (int)JobTypes.Gather, JobTypes.Gather.ToString() },
    };
}