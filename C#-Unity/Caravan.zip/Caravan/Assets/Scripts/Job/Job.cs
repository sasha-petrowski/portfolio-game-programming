using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public abstract class Job : IJobProvider
{
    protected const float PROGRESSBARSIZE = 5;

    public override string ToString()
    {
        return $"{GetType().ToString().Replace("Job", null)} -> {(_taken ? _jobStep.Method.Name.Replace("JobStep_", null) : null)}";
    }

    protected Func<Creature, bool> _jobStep;
    protected bool _taken;

    public abstract int JobType { get; }
    public abstract Vector2 GetPosition();

    public Job TryTakeJob(Creature worker)
    {
        if (TakeJobCondition(worker))
        {
            //Debug.Log("took job");
            OnTakeJob(worker);
            return this;
        }
        //Debug.LogError("Can't take job");
        return null;
    }

    protected virtual bool TakeJobCondition(Creature worker)
    {
        return !_taken;
    }

    protected virtual void OnTakeJob(Creature worker)
    {
        worker.CurrentJob?.OnLeaveJob(worker);
        worker.CurrentJob = this;

        _taken = true;
    }
    private void RemoveWorker(Creature worker)
    {
        if (worker.CurrentJob == this)
        {
            worker.CurrentJob = null;
        }
        _taken = false;
    }
    public virtual void OnLeaveJob(Creature worker)
    {
        RemoveWorker(worker);
        _jobStep = null;
    }
    public virtual void OnFinishJob(Creature worker)
    {
        RemoveWorker(worker);
        _jobStep = null;
    }
    public virtual void DoJob(Creature worker)
    {
        if (_jobStep(worker))
        {
            OnFinishJob(worker);
        }
    }
    public virtual void OnDrawGizmos()
    {

    }

}
