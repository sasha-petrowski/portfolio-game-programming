using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using Noises;

[CustomEditor(typeof(Noise), true)]
public class NoiseEditor : Editor
{
    private const int PREVIEW_SIZE = 512;

    private Texture2D _preview;

    private int _previewSeed;
    private float _previewSize = 512;
    public override void OnInspectorGUI()
    {
        Noise noise = (Noise)target;

        DrawDefaultInspector();
        if (noise == null) return;

        DrawUILine(Color.gray);

        _previewSeed = EditorGUILayout.IntField("Seed", _previewSeed);
        _previewSize = Mathf.Max(EditorGUILayout.FloatField("Preview Size", _previewSize), 1);

        if (GUILayout.Button("Preview Simplex"))
        {
            noise.InitNoise(_previewSeed);
            GeneratePreviewNoise(noise);
        }

        if (_preview != null)
        {
            GUILayout.Label(_preview);
        }
    }
    private void DrawUILine(Color color, int thickness = 2, int padding = 10)
    {
        Rect r = EditorGUILayout.GetControlRect(GUILayout.Height(padding + thickness));
        r.height = thickness;
        r.y += padding / 2;
        r.x -= 2;
        r.width += 6;
        EditorGUI.DrawRect(r, color);
    }
    private void GeneratePreviewNoise(Noise noise)
    {
        Color[] colorMap = new Color[PREVIEW_SIZE * PREVIEW_SIZE];

        int index = 0;

        for (int i = 0; i < PREVIEW_SIZE; i++)
        {
            for (int j = 0; j < PREVIEW_SIZE; j++)
            {
                float x = i * _previewSize / PREVIEW_SIZE;
                float y = j * _previewSize / PREVIEW_SIZE;

                float value = noise.SimplexNoise(x, y);

                colorMap[index++] = Color.Lerp(Color.black, Color.white, value);
            }
        }

        _preview = new Texture2D(PREVIEW_SIZE, PREVIEW_SIZE);
        _preview.filterMode = FilterMode.Point;
        _preview.SetPixels(colorMap);
        _preview.Apply();
    }
}
