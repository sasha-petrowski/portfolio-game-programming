using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharacterSelection : MonoBehaviour
{
    public static RuntimeAnimatorController CharacterAnimatorController;

    public Button SelectedButton;

    private void Start()
    {
        SetButtonColor(SelectedButton, Color.red);
        CharacterAnimatorController = SelectedButton.GetComponent<CharacterSelectionInfo>().CharacterAnimatorController;
    }

    public void OnSelectCharacter(Button button)
    {
        SetButtonColor(SelectedButton, Color.white);
        SetButtonColor(button, Color.red);

        SelectedButton = button;

        CharacterAnimatorController = SelectedButton.GetComponent<CharacterSelectionInfo>().CharacterAnimatorController;

    }

    private void SetButtonColor(Button button, Color color)
    {
        ColorBlock cb = button.colors;
        cb.normalColor = color;
        cb.pressedColor = color;
        cb.selectedColor = color;
        button.colors = cb;
    }
}
