﻿using UnityEngine;

namespace Gameplay.Stats
{
    public class StatProjectileSize : StatBase
    {
        [Tooltip("Size multiplier")]
        [SerializeField] private float _multiplier = 1.1f;

        public override void Apply(PlayerController player)
        {
            player.ProjectileSizeMult *= _multiplier;
        }
    }
}
