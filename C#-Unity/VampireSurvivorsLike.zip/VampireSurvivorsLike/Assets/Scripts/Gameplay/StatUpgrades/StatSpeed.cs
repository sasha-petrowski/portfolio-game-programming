﻿using UnityEngine;

namespace Gameplay.Stats
{
    public class StatSpeed : StatBase
    {
        [Tooltip("Speed multiplier")]
        [SerializeField] private float _multiplier = 1.1f;

        public override void Apply(PlayerController player)
        {
            player.MoveMult *= _multiplier;
        }
    }
}
