﻿namespace Gameplay.Stats
{
    public abstract class StatBase
    {
        public abstract void Apply(PlayerController player);
    }
}
