﻿using UnityEngine;

namespace Gameplay.Stats
{
    public class StatCooldown : StatBase
    {
        [Tooltip("Cooldown multiplier")]
        [SerializeField] private float _multiplier = 1.1f;

        public override void Apply(PlayerController player)
        {
            player.CooldownMult *= _multiplier;
        }
    }
}
