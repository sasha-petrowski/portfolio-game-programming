﻿using UnityEngine;

namespace Gameplay.Stats
{
    public class StatDamage : StatBase
    {
        [Tooltip("Damage multiplier")]
        [SerializeField] private float _multiplier = 1.1f;

        public override void Apply(PlayerController player)
        {
            player.DamageMult *= _multiplier;
        }
    }
}
