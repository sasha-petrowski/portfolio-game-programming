﻿using UnityEngine;

namespace Gameplay.Stats
{
    public class AttractionStat : StatBase
    {
        [Tooltip("Attraction multiplier (loot pickup)")]
        [SerializeField] private float _multiplier = 1.1f;

        public override void Apply(PlayerController player)
        {
            player.Attraction *= _multiplier;
        }
    }
}
