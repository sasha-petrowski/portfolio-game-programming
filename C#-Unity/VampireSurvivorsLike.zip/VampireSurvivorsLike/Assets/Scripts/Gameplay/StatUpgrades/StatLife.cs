﻿using UnityEngine;

namespace Gameplay.Stats
{
    public class StatLife : StatBase
    {
        [Tooltip("Life max multiplier")]
        [SerializeField] private float _multiplier = 1.1f;

        public override void Apply(PlayerController player)
        {
            player.Life *= _multiplier;
            player.LifeMax *= _multiplier;
        }
    }
}
