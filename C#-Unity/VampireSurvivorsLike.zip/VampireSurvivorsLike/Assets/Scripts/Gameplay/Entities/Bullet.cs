using UnityEngine;
using UnityEngine.Serialization;

/// <summary>
/// Represents a bullet moving in a given direction
/// A bullet can be fired by the player or by an enemy
/// call Initialize to set the direction
/// </summary>
public class Bullet : MonoBehaviour
{
    [SerializeField] int _team;
    [SerializeField] bool _destroyOnHit;

    float _speed = 10;
    float _damage = 5;
    Vector3 _direction;

    public void Initialize(Vector3 direction , float damage , float speed, float size )
    {
        transform.localScale = transform.localScale * size * MainGameplay.Instance.Player.ProjectileSizeMult;
        _direction = direction;
        _speed = speed;
        _damage = damage;
    }

    void Update()
    {
        transform.position += _speed * Time.deltaTime * _direction;
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        var other = HitWithParent.GetComponent<Unit>(col);
        
        if (other != null)
        {
            if(other.Team != _team)
            {
                other.Hit(_damage);
                if (_destroyOnHit)
                {
                    GameObject.Destroy(gameObject);
                }
            }
        }
    }
}