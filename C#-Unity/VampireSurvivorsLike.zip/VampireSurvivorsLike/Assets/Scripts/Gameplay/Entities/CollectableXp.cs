using UnityEngine;
using System.Collections;

/// <summary>
/// Represents the xp points the player has to collect to level up
/// </summary>
public class CollectableXp : MonoBehaviour
{
    public int Value;

    
    void OnTriggerEnter2D(Collider2D col)
    {
        var other = HitWithParent.GetComponent<PlayerController>(col);
        
        if (other != null)
        {
            other.CollectXP(Value);

            GameObject.Destroy(gameObject, 0.2f);

            StartCoroutine(MoveCoroutine(other.transform));

            GetComponent<Collider2D>().enabled = false;
        }
    }
    
    IEnumerator MoveCoroutine(Transform target)
    {
        while (this != null)
        {
            float delta = Time.deltaTime * 2 * MainGameplay.Instance.Player.Attraction;
            transform.position = transform.position * (1 - delta) + target.position * delta;
            yield return null;
        }
    }
    
}
