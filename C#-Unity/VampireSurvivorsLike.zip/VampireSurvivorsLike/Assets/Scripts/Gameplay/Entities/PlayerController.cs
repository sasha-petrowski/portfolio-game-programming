using System;
using System.Collections.Generic;
using System.Data;
using Gameplay.Items;
using UnityEngine;

/// <summary>
/// Represents the player
/// manages the controller, the weapons, the in game lifebar and the level up
/// </summary>
public class PlayerController : Unit
{
    [SerializeField] PlayerData _playerData;
    [SerializeField] LevelUpData _levelUpData;

    [SerializeField] LifeBar _lifeBar;
    [SerializeField] GameObject _lootCollider;

    public Action OnDeath { get; set; }


    public Action<int, int, int> OnXP { get; set; }
    public Action<int> OnLevelUp { get; set; }
    public List<Func<float, float>> BeforeHit { get; set; } = new List<Func<float, float>>();
    public List<Func<bool>> BeforeDeath { get; set; } = new List<Func<bool>>();
    public List<UpgradeData> UpgradesAvailable { get; private set; }


    public float MoveMult = 1;
    public float DamageMult = 1;
    public float CooldownMult = 1;
    public float ProjectileSizeMult = 1;

    [SerializeField] private float _attraction = 1;
    public float Attraction { 

        get => _attraction; 

        set 
        {
            _lootCollider.transform.localScale = Vector3.one * value;
            _attraction = value;
        }
    }

    public bool FlipX { get => _sr.flipX; private set => _sr.flipX = value; }

    public Vector2 Direction => _lastDirection;
    public float DirectionX => _lastDirectionX;
    public PlayerData PlayerData => _playerData;

    public List<ItemBase> Items => _items;

    int _level = 1;
    int _xp = 0;


    bool _isDead;
    Rigidbody2D _rb;
    SpriteRenderer _sr;
    Animator _anim;
    Vector2 _inputs;
    Vector2 _lastDirection = Vector2.right;
    float _lastDirectionX = 1;
    List<ItemBase> _items = new List<ItemBase>();


    void Awake()
    {
        _rb = GetComponent<Rigidbody2D>();
        _sr = GetComponent<SpriteRenderer>();
        _anim = GetComponent<Animator>();

        UpgradesAvailable = new List<UpgradeData>();
        UpgradesAvailable.AddRange(_playerData.Upgrades);
    }

    void Start()
    {
        Attraction = _attraction;

        _lifeMax = _playerData.Life;
        _life = LifeMax;

        _anim.runtimeAnimatorController = CharacterSelection.CharacterAnimatorController;

        foreach (var upgrade in _playerData.StartUpgrades)
        {
            upgrade.Upgrade.Execute(this);
        }
    }

    void Update()
    {
        if (_isDead)
            return;

        ReadInputs();
        UpdateItems();

        if (Input.GetKeyDown(KeyCode.F5))
        {
            _level++;
            OnLevelUp?.Invoke(_level);
        }
        if (Input.GetKeyDown(KeyCode.F6))
        {
            Hit(5);
        }
    }

    void ReadInputs()
    {
        if (MainGameplay.Instance.State != MainGameplay.GameState.Gameplay)
        {
            _inputs = new Vector2();
            return;
        }

        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");

        _inputs = new Vector2(horizontal, vertical);

        if(horizontal != 0)
        {
            FlipX = horizontal > 0;
        }
    }


    void FixedUpdate()
    {
        Move();
    }

    private void UpdateItems()
    {
        if (MainGameplay.Instance.State != MainGameplay.GameState.Gameplay)
            return;

        foreach (var item in Items)
        {
            item.Update(this);
        }
    }

    private void Move()
    {
        if (_inputs.sqrMagnitude > 0)
        {
            _inputs.Normalize();
            _rb.velocity = _inputs * _playerData.MoveSpeed * MoveMult;
            
            _lastDirection = _inputs;

            if (Mathf.Abs(_lastDirection.x) > 0.1f)
                _lastDirectionX = _inputs.x;
        }
        else
        {
            _rb.velocity = new Vector2();
        }
    }
    public void Heal(float heal)
    {
        Debug.Log($"Heal : {heal}");
        _life = Mathf.Min(_lifeMax, _life + heal);
        _lifeBar.SetValue(_life, _lifeMax);
    }
    public void Revive(float percentLife)
    {
        _life = _lifeMax * Mathf.Clamp01(percentLife);
        _lifeBar.SetValue(_life, _lifeMax);
    }
    public override void Hit(float damage)
    {
        if (_isDead)
            return;

        // proc any tanking items
        foreach (Func<float, float> beforeHit in BeforeHit)
        {
            if (damage < 0)
                return;

            damage = beforeHit(damage);
        }

        _life -= damage;

        _lifeBar.SetValue(Life, LifeMax);

        if (Life <= 0)
        {
            Debug.Log("Has 0 health");
            // proc any life saving items
            if (BeforeDeath.Count > 0)
            {
                foreach (Func<bool> beforeDeath in BeforeDeath)
                {
                    Debug.Log($"invoking : {beforeDeath.Method.Name}");
                    if (beforeDeath())
                    {
                        Debug.Log("death cancelled");
                        return;
                    }
                }
            }
            Debug.Log("dead");
            _isDead = true;
            OnDeath?.Invoke();
        }
    }

    internal void UnlockUpgrade(UpgradeData data)
    {
        UpgradesAvailable.Remove(data);

        UpgradesAvailable.AddRange(data.NextUpgrades);
    }

    internal void AddItem(ItemBase item)
    {
        item.Initialize();
        _items.Add(item);
    }

    public void CollectXP(int value)
    {
        if (_levelUpData.IsLevelMax(_level))
            return;

        _xp += value;

        int nextLevel = _level + 1;
        int currentLevelMaxXP = _levelUpData.GetXpForLevel(nextLevel);
        if (_xp >= currentLevelMaxXP)
        {
            _level++;
            OnLevelUp?.Invoke(_level);
            currentLevelMaxXP = _levelUpData.GetXpForLevel(nextLevel);
        }

        int currentLevelMinXP = _levelUpData.GetXpForLevel(_level);

        if (_levelUpData.IsLevelMax(_level))
        {
            OnXP?.Invoke(currentLevelMaxXP + 1, currentLevelMinXP, currentLevelMaxXP + 1);
        }
        else
        {
            OnXP?.Invoke(_xp, currentLevelMinXP, currentLevelMaxXP);
        }
    }


    void OnDestroy()
    {
        OnDeath = null;
        OnXP = null;
        OnLevelUp = null;
    }
}