﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Gameplay.Items
{
    /// <summary>
    /// Represents a weapon that shot one bullet at a time to the closest enemy
    /// </summary>
    public class WeaponCalamityOrb : WeaponBase
    {
        [SerializeField] private GameObject _emplacementPrefab;
        [SerializeField] private GameObject _spherePrefab;

        [SerializeField] protected int _amount;
        [SerializeField] protected float _turnSpeed;
        [SerializeField] private float _distance;

        private List<Transform> _emplacements;
        private List<GameObject> _spheres;

        private int _currentEmplacement;

        private Transform _pivot;

        public WeaponCalamityOrb()
        {
        }

        public override void Initialize()
        {
            _pivot = GameObject.Instantiate(_prefab, MainGameplay.Instance.Player.transform).transform;

            CreateEmplacements();
            SetDistance(_distance);
        }

        public override void OnRemove()
        {
            base.OnRemove();
            GameObject.Destroy(_pivot.gameObject);
        }

        public void CreateEmplacements()
        {
            _emplacements = new List<Transform>();
            _spheres = new List<GameObject>();
            for (int i = 0; i < _amount; i++)
            {
                float angle = i / (float)_amount * 360f;

                _emplacements.Add(GameObject.Instantiate(_emplacementPrefab, _pivot).transform);
                _emplacements[i].Rotate(new Vector3(0, 0, angle));

                _spheres.Add(CreateSphere(_emplacements[i]));
            }
        }

        private GameObject CreateSphere(Transform emplacement)
        {
            GameObject sphere = GameObject.Instantiate(_spherePrefab, emplacement);
            sphere.GetComponent<Bullet>().Initialize(Vector3.zero, GetDamage(), 0, _projectileSize);

            return sphere;
        }

        public void SetDistance(float distance)
        {
            _distance = distance;

            for (int i = 0; i < _amount; i++)
            {
                float radian = i / (float)_amount * 360f * Mathf.Deg2Rad;

                float sin = Mathf.Sin(radian);
                float cos = Mathf.Cos(radian);

                Vector3 position = new Vector3(
                    (distance * cos) - (distance * sin),
                    (distance * sin) + (distance * cos),
                    0);

                _emplacements[i].localPosition = position;
            }
        }

        protected override void TriggerTimer()
        {
            for(int i = 0; i < _amount; i++)
            {
                _currentEmplacement = (_currentEmplacement + 1) % _amount ;
                if(_spheres[_currentEmplacement] == null)
                {
                    _spheres[_currentEmplacement] = CreateSphere(_emplacements[_currentEmplacement]);
                    return;
                }
            }
        }

        public override void Update(PlayerController player)
        {
            base.Update(player);

            _pivot.Rotate(new Vector3(0, 0, _turnSpeed * Time.deltaTime));
        }
    }
}