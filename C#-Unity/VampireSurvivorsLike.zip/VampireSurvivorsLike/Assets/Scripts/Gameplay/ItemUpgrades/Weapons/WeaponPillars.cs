﻿using UnityEngine;

namespace Gameplay.Items
{
    /// <summary>
    /// Represents a weapon that shot one bullet at a time to the closest enemy
    /// </summary>
    public class WeaponPillars : WeaponWithProjectile
    {
        public WeaponPillars()
        {
        }


        protected override Vector3? GetFrom(int i)
        {
            return MainGameplay.Instance.Player.transform.position;
        }

        protected override Vector3? GetTarget(int i)
        {
            float radian = (i / (float)(_amount - 1) * 90f) * Mathf.Deg2Rad;
            //Debug.Log(radian * Mathf.Rad2Deg);
            float sin = Mathf.Sin(radian);
            float cos = Mathf.Cos(radian);

            return new Vector3(cos - sin, sin + cos, 0);
        }

        protected override void ShootAt(Vector3? from, Vector3? target, int i)
        {
            Vector3 direction = (Vector3)target;

            ConstructProjectile((Vector3)(from - target), -direction);

            if (_twoSided)
                ConstructProjectile((Vector3)(from + target), direction);
        }
        protected override GameObject ConstructProjectile(Vector3 from, Vector3 target)
        {
            GameObject pillar = GameObject.Instantiate(_prefab, from, Quaternion.identity);
            pillar.GetComponent<Bullet>().Initialize(target, GetDamage(), _speed, _projectileSize);

            return pillar;
        }
    }
}