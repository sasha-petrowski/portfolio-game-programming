﻿using UnityEngine;

namespace Gameplay.Items
{
    /// <summary>
    /// Represents a weapon that has projectiles
    /// </summary>
    public abstract class WeaponWithProjectile : WeaponBase
    {
        [SerializeField] protected float _speed = 5;
        [SerializeField] protected bool _twoSided;
        [SerializeField] protected int _amount = 1;

        protected override void TriggerTimer()
        {
            for(int i = 0; i < _amount; i++)
            {
                ShootAt(GetFrom(i), GetTarget(i), i);
            }
        }

        protected abstract Vector3? GetFrom(int i);
        protected abstract Vector3? GetTarget(int i);

        protected abstract void ShootAt(Vector3? from, Vector3? target, int i);

        protected abstract GameObject ConstructProjectile(Vector3 from, Vector3 target);
    }
}