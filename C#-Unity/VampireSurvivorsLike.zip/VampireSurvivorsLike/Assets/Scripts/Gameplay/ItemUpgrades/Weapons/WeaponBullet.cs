﻿using UnityEngine;

namespace Gameplay.Items
{
    /// <summary>
    /// Represents a weapon that shot one bullet at a time to the closest enemy
    /// </summary>
    public class WeaponBullet : WeaponWithProjectile
    {
        public WeaponBullet()
        {
        }
        
        protected override Vector3? GetFrom(int i)
        {
            return MainGameplay.Instance.Player.transform.position;
        }

        protected override Vector3? GetTarget(int i)
        {
            PlayerController player = MainGameplay.Instance.Player;
            EnemyController enemy;
            if (i == 0)
                enemy = MainGameplay.Instance.GetClosestEnemy(player.transform.position);
            else
                enemy = MainGameplay.Instance.GetRandomEnemyOnScreen();

            if (enemy == null)
                return null;

            Vector3 playerPosition = player.transform.position;
            return enemy.transform.position - playerPosition;
        }

        protected override void ShootAt(Vector3? from, Vector3? target, int i)
        {
            if (target != null)
            {
                Vector3 direction = ((Vector3)target);
                float magnitude = direction.magnitude;
                if (magnitude > 0)
                {
                    direction /= magnitude;

                    ConstructProjectile((Vector3)from, direction);

                    if (_twoSided)
                        ConstructProjectile((Vector3)from, -direction);
                }
            }
        }

        protected override GameObject ConstructProjectile(Vector3 from, Vector3 target)
        {
            GameObject bullet = GameObject.Instantiate(_prefab, from, Quaternion.identity);
            bullet.GetComponent<Bullet>().Initialize(target, GetDamage(), _speed, _projectileSize);

            return bullet;
        }
    }
}