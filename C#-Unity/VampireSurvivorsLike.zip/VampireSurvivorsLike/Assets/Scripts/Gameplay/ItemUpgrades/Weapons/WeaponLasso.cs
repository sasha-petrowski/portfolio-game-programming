﻿using UnityEngine;


namespace Gameplay.Items
{
    /// <summary>
    /// Represents a lasso with a large AOE
    /// </summary>
    public class WeaponLasso : WeaponWithProjectile
    {
        public WeaponLasso()
        {
        }

        protected override Vector3? GetFrom(int i)
        {
            return null;
        }

        protected override Vector3? GetTarget(int i)
        {
            return null;
        }

        protected override void ShootAt(Vector3? from, Vector3? target, int i)
        {
            PlayerController player = MainGameplay.Instance.Player;
            ConstructProjectile((Vector2)player.transform.position + Vector2.right * player.DirectionX * (2 + i * 0.5f), Vector3.zero).GetComponent<SpriteRenderer>().flipX = MainGameplay.Instance.Player.FlipX;

            if (_twoSided)
                ConstructProjectile((Vector2)player.transform.position + Vector2.left * player.DirectionX * (2 + i * 0.5f), Vector3.zero).GetComponent<SpriteRenderer>().flipX = !MainGameplay.Instance.Player.FlipX;
        }

        protected override GameObject ConstructProjectile(Vector3 from, Vector3 target)
        {
            GameObject go = GameObject.Instantiate(_prefab, from, Quaternion.identity, MainGameplay.Instance.Player.transform);

            go.GetComponent<Bullet>().Initialize(new Vector3(), GetDamage(), 0, _projectileSize);

            return go;
        }
    }
}