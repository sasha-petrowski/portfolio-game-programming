﻿using UnityEngine;

namespace Gameplay.Items
{
    /// <summary>
    /// Represents a weapon that shot one hit on a random enemy
    /// </summary>
    public class WeaponThunder : WeaponWithProjectile
    {
        public WeaponThunder()
        {
        }


        protected override Vector3? GetFrom(int i)
        {
            EnemyController enemy = MainGameplay.Instance.GetRandomEnemyOnScreen();
            if (enemy == null)
                return null;

            return enemy.transform.position;
        }

        protected override Vector3? GetTarget(int i)
        {
            return null;
        }

        protected override void ShootAt(Vector3? from, Vector3? target, int i)
        {
            if (from != null)
                ConstructProjectile((Vector3)from, Vector3.zero);
        }
        protected override GameObject ConstructProjectile(Vector3 from, Vector3 target)
        {
            GameObject go = GameObject.Instantiate(_prefab, from, Quaternion.identity);

            go.GetComponent<Bullet>().Initialize(new Vector3(), GetDamage(), 0, _projectileSize);

            return go;
        }
    }
}