﻿using UnityEngine;

namespace Gameplay.Items
{
    
    /// <summary>
    /// Represents a weapon
    /// </summary>
    public abstract class WeaponBase : ItemWithTimer
    {
        [SerializeField] private float _damage = 10;
        [SerializeField] protected GameObject _prefab;
        [SerializeField] protected float _projectileSize = 1;

        public float GetDamage()
        {
            return _damage * MainGameplay.Instance.Player.DamageMult;
        }
    }
}