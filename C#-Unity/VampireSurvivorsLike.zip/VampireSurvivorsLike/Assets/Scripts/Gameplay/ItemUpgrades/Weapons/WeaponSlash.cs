﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Gameplay.Items
{
    /// <summary>
    /// Represents a weapon that shot one bullet at a time to the closest enemy
    /// </summary>
    public class WeaponSlash : WeaponBase
    {
        public WeaponSlash()
        {
        }

        protected override void TriggerTimer()
        {
            GameObject slash = GameObject.Instantiate(_prefab, MainGameplay.Instance.Player.transform.position, Quaternion.identity);
            slash.GetComponent<Bullet>().Initialize(Vector3.zero, GetDamage(), 0, _projectileSize);

            if(Random.Range(0, 2) == 1)
            {
                slash.GetComponent<SpriteRenderer>().flipX = true;
            }
        }
    }
}