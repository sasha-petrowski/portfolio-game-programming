using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Gameplay.Items
{
    /// <summary>
    /// Represent all items
    /// </summary>
    public abstract class ItemBase
    {
        public virtual void Initialize()
        {
        }
        public virtual void OnRemove()
        {
        }
        public abstract void Update(PlayerController player);
    }
}
