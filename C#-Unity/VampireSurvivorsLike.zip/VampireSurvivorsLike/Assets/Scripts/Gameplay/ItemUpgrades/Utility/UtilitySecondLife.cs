﻿using UnityEngine;

namespace Gameplay.Items
{

    /// <summary>
    /// Revives the player the first time he dies
    /// </summary>
    public class UtilitySecondLife : ItemBase
    {
        private bool _used = false;

        public UtilitySecondLife()
        {
        }

        public override void Initialize()
        {
            MainGameplay.Instance.Player.BeforeDeath.Add(OnDeath);
        }

        public override void OnRemove()
        {
            MainGameplay.Instance.Player.BeforeDeath.Remove(OnDeath);
        }

        private bool OnDeath()
        {
            Debug.Log("called");
            if (_used == false)
            {
                Debug.Log("not used yet");
                MainGameplay.Instance.Player.Revive(1);

                MainGameplay.Instance.KillAllEnemies();

                _used = true;
                return true;
            }
            else
            {
                Debug.Log("already used");
                return false;
            }
        }

        public override void Update(PlayerController player)
        {
        }
    }
}