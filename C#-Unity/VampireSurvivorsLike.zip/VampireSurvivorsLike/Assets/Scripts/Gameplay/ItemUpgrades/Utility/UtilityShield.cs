﻿using UnityEngine;

namespace Gameplay.Items
{
    /// <summary>
    /// Protects the layer every x time for y percent of it's life
    /// </summary>
    public class UtilityShield : ItemWithTimer
    {

        [SerializeField] GameObject _prefab;
        [SerializeField] float _life = 0.3f;

        private float _currentLife;
        private SpriteRenderer _shieldRenderer;

        public UtilityShield()
        {
        }

        public override void Initialize()
        {
            MainGameplay.Instance.Player.BeforeHit.Add(OnTakeDamage);

            _shieldRenderer = GameObject.Instantiate(_prefab, MainGameplay.Instance.Player.transform).GetComponent<SpriteRenderer>();

            UpdateCurrentLife();
        }

        public override void OnRemove()
        {
            MainGameplay.Instance.Player.BeforeHit.Remove(OnTakeDamage);

            GameObject.Destroy(_shieldRenderer.gameObject);
        }


        protected override void TriggerTimer()
        {
            UpdateCurrentLife();
            Debug.Log("trigger");
        }

        private void UpdateCurrentLife()
        {
            _currentLife = MainGameplay.Instance.Player.LifeMax * _life;
            UpdateShieldAlpha();
        }

        private float OnTakeDamage(float damage)
        {
            float remains = damage - _currentLife;
            _currentLife = Mathf.Clamp(_currentLife - damage, 0, float.MaxValue);

            UpdateShieldAlpha();

            if (_currentLife < 0)
                OnEmptyShield();

            //Debug.Log($"Shield : {_currentLife}.");
            return Mathf.Clamp(remains, 0, float.MaxValue);
        }

        private void UpdateShieldAlpha()
        {
            Color color = _shieldRenderer.color;
            color.a = _currentLife / MainGameplay.Instance.Player.LifeMax;

            _shieldRenderer.color = color;

        }

        private void OnEmptyShield()
        {
            Debug.Log("Empty Shield.");
        }
    }
}