﻿using UnityEngine;

namespace Gameplay.Items
{
    /// <summary>
    /// Protects the layer every x time for y percent of it's life
    /// </summary>
    public class UtilityTimedHeal : ItemWithTimer
    {
        [SerializeField] float _heal = 0.1f;

        public UtilityTimedHeal()
        {
        }

        protected override void TriggerTimer()
        {
            MainGameplay.Instance.Player.Heal(MainGameplay.Instance.Player.LifeMax * _heal);
        }
    }
}