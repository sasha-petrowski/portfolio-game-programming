﻿using UnityEngine;

namespace Gameplay.Items
{

    /// <summary>
    /// Represents a utility with a timer
    /// </summary>
    public abstract class ItemWithTimer : ItemBase
    {
        [SerializeField] private float _coolDown = 1;

        private float _timerCoolDown;

        public ItemWithTimer()
        {
        }
        
        public override void Update( PlayerController player )
        {
            _timerCoolDown += Time.deltaTime * player.CooldownMult;

            if (_timerCoolDown < _coolDown)
                return;

            _timerCoolDown -= _coolDown;

            TriggerTimer();
        }

        protected abstract void TriggerTimer();
    }
}