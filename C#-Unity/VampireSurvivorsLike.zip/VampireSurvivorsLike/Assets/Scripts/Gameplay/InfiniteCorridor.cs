using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InfiniteCorridor : MonoBehaviour
{
    public Transform A;
    public Transform B;
    public Transform C;

    [SerializeField] float _height = 24;
    private float _currentHeight = 0;

    // Update is called once per frame
    void Update()
    {
        Vector3 playerPos = MainGameplay.Instance.Player.transform.position;
        if(playerPos.y - _currentHeight > _height * 0.5f)
        {
            GoUp();
        }
        else if (playerPos.y - _currentHeight < -_height * 0.5f)
        {
            GoDown();
        }
    }

    private void GoUp()
    {
        _currentHeight += _height;

        C.transform.position += new Vector3(0, _height * 3, 0);
        Transform tmp = A;
        A = C;
        C = B;
        B = tmp;
    }
    private void GoDown()
    {
        _currentHeight -= _height;

        A.transform.position -= new Vector3(0, _height * 3, 0);
        Transform tmp = C;
        C = A;
        A = B;
        B = tmp;
    }
}
