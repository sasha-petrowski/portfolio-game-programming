using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnHitEffect : MonoBehaviour
{

    #region Singleton

    public static OnHitEffect Instance;
    

    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("an instance of MainGameplay already exists");
        }

        Instance = this;
    }
    #endregion

    [SerializeField] private List<Sprite> _hitSprites;
    [SerializeField] private SpriteRenderer _spritePrefab;

    [SerializeField] private float _minDamage;
    [SerializeField] private float _maxDamage;

    [SerializeField] private float _minScale;
    [SerializeField] private float _maxScale;

    [SerializeField] private float _randomPosOffset;

    [SerializeField] private float _timeOffset;



    public void OnHit(float damage, Vector3 position)
    {
        SpriteRenderer render = GameObject.Instantiate(_spritePrefab, position + RandomOffset(), Quaternion.identity);
        float scale = ScaleFromDamage(damage);

        render.transform.localScale = Vector3.one * scale;
        render.sprite = RandomSprite();

        Destroy(render.gameObject, _timeOffset + scale);
    }

    private Sprite RandomSprite()
    {
        return _hitSprites[Random.Range(0, _hitSprites.Count)];
    }

    private float ScaleFromDamage(float damage)
    {
        return ((damage - _minDamage) / (_maxDamage - _minDamage) * (_maxScale - _minScale) + _minScale);
    }

    private Vector3 RandomOffset()
    {
        return new Vector3(Random.Range(-_randomPosOffset, _randomPosOffset), Random.Range(-_randomPosOffset, _randomPosOffset), -1);
    }
}
