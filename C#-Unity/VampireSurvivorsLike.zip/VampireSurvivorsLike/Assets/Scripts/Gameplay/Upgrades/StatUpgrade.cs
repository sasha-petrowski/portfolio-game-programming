﻿using Common.Tools;
using Gameplay.Stats;
using System;
using UnityEngine;


[Serializable]
public class StatUpgrade : BaseUpgrade
{
    [SerializeReference] [Instantiable(type: typeof(StatBase))] StatBase _stat;

    public StatBase Stat => _stat;

    public override void Execute(PlayerController player)
    {
        Stat.Apply(player);
    }
}

