﻿using Common.Tools;
using System;
using System.Linq;
using UnityEngine;
using Gameplay.Items;

[Serializable]
public class ItemUpgrade : BaseUpgrade
{
    [SerializeReference] [Instantiable(type: typeof(ItemBase))] ItemBase _item;

    public ItemBase Item => _item;

    public override void Execute( PlayerController player )
    {
        for (int i = player.Items.Count - 1; i >= 0; i--)
        {
            if (player.Items[i].GetType().IsAssignableFrom(_item.GetType()))
            {
                player.Items[i].OnRemove();
                player.Items.RemoveAt(i);
            }
        }

        player.AddItem(_item);
    }
}

