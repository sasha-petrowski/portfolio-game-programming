using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using WorldGeneration;

[RequireComponent(typeof(SpriteRenderer))]
public class CloseView : MonoBehaviour
{
    public Vector2Int Resolution = new Vector2Int(256, 256);
    public WorldGenerator WorldGenerator;

    private Vector3Int _lastPos;

    public Sprite GenerateSprite(World world)
    {
        Color[] colorMap = new Color[Resolution.x * Resolution.y];

        int index = 0;

        float x;
        float y;

        WorldPoint point = new WorldPoint();

        for (int i = 0; i < Resolution.y; i++)
        {
            for (int j = 0; j < Resolution.x; j++)
            {
                x = _lastPos.x + j;
                y = _lastPos.y + i;

                if (world.DebugActiveDistortion) Utility.TorusDistord(world, ref x, ref y, world.NoiseDistord, world.PositionDistord);

                x = (world.Width + x) % world.Width; // x on torus coordinate
                //y = y; // don't change Y, since we don't loop on top

                try
                {
                    point.Calibrate(world, x, y);
                    colorMap[index] = point.GetColor();
                }
                catch (Exception e)
                {
                    colorMap[index] = Color.red;
                    Debug.LogError(e);
                }


                index++;
            }
        }

        Texture2D texture = new Texture2D(Resolution.x, Resolution.y);
        texture.filterMode = FilterMode.Point;
        texture.SetPixels(colorMap);
        texture.Apply();

        return Sprite.Create(texture, new Rect(0.0f, 0.0f, Resolution.x, Resolution.y), new Vector2(0, 0), 1);
    }

    public void Generate()
    {
        if (WorldGenerator == null) return;
        if(WorldGenerator.World == null)
        {
            WorldGenerator.Generate();
        }

        // Terrain
        Sprite terrainSprite = GenerateSprite(WorldGenerator.World);

        GetComponent<SpriteRenderer>().sprite = terrainSprite;
    }



    private void OnDrawGizmos()
    {
        Vector3Int currentPos = new Vector3Int(Mathf.RoundToInt(transform.position.x), Mathf.RoundToInt(transform.position.y), 0);
        if (_lastPos != currentPos)
        {
            _lastPos = currentPos;
            Generate();
        }
    }
}
