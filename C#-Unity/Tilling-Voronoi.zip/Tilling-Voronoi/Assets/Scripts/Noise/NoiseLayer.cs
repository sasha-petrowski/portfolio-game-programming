[System.Serializable]
public class NoiseLayer
{
    public float Amplitude;
    public float Scale;
}