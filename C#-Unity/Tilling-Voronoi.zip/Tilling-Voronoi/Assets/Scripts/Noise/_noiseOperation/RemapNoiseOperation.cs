public class RemapNoiseOperation : NoiseOperation
{
    public float Min = -0.5f;
    public float Max = 0.5f;

    public override void Apply(ref float value)
    {
        value = (value * (Max - Min) + Min);
    }
}