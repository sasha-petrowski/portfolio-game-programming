﻿using System;
using Unity.VisualScripting;
using UnityEngine;

[Serializable]
public class NoiseOperationHolder
{
    [SerializeReference]
    [Instantiable(typeof(NoiseOperation))]
    public NoiseOperation Operation;

    public void Apply(ref float value)
    {
        Operation.Apply(ref value);
    }
}
public abstract class NoiseOperation
{
    public abstract void Apply(ref float value);
}