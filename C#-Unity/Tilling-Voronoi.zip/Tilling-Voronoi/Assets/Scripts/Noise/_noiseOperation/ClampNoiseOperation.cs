public class ClampNoiseOperation : NoiseOperation
{
    public float Min = 0;
    public float Max = 1;

    public override void Apply(ref float value)
    {
        value = value > Max ? Max : value < Min ? Min : value;
    }
}