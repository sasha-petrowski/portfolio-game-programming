public class RemapMinMaxNoiseOperation : NoiseOperation
{
    public float FromMin = 0;
    public float FromMax = 1;

    public float Min = 0;
    public float Max = 1;

    public override void Apply(ref float value)
    {
        value = ((value - FromMin) / (FromMax - FromMin) * (Max - Min) + Min);
    }
}