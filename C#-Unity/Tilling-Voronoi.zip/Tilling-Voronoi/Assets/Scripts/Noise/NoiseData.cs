using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Noises;

[CreateAssetMenu(fileName = "NoiseData", menuName = "Noise/NoiseData")]
public class Noise : ScriptableObject
{
    public static bool Initialized { get; private set; }
    private static OpenSimplexNoise s_simplexNoise;
    private static int s_seed;

    public static void InitNoise(int seed)
    {
        s_seed = seed;

        s_simplexNoise = new OpenSimplexNoise(seed);

        Initialized = true;
    }

    public List<NoiseLayer> Layers = new();
    public List<NoiseOperationHolder> Operations = new();

    public float SimplexNoise(float x, float y, float z)
    {
        float noise = 0;
        float layersAmplitude = 0;

        foreach (NoiseLayer layer in Layers)
        {
            noise += s_simplexNoise.Evaluate((x / layer.Scale), (y / layer.Scale), (z / layer.Scale)) * layer.Amplitude;
            layersAmplitude += layer.Amplitude;
        }

        noise = noise / layersAmplitude; // normalize noise for operations

        foreach (NoiseOperationHolder operation in Operations)
        {
            operation.Apply(ref noise);
        }

        return noise * layersAmplitude; // remap noise to normal
    }
}
