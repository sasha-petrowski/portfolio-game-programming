using System;
using System.Reflection;
using System.Security.Permissions;
using Unity.PlasticSCM.Editor.WebApi;
using Unity.VisualScripting;
using UnityEngine;
using WorldGeneration;

public class WorldPoint
{
    public const float HEIGHT_TEMPERATURE = 0.25f;

    World world;
    float x;
    float y;

    bool _outOfBounds;

    float weightA = 0;
    float weightB = 0;
    float weightR = 0;
    float sideHeight = 0;

    float height = 0;
    float humidity = 0;
    float waterSource = 0;
    float temperature = 0;


    float stream = 0;
    float lake = 0;
    float river = 0;

    RegionFeature region = null;
    RegionTriangle triangle = null;

    public Color GetColor()
    {
        if (_outOfBounds) return Color.white;

        /*
        if (region.Land.IsWater) return Color.clear;
        else return Color.Lerp(Color.black, Color.white, region.Humidity);
        */
        Color color;

        float height01 = Mathf.Clamp01(height * 0.5f + 0.5f);

        float ice = Mathf.Clamp01(Mathf.Clamp01((.1f - temperature) * 2 * 10) - river / 2);
        if (region.Land.IsWater)
        {
            color = Color.Lerp(world.WaterColors.Evaluate(height01), world.IceColors.Evaluate(height01), ice);
        }
        else
        {
            color = world.BiomeList.LerpLookup(Mathf.Clamp01(temperature), Mathf.Clamp01(humidity), height01);
        }


        if (stream + lake + river - ice > 0)
        {
            color = Color.Lerp(color, world.WaterColors.Evaluate(height01), Mathf.Clamp01(Mathf.Clamp01(lake + stream + river) - ice));
        }

        if (ice > 0) color = Color.Lerp(color, world.IceColors.Evaluate(height01), ice);

        return color;
    }

    public void Calibrate(World world, float x, float y)
    {
        this.world = world;
        this.x = x;
        this.y = y;

        if(y <= world.WorldBorderSize | y >= world.Height - world.WorldBorderSize)
        {
            _outOfBounds = true;
            return;
        }

        #region Reset stuff
        _outOfBounds = false;

        weightA = 0;
        weightB = 0;
        weightR = 0;
        sideHeight = 0;

        height = 0;
        humidity = 0;
        temperature = 0;

        waterSource = 0;

        stream = 0;
        lake = 0;
        river = 0;

        region = null;
        triangle = null;
        #endregion

        #region Get region & Triangle
        region = world.GetRegionAt(x, y);
        if (region == null) throw new Exception("Couldn't find Region");

        triangle = null;
        foreach (RegionTriangle regionTriangle in region.Triangles)
        {
            if (regionTriangle.IsInside(x, y, out weightA, out weightB, out weightR))
            {
                height = regionTriangle.HeightAt(weightA, weightB, weightR);
                sideHeight = regionTriangle.HeightAt(weightA, weightB);
                humidity = regionTriangle.IrrigationAt(weightA, weightB, weightR);

                triangle = regionTriangle;
                break;
            }
        }
        if (triangle == null)
        {
            Debug.Log(y);
            throw new Exception("Couldn't find Region triangle");
        }
            #endregion

        RiverSegmentFeature bestRiver = null;
        RegionFeature riverFrom = null;
        RegionFeature riverNext = null;
        float nearRiver = 0;
        float riverPosition = 0;
        foreach (RiverSegmentFeature riverSegment in region.RiverSegments)
        {
            if (riverSegment.PointOn(x, y, out float near, out float lerp))
            {
                if (near > nearRiver)
                {
                    bestRiver = riverSegment;
                    nearRiver = near;
                    riverPosition = riverSegment.OriginDistance + lerp / 4f + .75f;
                }
                if (riverSegment.From != region & riverSegment.Next != region)
                {
                    if (riverSegment.From != null) riverFrom = riverSegment.From;

                    if (riverSegment.Next != null) riverNext = riverSegment.Next;
                }
            }
        }
        float erosion = 0;
        if (bestRiver != null)
        {
            erosion = Mathf.Clamp01(nearRiver * 2);
            waterSource = Mathf.Max(waterSource, erosion);
            river = Mathf.Clamp01(nearRiver * 2 - 1);
            float riverHeight = height;

            if (riverFrom != null & riverPosition % 1 < 0.5f)
            {
                riverHeight = Mathf.Lerp(riverFrom.Height, region.Height, Mathf.Clamp01((riverPosition % 1f) + 0.5f));
            }
            if (riverNext != null & riverPosition % 1 > 0.5f)
            {
                riverHeight = Mathf.Lerp(region.Height, riverNext.Height, Mathf.Clamp01((riverPosition % 1f) - 0.5f));
            }

            height = Mathf.Lerp(height, riverHeight, erosion);
        }
        /*
        if (!region.Land.IsWater)
        {
            if (sideHeight - 0.1f > region.Height)
            {
                // Hexagonal rivers

                Vector2 size = new Vector2(1, 1.7320508f);
                Vector2 riverPos = new Vector2(Mathf.Abs(x / world.MountainRiverDistance), Mathf.Abs(y / world.MountainRiverDistance));

                Vector2 hexCenterA = new Vector2(Mathf.Floor(riverPos.x / size.x) + 0.5f, Mathf.Floor(riverPos.y / size.y) + 0.5f);
                Vector2 hexCenterB = new Vector2(Mathf.Floor((riverPos.x - 0.5f) / size.x) + 0.5f, Mathf.Floor((riverPos.y - 1) / size.y) + 0.5f);

                Vector2 offsetA = new Vector2(riverPos.x - hexCenterA.x * size.x, riverPos.y - hexCenterA.y * size.y);
                Vector2 offsetB = new Vector2(riverPos.x - (hexCenterB.x + .5f) * size.x, riverPos.y - (hexCenterB.y + .5f) * size.y);

                //Vector2 hexID;
                Vector2 hexPos;

                if (Vector2.Dot(offsetA, offsetA) < Vector2.Dot(offsetB, offsetB))
                {
                    //hexID = hexCenterA;
                    hexPos = offsetA;
                }
                else
                {
                    //hexID = hexCenterB;
                    hexPos = offsetB;
                }
                hexPos.x = Mathf.Abs(hexPos.x);
                hexPos.y = Mathf.Abs(hexPos.y);

                // Represents the lerp from the hex's center : 1 near the edges, 0 near the center
                float hexBorder = Mathf.Max(Vector2.Dot(hexPos, size * 0.5f), hexPos.x) * 2;

                // The slope depends on the edge height depending on the region's
                float slope = Mathf.Clamp01(1 - Mathf.Abs(((height - region.Height) / (sideHeight - 0.1f - region.Height)) - 0.5f) * 2);
                // Erosion is caused by big rivers and increase the likelyhood of mountain rivers
                slope = Mathf.Max(slope, erosion);

                // remap hexValue to the Width of rivers.
                stream = slope * Mathf.Clamp01((hexBorder - (world.MountainRiverDistance - (float)world.MountainRiverWidth) / world.MountainRiverDistance) * (world.MountainRiverDistance / (float)world.MountainRiverWidth));
            }

            if (region.LakeHeight > region.Height)
            {
                float depth = Mathf.Clamp01(1 - (height - region.Height) / (region.LakeHeight - region.Height));

                waterSource = Mathf.Max(Mathf.Clamp01(Mathf.Clamp01(depth * (1 - Mathf.Pow(1 - weightR, 2)) - 0.25f) * 8), waterSource);

                if (height < region.LakeHeight)
                {
                    lake = Mathf.Clamp01(Mathf.Clamp01(depth * (1 - Mathf.Pow(1 - weightR, 2)) - 0.5f) * 16);
                }
            }

        }
        */
        temperature = world.GetTemperature(y);
        if(height > 0) temperature -= height * HEIGHT_TEMPERATURE;
    }
}
