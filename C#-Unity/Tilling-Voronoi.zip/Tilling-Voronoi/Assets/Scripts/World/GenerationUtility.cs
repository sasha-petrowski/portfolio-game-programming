using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace WorldGeneration
{
    public static class GenerationUtility
    {
        public static void SpreadDepth(RegionFeature root)
        {
            int nextDepth = root.Depth + (root.Land.IsWater ? -1 : 1);

            List<RegionFeature> todo = new List<RegionFeature>();

            foreach (RegionFeature neighbor in root.Neighbors)
            {
                if (!neighbor.IsBorder
                    &&
                    neighbor.Depth == 0 | (root.Land.IsWater ? neighbor.Depth < nextDepth : neighbor.Depth > nextDepth))
                {
                    neighbor.Depth = nextDepth;
                    todo.Add(neighbor);
                }
            }

            foreach (RegionFeature neighbor in todo)
            {
                SpreadDepth(neighbor);
            }
        }
        public static void SpreadContinent(RegionFeature root, System.Random random, List<ContinentFeature> continents)
        {
            HashSet<RegionFeature> visited = new HashSet<RegionFeature>();
            LinkedList<RegionFeature> toVisit = new LinkedList<RegionFeature>();
            toVisit.AddFirst(root);

            while (toVisit.First != null)
            {
                RegionFeature region = toVisit.First.Value;
                toVisit.RemoveFirst();

                foreach (RegionFeature neighbor in region.Neighbors)
                {
                    if (neighbor.Land.IsWater == region.Land.IsWater)
                    {
                        if (neighbor.Land != region.Land)
                        {
                            if (neighbor.Land.Continent == null & region.Land.Continent == null)
                            {
                                ContinentFeature continent = new ContinentFeature(region.Land.IsWater);
                                continents.Add(continent);

                                continent.Lands.Add(region.Land);
                                continent.Lands.Add(neighbor.Land);

                                region.Land.Continent = continent;
                                neighbor.Land.Continent = continent;
                            }
                            else if (neighbor.Land.Continent == null)
                            {
                                region.Land.Continent.Lands.Add(neighbor.Land);

                                neighbor.Land.Continent = region.Land.Continent;
                            }
                            else if (region.Land.Continent == null)
                            {
                                neighbor.Land.Continent.Lands.Add(region.Land);

                                region.Land.Continent = neighbor.Land.Continent;
                            }
                        }

                        if (visited.Contains(neighbor)) continue;

                        visited.Add(neighbor);
                        toVisit.AddLast(neighbor);
                    }
                }
            }
            
            if(root.Land.Continent == null)
            {
                ContinentFeature continent = new ContinentFeature(root.Land.IsWater);

                continent.Lands.Add(root.Land);

                root.Land.Continent = continent;
            }
        }
    }
}