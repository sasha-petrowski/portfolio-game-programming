using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEditor.PlayerSettings;

namespace WorldGeneration
{
    public class RiverFeature : Feature
    {
        public const int MIN_BORDER = 4;
        public const int MAX_WIDTH = 2;
        public const float RIVER_IRRIGATION_LOG = 6;
        public const float RIVER_IRRIGATION_MULT = 0.5f;
        public const float HEIGHT_THRESHOLD = 0.05f;

        public Color Debug_Color;

        public List<RegionFeature> Origins = new();
        public RegionFeature End;

        /// <summary>
        /// Key : From, Value : To
        /// </summary>
        private Dictionary<RegionFeature, RegionFeature> _path = new();

        private RiverFeature(RegionFeature origin, RegionFeature end, Dictionary<RegionFeature, List<RegionFeature>> visitedFrom)
        {
            Debug_Color = Utility.RandColor();

            End = end;

            AddSegment(origin, end, visitedFrom);
        }
        private void OrderOrigin()
        {
            if (Origins.Count < 2) return;

            LinkedList<RegionFeature> orderedOrigins = new LinkedList<RegionFeature>();
            List<RegionFeature> from = new List<RegionFeature>();

            LinkedList<RegionFeature> toVisit = new LinkedList<RegionFeature>();
            toVisit.AddFirst(End);

            RegionFeature current;
            while(toVisit.First != null)
            {
                current = toVisit.First.Value;
                toVisit.RemoveFirst();

                foreach(var pair in _path)
                {
                    if(pair.Value == current)
                    {
                        if(Origins.Contains(pair.Key))
                        {
                            orderedOrigins.AddFirst(pair.Key);
                        }
                        else
                        {
                            toVisit.AddLast(pair.Key);
                        }
                    }
                }
            }

            Origins = orderedOrigins.ToList();
        }
        public void Initialise(World world)
        {
            HashSet<RegionFeature> visited = new();

            OrderOrigin();

            foreach (RegionFeature origin in Origins)
            {
                RegionFeature from = origin;
                RegionFeature current = _path[from];
                RegionFeature next;

                float originDistance = 0;
                origin.Humidity += Mathf.Log(1, RIVER_IRRIGATION_LOG) * RIVER_IRRIGATION_MULT;

                while (_path.TryGetValue(current, out next))
                {
                    RegionTriangle fromBorder = current.GetTriangle(from);
                    RegionTriangle nextBorder = current.GetTriangle(next);

                    Vector3 fromA = world.WrapPoint(fromBorder.A.Position, current.Position);
                    Vector3 fromB = world.WrapPoint(fromBorder.B.Position, current.Position);

                    Vector3 nextA = world.WrapPoint(nextBorder.A.Position, current.Position);
                    Vector3 nextB = world.WrapPoint(nextBorder.B.Position, current.Position);

                    Vector3 fromPos = (fromA + fromB) / 2;
                    Vector3 nextPos = (nextA + nextB) / 2;

                    Vector3 fromDirection = new Vector3(-(fromA.y - fromB.y), fromA.x - fromB.x);
                    Vector3 fromDirectionBis = new Vector3(-fromDirection.x, -fromDirection.y);
                    if (Vector2.SqrMagnitude(fromDirection - current.Position + fromPos) > Vector2.SqrMagnitude(fromDirectionBis - current.Position + fromPos)) fromDirection = fromDirectionBis;
                    fromDirection /= Mathf.Sqrt(fromBorder.LengthAB) / world.RiverBezierStrength;
                    fromDirection += fromPos;


                    Vector3 nextDirection = new Vector3(-(nextA.y - nextB.y), nextA.x - nextB.x);
                    Vector3 nextDirectionBis = new Vector3(-nextDirection.x, -nextDirection.y);
                    if (Vector2.SqrMagnitude(nextDirection - current.Position + nextPos) > Vector2.SqrMagnitude(nextDirectionBis - current.Position + nextPos)) nextDirection = nextDirectionBis;
                    nextDirection /= Mathf.Sqrt(nextBorder.LengthAB) / world.RiverBezierStrength;
                    nextDirection += nextPos;


                    Vector3 fromBis = BezierUtility.CubicPoint(.25f, fromPos, fromDirection, nextDirection, nextPos);
                    Vector3 middleBis = BezierUtility.CubicPoint(.5f, fromPos, fromDirection, nextDirection, nextPos);
                    Vector3 nextBis = BezierUtility.CubicPoint(.75f, fromPos, fromDirection, nextDirection, nextPos);


                    RiverSegmentFeature fromLine = new RiverSegmentFeature(fromPos, fromBis, from, next, world, originDistance + 0.25f);
                    RiverSegmentFeature aLine = new RiverSegmentFeature(fromBis, middleBis, from, next, world, originDistance + 0.5f);
                    RiverSegmentFeature bLine = new RiverSegmentFeature(middleBis, nextBis, from, next, world, originDistance + 0.75f);
                    RiverSegmentFeature nextLine = new RiverSegmentFeature(nextBis, nextPos, from, next, world, originDistance + 1f);

                    originDistance += 1;

                    current.RiverSegments.Add(fromLine);
                    current.RiverSegments.Add(aLine);
                    current.RiverSegments.Add(bLine);
                    current.RiverSegments.Add(nextLine);


                    if (from == origin)
                    {
                        RiverSegmentFeature originLine = new RiverSegmentFeature(fromPos + (fromPos - fromDirection), fromPos, null, current, world, 0);
                        current.RiverSegments.Add(originLine);
                        origin.RiverSegments.Add(originLine);
                        origin.RiverSegments.Add(fromLine);
                    }

                    if(!visited.Add(current)) break;

                    current.Humidity += Mathf.Log(originDistance + 1, RIVER_IRRIGATION_LOG) * RIVER_IRRIGATION_MULT;

                    if (next == End)
                    {
                        RiverSegmentFeature endLine = new RiverSegmentFeature(nextPos, nextPos + (nextPos - nextDirection), current, null, world, originDistance + 0.25f);
                        current.RiverSegments.Add(endLine);
                        End.RiverSegments.Add(endLine);
                        End.RiverSegments.Add(nextLine);
                    }

                    from = current;
                    current = next;
                }

                End.Humidity = Mathf.Log(originDistance + 1, RIVER_IRRIGATION_LOG) * RIVER_IRRIGATION_MULT;
            }
        }
        public override void DrawGizmos(World world)
        {
            Color before = Gizmos.color;
            Gizmos.color = Color.cyan;

            foreach (RegionFeature origin in Origins)
            {
                RegionFeature current = _path[origin];
                RegionFeature next;

                while (_path.TryGetValue(current, out next))
                {
                    foreach(RiverSegmentFeature segment in  current.RiverSegments)
                    { 
                        segment.DrawGizmos(world);
                    }

                    current = next;
                }
            }

            Gizmos.color = before;
        }

        #region River Factory

        /// <returns>
        /// -1 : False |
        /// 0 : Connected an existing river |
        /// 1 : Created a new River
        /// </returns>
        public static int TryCreateRiver(RegionFeature origin, out RiverFeature river, World world)
        {
            river = null;
            if (origin.Land.IsWater | origin.Rivers != null) return -1;

            switch(FindRiverPath(origin, out Dictionary<RegionFeature, List<RegionFeature>> visitedFrom, out RegionFeature end, world))
            {
                case 1:
                    river = new RiverFeature(origin, end, visitedFrom);
                    return 1;

                case 0:
                    river = end.Rivers[0];
                    river.AddSegment(origin, end, visitedFrom);
                    return 0;
            }

            return -1;
        }

        private void AddSegment(RegionFeature origin, RegionFeature end, Dictionary<RegionFeature, List<RegionFeature>> visitedFrom)
        {
            Origins.Add(origin);

            RegionFeature current = end;
            RegionFeature previous;

            while (current != origin)
            {
                if (visitedFrom.TryGetValue(current, out List<RegionFeature> from))
                {
                    previous = from[0];

                    _path.TryAdd(previous, current);

                    if (current.Rivers == null)
                    {
                        current.Rivers = new List<RiverFeature>() { this };
                    }
                    else if(!current.Rivers.Contains(this))
                    {
                        current.Rivers.Add(this);
                    }

                    Origins.Remove(current);

                    current = previous;
                }
            }

            if (origin.Rivers == null)
            {
                origin.Rivers = new List<RiverFeature>() { this };
            }
            else if (!origin.Rivers.Contains(this))
            {
                origin.Rivers.Add(this);
            }
        }
        private static int FindRiverPath(RegionFeature origin, out Dictionary<RegionFeature, List<RegionFeature>> visitedFrom, out RegionFeature end, World world)
        {
            #region Initialise vars
            visitedFrom = new();
            LinkedList<RegionFeature> toVisit = new();

            toVisit.AddFirst(origin);
            RegionFeature current;
            #endregion

            while (toVisit.First != null)
            {
                #region Remove First & set current
                current = toVisit.First.Value;
                toVisit.RemoveFirst();
                #endregion

                #region Average Border
                float averageBorder = 0;
                foreach (RegionTriangle triangle in current.Triangles)
                {
                    averageBorder += triangle.A.Height + triangle.B.Height;
                }
                averageBorder = (averageBorder / 2) / current.Triangles.Count;
                #endregion

                foreach (RegionTriangle triangle in current.Triangles) // for each sides
                {
                    if(triangle.Other == null) continue;

                    // don't cross if the border is too small or too high
                    if (triangle.LengthAB < MIN_BORDER * world.RiverWidth | (triangle.A.Height + triangle.B.Height) / 2 > averageBorder + HEIGHT_THRESHOLD) continue; 

                    #region End condition : Reach the sea
                    if (triangle.Other.Land.IsWater)
                    {
                        visitedFrom.Add(triangle.Other, new List<RegionFeature>() { current });
                        end = triangle.Other;
                        return 1;
                    }
                    #endregion

                    // don't cross if other region is higher or if its the origin
                    if (triangle.Other.Height > current.Height | triangle.Other == origin) continue;

                    #region End condition : Already a river
                    if (triangle.Other.Rivers != null)
                    {
                        visitedFrom.Add(triangle.Other, new List<RegionFeature>() { current });
                        end = triangle.Other;
                        return 0;
                    }
                    #endregion

                    #region Don't cross if we come from this direction
                    if (!visitedFrom.TryGetValue(triangle.Other, out List<RegionFeature> from))
                    {
                        from = new List<RegionFeature>();
                        visitedFrom.Add(triangle.Other, from);
                    }

                    if (from.Contains(current)) continue;
                    #endregion

                    // Add to visit and to visited
                    from.Add(current);
                    toVisit.AddLast(triangle.Other);
                }
            }

            end = null;
            return -1;
        }

        #endregion
    }
}