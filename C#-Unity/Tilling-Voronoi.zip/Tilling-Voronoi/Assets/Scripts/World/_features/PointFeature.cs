using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace WorldGeneration
{
    public abstract class PointFeature : Feature
    {
        public float x;
        public float y;

        public float Height = 0;
        public float Humidity = 0;

        public Vector3 Position => new Vector3(x, y);

        public PointFeature(float x, float y)
        {
            this.x = x;
            this.y = y;
        }
        public override void DrawGizmos(World world)
        {
            Gizmos.DrawSphere(Position, 1f * world.Width / world.TilesX / world.TilesY);
        }
    }
}