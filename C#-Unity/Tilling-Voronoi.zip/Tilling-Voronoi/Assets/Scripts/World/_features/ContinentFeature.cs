using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace WorldGeneration
{
    public class ContinentFeature : Feature
    {
        public Color Debug_Color;

        public List<LandFeature> Lands = new();

        public bool Ocean;

        public ContinentFeature(bool ocean)
        {
            Debug_Color = Utility.RandColor();

            Ocean = ocean;
        }

        public override void DrawGizmos(World world)
        {
            foreach (LandFeature land in Lands)
            {
                land.DrawGizmos(world);
            }
        }
    }
}