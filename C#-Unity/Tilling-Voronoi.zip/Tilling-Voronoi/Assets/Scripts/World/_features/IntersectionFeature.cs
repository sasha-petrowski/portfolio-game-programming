using System.Collections.Generic;

namespace WorldGeneration
{
    public class IntersectionFeature : PointFeature
    {
        public List<IntersectionFeature> Links = new();
        public List<RegionFeature> Regions = new();

        public IEnumerable<RegionTriangle> Triangles
        {
            get
            {
                RegionTriangle triangle;
                foreach(IntersectionFeature link  in Links)
                {
                    foreach (RegionFeature regionFeature in Regions)
                    {
                        triangle = regionFeature.GetTriangle(this, link);
                        if (triangle != null) yield return triangle;
                    }
                }
            }
        }

        public IntersectionFeature(float x, float y) : base(x, y) { }
    }
}