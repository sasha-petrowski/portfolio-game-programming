using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace WorldGeneration
{
    public class LandFeature : Feature
    {
        public Color Debug_Color;

        public bool IsWater;

        public ContinentFeature Continent;

        public RegionFeature Root;
        public List<RegionFeature> Regions = new();

        public LandFeature(RegionFeature root, bool isWater)
        {
            Debug_Color = Utility.RandColor();

            IsWater = isWater;

            Root = root;
            root.Land = this;
            Regions.Add(root);
        }

        public override void DrawGizmos(World world)
        {
            foreach(RegionFeature region in Regions) 
            {
                region.DrawGizmos(world);
            }
        }
    }
}