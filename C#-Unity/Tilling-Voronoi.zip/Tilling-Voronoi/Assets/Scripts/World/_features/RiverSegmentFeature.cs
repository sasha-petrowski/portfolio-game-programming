using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UIElements;
using UnityEngine;

namespace WorldGeneration
{
    public class RiverSegmentFeature : Feature
    {
        protected World _world;
        public Vector2 Start;
        public Vector2 End;
        public float Length;
        public float OriginDistance;
        public float Width;

        public RegionFeature From, Next;


        private float _dxl;
        private float _dyl;

        public RiverSegmentFeature(Vector2 start, Vector2 end, RegionFeature from, RegionFeature next, World world, float originDistance)
        {
            OriginDistance = originDistance;
            Width = Mathf.Min(Mathf.Sqrt(Mathf.Max(OriginDistance * 2, 1)), RiverFeature.MAX_WIDTH) * world.RiverWidth;

            From = from;
            Next = next;

            _world = world;

            Start = start;
            End = end;

            #region Wrap End to Start
            _dxl = Start.x - End.x;
            _dyl = Start.y - End.y;

            if (_dxl > world.HalfWidth)
            {
                End.x += world.Width;
            }
            else if (_dxl < -world.HalfWidth)
            {
                End.x -= world.Width;
            }

            if (_dyl > world.HalfHeight)
            {
                End.y += world.Height;
            }
            else if (_dyl < -world.HalfHeight)
            {
                End.y -= world.Height;
            }
            _dxl = End.x - Start.x;
            _dyl = End.y - Start.y;
            #endregion

            Length = Mathf.Sqrt(_dxl * _dxl + _dyl * _dyl);
        }

        public virtual bool PointOn(float x, float y, out float near, out float lerp)
        {
            float dxA = x - Start.x;
            float dyA = y - Start.y;

            #region Wrap X & Y to the Start
            if (dxA > _world.HalfWidth)
            {
                x -= _world.Width;
                dxA = x - Start.x;
            }
            else if (dxA < -_world.HalfWidth)
            {
                x += _world.Width;
                dxA = x - Start.x;
            }

            if (dyA > _world.HalfHeight)
            {
                y -= _world.Height;
                dyA = y - Start.y;
            }
            else if (dyA < -_world.HalfHeight)
            {
                y += _world.Height;
                dyA = y - Start.y;
            }
            #endregion

            float dxB = x - End.x;
            float dyB = y - End.y;

            float cross = dxA * _dyl - dyA * _dxl;

            near = Mathf.Abs((cross / Length) / Width);
            lerp = near * near;

            if (near > 1) return false;

            near = 1 - near;

            if (dxA * -_dxl - dyA * _dyl >= 0) // if behind point A
            {
                lerp = 0;
                near = Mathf.Clamp01(1 - (Mathf.Sqrt(dxA * dxA + dyA * dyA) / Width));
            }
            else if (dxB * -_dxl - dyB * _dyl <= 0) // if behind point B
            {
                lerp = 1;
                near = Mathf.Clamp01(1 - (Mathf.Sqrt(dxB * dxB + dyB * dyB) / Width));
            }
            else
            {
                lerp = (Mathf.Sqrt(dxA * dxA + dyA * dyA - lerp * Width * Width)) / Length;
            }
            
            if (Mathf.Abs(_dxl) >= Mathf.Abs(_dyl))
                return _dxl >= 0 ? Start.x <= x + Width && x <= End.x + Width : End.x <= x + Width && x <= Start.x + Width;
            else
                return _dyl >= 0 ? Start.y <= y + Width && y <= End.y + Width : End.y <= y + Width && y <= Start.y + Width;
        }

        public override void DrawGizmos(World world)
        {
            Gizmos.DrawLine(Start, End);
        }
    }
}