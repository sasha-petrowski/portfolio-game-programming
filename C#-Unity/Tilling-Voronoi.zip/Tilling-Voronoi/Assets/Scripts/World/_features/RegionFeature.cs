using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace WorldGeneration
{
    public class RegionFeature : PointFeature
    {
        public const float DEPTH_HEIGHT = 0.15f;


        public Color Debug_Color;

        public LandFeature Land { get; set; }
        public bool IsBorder;
        public int Depth;

        public float HighestBorder = float.MinValue;
        public float LowestBorder = float.MaxValue;
        public float LakeHeight;

        public List<RegionTriangle> Triangles = new();
        public List<RiverFeature> Rivers;
        public List<RiverSegmentFeature> RiverSegments = new();

        public RegionTriangle GetTriangle(RegionFeature neighbor)
        {
            foreach (RegionTriangle triangle in Triangles)
            {
                if (triangle.Other == neighbor) return triangle;
            }
            return null;
        }
        public RegionTriangle GetTriangle(IntersectionFeature a, IntersectionFeature b)
        {
            foreach (RegionTriangle triangle in Triangles)
            {
                if ((triangle.A == a | triangle.A == b) & (triangle.B == b | triangle.B == a)) return triangle;
            }
            return null;
        }

        public RegionFeature(float x, float y) : base(x, y)
        {
            Debug_Color = Utility.RandColor();
        }

        public IEnumerable<RegionFeature> Neighbors 
        {
            get
            {
                foreach (RegionTriangle triangle in Triangles)
                {
                    if(triangle.Other != null) yield return triangle.Other;
                }
            }
        }

        public override void DrawGizmos(World world)
        {
            Color before = Gizmos.color;

            foreach (RegionTriangle triangle in Triangles)
            {
                if(triangle.Other == null) continue;
                if (triangle.Other.Land != Land) Gizmos.color = new Color(1, 1, 1, .2f);
                else Gizmos.color = new Color(0, 0, 0, .333f);
                Vector3 a = new Vector3(triangle.A.x, triangle.A.y);
                Vector3 b = new Vector3(triangle.B.x, triangle.B.y);
                world.GizmoWrappingLine(a, b);
            }
            Gizmos.color = Color.red;
            base.DrawGizmos(world);


            Gizmos.color = before;
        }
    }
}