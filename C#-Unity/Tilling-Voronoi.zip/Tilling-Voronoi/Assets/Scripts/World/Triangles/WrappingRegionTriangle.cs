using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace WorldGeneration
{
    public class WrappingRegionTriangle : RegionTriangle
    {
        private float _aX;
        private float _aY;

        private float _bX;
        private float _bY;

        private World _world;
        public WrappingRegionTriangle(World world, RegionFeature region, RegionFeature other, IntersectionFeature a, IntersectionFeature b) : base(region, other, a, b)
        {
            _world = world;

            _aX = a.x - Region.x > _world.HalfWidth ? a.x - _world.Width : a.x - Region.x < -_world.HalfWidth ? a.x + _world.Width : a.x;
            _aY = a.y - Region.y > _world.HalfHeight ? a.y - _world.Height : a.y - Region.y < -_world.HalfHeight ? a.y + _world.Height : a.y;

            _bX = b.x - Region.x > _world.HalfWidth ? b.x - _world.Width : b.x - Region.x < -_world.HalfWidth ? b.x + _world.Width : b.x;
            _bY = b.y - Region.y > _world.HalfHeight ? b.y - _world.Height : b.y - Region.y < -_world.HalfHeight ? b.y + _world.Height : b.y;
        }


        public override bool IsInside(float x, float y, out float weightA, out float weightB, out float weightR)
        {
            x = x - Region.x > _world.HalfWidth ? x - _world.Width : x - Region.x < -_world.HalfWidth ? x + _world.Width : x;
            y = y - Region.y > _world.HalfHeight ? y - _world.Height : y - Region.y < -_world.HalfHeight ? y + _world.Height : y;

            float divider = (_bY - Region.y) * (_aX - Region.x) + (Region.x - _bX) * (_aY - Region.y);
            weightA = ((_bY - Region.y) * (x - Region.x) + (Region.x - _bX) * (y - Region.y)) / divider;
            weightB = ((Region.y - _aY) * (x - Region.x) + (_aX - Region.x) * (y - Region.y)) / divider;
            weightR = 1 - weightA - weightB;

            return weightA >= 0 & weightB >= 0 & weightR >= -1;
        }

        protected override void CalculateLength()
        {
            LengthAB = Mathf.Sqrt((_aX - _bX) * (_aX - _bX) + (_aY - _bY) * (_aY - _bY));
            LengthBC = Mathf.Sqrt((_bX - Region.x) * (_bX - Region.x) + (_bY - Region.y) * (_bY - Region.y));
            LengthCA = Mathf.Sqrt((Region.x - _aX) * (Region.x - _aX) + (Region.y - _aY) * (Region.y - _aY));

            float s = (LengthAB + LengthBC + LengthCA) / 2f;
            Area = Mathf.Sqrt(s * (s - LengthAB) * (s - LengthBC) * (s - LengthCA));
        }
    }
}