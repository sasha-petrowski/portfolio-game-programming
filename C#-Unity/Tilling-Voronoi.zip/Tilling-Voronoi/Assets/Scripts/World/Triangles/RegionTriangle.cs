using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace WorldGeneration
{
    public class RegionTriangle
    {
        public RegionFeature Region;

        public RegionFeature Other;

        public IntersectionFeature A;
        public IntersectionFeature B;
        public float LengthAB, LengthBC, LengthCA;
        public float Area;

        public RegionTriangle(RegionFeature region, RegionFeature other, IntersectionFeature a, IntersectionFeature b)
        {
            region.Triangles.Add(this);
            Region = region;
            Other = other;

            A = a;
            B = b;
        }

        public static RegionTriangle AddTriangle(World world, RegionFeature region, RegionFeature other, IntersectionFeature a, IntersectionFeature b)
        {
            bool wrappingAB = Mathf.Abs(a.x - b.x) > world.HalfWidth | Mathf.Abs(a.y - b.y) > world.HalfHeight;
            bool wrappingRA = Mathf.Abs(region.x - a.x) > world.HalfWidth | Mathf.Abs(region.y - a.y) > world.HalfHeight;
            bool wrappingRB = Mathf.Abs(region.x - b.x) > world.HalfWidth | Mathf.Abs(region.y - b.y) > world.HalfHeight;

            bool outA = a.x < 0 | a.x > world.Width | a.y < 0 | a.y > world.Height;
            bool outB = b.x < 0 | b.x > world.Width | b.y < 0 | b.y > world.Height;

            RegionTriangle triangle;

            if (wrappingAB | wrappingRA | wrappingRB | outA | outB)
            {
                triangle = new WrappingRegionTriangle(world, region, other, a, b);
            }
            else
            {
                triangle = new RegionTriangle(region, other, a, b);
            }

            triangle.CalculateLength();

            return triangle;
        }
        protected virtual void CalculateLength()
        {
            LengthAB = Mathf.Sqrt((A.x - B.x) * (A.x - B.x) + (A.y - B.y) * (A.y - B.y));
            LengthBC = Mathf.Sqrt((B.x - Region.x) * (B.x - Region.x) + (B.y - Region.y) * (B.y - Region.y));
            LengthCA = Mathf.Sqrt((Region.x - A.x) * (Region.x - A.x) + (Region.y - A.y) * (Region.y - A.y));

            float s = (LengthAB + LengthBC + LengthCA) / 2f;
            Area = Mathf.Sqrt(s * (s - LengthAB) * (s - LengthBC) * (s - LengthCA));
        }

        public float HeightAt(float weightA, float weightB, float weightR)
        {
            return A.Height * weightA + B.Height * weightB + Region.Height * weightR;
        }
        public float HeightAt(float weightA, float weightB)
        {
            return weightA + weightB == 0 ? Region.Height : (A.Height * weightA + B.Height * weightB) / (weightA + weightB);
        }
        public float IrrigationAt(float weightA, float weightB, float weightR)
        {
            if(Other != null)
            {
                float lerp = (1 - weightR) * (1 - Mathf.Abs(weightA - weightB) / (weightA + weightB));
                return (Other.Humidity + Region.Humidity) * 0.5f * lerp + (A.Humidity * weightA + B.Humidity * weightB + Region.Humidity * weightR) * (1 - lerp);
            }
            else return A.Humidity * weightA + B.Humidity * weightB + Region.Humidity * weightR; ;
        }

        public virtual bool IsInside(float x, float y, out float weightA, out float weightB, out float weightR)
        {
            float divider = (B.y - Region.y) * (A.x - Region.x) + (Region.x - B.x) * (A.y - Region.y);
            weightA = ((B.y - Region.y) * (x - Region.x) + (Region.x - B.x) * (y - Region.y)) / divider;
            weightB = ((Region.y - A.y) * (x - Region.x) + (A.x - Region.x) * (y - Region.y)) / divider;
            weightR = 1 - weightA - weightB;

            return weightA >= 0 & weightB >= 0 & weightR >= -1;
        }

    }
}