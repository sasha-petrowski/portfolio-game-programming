using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Unity.VisualScripting;
using UnityEngine;
using WorldGeneration.WrappingVoronoi;

namespace WorldGeneration
{
    [Serializable]
    public class World
    {
        public const int CLOSE_INTERSECTION = 8;
        public const float LATITUDE_HUMIDITY = 0.5f;
        public const float COAST_HUMIDITY = 1/4f;
        public const float COAST_MAXHEIGHT = 0.05f;



        [Header("Variables")]
        public int Seed;

        public int TilesX;
        [Min(2)]
        public int TilesY;
        [Min(1)]
        public int LandSites = 32;
        [Min(1)]
        public int OceanSites = 32;

        [Min(16)]
        public int Width = 1024;
        [Min(16)]
        public int Height = 512;
        [Range(0f, 1f)]
        public float Variance;

        [Min(1)]
        public int MountainRiverWidth = 10;
        [Min(1)]
        public int MountainRiverDistance = 50;
        [Min(1)]
        public int WorldBorderSize = 128;
        [Min(1)]
        public float RiverBezierStrength = 4;
        [Min(1)]
        public float RiverWidth = 32;


        [Header("Noises")]
        public Noise NoiseDistord;
        public Noise PositionDistord;
        public Noise RegionHeightNoise;
        public Noise BorderHeightNoise;
        public Noise IntersectionHeightNoise;

        [Header("Biomes")]
        public BiomeList BiomeList;
        public Gradient WaterColors;
        public Gradient IceColors;

        [Header("Debug")]
        public bool DebugActiveDistortion;
        public Transform GizmoTransform;


        [HideInInspector]
        public float HalfWidth, HalfHeight;

        public RegionFeature[] Regions => _regions;
        public List<RiverFeature> Rivers => _rivers;

        private float _stepX, _stepY;
        private System.Random _random;
        private Voronoi _voronoi;
        private RegionFeature[] _regions;
        private LandFeature[] _lands;
        private List<ContinentFeature> _continents = new();
        private List<RegionFeature>[,] _chunks;
        private List<RiverFeature> _rivers = new();

        private bool _generated = false;
        private List<GraphEdge> _Vlist;

        public void Generate()
        {
            _stepX = Width / TilesX;
            _stepY = Height / TilesY;

            HalfWidth = Width / 2f;
            HalfHeight = Height / 2f;

            _chunks = new List<RegionFeature>[TilesX, TilesY];
            for (int y = 0; y < TilesY; y++)
            {
                for (int x = 0; x < TilesX; x++)
                {
                    _chunks[x, y] = new List<RegionFeature>(1);
                }
            }

            _random = new System.Random(Seed);
            Utility.Seed(Seed);
            Noise.InitNoise(Seed);

            Voronoi voronoi = CreateVoronoi();
            _voronoi = voronoi;
            _regions = new RegionFeature[TilesX * TilesY];

            Dictionary<Vector2Int, IntersectionFeature> intersections = new Dictionary<Vector2Int, IntersectionFeature>();
            Dictionary<Site, RegionFeature> regions = new Dictionary<Site, RegionFeature>();

            int index = 0;
            _Vlist = voronoi.GenerateGraph().ToList();
            foreach (GraphEdge edge in _Vlist)
            {
                if (edge == null) continue;

                if (edge.site1 != null && edge.site2 != null)
                {
                    AddEdge(ref index, edge, intersections, regions);
                }
            }
            #region Create triangle on borders
            List<IntersectionFeature> unlinked = new();
            foreach (RegionFeature region in _regions)
            {
                unlinked.Clear();
                foreach (RegionTriangle triangle in region.Triangles)
                {
                    if (! unlinked.Remove(triangle.A))
                    {
                        unlinked.Add(triangle.A);
                    }

                    if (! unlinked.Remove(triangle.B))
                    {
                        unlinked.Add(triangle.B);
                    }
                }

                if(unlinked.Count > 1)
                {
                    AddBorderEdge(region, unlinked[0], unlinked[1]);
                }
            }
            #endregion

            #region Create and assign Land and Continents
            _lands = new LandFeature[LandSites + OceanSites];
            HashSet<RegionFeature> visited = new HashSet<RegionFeature>();

            LinkedList<RegionFeature> landToVisit = new LinkedList<RegionFeature>();
            LinkedList<RegionFeature> oceanToVisit = new LinkedList<RegionFeature>();

            for (int i = 0; i < LandSites + OceanSites; i++)
            {
                RegionFeature region;
                do
                {
                    float x = (float)_random.NextDouble() * Width;
                    float y = (float)_random.NextDouble() * Height;
                    /*
                    if(i >= LandSites)
                    {
                        y = (float)_random.NextDouble() * Height;
                    }
                    else
                    {
                        y = ((float)_random.NextDouble() * 0.7f + 0.15f) * Height;
                    }
                    */
                    region = GetRegionAt(x, y);
                }
                while (landToVisit.Contains(region) | oceanToVisit.Contains(region));

                LandFeature continent = new LandFeature(region, i >= LandSites);

                _lands[i] = continent;

                if(continent.IsWater)
                {
                    oceanToVisit.AddLast(region);
                }
                else
                {
                    landToVisit.AddLast(region);
                }
                visited.Add(region);
            }
            int visitIndex = 0;
            LinkedList<RegionFeature> toVisit;
            bool finished = false;

            while (! finished)
            {
                if(oceanToVisit.First == null | (visitIndex % 3 == 0 & landToVisit.First != null)) // do land 1/3 of the time
                {
                    toVisit = landToVisit;
                }
                else
                {
                    toVisit = oceanToVisit;
                }
                visitIndex++;

                finished = toVisit.First == null;
                if(! finished)
                {
                    int rndIndex = (int)((float)_random.NextDouble() * toVisit.Count);
                    LinkedListNode<RegionFeature> node = toVisit.First;
                    for (int i = 0; i < rndIndex; i++)
                    {
                        node = node.Next;
                    }
                    toVisit.Remove(node);

                    RegionFeature region = node.Value;

                    foreach (RegionFeature neighbor in region.Neighbors)
                    {
                        if (visited.Contains(neighbor)) continue;

                        visited.Add(neighbor);
                        toVisit.AddLast(neighbor);

                        neighbor.Land = region.Land;
                        region.Land.Regions.Add(neighbor);
                    }
                }
            }
            foreach (LandFeature land in _lands)
            {
                if(land.Continent == null)
                {
                    GenerationUtility.SpreadContinent(land.Root, _random, _continents);
                }
            }
            #endregion

            #region Region Depth & Height
            foreach (RegionFeature region in _regions)
            {
                //Determining Border regions
                region.IsBorder = false;

                foreach (RegionFeature neighbor in region.Neighbors)
                {
                    if (region.Land.IsWater != neighbor.Land.IsWater)
                    {
                        region.IsBorder = true;
                        break;
                    }
                }
            }

            foreach (RegionFeature region in _regions)
            {
                if (region.IsBorder)
                {
                    GenerationUtility.SpreadDepth(region);
                }
            }
            // Multiply height by a noise
            foreach (RegionFeature region in _regions)
            {
                region.Height = region.Depth * RegionFeature.DEPTH_HEIGHT * RegionHeightNoise.SimplexNoise(region.x, region.y, 0);
            }
            #endregion

            #region Intersection Noise Height
            foreach (IntersectionFeature intersection in intersections.Values)
            {
                LandFeature land = intersection.Regions[0].Land;

                bool isBorder = false;
                bool seaBorder = false;
                foreach (RegionFeature region in intersection.Regions)
                {
                    if (region.Land.IsWater != land.IsWater) // Test if intersection is a border between sea or lands
                    {
                        seaBorder = true;
                        isBorder = true;
                        break;
                    }
                    if (region.Land != land) // If land border set height depending on Border Noise
                    {
                        isBorder = true;
                        intersection.Height = BorderHeightNoise.SimplexNoise(intersection.x, intersection.y, 0);
                        break;
                    }
                }

                if (isBorder == false | seaBorder) // set height depending on Intersection noise if not a land border
                {
                    intersection.Height = IntersectionHeightNoise.SimplexNoise(intersection.x, intersection.y, 0);
                }
            }
            #endregion

            #region Flaten close points
            foreach (IntersectionFeature intersection in intersections.Values)
            {
                // Softens the height of intersections with very close neighbors
                foreach (RegionTriangle triangle in intersection.Triangles)
                {
                    if (triangle.LengthAB < CLOSE_INTERSECTION)
                    {
                        intersection.Height = intersection.Height / 2;
                        break;
                    }
                }
            }
            #endregion

            #region Logic for height changes
            foreach (IntersectionFeature intersection in intersections.Values)
            {
                bool anyLand = true;

                // don't do mountains in the ocean
                if (intersection.Height > 0)
                {
                    anyLand = false;
                    intersection.Height = -intersection.Height;

                    foreach (RegionFeature region in intersection.Regions)
                    {
                        anyLand = anyLand || !region.Land.IsWater;

                        if (!region.Land.IsWater)
                        {
                            intersection.Height = -intersection.Height;
                            break;
                        }
                    }
                }

                if (anyLand == false) // reduce depth of trenches in the middle of deep oceans
                {
                    intersection.Height = intersection.Height / 2;
                    foreach (RegionFeature region in intersection.Regions)
                    {
                        if (!region.IsBorder)
                        {
                            intersection.Height = intersection.Height * 2;
                            break;
                        }
                    }
                }

                // only make chasms in area with only water or land
                if (intersection.Height < 0 && intersection.Regions.Count > 0)
                {
                    bool type = intersection.Regions[0].Land.IsWater;

                    foreach (RegionFeature region in intersection.Regions)
                    {
                        if (type != region.Land.IsWater)
                        {
                            intersection.Height = 0;
                            break;
                        }
                    }
                }

                // Add average height from neighboring regions
                float total = 0;
                foreach (RegionFeature region in intersection.Regions)
                {
                    total += region.Height;
                }
                intersection.Height += total / intersection.Regions.Count;
            }
            #endregion

            #region Set Border height of regions

            foreach (RegionFeature region in _regions)
            {
                foreach (RegionTriangle triangle in region.Triangles)
                {
                    if (region.HighestBorder < triangle.A.Height)
                    {
                        region.HighestBorder = triangle.A.Height;
                    }
                    else if (region.LowestBorder > triangle.A.Height)
                    {
                        region.LowestBorder = triangle.A.Height;
                        region.LakeHeight = region.LowestBorder - (region.LowestBorder - region.Height) / 2f;
                    }
                    if (region.HighestBorder < triangle.B.Height)
                    {
                        region.HighestBorder = triangle.B.Height;
                    }
                    else if (region.LowestBorder > triangle.B.Height)
                    {
                        region.LowestBorder = triangle.B.Height;
                        region.LakeHeight = region.LowestBorder - (region.LowestBorder - region.Height) / 2f;
                    }
                }
            }
            #endregion

            #region Region Humidity

            foreach (RegionFeature region in _regions)
            {
                region.Humidity = GetHumidity(region.y);

                if (! region.Land.IsWater) // Add humidity to coastal region
                {
                    foreach (RegionTriangle triangle in region.Triangles)
                    {
                        if(triangle.Other == null) continue;
                        if (triangle.Other.Land.IsWater && (triangle.A.Height + triangle.B.Height) * 0.5f <= region.Height + COAST_MAXHEIGHT)
                        {
                            region.Humidity += COAST_HUMIDITY;
                            break;
                        }
                    }
                }
            }

            #endregion

            #region Create Rivers

            foreach (RegionFeature region in _regions.OrderBy(o => -o.Depth).ToList()) // Create rivers starting from the Highest Regions
            {
                if (region.Triangles.Count > 3 && region.Depth >= 1 && RiverFeature.TryCreateRiver(region, out RiverFeature river, this) == 1)
                {
                    _rivers.Add(river);
                }
            }
            foreach (RiverFeature river in _rivers)
            {
                river.Initialise(this);
            }
            #endregion

            #region Intersection Irrigation average

            foreach (IntersectionFeature intersection in intersections.Values)
            {
                float sum = 0;
                foreach (RegionFeature region in intersection.Regions)
                {
                    sum += region.Humidity;
                }
                intersection.Humidity = sum / intersection.Regions.Count;
            }
            #endregion

            _generated = true;
        }

        private void AddEdge(ref int index, GraphEdge edge, Dictionary<Vector2Int, IntersectionFeature> intersections, Dictionary<Site, RegionFeature> regions)
        {
            #region Make sure Sites are not copies
            bool bothCopy = false;
            Site site1 = edge.site1;
            Site site2 = edge.site2;

            if (site1 is SiteCopy siteCopy1)
            {
                site1 = siteCopy1.Site;
                bothCopy = true;
            }
            if (site2 is SiteCopy siteCopy2)
            {
                site2 = siteCopy2.Site;
                bothCopy = true & bothCopy;
            }

            if (bothCopy || site1 == site2) return;
            #endregion

            #region Create or get Regions from Sites
            RegionFeature region1;
            RegionFeature region2;
            if (!regions.TryGetValue(site1, out region1))
            {
                region1 = new RegionFeature(site1.x, site1.y);

                GetChunk(region1.x, region1.y).Add(region1);
                _regions[index++] = region1;
                regions.Add(site1, region1);
            }
            if (!regions.TryGetValue(site2, out region2))
            {
                region2 = new RegionFeature(site2.x, site2.y);

                GetChunk(region2.x, region2.y).Add(region2);
                _regions[index++] = region2;
                regions.Add(site2, region2);
            }
            #endregion

            #region Get positions of edge extremity
            Vector2Int aPos = WrapPosition(Mathf.RoundToInt(edge.x1), Mathf.RoundToInt(edge.y1));
            Vector2Int bPos = WrapPosition(Mathf.RoundToInt(edge.x2), Mathf.RoundToInt(edge.y2));

            if (aPos == bPos) return;
            #endregion

            #region Get or create Intersection A & B
            IntersectionFeature a;
            IntersectionFeature b;
            if (!intersections.TryGetValue(aPos, out a))
            {
                a = new IntersectionFeature(edge.x1, edge.y1);
                intersections.Add(aPos, a);
            }

            if (!a.Regions.Contains(region1)) a.Regions.Add(region1);
            if (!a.Regions.Contains(region2)) a.Regions.Add(region2);

            if (!intersections.TryGetValue(bPos, out b))
            {
                b = new IntersectionFeature(edge.x2, edge.y2);
                intersections.Add(bPos, b);
            }

            if (!b.Regions.Contains(region1)) b.Regions.Add(region1);
            if (!b.Regions.Contains(region2)) b.Regions.Add(region2);
            #endregion

            #region Get or Create triangles between both regions
            if (!a.Links.Contains(b))
            {
                RegionTriangle.AddTriangle(this, region1, region2, a, b);
                RegionTriangle.AddTriangle(this, region2, region1, a, b);

                a.Links.Add(b);
                b.Links.Add(a);
            }
            #endregion
        }
        private void AddBorderEdge(RegionFeature region, IntersectionFeature a, IntersectionFeature b)
        {
            #region Link region to A & B
            if (!a.Regions.Contains(region)) a.Regions.Add(region);

            if (!b.Regions.Contains(region)) b.Regions.Add(region);
            #endregion

            #region Get or Create triangles border
            if (!a.Links.Contains(b))
            {
                RegionTriangle.AddTriangle(this, region, null, a, b);

                a.Links.Add(b);
                b.Links.Add(a);
            }
            #endregion
        }
        private Voronoi CreateVoronoi()
        {
            float[] xVal = new float[TilesX * TilesY];
            float[] yVal = new float[TilesX * TilesY];

            int index = 0;
            float xx;
            float yy;
            bool tooClose;
            // Instantiate point at semi-random positions depending on variance
            for (int y = 0; y < TilesY; y++)
            {
                for (int x = 0; x < TilesX; x++)
                {
                    xx = _stepX * (x + 0.5f + (((float)_random.NextDouble() - 0.5f) * 2) * Variance);
                    yy = _stepY * (y + 0.5f + (((float)_random.NextDouble() - 0.5f) * 2) * Variance);

                    do
                    {
                        tooClose = false;

                        for (int i = 0; i < index; i++)
                        {
                            if (Mathf.Abs(xVal[i] - xx) % Width < 2f && Mathf.Abs(yVal[i] - yy) % Width < 2f)
                            {
                                tooClose = true;

                                xx += 0.5f;
                                yy += 0.5f;

                                break;
                            }
                        }
                    }
                    while (tooClose);


                    xVal[index] = (Width + xx) % Width;
                    yVal[index] = (Height + yy) % Height;
                    index++;
                }
            }

            return new Voronoi(xVal, yVal, 0, Width, 0, Height);
        }

        public Vector2 WrapPosition(float x, float y)
        {
            return new Vector2((Width + x) % Width, (Height + y) % Height);
        }
        public Vector2Int WrapPosition(int x, int y)
        {
            return new Vector2Int((Width + x) % Width, (Height + y) % Height);
        }

        public float GetTemperature(float y)
        {
            return 1 - Mathf.Abs(y / Height - 0.5f) * 2;
            //return temperature * temperature * Mathf.Sign(temperature);
        }
        public float GetHumidity(float y)
        {
            float humidity = Mathf.Abs(y / Height - 0.5f) * 6;
            if(humidity > 1)
            {
                humidity = Mathf.Max(1 - (humidity - 1), 0.5f);
            }
            return humidity * LATITUDE_HUMIDITY;
        }

        public RegionFeature GetRegionAt(float x, float y)
        {
            RegionFeature best = null;
            float bestDistance = float.MaxValue;
            float distance;

            float dx, dy;

            foreach (List<RegionFeature> chunk in GetNearbyChunks(x, y))
            {
                foreach (RegionFeature region in chunk)
                {
                    // slightly more optimized than calling SQRDistance many times
                    //distance = SqrDistance(x, y, region.x, region.y);
                    dx = Mathf.Abs(x - region.x);
                    if (dx > HalfWidth) dx -= Width;

                    dy = Mathf.Abs(y - region.y);
                    if (dy > HalfHeight) dy -= Height;

                    distance = dx * dx + dy * dy;

                    if (distance < bestDistance)
                    {
                        bestDistance = distance;
                        best = region;
                    }
                }
            }

            return best;
        }
        public List<RegionFeature> GetChunk(float posX, float posY)
        {
            return _chunks[(int)(TilesX + posX / _stepX) % TilesX, (int)(TilesY + posY / _stepY) % TilesY];
        }
        public void GetChunk(float posX, float posY, out int x, out int y)
        {
            x = (int)(TilesX + posX / _stepX) % TilesX;
            y = (int)(TilesY + posY / _stepY) % TilesY;
        }
        public IEnumerable<List<RegionFeature>> GetNearbyChunks(float posX, float posY)
        {
            int x = (int)(TilesX + ((posX / _stepX) % TilesX));
            int y = (int)(TilesY + ((posY / _stepY) % TilesY));

            int modX = x % TilesX;
            int modY = y % TilesY;

            List<RegionFeature> centerRegions = _chunks[modX, modY];
            yield return centerRegions; // Center

            yield return _chunks[(x - 1) % TilesX, modY]; // left
            yield return _chunks[(x + 1) % TilesX, modY]; // right

            if (modY > 0)
            {
                yield return _chunks[modX, (y - 1) % TilesY]; // bottom
                yield return _chunks[(x - 1) % TilesX, (y - 1) % TilesY]; // bottom left
                yield return _chunks[(x + 1) % TilesX, (y - 1) % TilesY]; // bottom right
            }
            if (modY < TilesY - 1)
            {
                yield return _chunks[modX, (y + 1) % TilesY]; // top

                yield return _chunks[(x - 1) % TilesX, (y + 1) % TilesY]; // top left
                yield return _chunks[(x + 1) % TilesX, (y + 1) % TilesY]; // top right
            }


            if(centerRegions.Count == 0)
            {
                yield return _chunks[(x - 2) % TilesX, modY]; // left ++
                yield return _chunks[(x + 2) % TilesX, modY]; // right ++

                if (modY > 0)
                {
                    yield return _chunks[(x - 2) % TilesX, (y - 1) % TilesY]; // bottom left ++
                    yield return _chunks[(x + 2) % TilesX, (y - 1) % TilesY]; // bottom right ++
                }
                if (modY < TilesY - 1)
                {
                    yield return _chunks[(x - 2) % TilesX, (y + 1) % TilesY]; // top left ++
                    yield return _chunks[(x + 2) % TilesX, (y + 1) % TilesY]; // top right ++
                }
                if (modY > 1)
                {
                    yield return _chunks[modX, (y - 2) % TilesY]; // bottom ++
                    yield return _chunks[(x - 1) % TilesX, (y - 2) % TilesY]; // bottom ++ left
                    yield return _chunks[(x + 1) % TilesX, (y - 2) % TilesY]; // bottom ++ right
                }
                if (modY < TilesY - 2)
                {
                    yield return _chunks[modX, (y + 2) % TilesY]; // top ++
                    yield return _chunks[(x - 1) % TilesX, (y + 2) % TilesY]; // top ++ left
                    yield return _chunks[(x + 1) % TilesX, (y + 2) % TilesY]; // top ++ right
                }
            }
        }


        public void DrawGizmos()
        {
            if (!_generated) return;
            if (_regions == null) return;

            foreach (ContinentFeature continent in _continents)
            {
                continent.DrawGizmos(this);
            }

            foreach (RiverFeature Regionriver in _rivers)
            {
                Regionriver.DrawGizmos(this);
            }
            
            RegionFeature mouseRegion = GetRegionAt(GizmoTransform.position.x, GizmoTransform.position.y);
            
            /*
            if (RiverFeature.TryCreateRiver(mouseRegion, out RiverFeature river) >= 0)
            {
                Gizmos.color = Color.green;

                river.OnDrawGizmos(this);
            }
            else
            {
                Gizmos.color = Color.red;
            }
            */
        }
        public void GizmoWrappingPoint(Vector3 point)
        {
            bool wrapping = false;
            Vector3 p2 = point;

            if (point.x > Width)
            {
                wrapping = true;
                p2.x -= Width;
            }
            else if (point.x < -Width)
            {
                wrapping = true;
                p2.x += Width;
            }

            if (point.y > Height)
            {
                wrapping = true;
                p2.y -= Height;
            }
            else if (point.y < -Height)
            {
                wrapping = true;
                p2.y += Height;
            }


            Gizmos.DrawSphere(point, (Width / TilesX) / 50f);
            if (wrapping) Gizmos.DrawWireSphere(p2, (Width / TilesX) / 50f);
        }
        public void GizmoWrappingLine(Vector3 a, Vector3 b)
        {
            float dx = a.x - b.x;
            float dy = a.y - b.y;

            bool wrapping = false;
            Vector3 a2 = a;
            Vector3 b2 = b;

            if (dx > Width / 2f)
            {
                wrapping = true;
                a2.x -= Width;
                b2.x += Width;
            }
            else if (dx < -Width / 2f)
            {
                wrapping = true;
                a2.x += Width;
                b2.x -= Width;
            }

            if (dy > Height / 2f)
            {
                wrapping = true;
                a2.y -= Height;
                b2.y += Height;
            }
            else if (dy < -Height / 2f)
            {
                wrapping = true;
                a2.y += Height;
                b2.y -= Height;
            }


            Gizmos.DrawLine(a, b2);
            if (wrapping) Gizmos.DrawLine(a2, b);
        }
        public Vector3 WrapPoint(Vector3 point, Vector3 reference)
        {
            float dx = point.x - reference.x;
            float dy = point.y - reference.y;

            Vector3 newPoint = point;

            if (dx > HalfWidth)
            {
                newPoint.x -= Width;
            }
            else if (dx < -HalfWidth)
            {
                newPoint.x += Width;
            }

            if (dy > HalfHeight)
            {
                newPoint.y -= Height;
            }
            else if (dy < -HalfHeight)
            {
                newPoint.y += Height;
            }

            return newPoint;
        }

    }
}
