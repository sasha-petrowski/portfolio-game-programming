using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEditor.PackageManager;
using UnityEngine;

[CreateAssetMenu(fileName = "BiomeList", menuName = "World/Biomes/List")]
public class BiomeList : ScriptableObject
{
    [Serializable]
    private class Row<T>
    {
        [SerializeField]
        private List<T> _row;
        public List<T> Elements => _row;
        public T this[int key]
        {
            get => _row[key];
            set => _row[key] = value;
        }
        public int Count => _row.Count;
    }

    [SerializeField]
    private List<Row<Gradient>> _biomes;

    public Color Lookup(float temperature, float humidity, float height = 0.5f)
    {
        int floorX = Mathf.Clamp(Mathf.FloorToInt(temperature * _biomes.Count), 0, _biomes.Count - 1);
        int floorY = Mathf.Clamp(Mathf.FloorToInt(humidity * _biomes[floorX].Count), 0, _biomes[floorX].Count - 1);

        return _biomes[floorX][floorY].Evaluate(height);
    }
    public Color LerpLookup(float temperature, float humidity, float height = 0.5f)
    {
        float xx = temperature * _biomes.Count;
        int floorX = Mathf.Clamp(Mathf.FloorToInt(xx), 0, _biomes.Count - 1);
        int roundX = Mathf.RoundToInt(xx);

        float yy = humidity * _biomes[floorX].Count;
        int floorY = Mathf.Clamp(Mathf.FloorToInt(yy), 0, _biomes[floorX].Count - 1);
        int roundY = Mathf.RoundToInt(yy);

        if ((roundX == 0 || roundX == _biomes.Count) && (roundY == 0 || roundY == _biomes[floorX].Count))
        {
            return _biomes[floorX][floorY].Evaluate(height);
        }
        else if (roundX == 0 || roundX == _biomes.Count)
        {
            return Color.Lerp(_biomes[floorX][roundY - 1].Evaluate(height), _biomes[floorX][roundY].Evaluate(height), yy - roundY + 0.5f);
        }
        else if (roundY == 0 || roundY == _biomes[floorX].Count)
        {
            return Color.Lerp(_biomes[roundX - 1][floorY].Evaluate(height), _biomes[roundX][floorY].Evaluate(height), xx - roundX + 0.5f);
        }
        else
        {
            return Color.Lerp(Color.Lerp(_biomes[roundX - 1][roundY - 1].Evaluate(height), _biomes[roundX - 1][roundY].Evaluate(height), yy - roundY + 0.5f), Color.Lerp(_biomes[roundX][roundY - 1].Evaluate(height), _biomes[roundX][roundY].Evaluate(height), yy - roundY + 0.5f), xx - roundX + 0.5f);
        }
    }
}
