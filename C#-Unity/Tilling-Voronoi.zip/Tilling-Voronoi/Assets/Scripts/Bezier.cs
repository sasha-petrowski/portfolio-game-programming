using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using WorldGeneration;

public static class BezierUtility
{
    public static Vector2 QuadPoint(float t, Vector2 pA, Vector2 p1, Vector2 pB)
    {
        float om = 1 - t;
        return om * om * pA + 2 * om * t * p1 + t * t * pB;
    }
    public static Vector2 CubicPoint(float t, Vector2 pA, Vector2 p1, Vector2 p2, Vector2 pB)
    {
        float om = 1 - t;

        // four points
        //return om * om * pA.position + 2 * t * om * om * p1.position + 2 * t * t * om * p2.position + t * t * pB.position;

        // old four points
        return om * om * om * pA + 3 * t * om * om * p1 + 3 * t * t * om * p2 + t * t * t * pB;
    }
}

[RequireComponent(typeof(SpriteRenderer))]
public class Bezier : MonoBehaviour
{
    public Transform pA;
    public Transform pB;

    public Transform p1;
    public Transform p2;

    [Range(10, 1000)]
    public int Steps;
    public bool ActiveDistortion;
    public float DistortionScale = 32;

    [Header("Texture")]
    public int Size;
    public float MaxDistance = 10;

    [Header("Refs")]
    public Noise NoiseDistord;
    public Noise PositionDistord;

    private void OnValidate()
    {
        GetComponent<SpriteRenderer>().sprite = PointsOnLineTexture();
    }

    public Sprite PointsOnLineTexture()
    {
        Color[] colorMap = new Color[Size * Size];

        int index = 0;

        float x;
        float y;

        for (int i = 0; i < Size; i++)
        {
            for (int j = 0; j < Size; j++)
            {
                x = j;
                y = i;

                float distance = CubicDistance(new Vector2(x, y), pA.position, p1.position, p2.position, pB.position);
                float triDistance = QuadDistance(new Vector2(x, y), pA.position, p1.position, pB.position);

                colorMap[index] = Color.Lerp(Color.blue, Color.clear, Mathf.Clamp01(triDistance / MaxDistance));
                colorMap[index] = Color.Lerp(Color.red, colorMap[index], Mathf.Clamp01(distance / MaxDistance));

                index++;
            }
        }

        Texture2D texture = new Texture2D(Size, Size);
        texture.filterMode = FilterMode.Point;
        texture.SetPixels(colorMap);
        texture.Apply();

        return Sprite.Create(texture, new Rect(0.0f, 0.0f, Size, Size), new Vector2(0, 0), 1);
    }
    private Vector2 QuadPoint(float t)
    {
        float om = 1 - t;

        // three points
        return Mathf.Pow(om, 2) * pA.position + 2 * om * t * p1.position + Mathf.Pow(t, 2) * pB.position;
    }
    private Vector2 CubicPoint(float t)
    {
        float om = 1 - t;

        // four points
        //return om * om * pA.position + 2 * t * om * om * p1.position + 2 * t * t * om * p2.position + t * t * pB.position;

        // old four points
        return om * om * om * pA.position + 3 * t * om * om * p1.position + 3 * t * t * om * p2.position + t * t * t * pB.position;
    }
    public float CubicDistance(Vector2 p, Vector2 pA, Vector2 p1, Vector2 p2, Vector2 pB)
    {
        float ax = pA.x - 2 * p1.x + pB.x;
        float bx = 2 * p1.x - 2 * pA.x;
        float cx = pA.x - p.x;

        float ay = pA.y - 2 * p1.y + pB.y;
        float by = 2 * p1.y - 2 * pA.y;
        float cy = pA.y - p.y;

        // "Candidate" for t:
        float t = -(cx * ay - cy * ax) / (bx * ay - by * ax);
        

        // Compute the point corresponding to this candidate value ...
        Vector2 q = CubicPoint(t);

        // ... and check if it is near the given point p:
        float distance = Mathf.Sqrt(Mathf.Pow(Mathf.Abs(q.x - p.x), 2) + Mathf.Pow(Mathf.Abs(q.y - p.y), 2));
        //float distance = Mathf.Min(Mathf.Abs(q.x - p.x), Mathf.Abs(q.y - p.y));

        return distance;
    }
    public float QuadDistance(Vector2 p, Vector2 pA, Vector2 p1, Vector2 pB)
    {
        float ax = pA.x - 2 * p1.x + pB.x;
        float bx = 2 * p1.x - 2 * pA.x;
        float cx = pA.x - p.x;

        float ay = pA.y - 2 * p1.y + pB.y;
        float by = 2 * p1.y - 2 * pA.y;
        float cy = pA.y - p.y;

        // "Candidate" for t:
        float t = -(cx * ay - cy * ax) / (bx * ay - by * ax);
        
        // Compute the point corresponding to this candidate value ...
        Vector2 q = QuadPoint(t);

        // ... and check if it is near the given point p:
        float distance = Mathf.Sqrt(Mathf.Pow(Mathf.Abs(q.x - p.x), 2) + Mathf.Pow(Mathf.Abs(q.y - p.y), 2));
        //float distance = Mathf.Min(Mathf.Abs(q.x - p.x), Mathf.Abs(q.y - p.y));

        return distance;
    }

    private void OnDrawGizmos()
    {
        if(p1.hasChanged | p2.hasChanged)
        {
            p1.hasChanged = false;
            p2.hasChanged = false;
            GetComponent<SpriteRenderer>().sprite = PointsOnLineTexture();
        }


        float step = 1f / Steps;

        Vector2 current = pA.position;
        Vector2 previous;
        if (ActiveDistortion & Noise.Initialized) Distord(ref current);

        for (float t = step; t <= 1f; t += step)             // t always lies between 0 and 1
        {
            previous = current;
            current = CubicPoint(t);
            if (ActiveDistortion & Noise.Initialized) Distord(ref current);


            Gizmos.DrawLine(previous, current);

        }

        previous = current;
        current = pB.position;
        if (ActiveDistortion & Noise.Initialized) Distord(ref current);

        Gizmos.DrawLine(previous, current);
    }

    private void Distord(ref Vector2 pos)
    {
        pos *= DistortionScale;

        Utility.Distord(ref pos.x, ref pos.y, NoiseDistord, PositionDistord);

        pos /= DistortionScale;
    }
}
