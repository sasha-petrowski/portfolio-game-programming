using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(WorldGenerator), true)]
public class WorldGeneratorEditor : Editor
{
    public override void OnInspectorGUI()
    {
        WorldGenerator voronoi = (WorldGenerator)target;
        if (voronoi == null)
        {
            DrawDefaultInspector();
            return;
        }

        if (GUILayout.Button("Randomize"))
        {
            voronoi.World.Seed = Random.Range(int.MinValue, int.MaxValue);
            voronoi.Generate();
        }
        if (GUILayout.Button("Generate"))
        {
            voronoi.Generate();
        }

        DrawDefaultInspector();
    }
}
