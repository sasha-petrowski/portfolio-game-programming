using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(BiomeList), true)]
public class BiomeListEditor : Editor
{
    private const int Extra = 16;
    private static readonly Vector2Int _previewSize = new Vector2Int(256 + Extra, 256 + Extra);

    private Texture2D _preview;

    private void OnValidate()
    {
        BiomeList biomeList = (BiomeList)target;
        if (biomeList == null) return;
        GeneratePreview(biomeList);
    }

    public override void OnInspectorGUI()
    {
        BiomeList biomeList = (BiomeList)target;

        DrawDefaultInspector();
        if (biomeList == null) return;

        DrawUILine(Color.gray);

        if (GUILayout.Button("Update Preview"))
        {
            GeneratePreview(biomeList);
        }

        if (_preview != null)
        {
            GUILayout.Label(_preview);
        }
    }
    private void DrawUILine(Color color, int thickness = 2, int padding = 10)
    {
        Rect r = EditorGUILayout.GetControlRect(GUILayout.Height(padding + thickness));
        r.height = thickness;
        r.y += padding / 2;
        r.x -= 2;
        r.width += 6;
        EditorGUI.DrawRect(r, color);
    }
    private void GeneratePreview(BiomeList biomeList)
    {
        Color[] colorMap = new Color[_previewSize.x * _previewSize.y];

        int index = 0;

        for (int i = 0; i < _previewSize.x; i++)
        {
            for (int j = 0; j < _previewSize.y; j++)
            {
                float temperature = (float)(i - Extra) / (_previewSize.x - Extra);
                float humidity = (float)(j - Extra) / (_previewSize.y - Extra);

                if (i < Extra & j < Extra)
                {
                    colorMap[index++] = Color.black;
                }
                else if (i < Extra)
                {
                    colorMap[index++] = Color.Lerp(Color.black, Color.blue, humidity);
                }
                else if (j < Extra)
                {
                    colorMap[index++] = Color.Lerp(Color.black, Color.red, temperature);
                }
                else if (j > Extra & i > Extra)
                {
                    colorMap[index++] = biomeList.Lookup(temperature, humidity);
                }
                else
                {
                    colorMap[index++] = Color.black;
                }
            }
        }

        _preview = new Texture2D(_previewSize.x, _previewSize.y);
        _preview.filterMode = FilterMode.Point;
        _preview.SetPixels(colorMap);
        _preview.Apply();
    }
}
