using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using WorldGeneration;

[CustomEditor(typeof(Noise), true)]
public class NoiseEditor : Editor
{
    private const int PREVIEW_SIZE = 512;

    private Texture2D _preview;

    private int _previewSeed;
    private float _previewSize = 512;
    private Noise _previewDistortion;
    public override void OnInspectorGUI()
    {
        Noise noise = (Noise)target;

        DrawDefaultInspector();
        if (noise == null) return;

        DrawUILine(Color.gray);

        _previewSeed = EditorGUILayout.IntField("Seed", _previewSeed);
        _previewSize = Mathf.Max(EditorGUILayout.FloatField("Preview Size", _previewSize), 1);
        _previewDistortion = EditorGUILayout.ObjectField(_previewDistortion, typeof(Noise), false, GUILayout.Height(EditorGUIUtility.singleLineHeight)) as Noise;



        if (GUILayout.Button("Preview Simplex"))
        {
            Noise.InitNoise(_previewSeed);
            GeneratePreviewNoise(noise);
        }
        if (GUILayout.Button("Preview Distortion"))
        {
            Noise.InitNoise(_previewSeed);
            GeneratePreviewDistortion(noise);
        }

        if (_preview != null)
        {
            GUILayout.Label(_preview);
        }
    }
    private void DrawUILine(Color color, int thickness = 2, int padding = 10)
    {
        Rect r = EditorGUILayout.GetControlRect(GUILayout.Height(padding + thickness));
        r.height = thickness;
        r.y += padding / 2;
        r.x -= 2;
        r.width += 6;
        EditorGUI.DrawRect(r, color);
    }
    private void GeneratePreviewNoise(Noise noise)
    {
        Color[] colorMap = new Color[PREVIEW_SIZE * PREVIEW_SIZE];

        int index = 0;

        for (int i = 0; i < PREVIEW_SIZE; i++)
        {
            for (int j = 0; j < PREVIEW_SIZE; j++)
            {
                float x = i * _previewSize / PREVIEW_SIZE;
                float y = j * _previewSize / PREVIEW_SIZE;

                if (_previewDistortion != null) Utility.Distord(ref x, ref y, _previewDistortion);

                float value = noise.SimplexNoise(x, y, 0);

                colorMap[index++] = Color.Lerp(Color.black, Color.white, value);
            }
        }

        _preview = new Texture2D(PREVIEW_SIZE, PREVIEW_SIZE);
        _preview.filterMode = FilterMode.Point;
        _preview.SetPixels(colorMap);
        _preview.Apply();
    }
    private void GeneratePreviewDistortion(Noise noise)
    {
        Color[] colorMap = new Color[PREVIEW_SIZE * PREVIEW_SIZE];

        int index = 0;

        for (int i = 0; i < PREVIEW_SIZE; i++)
        {
            for (int j = 0; j < PREVIEW_SIZE; j++)
            {
                float x = i * _previewSize / PREVIEW_SIZE;
                float y = j * _previewSize / PREVIEW_SIZE;

                if (_previewDistortion != null) 
                {
                    Utility.Distord(ref x, ref y, _previewDistortion, noise);
                }
                else
                {
                    Utility.Distord(ref x, ref y, noise);
                }

                colorMap[index++] = (x / _previewSize < 0.05f | y / _previewSize < 0.05f | x / _previewSize > 0.95f | y / _previewSize > 0.95f) ? Color.red : (x / _previewSize > 0.25f && x / _previewSize < 0.75f && y / _previewSize > 0.25f && y / _previewSize < 0.75f) ? Color.black : Color.white;
            }
        }

        _preview = new Texture2D(PREVIEW_SIZE, PREVIEW_SIZE);
        _preview.filterMode = FilterMode.Point;
        _preview.SetPixels(colorMap);
        _preview.Apply();
    }
}
