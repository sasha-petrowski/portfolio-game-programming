﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using WorldGeneration;
using WorldGeneration.WrappingVoronoi;

public class WorldGenerator : MonoBehaviour
{
    public bool GenerateOnValidate;
    
    public World World;

    [Header("Refs")]
    [SerializeField]
    private DebugTexture _debugTexture;


    private void OnValidate()
    {
        if(GenerateOnValidate) StartCoroutine(GenerateCoroutine());
    }
    IEnumerator GenerateCoroutine()
    {
        yield return null;
        Generate();
    }

    public void Generate()
    {
        Stopwatch global = new();
        Stopwatch world = new();
        Stopwatch texture = new();

        global.Start();
        world.Start();
        // Create world
        World.Generate();
        world.Stop();

        texture.Start();
        #region Generate Textures

        // Color
        /*
        Sprite colorSprite = DebugTexture.WorldColor(_world, OffsetX, OffsetY, DistortionFrequency, DistortionAmplitude, DistortionFrequencyB, DistortionAmplitudeB);
        foreach (SpriteRenderer renderer in _voronoiColor)
        {
            renderer.sprite = colorSprite;
        }
        */
        
        // Terrain
        _debugTexture.Generate(_debugTexture.WorldHeight, World);

        #endregion
        texture.Stop();
        global.Stop();

        UnityEngine.Debug.Log($"Finished generating in {global.ElapsedMilliseconds / 1000}s\nWorld : {world.ElapsedMilliseconds}ms + Textures : {texture.ElapsedMilliseconds}ms, Avg per tile : {texture.ElapsedMilliseconds * 1d / (_debugTexture.Resolution.x * _debugTexture.Resolution.y)}ms");
        UnityEngine.Debug.Log($"Can generate : {Math.Round(16 / (texture.ElapsedMilliseconds * 1d / (World.Width * World.Height)))} tiles per frame at 60fps");

    }


    private void OnDrawGizmos()
    {
        if (World != null)
        {
            World.DrawGizmos();
        }
    }

}
