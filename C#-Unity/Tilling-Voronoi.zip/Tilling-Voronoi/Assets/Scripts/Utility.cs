using UnityEngine;
using WorldGeneration;

public static class Utility
{
    private static System.Random _random = new System.Random(0);

    public static void Seed(int seed)
    {
        _random = new System.Random(seed);
    }
    public static Color RandColor()
    {
        return new Color((float)_random.NextDouble(), (float)_random.NextDouble(), (float)_random.NextDouble());
    }
    public static Color BlackOrWhite()
    {
        return _random.Next() % 2 == 0 ? Color.white : Color.black;
    }
    public static Color RandColor(float min)
    {
        return new Color(min + (float)_random.NextDouble() * (1f - min), (float)_random.NextDouble(), min + (float)_random.NextDouble() * (1f - min));
    }

    public static void Distord(ref float x, ref float y, Noise noise)
    {
        x += noise.SimplexNoise(x + 195160.011f, y + 246120.031f, 0);
        y += noise.SimplexNoise(x + 327490.021f, y + 456440.041f, 0);
    }
    public static void Distord(ref float x, ref float y, Noise preNoise, Noise noise)
    {
        float xx = x + preNoise.SimplexNoise(x + 456428.011f, y + 722000.031f, 0);
        float yy = y + preNoise.SimplexNoise(x + 123845.021f, y + 241011.041f, 0);

        x += noise.SimplexNoise(xx + 195160.011f, yy + 246120.031f, 0);
        y += noise.SimplexNoise(xx + 327490.021f, yy + 456440.041f, 0);
    }
    public static void TorusDistord(World world, ref float x, ref float y, Noise preNoise, Noise noise)
    {
        float sinX = Mathf.Sin(x / world.HalfWidth * Mathf.PI) * world.HalfWidth / 2;
        float cosX = Mathf.Sin(x / world.HalfWidth * Mathf.PI) * world.HalfWidth / 2;

        sinX        += preNoise.SimplexNoise(sinX + 456428.011f, y + 722000.031f, cosX + 456440.041f);
        cosX        += preNoise.SimplexNoise(sinX + 327490.021f, y + 456440.041f, cosX + 722000.031f);
        float yy = y + preNoise.SimplexNoise(sinX + 123845.021f, y + 241011.041f, cosX + 195160.011f);

        x += noise.SimplexNoise(sinX + 195160.011f, yy + 246120.031f, cosX + 15646.231f);
        y += noise.SimplexNoise(sinX + 327490.021f, yy + 456440.041f, cosX + 68515.359f);
    }
}