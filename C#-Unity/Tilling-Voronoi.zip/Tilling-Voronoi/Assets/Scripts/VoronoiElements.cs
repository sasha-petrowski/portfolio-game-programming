﻿using System;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEngine.UI.Image;
using UnityEngine.XR;

namespace WorldGeneration.WrappingVoronoi
{	
	// use for sites and vertecies
	public class Site
	{
		public float x;
		public float y;

        public int SiteIndex;

        public Site (float x, float y)
        {
            this.x = x;
            this.y = y;
        }

        public Vector2 Position => new Vector2(x, y);
    }
    public class SiteCopy : Site
    {
        public Site Site;

        public SiteCopy(float x, float y, Site site) : base(x, y)
        {
			Site = site;
        }
    }
    public class Edge
	{
		public float a = 0, b = 0, c = 0;
		public Site[] ep;
		public Site[] reg;
		public int EdgeIndex;
		
		public Edge ()
		{
			ep = new Site[2];
			reg = new Site[2];
		}
	}
	
	
	public class Halfedge
	{
		public Halfedge ELleft, ELright;
		public Edge ELedge;
		public bool deleted;
		public int ELpm;
		public Site vertex;
		public float ystar;
		public Halfedge PQnext;
		
		public Halfedge ()
		{
			PQnext = null;
		}
	}
	
	public class GraphEdge
	{
		public float x1, y1, x2, y2;
        public Site site1, site2;

        public Vector2 Position1 => new Vector2(x1, y1);
        public Vector2 Position2 => new Vector2(x2, y2);
    }
	public class SiteSorterYX : IComparer<Site>
	{
		public int Compare ( Site s1, Site s2 )
		{
			if ( s1.y < s2.y )	return -1;
			if ( s1.y > s2.y ) return 1;
			if ( s1.x < s2.x ) return -1;
			if ( s1.x > s2.x ) return 1;
			return 0;
		}
	}
}
