using System;
using System.Collections.Generic;
using UnityEngine;
using WorldGeneration;

public class DebugTexture : MonoBehaviour
{
    public Vector2Int Resolution = new Vector2Int(1024, 512);

    [Header("Refs")]
    [SerializeField]
    private List<SpriteRenderer> _renderers;
    [SerializeField]
    private Transform _bottomLeft, _bottomRight, _topLeft, _topRight;


    public Sprite WorldHeight(World world)
    {
        Color[] colorMap = new Color[Resolution.x * Resolution.y];

        int index = 0;

        float x;
        float y;

        WorldPoint point = new WorldPoint();

        float stepX = (float)world.Width / Resolution.x;
        float stepY = (float)world.Height / Resolution.y;

        for (int i = 0; i < Resolution.y; i++)
        {
            for (int j = 0; j < Resolution.x; j++)
            {
                x = j * stepX;
                y = i * stepY;

                if (world.DebugActiveDistortion) Utility.TorusDistord(world, ref x, ref y, world.NoiseDistord, world.PositionDistord);

                x = (world.Width + x) % world.Width; // x on torus coordinate
                                                     //y = y; // don't change Y, since we don't loop on top
/*
                float sinX = Mathf.Sin(x / world.HalfWidth * Mathf.PI) * world.Width;
                float cosX = Mathf.Sin(x / world.HalfWidth * Mathf.PI) * world.Width;

                if(sinX > 0)
                {
                    colorMap[index++] = Color.Lerp(Color.white, Color.red, sinX / world.Width);
                }
                else
                {
                    colorMap[index++] = Color.Lerp(Color.white, Color.blue, -sinX / world.Width);
                }
                continue;
*/
                try
                {
                    point.Calibrate(world, x, y);
                    colorMap[index] = point.GetColor();
                }
                catch (Exception e)
                {
                    colorMap[index] = Color.red;
                    Debug.LogError(e);
                }
                

                index++;
            }
        }

        Texture2D texture = new Texture2D(Resolution.x, Resolution.y);
        texture.filterMode = FilterMode.Point;
        texture.SetPixels(colorMap);
        texture.Apply();

        return Sprite.Create(texture, new Rect(0.0f, 0.0f, Resolution.x, Resolution.y), new Vector2(0, 0), 1);
    }

    public void Generate(Func<World, Sprite> textureFunc, World world)
    {
        #region Position texture parents
        _bottomLeft.position = new Vector3(0, 0);
        _bottomRight.position = new Vector3(world.Width, 0);
        _topLeft.position = new Vector3(0, world.Height);
        _topRight.position = new Vector3(world.Width, world.Height);

        Vector3 scale = new Vector3((float)world.Width / Resolution.x, (float)world.Height / Resolution.y, 1);

        _bottomLeft.transform.localScale = scale;
        _bottomRight.transform.localScale = scale;
        _topLeft.transform.localScale = scale;
        _topRight.transform.localScale = scale;
        #endregion

        Sprite terrainSprite = textureFunc(world);
        foreach (SpriteRenderer renderer in _renderers)
        {
            renderer.sprite = terrainSprite;
        }
    }
}
