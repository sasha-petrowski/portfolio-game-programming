﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Noises
{
    [System.Serializable]
    public struct NoiseSettings
    {
        public float Scale;
        public float Lacunarity;
        public float Persistance;
    }
    public static class Noise
    {
        public static OpenSimplexNoise SimplexNoise;

        public static int Seed;

        public static void InitNoise(int seed)
        {
            Seed = seed;

            SimplexNoise = new OpenSimplexNoise(Seed);
        }

        public static float Simplex3D(NoiseData noiseData, float x, float y, float z)
        {
            float combinedNoise = 0;
            float combinedAmplitude = 0;

            foreach(NoiseLayer layer in noiseData.Layers)
            {
                /*
                for (int o = 0; o < layer.Settings.Octaves; o++)
                {
                    noise = noise * (1 - amplitude) + (float)SimplexNoise.Evaluate((x / layer.Settings.Scale * frequency), (y / layer.Settings.Scale * frequency), (z / layer.Settings.Scale * frequency)) * amplitude;

                    amplitude *= layer.Settings.Persistance;
                    frequency *= layer.Settings.Lacunarity;
                }

                combinedNoise += noise * layer.Amplitude;
                combinedAmplitude += layer.Amplitude;
                */
                
                combinedNoise += (float)SimplexNoise.Evaluate((x / layer.Scale), (y / layer.Scale), (z / layer.Scale)) * layer.Amplitude;
                combinedAmplitude += layer.Amplitude;
            }
            float value = (((combinedNoise / combinedAmplitude) - noiseData.RemapMin) / (noiseData.RemapMax - noiseData.RemapMin) * (noiseData.Max - noiseData.Min) + noiseData.Min);
            if (noiseData.InvertOverMax && value >= noiseData.Max)
            {
                value = noiseData.Max - (value - noiseData.Max);
            }
            else if(noiseData.InvertOverMin && value < noiseData.Min)
            {
                value = noiseData.Min + (noiseData.Min - value);
            }
            return Mathf.Clamp(value, noiseData.Min, noiseData.Max);
            //return Mathf.Clamp(((combinedNoise / combinedAmplitude) - noiseData.RemapMin) / (noiseData.RemapMax - noiseData.RemapMin), noiseData.Min, noiseData.Max);
        }
    }
}
