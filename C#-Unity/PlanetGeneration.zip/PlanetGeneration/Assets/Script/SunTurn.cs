using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SunTurn : MonoBehaviour
{
    public float DayTime;
    public float YearTime;

    public Material Skybox;

    // Update is called once per frame
    void Update()
    {
        float longitude = 360 * ((Time.time / DayTime) % 1f);
        float latitude = 23.5f * Mathf.Cos(Time.time / YearTime);

        Vector3 angle = new Vector3(latitude, longitude, 0);

        transform.rotation = Quaternion.Euler(angle);

        Skybox.SetVector("_SunDirection", -transform.forward);
    }
}
