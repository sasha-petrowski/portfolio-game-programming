using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;
public class PlayerController : MonoBehaviour
{
    [SerializeField]
    private Transform _camera;
    [SerializeField]
    private Transform _lookAtPlayer;
    [SerializeField]
    private Material _skybox;

    public float MinHeight = 50f;

    public float Speed = 50f;
    public float SprintMultiplier = 10f;

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;

        AlignToOrbit();
    }

    public void Update()
    {
        // Movement
        float sprint = (Input.GetKey(KeyCode.LeftShift) ? SprintMultiplier : 1);
        Vector3 direction = new Vector3(Input.GetAxisRaw("Horizontal"), (Input.GetKey(KeyCode.A) ? -1 : 0) + (Input.GetKey(KeyCode.E) ? 1 : 0), Input.GetAxisRaw("Vertical"));

        float magnitude = direction.magnitude;

        if (magnitude > 0)
        {
            direction /= magnitude;

            // rotate direction toward camera (but only on the y Axis)
            Vector3 yOnly = _camera.transform.localEulerAngles;
            yOnly.x = 0;
            yOnly.z = 0;

            // dark trigo magic
            direction = Quaternion.Euler(yOnly) * direction;

            // align direction with angle of player
            direction = transform.TransformDirection(direction);

            // add direction multiplied by speed and deltatime
            transform.position += direction * Time.deltaTime * Speed * sprint;
        }

        AlignToOrbit();
    }

    public void AlignToOrbit()
    {
        Vector3 normal = transform.position - _lookAtPlayer.transform.position;
        Vector3 forwardsVector = -Vector3.Cross(normal, transform.right);

        transform.rotation = Quaternion.LookRotation(forwardsVector, normal);

        _lookAtPlayer.rotation = transform.rotation;

        _skybox.SetVector("_ViewerDirection", transform.up);
    }
}
