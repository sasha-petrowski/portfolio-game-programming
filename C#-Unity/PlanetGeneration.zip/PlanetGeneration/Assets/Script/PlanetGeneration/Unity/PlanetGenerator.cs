using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Noises;
using PlanetGeneration.MeshGeneration;

namespace PlanetGeneration
{
    public class PlanetGenerator : MonoBehaviour
    {
        [SerializeField]
        private Transform _chunkLoader;
        public PlanetSettings PlanetSettings;


        private Planet _planet;

        public void InitRequired()
        {
            Planet.Settings = PlanetSettings;
            Noise.InitNoise(PlanetSettings.NoiseSeed);
        }

        private void Start()
        {
            InitRequired();

            _planet = new Planet();
            _planet.UpdateRootSubs(_chunkLoader.position);

            // Generate "Low" LOD Planet
            Vector3[] vertices = PlanetUtility.IsocahedronVertex;
            int subLevel = 6;

            for (int i = 0; i < PlanetUtility.IsocahedronFaces.Length; i++)
            {
                Vector3Int face = PlanetUtility.IsocahedronFaces[i];
                Shape[] faceShapes = {
                    MeshUtility.TriangleShape(
                        vertices[face.x],
                        (vertices[face.x] + vertices[face.y]).normalized,
                        (vertices[face.z] + vertices[face.x]).normalized, subLevel),

                    MeshUtility.TriangleShape(
                        (vertices[face.x] + vertices[face.y]).normalized,
                        vertices[face.y],
                        (vertices[face.y] + vertices[face.z]).normalized, subLevel),

                    MeshUtility.TriangleShape(
                        (vertices[face.z] + vertices[face.x]).normalized,
                        (vertices[face.y] + vertices[face.z]).normalized,
                        vertices[face.z], subLevel),

                    MeshUtility.TriangleShape(
                        (vertices[face.x] + vertices[face.y]).normalized,
                        (vertices[face.y] + vertices[face.z]).normalized,
                        (vertices[face.z] + vertices[face.x]).normalized, subLevel)
                };

                GameObject parentObject = new GameObject($"BigFace.{ i }");
                parentObject.transform.SetParent(transform);
                for (int n = 0; n < faceShapes.Length; n++)
                {
                    Mesh mesh = MeshUtility.SimpleMesh(faceShapes[n]);

                    GameObject meshObject = new GameObject($"Face.{ n }");
                    meshObject.transform.SetParent(parentObject.transform);
                    meshObject.transform.localScale = Vector3.one * 0.9975f;

                    // Add a mesh filter and set the mesh to our mesh.
                    MeshFilter meshFilter = meshObject.AddComponent<MeshFilter>();
                    meshFilter.mesh = mesh;

                    MeshRenderer meshRendererObject = meshObject.AddComponent<MeshRenderer>();

                    meshRendererObject.material = Planet.Settings.MapMat;

                }
            }
        }
        private void Update()
        {
            _planet.UpdateRootSubs(_chunkLoader.position);
        }
    }
}
