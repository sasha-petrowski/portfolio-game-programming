using UnityEngine;

[CreateAssetMenu(fileName = "BiomeData", menuName = "PlanetGeneration/BiomeData")]
public class BiomeData : ScriptableObject
{
    public Gradient TerrainGradient;
    public Color SeaColor;
    public Color RiverColor;
}
