using System.Collections;
using System.Collections.Generic;
using UnityEngine;



[CreateAssetMenu(fileName = "BiomeSettings", menuName = "PlanetGeneration/BiomeSettings")]
public class BiomeSettings : ScriptableObject
{
    public List<BiomeData> BiomesOld;

    [System.Serializable]
    public class BiomeList
    {
        public string Name;
        public List<BiomeData> Datas;
    }

    public List<BiomeList> Biomes;
    
    public BiomeData Get(float temperature, float precipitation)
    {
        /*
        if(temperature < -0.33f)
            return BiomesOld[0];

        else if (temperature < 0.33f)
            return BiomesOld[1];

        else
            return BiomesOld[2];
        */
        float remapedTemp = temperature * 0.5f + 0.5f;
        int tempIndex = Mathf.RoundToInt(Mathf.Clamp(remapedTemp * Biomes.Count, 0, Biomes.Count - 1));

        int precIndex = Mathf.RoundToInt(Mathf.Clamp(precipitation * Biomes[tempIndex].Datas.Count, 0, Biomes[tempIndex].Datas.Count - 1));

        return Biomes[tempIndex].Datas[precIndex];
    }
}
