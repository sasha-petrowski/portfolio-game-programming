using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PlanetGeneration
{
    [CreateAssetMenu(fileName = "PlanetSettings", menuName = "PlanetGeneration/PlanetSettings")]
    public class PlanetSettings : ChangeData
    {
        private const float SMALLFEATURE = 0.1f;
        private bool _hasChanged;
        public override bool HasChanged()
        {
            if (_hasChanged || LandNoise.Generate || CliffNoise.Generate || ElevationDetailNoise.Generate || PrecipitationNoise.Generate || TemperatureNoise.Generate || ClimateDetailNoise.Generate)
            {
                LandNoise.Generate = false;
                CliffNoise.Generate = false;
                ElevationDetailNoise.Generate = false;
                PrecipitationNoise.Generate = false;
                TemperatureNoise.Generate = false;
                ClimateDetailNoise.Generate = false;
                _hasChanged = false;
                return true;
            }
            return false;
        }

        public Material MapMat;

        [Header("Biomes")]
        public BiomeSettings Biomes;
        public float BiomeBlend;
        [Space]

        [Header("Noise Refs")]
        public NoiseData LandNoise;
        public NoiseData CliffNoise;
        public NoiseData ElevationDetailNoise;

        public NoiseData PrecipitationNoise;
        public NoiseData TemperatureNoise;
        public NoiseData ClimateDetailNoise;

        [Header("Noise Blending")]
        [Tooltip("How much the DetailNoise will blend with LandNoise and CliffNoise")]
        public float DetailBlend = 0.05f;

        [Header("Planet")]
        public int NoiseSeed;
        public AnimationCurve HeightCurve;
        public float MaxHeight = 500f;
        public float Perimeter = 75398f;
        public float Radius = 12000f;

        [Header("Geological features")]
        // Rivers
        [Range(0, SMALLFEATURE)]
        public float RiverWidth = 0.01f;
        [Range(0, SMALLFEATURE)]
        public float RiverDepth = 0.0025f;
        [Range(0, 1)]
        public float RiverSeaLenght = 0.01f;
        [Range(0, 1)]
        public float RiverSeaBlend = 0.05f;

        [Space]
        // Sea
        [Range(0, 1)]
        public float SeaLevel = 0.4f;
        [Range(0, 1)]
        [Tooltip("Below this point Islands can start appearing")]
        public float DeepSeaLevel = 0.3f;
        [Range(0, 1)]
        public float CoastLenght = 0.075f;
        [Range(0, 1)]
        public float IslandCoastLenght = 0.1f;
        public float IslandHeightMultiplier = 2f;

        [Space]
        // Mountains
        [Range(0, 1)]
        public float MountainLevel = 0.7f;
        [Range(0, 1)]
        public float SnowLevel = 0.82f;

        [Space]
        [Header("Temperature")]
        [Tooltip("How much the TemperatureNoise will blend with the Equator Falloff map")]
        public float TemperatureEquatorBlend = 0.33f;

        [Space]
        [Range(0, 1)]
        public float TemperatureCoastLenght = 0.15f;
        [Range(0, 1)]
        [SerializeField]
        private float _temperatureCoastBlend = 0.25f;

        [Space]

        [Range(-1, 0)]
        public float LowTemperatureLevel = -0.33f;
        public float LowTemperature = -10;

        [Space]
        [Range(0, 1)]
        public float HighTemperatureLevel = 0.5f;
        public float HighTemperature = 30;

        [Space]
        [Header("Precipitation")]
        [Range(0, 1)]
        public float PrecipitationEquatorBlend = 0.30f;
        [Range(0, 1)]
        public float PrecipitationIslandOffset = 0.25f;



        [Header("Color Debug")]
        public bool DrawElevation;
        public bool DrawTemperature;
        public bool DrawPrecipitation;
        public bool DrawPrecipitationLatitude;
        public bool DrawClimate;
        public bool DrawOceanMask;
        public bool DrawRiverMask;
        public bool Grayscale;
        #region Computed fields

        private void OnValidate()
        {
            _hasChanged = true;

            CliffLevel = SeaLevel + CoastLenght;

            IslandLevel = DeepSeaLevel + IslandCoastLenght;

            TemperatureCoastBlend = _temperatureCoastBlend / TemperatureCoastLenght;

            AVGTemperatureLevel = (LowTemperatureLevel + HighTemperatureLevel) * 0.5f;
            AVGTemperature = (LowTemperature + HighTemperature) * 0.5f;
        }

        [HideInInspector]
        public float CliffLevel;
        [HideInInspector]
        public float IslandLevel;
        [HideInInspector]
        public float TemperatureCoastBlend;

        [HideInInspector]
        public float AVGTemperatureLevel;
        [HideInInspector]
        public float AVGTemperature;

        #endregion
    }

}