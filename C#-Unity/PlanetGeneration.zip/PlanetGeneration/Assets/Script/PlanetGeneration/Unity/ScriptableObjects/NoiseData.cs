using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Noises;

[System.Serializable]
public struct NoiseLayer
{
    public float Amplitude;
    public float Scale;
    //public NoiseSettings Settings;
}

[CreateAssetMenu(fileName = "NoiseData", menuName = "Noise/NoiseData")]
public class NoiseData : ScriptableObject
{
    public bool Generate;
    public float RemapMin = 0;
    public float RemapMax = 1;

    public float Min = 0;
    public float Max = 1;

    public bool InvertOverMax = false;
    public bool InvertOverMin = false;

    public List<NoiseLayer> Layers;


    private void OnValidate()
    {
        Generate = true;
    }
}
