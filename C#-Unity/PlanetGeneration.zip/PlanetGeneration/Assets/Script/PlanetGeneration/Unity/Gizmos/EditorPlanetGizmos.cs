using PlanetGeneration;
using PlanetGeneration.MeshGeneration;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EditorPlanetGizmos : UpdatableGizmo
{
    [SerializeField]
    private MeshFilter _meshFilter;
    [SerializeField]
    private MeshRenderer _meshRenderer;

    [Tooltip("0 : Goldberg\n1 : Icosahedron Face")]
    [Range(0, 1)]
    public int ShapeToDraw;
    [Range(0, 19)]
    public int FaceToDraw;
    [Range(0.01f, 1)]
    public float ShapeSize;
    [Range(0, 4)]
    public int Subdivisions;

    public Shape Shape;

    private bool _changed = false;

    [Header("Debug Options")]
    public bool DrawUV;
    public bool DrawTemperature;
    public bool DrawPentagons;
    public bool DrawHexagons;
    public bool DrawSubdivisions;
    public bool DrawCliffs;


    private void OnValidate()
    {
        _changed = true;
    }


    private void Start()
    {
        gameObject.SetActive(false);
    }

    private void GizmoUV()
    {
        foreach (Vertex v in Shape.Vertices)
        {
            //UnityEditor.Handles.Label(v.Position, v.UV.ToString());
        }
    }
    private void GizmoTemperature()
    {
        foreach (Vertex v in Shape.Vertices)
        {
            UnityEditor.Handles.Label(v.Position, v.GenerationData.TemperatureValue.ToString());
        }
    }
    private void GizmoPentagons()
    {
        foreach (Vertex vertex in Shape.Vertices)
        {
            float size = 1.02f;
            if (vertex.Edges.Count == 5)
            {
                Gizmos.color = new Color(1, 1, 1, 1);
                Gizmos.DrawLine(vertex.Normal * vertex.Height, vertex.Normal * vertex.Height * 1.25f);
                Vector3 lastPosition = (vertex.Normal + vertex.Edges[0].Other(vertex).Normal + vertex.Edges[^1].Other(vertex).Normal) / 3f * vertex.Height * size;
                for (int i = 0; i < vertex.Edges.Count; i++)
                {
                    Vector3 position = (vertex.Normal + vertex.Edges[i].Other(vertex).Normal + vertex.Edges[(i + 1) % vertex.Edges.Count].Other(vertex).Normal) / 3f * vertex.Height * size;
                    Gizmos.DrawLine(lastPosition, position);
                    lastPosition = position;
                }
            }
        }
    }
    private void GizmoHexagons()
    {
        float distance = 1.00001f;
        Gizmos.color = new Color(0, 0, 1, 0.75f);

        foreach (Vertex vertex in Shape.Vertices)
        {
            if (vertex.Edges.Count != 5)
            {
                if (vertex.Edges.Count == 4)
                {
                    int leftmostIndex = 0;
                    for (int i = 0; i < vertex.Edges.Count; i++)
                    {
                        if (vertex.Edges[i].Other(vertex).Edges.Count < 6 && !vertex.Edges[(vertex.Edges.Count + i - 1) % vertex.Edges.Count].Other(vertex).IsLinkedTo(vertex.Edges[i].Other(vertex)))
                        {
                            leftmostIndex = i;
                            i = vertex.Edges.Count;
                        }
                    }

                    Vertex A = vertex.Edges[(leftmostIndex) % vertex.Edges.Count].Other(vertex);
                    Vertex B = vertex.Edges[(leftmostIndex + 1) % vertex.Edges.Count].Other(vertex);
                    Vertex C = vertex.Edges[(leftmostIndex + 2) % vertex.Edges.Count].Other(vertex);
                    Vertex D = vertex.Edges[(leftmostIndex + 3) % vertex.Edges.Count].Other(vertex);

                    Vector3 left = (A.Normal + vertex.Normal) / 2f * vertex.Height * distance;
                    Vector3 vAB = (A.Normal + B.Normal + vertex.Normal) / 3f * vertex.Height * distance;
                    Vector3 vBC = (B.Normal + C.Normal + vertex.Normal) / 3f * vertex.Height * distance;
                    Vector3 vCD = (C.Normal + D.Normal + vertex.Normal) / 3f * vertex.Height * distance;
                    Vector3 right = (D.Normal + vertex.Normal) / 2f * vertex.Height * distance;

                    Gizmos.DrawLine(left, vAB);
                    Gizmos.DrawLine(vAB, vBC);
                    Gizmos.DrawLine(vBC, vCD);
                    Gizmos.DrawLine(vCD, right);

                }
                else
                {
                    Vector3 lastPosition = (vertex.Normal + vertex.Edges[0].Other(vertex).Normal + vertex.Edges[^1].Other(vertex).Normal) / 3f * vertex.Height * distance;
                    for (int i = 0; i < vertex.Edges.Count; i++)
                    {
                        Vector3 position = (vertex.Normal + vertex.Edges[i].Other(vertex).Normal + vertex.Edges[(i + 1) % vertex.Edges.Count].Other(vertex).Normal) / 3f * vertex.Height * distance;
                        Gizmos.DrawLine(lastPosition, position);
                        lastPosition = position;
                    }
                }
            }
        }
    }
    private void GizmoSubdivision()
    {
        Gizmos.color = new Color(0, 0, 0, 0.25f);
        foreach (Edge edge in Shape.Edges)
        {
            Gizmos.DrawLine(edge.Vertices[0].Normal * edge.Vertices[0].Height, edge.Vertices[1].Normal * edge.Vertices[1].Height);
        }
    }
    private void GizmoCliffs()
    {
        foreach (Vertex vertex in Shape.Vertices)
        {
            if (vertex.GenerationData.LandNoise > Planet.Settings.SeaLevel && vertex.GenerationData.LandNoise < vertex.GenerationData.CliffNoise)
            {
                Gizmos.color = Color.red;
                Gizmos.DrawLine(vertex.Position, vertex.Position + vertex.Normal * -(vertex.GenerationData.LandNoise - vertex.GenerationData.CliffNoise) * 2000f);
            }
            else if (vertex.GenerationData.LandNoise < Planet.Settings.DeepSeaLevel && vertex.GenerationData.CliffNoise < Planet.Settings.IslandLevel)
            {
                Gizmos.color = Color.blue;
                Gizmos.DrawLine(vertex.Position, vertex.Position + vertex.Normal * (Planet.Settings.IslandLevel - vertex.GenerationData.CliffNoise) * 2000f);
            }
        }
    }
    private void OnDrawGizmos()
    {
        if (_changed == true)
        {
            OnGizmoUpdate();
        }
        if (Shape != null)
        {
            if (DrawUV)
            {
                GizmoUV();
            }
            if (DrawTemperature)
            {
                GizmoTemperature();
            }
            if (DrawPentagons)
            {
                GizmoPentagons();
            }
            if (DrawHexagons)
            {
                GizmoHexagons();
            }
            if (DrawSubdivisions)
            {
                GizmoSubdivision();
            }
            if (DrawCliffs)
            {
                GizmoCliffs();
            }
        }
    }
    
    public override void OnGizmoUpdate()
    {
        _changed = false;
        if (!Application.isPlaying)
        {
            switch (ShapeToDraw)
            {
                default:
                    Shape = MeshUtility.PolygonShape(PlanetUtility.IsocahedronVertex, PlanetUtility.IsocahedronFaces, Subdivisions);
                    break;

                case 1:
                    Shape = MeshUtility.TriangleShape(PlanetUtility.IsocahedronVertex[PlanetUtility.IsocahedronFaces[FaceToDraw].x], (PlanetUtility.IsocahedronVertex[PlanetUtility.IsocahedronFaces[FaceToDraw].x] * (1 - ShapeSize) + PlanetUtility.IsocahedronVertex[PlanetUtility.IsocahedronFaces[FaceToDraw].y] * ShapeSize).normalized, (PlanetUtility.IsocahedronVertex[PlanetUtility.IsocahedronFaces[FaceToDraw].x] * (1 - ShapeSize) + PlanetUtility.IsocahedronVertex[PlanetUtility.IsocahedronFaces[FaceToDraw].z] * ShapeSize).normalized, Subdivisions + 2);
                    break;
            }

            Mesh mesh = MeshUtility.SimpleMesh(Shape);
            _meshFilter.mesh = mesh;
        }
    }
}
