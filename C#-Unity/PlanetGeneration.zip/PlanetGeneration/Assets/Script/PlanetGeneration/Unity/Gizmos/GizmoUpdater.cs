using PlanetGeneration;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Noises;

namespace PlanetGeneration
{
    public class GizmoUpdater : MonoBehaviour
    {
        public List<ChangeData> ChangeData;
        [SerializeField]
        private PlanetGenerator _planetGenerator;

        private void Start()
        {
            gameObject.SetActive(false);
        }

        private void OnDrawGizmos()
        {
            if (!Application.isPlaying)
            {
                bool changed = false;
                foreach(ChangeData change in ChangeData)
                {
                    if (change.HasChanged())
                    {
                        changed = true;
                    }
                }

                if (changed)
                {
                    _planetGenerator.InitRequired();
                    UpdateChildren();
                }
            }
        }

        private void UpdateChildren()
        {
            foreach(UpdatableGizmo gizmo in transform.GetComponentsInChildren<UpdatableGizmo>())
            {
                gizmo.OnGizmoUpdate();
            }
        }
    }

}

