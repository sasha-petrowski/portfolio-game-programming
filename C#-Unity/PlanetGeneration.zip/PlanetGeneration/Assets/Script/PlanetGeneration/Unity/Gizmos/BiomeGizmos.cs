using UnityEngine;

public class BiomeGizmos : MonoBehaviour
{
    public BiomeSettings Biomes;
    public float Width;
    public float Height;

    private void Start()
    {
        gameObject.SetActive(false);
    }
    private void OnDrawGizmos()
    {
        if (Biomes == null)
            return;

        int temperatureCount = Biomes.Biomes.Count;
        float temperatureFraction = 1 / (float)temperatureCount;

        for (int i = 0; i < temperatureCount; i++)
        {
            int precipitationCount = Biomes.Biomes[i].Datas.Count;
            float precipitationFraction = 1 / (float)precipitationCount;

            for (int n = 0; n < precipitationCount; n++)
            {
                Gizmos.color = Biomes.Biomes[i].Datas[n].TerrainGradient.Evaluate(0.5f);

                Gizmos.DrawCube(new Vector3(precipitationFraction * (n + 0.5f) * Width, - temperatureFraction * i * Height, 0), new Vector3(precipitationFraction * Width, temperatureFraction * Height, 1));
            }
        }
    }
}
