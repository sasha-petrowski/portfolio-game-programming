using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using PlanetGeneration;
using PlanetGeneration.MeshGeneration;
using Noises;
using System;

public class PlanetFaceGizmo : UpdatableGizmo
{
    [SerializeField]
    private PlanetGenerator _planetGenerator;

    [Range(0, Planet.SUBLEVEL)]
    public int DrawSubLevel;

    [Header("Debug Options")]
    public bool DrawSubdivisions;
    public bool DrawFaces;
    
    public Planet Planet;

    private void Start()
    {
        gameObject.SetActive(false);
    }
    private void OnValidate()
    {
        OnGizmoUpdate();
    }
    
    private void RecursiveDrawSubs(PlanetSubdivision sub)
    {
        Color color = Planet.ColorToSubLevel[sub.SubLevel];
        if (sub.SubLevel != DrawSubLevel)
        {
            color.a = 0.1f;
        }
        else
        {
            if (sub.SubIndex == 0 || (sub.SubIndex & (0b_111 << ((sub.SubLevel - 1) * 3))) == (0b_1 << ((sub.SubLevel - 1) * 3)))
            {
                color.a = 0.25f;
            }
        }


        Gizmos.color = color;
        Gizmos.DrawLine(sub.APos, sub.BPos);
        Gizmos.DrawLine(sub.BPos, sub.CPos);
        Gizmos.DrawLine(sub.CPos, sub.APos);
        if (sub.Subs != null)
        {
            for (int i = 0; i < sub.Subs.Length; i++)
            {
                if (sub.Subs[i] != null)
                {
                    RecursiveDrawSubs(sub.Subs[i]);
                }
            }
        }
    }
    private void DrawPlanetNeighbors(PlanetSubdivision root)
    {

        bool transparentLayer = !(root.SubLevel == DrawSubLevel || root.Subs == null || root.Subs.Length == 0);


        Vector3 center = (root.APos + root.BPos + root.CPos) / 3f;

        Vector3 aPos = root.APos * 0.95f + center * 0.05f;
        Vector3 bPos = root.BPos * 0.95f + center * 0.05f;
        Vector3 cPos = root.CPos * 0.95f + center * 0.05f;

        Vector3 ab = (aPos + bPos) * 0.5f;
        Vector3 bc = (bPos + cPos) * 0.5f;
        Vector3 ca = (cPos + aPos) * 0.5f;

        if (!transparentLayer)
        {
            Gizmos.color = root.Color;
            Gizmos.DrawSphere(center, 500f / (root.SubLevel * root.SubLevel));
        }


        if (root.Nab != null)
        {
            if (root.Ab == null)
            {
                Gizmos.color = Color.black;
            }
            else
            {
                Gizmos.color = Color.white;
            }
            Gizmos.color = Color.Lerp(Gizmos.color, Color.red, 0.25f);
            if (transparentLayer)
            {
                Gizmos.color = new Color(Gizmos.color.r, Gizmos.color.g, Gizmos.color.b, 0.33f);
            }

            Gizmos.DrawLine((root.APos + root.BPos) * 0.5f, center);

            if (!transparentLayer)
            {
                Gizmos.color = new Color(Gizmos.color.r, Gizmos.color.g, Gizmos.color.b, 0.5f);
                Gizmos.DrawLine(ab, aPos);
                Gizmos.DrawLine(ab, bPos);
            }
        }
        if (root.Nbc != null)
        {
            if (root.Bc == null)
            {
                Gizmos.color = Color.black;
            }
            else
            {
                Gizmos.color = Color.white;
            }
            Gizmos.color = Color.Lerp(Gizmos.color, Color.green, 0.25f);
            if (transparentLayer)
            {
                Gizmos.color = new Color(Gizmos.color.r, Gizmos.color.g, Gizmos.color.b, 0.33f);
            }

            Gizmos.DrawLine((root.BPos + root.CPos) * 0.5f, center);

            if (!transparentLayer)
            {
                Gizmos.color = new Color(Gizmos.color.r, Gizmos.color.g, Gizmos.color.b, 0.5f);
                Gizmos.DrawLine(bc, bPos);
                Gizmos.DrawLine(bc, cPos);
            }
        }
        if (root.Nca != null)
        {
            if (root.Ca == null)
            {
                Gizmos.color = Color.black;
            }
            else
            {
                Gizmos.color = Color.white;
            }
            Gizmos.color = Color.Lerp(Gizmos.color, Color.blue, 0.25f);
            if (transparentLayer)
            {
                Gizmos.color = new Color(Gizmos.color.r, Gizmos.color.g, Gizmos.color.b, 0.33f);
            }

            Gizmos.DrawLine((root.CPos + root.APos) * 0.5f, center);

            if (!transparentLayer)
            {
                Gizmos.color = new Color(Gizmos.color.r, Gizmos.color.g, Gizmos.color.b, 0.5f);
                Gizmos.DrawLine(ca, cPos);
                Gizmos.DrawLine(ca, aPos);
            }
        }

        if (root.Subs != null && root.SubLevel != DrawSubLevel)
        {
            for (int i = 0; i < root.Subs.Length; i++)
            {
                DrawPlanetNeighbors(root.Subs[i]);
            }
        }
    }

    private void OnDrawGizmos()
    {
        if (Planet != null)
        {
            if (!Application.isPlaying)
            {
                Planet.UpdateRootSubs(new Vector3(0, _planetGenerator.PlanetSettings.Radius, 0));
            }

            if (DrawSubdivisions)
            {
                for (int i = 0; i < Planet.Subs.Length; i++)
                {
                    RecursiveDrawSubs(Planet.Subs[i]);
                }
                Gizmos.color = Color.black;
                Gizmos.DrawLine(Vector3.zero, new Vector3(0, _planetGenerator.PlanetSettings.Radius, 0) * 2f);

                //Gizmos.color = new Color(0, 0, 0, 0.25f);
                //Gizmos.DrawSphere(CaravanCenter.position, 250);

                Gizmos.color = Color.black;

                foreach (Vector2Int key in Planet.RootSubs.Keys)
                {
                    PlanetSubdivision sub = Planet.RootSubs[key];


                    Gizmos.DrawLine(sub.APos, sub.BPos);
                    Gizmos.DrawLine(sub.BPos, sub.CPos);
                    Gizmos.DrawLine(sub.CPos, sub.APos);
                }
            }

            if (DrawFaces)
            {
                foreach (PlanetSubdivision sub in Planet.Subs)
                {
                    //Handles.Label(sub.Position, $".{ sub.FaceIndex }, s.{ Convert.ToString(sub.SubIndex, toBase: 8),4}");
                    DrawPlanetNeighbors(sub);
                }
            }
        }
    }

    public override void OnGizmoUpdate()
    {
        if(Planet.Settings != null)
        {
            Planet = new Planet();
        }
    }
}
