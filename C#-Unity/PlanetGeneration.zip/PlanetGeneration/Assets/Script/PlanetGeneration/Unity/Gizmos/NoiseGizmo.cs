using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Noises;

public class NoiseGizmo : MonoBehaviour
{
    [Header("Noise")]
    public int NoiseMapSize;
    private float[,] _noiseMap;
    [SerializeField]
    private NoiseData _testNoise;

    [Header("Debug Options")]
    public bool DrawNoise;

    private void Start()
    {
        gameObject.SetActive(false);
    }
    private void OnValidate()
    {
        GenerateNoise();
    }

    private void OnDrawGizmos()
    {
        if (!Application.isPlaying)
        {
            if (_testNoise.Generate)
            {
                _testNoise.Generate = false;

                GenerateNoise();
            }
        }

        if (DrawNoise)
        {
            for (int x = 0; x < NoiseMapSize; x++)
            {
                for (int y = 0; y < NoiseMapSize; y++)
                {
                    Gizmos.color = new Color(_noiseMap[x, y], _noiseMap[x, y], _noiseMap[x, y]);
                    Gizmos.DrawCube(new Vector3(x * 500 - NoiseMapSize * 250, y * 500 - NoiseMapSize * 250, 0), new Vector3(500, 500, 0));
                }
            }
        }
    }

    private void GenerateNoise()
    {
        if (Noise.SimplexNoise == null)
        {
            Noise.InitNoise(0);
        }

        _noiseMap = new float[NoiseMapSize, NoiseMapSize];

        for (int x = 0; x < NoiseMapSize; x++)
        {
            for (int y = 0; y < NoiseMapSize; y++)
            {
                _noiseMap[x, y] = Noise.Simplex3D(_testNoise, x * 500f, y * 500f, 0);
            }
        }
    }
}
