using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class UpdatableGizmo : MonoBehaviour
{
    public abstract void OnGizmoUpdate();
}
