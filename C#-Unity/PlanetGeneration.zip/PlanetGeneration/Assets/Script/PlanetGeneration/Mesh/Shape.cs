﻿using System.Collections.Generic;

namespace PlanetGeneration.MeshGeneration
{
    public class Shape
    {
        public LinkedList<Vertex> Vertices = new LinkedList<Vertex>();
        public LinkedList<Edge> Edges = new LinkedList<Edge>();

        public int Subdivision;

        public void Subdivise(int subdivision)
        {
            for(int i = Subdivision + 1; i <= subdivision; i++)
            {
                Subdivision = i;
                LinkedListNode<Edge> current = Edges.Last;
                while (current != null)
                {
                    Edge edge = current.Value;
                    //Debug.Log($"<color=red>Subdivise Edge : {edge.TMP_name}</color>");
                    current = current.Previous;
                    edge.Subdivise(i);
                }
            }
        }
    }
}
