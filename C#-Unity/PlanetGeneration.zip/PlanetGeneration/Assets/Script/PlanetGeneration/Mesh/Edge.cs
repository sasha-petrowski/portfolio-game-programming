﻿using System;
using System.Collections.Generic;

namespace PlanetGeneration.MeshGeneration
{
    public class Edge
    {
        public string TMP_name;
        public Shape Shape;
        public Vertex[] Vertices { get; private set; } = new Vertex[2];
        public List<Action<Vertex>> OnSubdivised = new List<Action<Vertex>>();

        public Edge(Vertex a, Vertex b)
        {
            TMP_name = $"{a.TMP_name} > {b.TMP_name}";
            //Debug.Log($"<color=green>Create Edge : {TMP_name}</color>");
            Shape = a.Shape;
            Shape.Edges.AddLast(this);
            Vertices[0] = a;
            Vertices[1] = b;
        }

        public void Subdivise(int subdivision)
        {
            Vertex sub = new Vertex(subdivision, Shape, Vertex.AverageNormal(Vertices[0], Vertices[1])/*, (Vertices[0].UV + Vertices[1].UV) * 0.5f*/);
            sub.TMP_name = $"{Vertices[0].TMP_name}{Vertices[1].TMP_name}";

            //Debug.Log($"<color=blue>Create new Vertex : {sub.TMP_name}</color>");

            Vertices[0].LinkSubdivision(sub, this, Vertices[1]);
            Vertices[1].LinkSubdivision(sub, this, Vertices[0]);

            foreach(Action<Vertex> action in OnSubdivised)
            {
                action(sub);
            }
            Shape.Edges.Remove(this);
        }

        public Vertex Other(Vertex current)
        {
            return Vertices[0] != current ? Vertices[0] : Vertices[1];
        }
    }
}
