﻿using System.Collections.Generic;
using UnityEngine;

using Noises;

namespace PlanetGeneration.MeshGeneration
{
    public class Vertex
    {
        public string TMP_name;

        public Shape Shape;
        public int Subdivision;
        public List<Edge> Edges;
        public Vector3 Normal;
        public Vector3 Position;

        public float Height;

        public GenerationData GenerationData;

        public Vertex(int subdivision, Shape shape, Vector3 normal)
        {
            Subdivision = subdivision;
            Shape = shape;
            Shape.Vertices.AddLast(this);
            Edges = new List<Edge>();
            Normal = normal;

            //UV = new Vector2((Mathf.Atan2(Normal.z, Normal.x) / (2f * Mathf.PI)), (Mathf.Asin(Normal.y) / Mathf.PI) + 0.5f);
            /*
            if(UV.x < 0)
            {
                UV.x = -UV.x;
            }
            */

            Vector3 planetPos = Normal * Planet.Settings.Radius;

            GenerationData = new GenerationData(planetPos, normal);

            // No more changes are to be made so we set the Height & Position of the Vertex
            Height = (Planet.Settings.Radius - (Planet.Settings.MaxHeight * (1 - Planet.Settings.HeightCurve.Evaluate(GenerationData.HeightValue))));
            Position = normal * Height;

            /*
            if(normal.y < 0.0025f && normal.y > -0.0025f)
            {
                GenerationData.Color = new Color32(255, 0, 0, 255);
            }
            */
        }
        public void LinkSubdivision(Vertex sub, Edge oldEdge, Vertex other)
        {
            //Debug.Log($"<color=pink>LinkSubdivision, current {TMP_name}, other {other.TMP_name}</color>");
            for (int i = 0; i < Edges.Count; i++)
            {
                Vertex edgeOther = Edges[i].Other(this);
                //Debug.Log($"Look at {Edges[i].TMP_name} edgeOther : ({edgeOther.TMP_name})");
                if (Edges[i] == oldEdge)
                {
                    //Debug.Log($"<color=orange>LinkSubdivision Edge :</color>");
                    Edges[i] = new Edge(this, sub);
                    sub.AddEdge(Edges[i]);
                }
                else if (edgeOther.IsLinkedTo(sub, other, out Vertex directLink))
                {
                    if (directLink != null)
                    {
                        //Debug.Log($"<color=orange>Direct link {sub.TMP_name} to {directLink.TMP_name}:</color>");
                        sub.NewLink(directLink);
                    }
                    else
                    {
                        //Debug.Log($"<color=orange>Subscribe {sub.TMP_name} to {Edges[i].TMP_name}:</color>");
                        Edges[i].OnSubdivised.Add(sub.NewLink);
                    }
                }
            }
        }
        public void NewLink(Vertex other)
        {
            if(!IsLinkedTo(other) && !other.IsLinkedTo(this))
            {
                //Debug.Log($"{Position} - {other.Position}");
                Edge newEdge = new Edge(this, other);
                this.AddEdge(newEdge);
                other.AddEdge(newEdge);
            }
        }
        protected void AddEdge(Edge other)
        {
            Edges.Add(other);
        }
        public bool IsLinkedTo(Vertex other)
        {
            foreach (Edge edge in Edges)
            {
                if (edge.Other(this) == other)
                    return true;
            }
            return false;
        }
        public bool IsLinkedTo(Vertex sub, Vertex other, out Vertex directLink)
        {
            directLink = null;
            foreach (Edge edge in Edges)
            {
                Vertex edgeOther = edge.Other(this);
                if (edgeOther == other)
                    return true;

                if (sub != null && sub != edgeOther && edgeOther.Subdivision == sub.Subdivision)
                {
                    foreach(Edge subEdge in edgeOther.Edges)
                    {
                        if (subEdge.Other(edgeOther) == other)
                        {
                            directLink = edgeOther;
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        public static Vector3 AverageNormal(Vertex a, Vertex b)
        {
            return (a.Normal + b.Normal).normalized;
        }
    }
}
