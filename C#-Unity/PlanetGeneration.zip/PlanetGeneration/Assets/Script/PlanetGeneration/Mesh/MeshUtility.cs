﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using UnityEngine;
using Noises;

namespace PlanetGeneration.MeshGeneration
{
    public static class MeshUtility
    {
        private const float HEXSPLIT = 0.66f;
        private const float HEXONESPLIT = 1f - HEXSPLIT;

        private static void SolveTriangleUV(Vertex a, Vertex b, Vertex c)
        {
            /*
            Vector3 texA = new Vector3(a.UV.x, a.UV.y, 0);
            Vector3 texB = new Vector3(b.UV.x, b.UV.y, 0);
            Vector3 texC = new Vector3(c.UV.x, c.UV.y, 0);
            Vector3 texNormal = Vector3.Cross(texB - texA, texC - texA);

            // if triangle is a "zipper"
            if (texNormal.z > 0 && (a.UV.x < 0.25f || b.UV.x < 0.25f || c.UV.x < 0.25f))
            {
                //Debug.LogWarning("Fixing triangle");
                if (a.UV.x < 0.25f)
                {
                    //Debug.Log("A");
                    a.UV.x += 1f;
                }
                if (b.UV.x < 0.25f)
                {
                    //Debug.Log("B");
                    b.UV.x += 1f;
                }
                if (c.UV.x < 0.25f)
                {
                    //Debug.Log("C");
                    c.UV.x += 1f;
                }
            }
            
            // if triangle is part of a pole (north or south)
            
            if (a.Normal.y == 1 || a.Normal.y == -1)
            {
                a.UV.x = (b.UV.x + c.UV.x) * 0.5f;
            }
            else if (b.Normal.y == 1 || b.Normal.y == -1)
            {
                b.UV.x = (a.UV.x + c.UV.x) * 0.5f;
            }
            else if (c.Normal.y == 1 || c.Normal.y == -1)
            {
                c.UV.x = (a.UV.x + b.UV.x) * 0.5f;
            }
            */
        }
        public static void OrderEdges(Shape shape)
        {
            Matrix4x4 vertexMatrix = new Matrix4x4();

            foreach (Vertex vertex in shape.Vertices)
            {
                vertexMatrix.SetTRS(Vector3.zero, Quaternion.LookRotation(vertex.Normal), Vector3.one);

                //Reorder edges so we can calculate the new vertices positions

                float[] angle = new float[vertex.Edges.Count];
                //Debug.LogWarning($"ordering : {vertex.TMP_name}");
                Vector2 vec;
                for (int i = 0; i < vertex.Edges.Count; i++)
                {
                    vec = vertexMatrix.inverse.MultiplyPoint3x4(vertex.Edges[i].Other(vertex).Normal);
                    angle[i] = Mathf.Atan2(vec.x, vec.y) * Mathf.Rad2Deg;
                }

                Edge tmp_e;
                float tmp_a;
                for (int i = 0; i < vertex.Edges.Count; i++)
                {
                    for (int n = i + 1; n < vertex.Edges.Count; n++)
                    {
                        if (angle[i] < angle[n])
                        {
                            tmp_a = angle[i];
                            tmp_e = vertex.Edges[i];

                            angle[i] = angle[n];
                            angle[n] = tmp_a;

                            vertex.Edges[i] = vertex.Edges[n];
                            vertex.Edges[n] = tmp_e;
                        }
                    }
                }

                if(vertex.Edges.Count == 2 && angle[0] > 90 && angle[1] < -90)
                {
                    tmp_e = vertex.Edges[0];
                    vertex.Edges[0] = vertex.Edges[1];
                    vertex.Edges[1] = tmp_e;
                }
            }
        }
        public static Vector2 SphereUV(Vector3 normal)
        {
            return new Vector2((Mathf.Atan2(normal.z, normal.x) / (2f * Mathf.PI)), (Mathf.Asin(normal.y) / Mathf.PI) + 0.5f);
        }
        public static Shape TriangleShape(Vector3 normalA, Vector3 normalB, Vector3 normalC, int targetSubdivision)
        {
            Shape triangle = new Shape();
            /*
            Vertex vA = new Vertex(0, triangle, normalA, SphereUV(normalA));
            Vertex vB = new Vertex(0, triangle, normalB, SphereUV(normalB));
            Vertex vC = new Vertex(0, triangle, normalC, SphereUV(normalC));
            SolveTriangleUV(vA, vB, vC);
            */

            Vertex vA = new Vertex(0, triangle, normalA);
            Vertex vB = new Vertex(0, triangle, normalB);
            Vertex vC = new Vertex(0, triangle, normalC);

            vA.NewLink(vB);
            vB.NewLink(vC);
            vC.NewLink(vA);


            triangle.Subdivise(targetSubdivision);

            OrderEdges(triangle);

            return triangle;
        }
        public static Shape PolygonShape(Vector3[] vertices, Vector3Int[] faces, int subdivision)
        {
            Shape polygon = new Shape();
            Vertex[] points = new Vertex[vertices.Length];

            for (int i = 0; i < vertices.Length; i++)
            {
                points[i] = new Vertex(0, polygon, vertices[i]/*, SphereUV(vertices[i])*/);
                //points[i].TMP_name = ((char)('A' + i)).ToString();
            }

            for (int i = 0; i < faces.Length; i++)
            {
                points[faces[i].x].NewLink(points[faces[i].y]);
                points[faces[i].y].NewLink(points[faces[i].z]);
                points[faces[i].z].NewLink(points[faces[i].x]);
            }

            polygon.Subdivise(subdivision);

            OrderEdges(polygon);

            return polygon;
        }
        public static Vector3 Position(Vertex vertex, Vector3 nA)
        {
            return vertex.Position * HEXONESPLIT + nA * vertex.Height * HEXSPLIT;
        }
        private static Color32 Lerp(Vertex a, Vertex b, Vertex c)
        {
            return Color32.Lerp(a.GenerationData.Color, Color32.Lerp(b.GenerationData.Color, c.GenerationData.Color, 0.5f), 0.6666f);
        }


        #region SimpleMesh
        public static Mesh SimpleMesh(Shape shape)
        {

            Mesh mesh = new Mesh();

            List<Vector3> vertices = new List<Vector3>(/*shape.Vertices.Count + shape.Edges.Count * 4*/);
            List<Color32> colors = new List<Color32>();
            List<Vector3> normals = new List<Vector3>(/*shape.Vertices.Count + shape.Edges.Count * 4*/);
            List<int> triangles = new List<int>(/*shape.Vertices.Count + shape.Edges.Count * 2*/);
            //List<Vector2> uv = new List<Vector2>(/*shape.Vertices.Count + shape.Edges.Count * 2*/);

            LinkedListNode<Vertex> vertexNode = shape.Vertices.First;
            while (vertexNode != null)
            {
                Vertex vertex = vertexNode.Value;

                if (vertex.Edges.Count == 2)
                {
                    TwoSimpleMesh(vertex, vertices, normals, colors, triangles/*, uv*/);
                }
                else if (vertex.Edges.Count == 4)
                {
                    FourSimpleMesh(vertex, vertices, normals, colors, triangles/*, uv*/);

                }
                else
                {
                    SimpleMesh(vertex, vertices, normals, colors, triangles/*, uv*/);
                }

                vertexNode = vertexNode.Next;
            }

            mesh.SetVertices(vertices);
            mesh.SetNormals(normals);
            mesh.SetColors(colors);
            mesh.SetTriangles(triangles, 0);
            //mesh.SetUVs(0, uv);

            return mesh;
        }
        private static void TwoSimpleMesh(Vertex vertex, List<Vector3> vertices, List<Vector3> normals, List<Color32> colors, List<int> triangles/*, List<Vector2> uv*/)
        {
            int fromIndex = vertices.Count;

            Vertex A = vertex.Edges[0].Other(vertex);
            Vertex B = vertex.Edges[1].Other(vertex);

            Vector3 topPos = (vertex.Position + A.Position + B.Position) / 3f;
            //Vector2 topUV = (vertex.UV + A.UV + B.UV) / 3f;

            Vector3 aPos = (vertex.Position + A.Position) * 0.5f;
            //Vector2 aUV = (vertex.UV + A.UV) * 0.5f;

            Vector3 bPos = (vertex.Position + B.Position) * 0.5f;
            //Vector2 bUV = (vertex.UV + B.UV) * 0.5f;

            Vector3 nLeft = Vector3.Cross(aPos - vertex.Position, topPos - vertex.Position).normalized;
            Vector3 nRight = Vector3.Cross(topPos - vertex.Position, bPos - vertex.Position).normalized;
            Vector3 normal = (nLeft + nRight).normalized;

            #region Hex Vertices
            // Center - 0
            vertices.Add(vertex.Position);
            normals.Add(normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(vertex.UV);

            // Left - 1
            vertices.Add(aPos);
            normals.Add(nLeft);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(aUV);

            // Top - 2
            vertices.Add(topPos);
            normals.Add(normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(topUV);

            // Right - 3
            vertices.Add(bPos);
            normals.Add(nRight);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(bUV);
            #endregion

            #region Triangles
            // Left
            triangles.Add(fromIndex + 1);
            // Top
            triangles.Add(fromIndex + 2);
            // Center
            triangles.Add(fromIndex);

            // Top
            triangles.Add(fromIndex + 2);
            // Right
            triangles.Add(fromIndex + 3);
            // Center
            triangles.Add(fromIndex);
            #endregion
        }
        private static void FourSimpleMesh(Vertex vertex, List<Vector3> vertices, List<Vector3> normals, List<Color32> colors, List<int> triangles/*, List<Vector2> uv*/)
        {
            int fromIndex = vertices.Count;
            int leftmostIndex = 0;
            for (int i = 0; i < vertex.Edges.Count; i++)
            {
                if (vertex.Edges[i].Other(vertex).Edges.Count < 6 && !vertex.Edges[(vertex.Edges.Count + i - 1) % vertex.Edges.Count].Other(vertex).IsLinkedTo(vertex.Edges[i].Other(vertex)))
                {
                    leftmostIndex = i;
                    i = vertex.Edges.Count;
                }
            }
            Vertex A = vertex.Edges[(leftmostIndex) % vertex.Edges.Count].Other(vertex);
            Vertex B = vertex.Edges[(leftmostIndex + 1) % vertex.Edges.Count].Other(vertex);
            Vertex C = vertex.Edges[(leftmostIndex + 2) % vertex.Edges.Count].Other(vertex);
            Vertex D = vertex.Edges[(leftmostIndex + 3) % vertex.Edges.Count].Other(vertex);

            Vector3 leftPos = (vertex.Position + A.Position) * 0.5f;
            //Vector2 leftUV = (vertex.UV + A.UV) * 0.5f;

            Vector3 ABPos = (A.Position + B.Position + vertex.Position) / 3f;
            //Vector3 ABUV = (A.UV + B.UV + vertex.UV) / 3f;

            Vector3 BCPos = (B.Position + C.Position + vertex.Position) / 3f;
            //Vector3 BCUV = (B.UV + C.UV + vertex.UV) / 3f;

            Vector3 CDPos = (C.Position + D.Position + vertex.Position) / 3f;
            //Vector3 CDUV = (C.UV + D.UV + vertex.UV) / 3f;

            Vector3 rightPos = (vertex.Position + D.Position) * 0.5f;
            //Vector2 rightUV = (vertex.UV + D.UV) * 0.5f;

            Vector3 nLeft = Vector3.Cross(leftPos - vertex.Position, ABPos - vertex.Position).normalized;
            Vector3 nAB= Vector3.Cross(ABPos - vertex.Position, BCPos - vertex.Position).normalized;
            Vector3 nBC = Vector3.Cross(BCPos - vertex.Position, CDPos - vertex.Position).normalized;
            Vector3 nCD = Vector3.Cross(CDPos - vertex.Position, rightPos - vertex.Position).normalized;

            #region Vertices
            // Center - 0
            vertices.Add(vertex.Position);
            normals.Add((nLeft + nAB + nBC + nCD).normalized);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(vertex.UV);

            // Hex - 1 (Left)
            vertices.Add(leftPos);
            normals.Add(nLeft);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(leftUV);

            // Hex - 2 (AB)
            vertices.Add(ABPos);
            normals.Add(nAB);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(ABUV);

            // Hex - 3 (BC)
            vertices.Add(BCPos);
            normals.Add(nBC);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(BCUV);

            // Hex - 4 (CD)
            vertices.Add(CDPos);
            normals.Add(nCD);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(CDUV);

            // Hex - 5 (Right)
            vertices.Add(rightPos);
            normals.Add(nCD);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(rightUV);
            #endregion

            #region Triangles
            // left
            triangles.Add(fromIndex + 1);
            // vAB
            triangles.Add(fromIndex + 2);
            //center
            triangles.Add(fromIndex);

            // vAB
            triangles.Add(fromIndex + 2);
            // vBC
            triangles.Add(fromIndex + 3);
            //center
            triangles.Add(fromIndex);

            // vBC
            triangles.Add(fromIndex + 3);
            // vCD
            triangles.Add(fromIndex + 4);
            //center
            triangles.Add(fromIndex);

            // vCD
            triangles.Add(fromIndex + 4);
            // right
            triangles.Add(fromIndex + 5);
            //center
            triangles.Add(fromIndex);
            #endregion
        }
        private static void SimpleMesh(Vertex vertex, List<Vector3> vertices, List<Vector3> normals, List<Color32> colors, List<int> triangles/*, List<Vector2> uv*/)
        {
            int fromIndex = vertices.Count;

            vertices.Add(vertex.Position);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(vertex.UV);
            Vector3 avgNormal = Vector3.zero;
            for (int i = 0; i < vertex.Edges.Count; i++)
            {
                Vertex A = vertex.Edges[i].Other(vertex);
                Vertex B = vertex.Edges[(i + 1) % vertex.Edges.Count].Other(vertex);
                Vertex C = vertex.Edges[(i + 2) % vertex.Edges.Count].Other(vertex);

                Vector3 aPos = (vertex.Position + A.Position + B.Position) / 3f;
                //Vector3 aUV = (vertex.UV + A.UV + B.UV) / 3f;

                Vector3 bPos = (vertex.Position + B.Position + C.Position) / 3f;

                Vector3 normal = Vector3.Cross(aPos - vertex.Position, bPos - vertex.Position).normalized;
                
                avgNormal += normal;
                #region Vertices
                // Hex-A
                vertices.Add(aPos);
                normals.Add(normal);
                colors.Add(vertex.GenerationData.Color);
                //uv.Add(aUV);
                /*
                // Hex-B
                vertices.Add(bPos);
                normals.Add(vertex.Normal);
                colors.Add(vertex.Color);
                */
                #endregion

                #region Triangles
                /*HEX TRIANGLE */
                // Hex-A
                triangles.Add(fromIndex + 1 + i);
                // Hex-B
                triangles.Add(fromIndex + 1 + ((i + 1) % vertex.Edges.Count));
                // Vertex
                triangles.Add(fromIndex);
                #endregion
            }
            normals[fromIndex] = avgNormal.normalized;
        }
        #endregion

        #region ComplexMesh
        public static Mesh ComplexMesh(Shape shape)
        {

            Mesh mesh = new Mesh();

            List<Vector3> vertices = new List<Vector3>(/*shape.Vertices.Count + shape.Edges.Count * 4*/);
            List<Color32> colors = new List<Color32>();
            List<Vector3> normals = new List<Vector3>(/*shape.Vertices.Count + shape.Edges.Count * 4*/);
            List<int> triangles = new List<int>(/*shape.Vertices.Count + shape.Edges.Count * 2*/);
            //List<Vector2> uv = new List<Vector2>();

            LinkedListNode<Vertex> vertexNode = shape.Vertices.First;
            while (vertexNode != null)
            {
                Vertex vertex = vertexNode.Value;

                if(vertex.Edges.Count == 2)
                {
                    TwoComplexMesh(vertex, vertices, normals, colors, triangles/*, uv*/);
                }
                else if (vertex.Edges.Count == 4)
                {
                    FourComplexMesh(vertex, vertices, normals, colors, triangles/*, uv*/);
                }
                else
                {
                    ComplexMesh(vertex, vertices, normals, colors, triangles/*, uv*/);
                }

                vertexNode = vertexNode.Next;
            }
            
            mesh.SetVertices(vertices);
            mesh.SetNormals(normals);
            mesh.SetColors(colors);
            mesh.SetTriangles(triangles, 0);
            //mesh.SetUVs(0, uv);
            return mesh;
        }
        private static void TwoComplexMesh(Vertex vertex, List<Vector3> vertices, List<Vector3> normals, List<Color32> colors, List<int> triangles/*, List<Vector2> uv*/)
        {
            int fromIndex = vertices.Count;

            Vertex A = vertex.Edges[0].Other(vertex);
            Vertex B = vertex.Edges[1].Other(vertex);

            Vector3 nAvg = (vertex.Normal + A.Normal + B.Normal).normalized;
            Vector3 topPos = Position(vertex, nAvg);
            //Vector2 topUV = UV(vertex, (vertex.UV + A.UV + B.UV) / 3f);

            Vector3 nA = (vertex.Normal + A.Normal).normalized;
            Vector3 aPos = Position(vertex, nA);
            //Vector2 aUV = UV(vertex, (vertex.UV + A.UV) * 0.5f);

            Vector3 nB = (vertex.Normal + B.Normal).normalized;
            Vector3 bPos = Position(vertex, nB);
            //Vector2 bUV = UV(vertex, (vertex.UV + B.UV) * 0.5f);

            Vector3 avgPos = nAvg * (vertex.Height + A.Height + B.Height) / 3f;
            //Vector2 avgUV = (vertex.UV + A.UV + B.UV) / 3f;

            Vector3 linkAPos = Position(A, nA);
            Vector3 nLinkA = Vector3.Cross(linkAPos - aPos, topPos - aPos).normalized;
            //Vector2 linkAUV = UV(A, (vertex.UV + A.UV) * 0.5f);

            Vector3 linkBPos = Position(B, nAvg);
            Vector3 nLinkB = Vector3.Cross(linkBPos - topPos, bPos - topPos).normalized;
            //Vector2 linkBUV = UV(B, (vertex.UV + B.UV) * 0.5f);

            #region Hex Vertices
            // Center - 0
            vertices.Add(vertex.Position);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(vertex.UV);

            // Left - 1
            vertices.Add(aPos);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(aUV);

            // Top - 2
            vertices.Add(topPos);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(topUV);

            // Right - 3
            vertices.Add(bPos);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(bUV);
            #endregion

            #region Link Vertices
            // 0 - A - 4
            vertices.Add(aPos);
            normals.Add(nLinkA);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(aUV);

            // 0 - Top - 5
            vertices.Add(topPos);
            normals.Add(nLinkA);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(topUV);

            // 0 - Link - 6
            vertices.Add(linkAPos);
            normals.Add(nLinkA);
            colors.Add(A.GenerationData.Color);
            //uv.Add(linkAUV);

            // 1 - Top - 7
            vertices.Add(topPos);
            normals.Add(nLinkB);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(topUV);

            // 1 - B - 8
            vertices.Add(bPos);
            normals.Add(nLinkB);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(bUV);

            // 1 - Link - 9
            vertices.Add(linkBPos);
            normals.Add(nLinkB);
            colors.Add(B.GenerationData.Color);
            //uv.Add(linkBUV);

            // smol - AVg - 10
            vertices.Add(avgPos);
            normals.Add(nLinkB);
            colors.Add(Lerp(vertex, A, B));
            //uv.Add(avgUV);

            #endregion

            #region Triangles
            #region Hex triangles
            // Left
            triangles.Add(fromIndex + 1);
            // Top
            triangles.Add(fromIndex + 2);
            // Center
            triangles.Add(fromIndex);

            // Top
            triangles.Add(fromIndex + 2);
            // Right
            triangles.Add(fromIndex + 3);
            // Center
            triangles.Add(fromIndex);
            #endregion
            #region Link triangles

            /* LINK TRIANGLE (Big) ( A )*/
            // Dupe-A
            triangles.Add(fromIndex + 4);
            // Link
            triangles.Add(fromIndex + 6);
            // Dupe-Top
            triangles.Add(fromIndex + 5);

            /* LINK TRIANGLE (Big) ( B )*/

            // Dupe-Top
            triangles.Add(fromIndex + 7);
            // Link
            triangles.Add(fromIndex + 9);
            // Dupe-B
            triangles.Add(fromIndex + 8);

            /* LINK TRIANGLE (Smol) */

            // Dupe-Top
            triangles.Add(fromIndex + 7);
            // AVG
            triangles.Add(fromIndex + 10);
            // Link
            triangles.Add(fromIndex + 9);

            #endregion
            #endregion
        }
        private static void FourComplexMesh(Vertex vertex, List<Vector3> vertices, List<Vector3> normals, List<Color32> colors, List<int> triangles/*, List<Vector2> uv*/)
        {
            int fromIndex = vertices.Count;
            int leftmostIndex = 0;
            for (int i = 0; i < vertex.Edges.Count; i++)
            {
                if (vertex.Edges[i].Other(vertex).Edges.Count < 6 && !vertex.Edges[(vertex.Edges.Count + i - 1) % vertex.Edges.Count].Other(vertex).IsLinkedTo(vertex.Edges[i].Other(vertex)))
                {
                    leftmostIndex = i;
                    i = vertex.Edges.Count;
                }
            }
            Vertex A = vertex.Edges[(leftmostIndex) % vertex.Edges.Count].Other(vertex);
            Vertex B = vertex.Edges[(leftmostIndex + 1) % vertex.Edges.Count].Other(vertex);
            Vertex C = vertex.Edges[(leftmostIndex + 2) % vertex.Edges.Count].Other(vertex);
            Vertex D = vertex.Edges[(leftmostIndex + 3) % vertex.Edges.Count].Other(vertex);

            Vector3 nLeft = (A.Normal + vertex.Normal).normalized;
            Vector3 nAB = (A.Normal + B.Normal + vertex.Normal).normalized;
            Vector3 nBC = (B.Normal + C.Normal + vertex.Normal).normalized;
            Vector3 nCD = (C.Normal + D.Normal + vertex.Normal).normalized;
            Vector3 nRight = (D.Normal + vertex.Normal).normalized;

            Vector3 leftPos = Position(vertex, nLeft);
            //Vector2 leftUV = UV(vertex, (vertex.UV + A.UV) * 0.5f);

            Vector3 ABPos = Position(vertex, nAB);
            //Vector2 ABUV = UV(vertex, (vertex.UV + A.UV + B.UV) / 3f);

            Vector3 BCPos = Position(vertex, nBC);
            //Vector2 BCUV = UV(vertex, (vertex.UV + B.UV + C.UV) / 3f);

            Vector3 CDPos = Position(vertex, nCD);
            //Vector2 CDUV = UV(vertex, (vertex.UV + C.UV + D.UV) / 3f);

            Vector3 rightPos = Position(vertex, nRight);
            //Vector2 rightUV = UV(vertex, (vertex.UV + D.UV) * 0.5f);

            Vector3 leftLinkPos = Position(A, nLeft);
            //Vector2 linkleftUV = UV(A, (vertex.UV + A.UV) * 0.5f);

            Vector3 ABLinkPos = Position(B, nAB);
            //Vector2 linkABUV = UV(B, (vertex.UV + A.UV + B.UV) / 3f);

            Vector3 BCLinkPos = Position(C, nBC);
            //Vector2 linkBCUV = UV(C, (vertex.UV + B.UV + C.UV) / 3f);

            Vector3 CDLinkPos = Position(D, nCD);
            //Vector2 linkCDUV = UV(D, (vertex.UV + C.UV + D.UV) / 3f);

            Vector3 leftNormal = Vector3.Cross(leftLinkPos - leftPos, ABPos - leftPos).normalized;
            Vector3 ABNormal = Vector3.Cross(ABLinkPos - ABPos, BCPos - ABPos).normalized;
            Vector3 BCNormal = Vector3.Cross(BCLinkPos - BCPos, CDPos - BCPos).normalized;
            Vector3 CDNormal = Vector3.Cross(CDLinkPos - CDPos, rightPos - CDPos).normalized;

            #region Vertices

            #region Hex Vertices
            // Center - 0
            vertices.Add(vertex.Position);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(vertex.UV);

            // Hex - 1 (Left)
            vertices.Add(leftPos);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(leftUV);

            // Hex - 2 (AB)
            vertices.Add(ABPos);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(ABUV);

            // Hex - 3 (BC)
            vertices.Add(BCPos);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(BCUV);

            // Hex - 4 (CD)
            vertices.Add(CDPos);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(CDUV);

            // Hex - 5 (Right)
            vertices.Add(rightPos);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(rightUV);
            #endregion

            #region Link Vertices
            #region Left ( 6 -  8)
            // Left - 6 (Left)
            vertices.Add(leftPos);
            normals.Add(leftNormal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(leftUV);
            // Left - 7 (Link)
            vertices.Add(leftLinkPos);
            normals.Add(leftNormal);
            colors.Add(A.GenerationData.Color);
            //uv.Add(linkleftUV);
            // Left - 8 (AB)
            vertices.Add(ABPos);
            normals.Add(leftNormal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(ABUV);
            #endregion
            #region AB   ( 9 - 12)
            // AB - 9 (AB)
            vertices.Add(ABPos);
            normals.Add(ABNormal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(ABUV);
            // AB - 10 (Link)
            vertices.Add(ABLinkPos);
            normals.Add(ABNormal);
            colors.Add(B.GenerationData.Color);
            //uv.Add(linkABUV);
            // AB - 11 (BC)
            vertices.Add(BCPos);
            normals.Add(ABNormal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(BCUV);
            // AB - 12 (avg AB)
            vertices.Add(nAB * (vertex.Height + A.Height + B.Height) / 3f);
            normals.Add(ABNormal);
            colors.Add(Lerp(vertex, A, B));
            //uv.Add((vertex.UV + A.UV + B.UV) / 3f);
            #endregion
            #region BC   (13 - 16)
            // BC - 13 (BC)
            vertices.Add(BCPos);
            normals.Add(BCNormal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(BCUV);
            // BC - 14 (Link)
            vertices.Add(BCLinkPos);
            normals.Add(BCNormal);
            colors.Add(C.GenerationData.Color);
            //uv.Add(linkBCUV);
            // BC - 15 (CD)
            vertices.Add(CDPos);
            normals.Add(BCNormal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(CDUV);
            // BC - 16 (avg BC)
            vertices.Add(nBC * (vertex.Height + B.Height + C.Height) / 3f);
            normals.Add(BCNormal);
            colors.Add(Lerp(vertex, B, C));
            //uv.Add((vertex.UV + B.UV + C.UV) / 3f);
            #endregion
            #region CD   (17 - 20)
            // CD - 17 (CD)
            vertices.Add(CDPos);
            normals.Add(CDNormal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(CDUV);
            // CD - 18 (Link)
            vertices.Add(CDLinkPos);
            normals.Add(CDNormal);
            colors.Add(D.GenerationData.Color);
            //uv.Add(linkCDUV);
            // CD - 19 (Right)
            vertices.Add(rightPos);
            normals.Add(CDNormal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(rightUV);
            // CD - 20 (avg CD)
            vertices.Add(nCD * (vertex.Height + C.Height + D.Height) / 3f);
            normals.Add(CDNormal);
            colors.Add(Lerp(vertex, C, D));
            //uv.Add((vertex.UV + C.UV + D.UV) / 3f);

            #endregion
            #endregion

            #endregion

            #region Triangles
            #region Hex Triangles
            // left
            triangles.Add(fromIndex + 1);
            // vAB
            triangles.Add(fromIndex + 2);
            //center
            triangles.Add(fromIndex);

            // vAB
            triangles.Add(fromIndex + 2);
            // vBC
            triangles.Add(fromIndex + 3);
            //center
            triangles.Add(fromIndex);

            // vBC
            triangles.Add(fromIndex + 3);
            // vCD
            triangles.Add(fromIndex + 4);
            //center
            triangles.Add(fromIndex);

            // vCD
            triangles.Add(fromIndex + 4);
            // right
            triangles.Add(fromIndex + 5);
            //center
            triangles.Add(fromIndex);
            #endregion
            #region Link triangles
            #region Left
            // Left
            triangles.Add(fromIndex + 6);
            // Link
            triangles.Add(fromIndex + 7);
            // AB
            triangles.Add(fromIndex + 8);
            #endregion
            #region AB
            // AB
            triangles.Add(fromIndex + 9);
            // Link
            triangles.Add(fromIndex + 10);
            // BC
            triangles.Add(fromIndex + 11);

            // AB
            triangles.Add(fromIndex + 9);
            // Avg
            triangles.Add(fromIndex + 12);
            // Link
            triangles.Add(fromIndex + 10);
            #endregion
            #region BC
            // BC
            triangles.Add(fromIndex + 13);
            // Link
            triangles.Add(fromIndex + 14);
            // CD
            triangles.Add(fromIndex + 15);

            // BC
            triangles.Add(fromIndex + 13);
            // Avg
            triangles.Add(fromIndex + 16);
            // Link
            triangles.Add(fromIndex + 14);
            #endregion
            #region CD
            // CD
            triangles.Add(fromIndex + 17);
            // Link
            triangles.Add(fromIndex + 18);
            // Right
            triangles.Add(fromIndex + 19);

            // CD
            triangles.Add(fromIndex + 17);
            // Avg
            triangles.Add(fromIndex + 20);
            // Link
            triangles.Add(fromIndex + 18);
            #endregion
            #endregion
            #endregion
        }
        private static void ComplexMesh(Vertex vertex, List<Vector3> vertices, List<Vector3> normals, List<Color32> colors, List<int> triangles/*, List<Vector2> uv*/)
        {
            int fromIndex = vertices.Count;

            vertices.Add(vertex.Position);
            normals.Add(vertex.Normal);
            colors.Add(vertex.GenerationData.Color);
            //uv.Add(vertex.UV);
            for (int i = 0; i < vertex.Edges.Count; i++)
            {
                Vertex A = vertex.Edges[i].Other(vertex);
                Vertex B = vertex.Edges[(i + 1) % vertex.Edges.Count].Other(vertex);
                Vertex C = vertex.Edges[(i + 2) % vertex.Edges.Count].Other(vertex);

                //Vector3 linkAPos = (vertex.Position + A.Position + B.Position) / 3f;
                Vector3 aNormal = (vertex.Normal + A.Normal + B.Normal).normalized;
                Vector3 aPos = Position(vertex, aNormal);
                //Vector2 aUV = UV(vertex, (vertex.UV + A.UV + B.UV) / 3f);

                Vector3 bNormal = (vertex.Normal + B.Normal + C.Normal).normalized;
                Vector3 bPos = Position(vertex, bNormal);
                //Vector2 bUV = UV(vertex, (vertex.UV + B.UV + C.UV) / 3f);

                Vector3 linkPos = Position(B, aNormal);
                Vector3 linkNormal = Vector3.Cross(linkPos - aPos, bPos - aPos).normalized;
                //Vector2 linkUV = UV(B, (vertex.UV + A.UV + B.UV) / 3f);

                #region Vertices
                // Hex-A
                vertices.Add(aPos);
                normals.Add(vertex.Normal);
                colors.Add(vertex.GenerationData.Color);
                //uv.Add(aUV);

                // Dupe-A
                vertices.Add(aPos);
                normals.Add(linkNormal);
                colors.Add(vertex.GenerationData.Color);
                //uv.Add(aUV);

                // Dupe-B
                vertices.Add(bPos);
                normals.Add(linkNormal);
                colors.Add(vertex.GenerationData.Color);
                //uv.Add(bUV);

                // Link
                vertices.Add(linkPos);
                normals.Add(linkNormal);
                colors.Add(B.GenerationData.Color);
                //uv.Add(linkUV);

                // AVG
                vertices.Add(aNormal * (vertex.Height + A.Height + B.Height) / 3f);
                normals.Add(linkNormal);
                colors.Add(Lerp(vertex, A, B));
                //uv.Add((vertex.UV + A.UV + B.UV) / 3f);
                #endregion

                #region Triangles
                /*HEX TRIANGLE */
                // Hex-A
                triangles.Add(fromIndex + 1 + i * 5);
                // Hex-B
                triangles.Add(fromIndex + 1 + ((i + 1) % vertex.Edges.Count) * 5);
                // Vertex
                triangles.Add(fromIndex);

                /* LINK TRIANGLE (Big) */
                // Dupe-A
                triangles.Add(fromIndex + 2 + i * 5);
                // Link
                triangles.Add(fromIndex + 4 + i * 5);
                // Dupe-B
                triangles.Add(fromIndex + 3 + i * 5);

                /* LINK TRIANGLE (Smol) */
                // Dupe-A
                triangles.Add(fromIndex + 2 + i * 5);
                // AVG
                triangles.Add(fromIndex + 5 + i * 5);
                // Link
                triangles.Add(fromIndex + 4 + i * 5);
                #endregion
            }
        }
        #endregion
    }
}