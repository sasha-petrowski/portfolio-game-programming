﻿using System.Collections.Generic;

using UnityEngine;


namespace PlanetGeneration
{
    public class Planet
    {
        public static PlanetSettings Settings;

        public static Color[] ColorToSubLevel =
        {
            Color.black,
            Color.blue,
            Color.green,
            Color.red,
            Color.black,
            Color.blue,
            Color.green,
            Color.red,
            Color.white
        };

        public const int SUBLEVEL = 8;

        public Dictionary<Vector2Int, PlanetSubdivision> PreviousRootSubs = new Dictionary<Vector2Int, PlanetSubdivision>();
        public Dictionary<Vector2Int, PlanetSubdivision> RootSubs = new Dictionary<Vector2Int, PlanetSubdivision>();

        public PlanetSubdivision[] Subs = new PlanetSubdivision[PlanetUtility.IsocahedronFaces.Length];

        public Planet()
        {
            Vector3[] vertex = PlanetUtility.IsocahedronVertex;
            Vector3Int[] faces = PlanetUtility.IsocahedronFaces;
            Vector3Int[] neighbors = PlanetUtility.IsocahedronNeighbors;

            PlanetPoint[] planetPoints = new PlanetPoint[vertex.Length];

            for (int i = 0; i < planetPoints.Length; i++)
            {
                planetPoints[i] = new PlanetPoint(vertex[i]);
            }

            for (int i = 0; i < Subs.Length; i++)
            {
                Subs[i] = new PlanetSubdivision(i, 0, 0, null, planetPoints[faces[i].x], planetPoints[faces[i].y], planetPoints[faces[i].z]);
            }

            for (int i = 0; i < Subs.Length; i++)
            {
                Subs[i].Nab = Subs[neighbors[i].x];
                Subs[i].Nbc = Subs[neighbors[i].y];
                Subs[i].Nca = Subs[neighbors[i].z];
            }
        }

        public void UpdateRootSubs(Vector3 pos)
        {
            Dictionary<Vector2Int, PlanetSubdivision> tmp = PreviousRootSubs;
            PreviousRootSubs = RootSubs;
            RootSubs = tmp;
            RootSubs.Clear();

            float nearMagnitude = Mathf.Pow(PlanetSubdivision.FaceRadius, 2);
            for(int i = 0; i < Subs.Length; i++)
            {
                if (nearMagnitude > Subs[i].Magnitude(pos))
                {
                    UpdateRootSubs(Subs[i], ref pos);
                }
                else
                {
                    Subs[i].FreeSubs();
                }
            }
        }
        private void UpdateRootSubs(PlanetSubdivision sub, ref Vector3 pos)
        {
            if (SUBLEVEL - 1 > sub.SubLevel)
            {
                float nearMagnitude = Mathf.Pow(sub.NearRadius, 2);
                if (sub.Subs == null)
                {
                    sub.Subdivise();
                }
                for (int i = 0; i < sub.Subs.Length; i++)
                {
                    if (nearMagnitude > sub.Subs[i].Magnitude(pos))
                    {
                        UpdateRootSubs(sub.Subs[i], ref pos);
                    }
                    else
                    {
                        sub.Subs[i].FreeSubs();
                    }
                }
            }
            else
            {
                RootSubs.Add(sub.DirectoryIndex, sub);
                if (sub.Subs == null)
                {
                    sub.Subdivise();
                }
                for (int i = 0; i < sub.Subs.Length; i++)
                {
                    sub.Subs[i].CreateMesh();
                }
            }
        }
    }
}
