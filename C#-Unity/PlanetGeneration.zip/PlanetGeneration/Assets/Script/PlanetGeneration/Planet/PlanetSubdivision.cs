﻿using System;
using UnityEngine;

using PlanetGeneration.MeshGeneration;


namespace PlanetGeneration
{
    public class PlanetSubdivision
    {

        public const int TILESUBDIVISION = 3;
        public static readonly float FaceRadius = Planet.Settings.Radius * 0.75f;
        private static readonly float[] _nearRadius =
        {
            //1
            FaceRadius / 2f,
            
            //2
            FaceRadius / 3f,
            
            //3
            FaceRadius / 5f,
            
            //4
            FaceRadius / 8f,
            
            //5
            FaceRadius / 12f,
            
            //6
            FaceRadius / 14f,
            
            //7
            600f,
            
            //8
            250f
        };

        public PlanetPoint A;
        public PlanetPoint B;
        public PlanetPoint C;

        public PlanetSubdivision Nab;
        public PlanetSubdivision Nbc;
        public PlanetSubdivision Nca;

        public PlanetPoint Ab;
        public PlanetPoint Bc;
        public PlanetPoint Ca;

        public Vector3 APos { get => A.Normal * Planet.Settings.Radius; }
        public Vector3 BPos { get => B.Normal * Planet.Settings.Radius; }
        public Vector3 CPos { get => C.Normal * Planet.Settings.Radius; }

        public Vector3 Position;

        public int FaceIndex;
        public int SubIndex;

        public Vector2Int DirectoryIndex { get => new Vector2Int(FaceIndex, SubIndex); }
        public float NearRadius { get => _nearRadius[SubLevel]; }


        public int SubLevel;
        public PlanetSubdivision[] Subs;
        public PlanetSubdivision Parent;
        public MeshFilter MeshFilter;
        public Shape Shape;

        public Color Color;

        public PlanetSubdivision(int faceIndex, int subIndex, int subLevel, PlanetSubdivision parent,  PlanetPoint a, PlanetPoint b, PlanetPoint c)
        {
            /*
            int checkBit = (0b_111 << ((subLevel - 1) * 3));
            Debug.Log($"f.{faceIndex}, s.{subIndex}, sb.{Convert.ToString(subIndex, toBase: 2), 3 * Planet.SUBLEVEL}, sx.{Convert.ToString(subIndex, toBase: 8), 4}\n"
                + $"checkbit = {Convert.ToString(checkBit, toBase: 2),3 * Planet.SUBLEVEL} both = {Convert.ToString(subIndex & checkBit, toBase: 2),3 * Planet.SUBLEVEL}, bool = {(subIndex & checkBit) == checkBit}");
            */
            FaceIndex = faceIndex;
            SubIndex = subIndex;
            SubLevel = subLevel;

            Parent = parent;

            A = a;

            B = b;

            C = c;

            Position = (a.Normal + b.Normal + c.Normal).normalized * Planet.Settings.Radius;
        }

        public float Magnitude(Vector3 pos)
        {
            return (Position.x - pos.x) * (Position.x - pos.x) + (Position.y - pos.y) * (Position.y - pos.y) + (Position.z - pos.z) * (Position.z - pos.z);
        }
        public PlanetPoint TryGetLink(PlanetSubdivision neighbor)
        {
            if (neighbor == Nab)
            {
                return Ab;
            }
            else if (neighbor == Nbc)
            {
                return Bc;
            }
            else if (neighbor == Nca)
            {
                return Ca;
            }
            else
            {
                return null;
            }
        }
        public void TrySetLink(PlanetSubdivision neighbor, PlanetPoint point)
        {
            if (neighbor == Nab)
            {
                Ab = point;
            }
            else if (neighbor == Nbc)
            {
                Bc = point;
            }
            else if (neighbor == Nca)
            {
                Ca = point;
            }
        }
        public PlanetSubdivision TryLinkSubs(PlanetSubdivision neighbor, PlanetPoint point, PlanetSubdivision other)
        {
            if(Subs != null)
            {
                if (neighbor == Nab)
                {
                    if (point == A)
                    {
                        Subs[1].Nab = other;
                        return Subs[1];
                    }
                    else if (point == B)
                    {
                        Subs[2].Nca = other;
                        return Subs[2];
                    }
                }
                else if (neighbor == Nbc)
                {
                    if (point == B)
                    {
                        Subs[2].Nab = other;
                        return Subs[2];
                    }
                    else if (point == C)
                    {
                        Subs[3].Nca = other;
                        return Subs[3];
                    }
                }
                else if (neighbor == Nca)
                {
                    if (point == A)
                    {
                        Subs[1].Nca = other;
                        return Subs[1];
                    }
                    else if (point == C)
                    {
                        Subs[3].Nab = other;
                        return Subs[3];
                    }
                }
            }
            //Debug.Log($".{ FaceIndex }, s.{ Convert.ToString(SubIndex, toBase: 8),4}");
            return null;
        }
        public void CreateSubPoints()
        {
            if (Ab == null)
            {
                if (Nab != null)
                {
                    Ab = Nab.TryGetLink(this);
                    if (Ab == null)
                    {
                        Ab = new PlanetPoint((A.Normal + B.Normal).normalized);
                        Nab.TrySetLink(this, Ab);
                    }
                }
                else
                {
                    Ab = new PlanetPoint((A.Normal + B.Normal).normalized);
                }
            }

            if (Bc == null)
            {
                if (Nbc != null)
                {
                    Bc = Nbc.TryGetLink(this);
                    if (Bc == null)
                    {
                        Bc = new PlanetPoint((B.Normal + C.Normal).normalized);
                        Nbc.TrySetLink(this, Bc);
                    }
                }
                else
                {
                    Bc = new PlanetPoint((B.Normal + C.Normal).normalized);
                }
            }

            if (Ca == null)
            {
                if (Nca != null)
                {
                    Ca = Nca.TryGetLink(this);
                    if (Ca == null)
                    {
                        Ca = new PlanetPoint((C.Normal + A.Normal).normalized);
                        Nca.TrySetLink(this, Ca);
                    }
                }
                else
                {
                    Ca = new PlanetPoint((C.Normal + A.Normal).normalized);
                }
            }
        }
        public void Subdivise()
        {
            if(Planet.SUBLEVEL > SubLevel)
            {
                if(Subs == null)
                {
                    CreateSubPoints();

                    Subs = new PlanetSubdivision[4];

                    Subs[0] = new PlanetSubdivision(FaceIndex, CreateSubIndex(SubIndex, SubLevel, 0), SubLevel + 1, this, Ab, Bc, Ca);
                    Subs[1] = new PlanetSubdivision(FaceIndex, CreateSubIndex(SubIndex, SubLevel, 1), SubLevel + 1, this, A,  Ab, Ca);
                    Subs[2] = new PlanetSubdivision(FaceIndex, CreateSubIndex(SubIndex, SubLevel, 2), SubLevel + 1, this, B,  Bc, Ab);
                    Subs[3] = new PlanetSubdivision(FaceIndex, CreateSubIndex(SubIndex, SubLevel, 3), SubLevel + 1, this, C,  Ca, Bc);

                    //Color
                    Subs[0].Color = Color.white;
                    Subs[1].Color = Color.red;
                    Subs[2].Color = Color.green;
                    Subs[3].Color = Color.blue;

                    // Center
                    Subs[0].Nab = Subs[2];
                    Subs[0].Nbc = Subs[3];
                    Subs[0].Nca = Subs[1];

                    // Other to Center
                    Subs[1].Nbc = Subs[0];
                    Subs[2].Nbc = Subs[0];
                    Subs[3].Nbc = Subs[0];

                    // AB Edge
                    if (Nab != null)
                    {
                        Subs[1].Nab = Nab.TryLinkSubs(this, A, Subs[1]);
                        Subs[2].Nca = Nab.TryLinkSubs(this, B, Subs[2]);
                    }

                    // BC Edge
                    if (Nbc != null)
                    {
                        Subs[2].Nab = Nbc.TryLinkSubs(this, B, Subs[2]);
                        Subs[3].Nca = Nbc.TryLinkSubs(this, C, Subs[3]);
                    }

                    // CA Edge
                    if (Nca != null)
                    {
                        Subs[3].Nab = Nca.TryLinkSubs(this, C, Subs[3]);
                        Subs[1].Nca = Nca.TryLinkSubs(this, A, Subs[1]);
                    }
                }
            }
        }
        public static int CreateSubIndex(int parentIndex, int subLevel, int i)
        {
            return parentIndex + ( (i + 1) << (3 * subLevel));
        }
        /*
        public void CreateSub(int i)
        {
            switch (i)
            {
                case 0:
                    Subs[0] = new PlanetSubdivision(FaceIndex, SubIndex + (1 << (3 * SubLevel)), SubLevel + 1, this, (A.Normal + B.Normal).normalized, (B.Normal + C.Normal).normalized, (C.Normal + A.Normal).normalized);
                    break;

                case 1:
                    Subs[1] = new PlanetSubdivision(FaceIndex, SubIndex + (2 << (3 * SubLevel)), SubLevel + 1, this, A, (C + A).normalized, (A + B).normalized);
                    break;

                case 2:
                    Subs[2] = new PlanetSubdivision(FaceIndex, SubIndex + (3 << (3 * SubLevel)), SubLevel + 1, this, B, (A + B).normalized, (B + C).normalized);
                    break;

                case 3:
                    Subs[3] = new PlanetSubdivision(FaceIndex, SubIndex + (4 << (3 * SubLevel)), SubLevel + 1, this, C, (B + C).normalized, (C + A).normalized);
                    break;
            }
        }
        */
        public void FreeSubs()
        {
            if (Subs != null)
            {
                for (int i = 0; i < Subs.Length; i++)
                {
                    Subs[i].FreeSubs();
                }
            }
            Subs = null;
            DeleteMesh();
        }

        public void DeleteMesh()
        {
            if(MeshFilter != null)
            {
                GameObject.Destroy(MeshFilter.gameObject);
                Shape = null;
            }
        }

        public void CreateMesh()
        {
            if (Application.isPlaying && MeshFilter == null)
            {
                Shape = MeshUtility.TriangleShape(A.Normal, B.Normal, C.Normal, TILESUBDIVISION);

                Mesh mesh = MeshUtility.ComplexMesh(Shape);

                GameObject meshObject = new GameObject($"Mesh f.{ FaceIndex }, s.{ Convert.ToString(SubIndex, toBase: 8), 4}");

                MeshFilter = meshObject.AddComponent<MeshFilter>();
                MeshFilter.mesh = mesh;

                MeshRenderer meshRendererObject = meshObject.AddComponent<MeshRenderer>();

                meshRendererObject.material = Planet.Settings.MapMat;

                MeshCollider meshCollider = meshObject.AddComponent<MeshCollider>();
                meshCollider.sharedMesh = mesh;
            }
        }
    }
}
