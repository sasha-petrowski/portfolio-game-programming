﻿using UnityEngine;

namespace PlanetGeneration
{
    public class PlanetPoint
    {
        public Vector3 Normal;
        public PlanetPoint(Vector3 normal)
        {
            //Color = new Color(Random.Range(0.25f, 1f), Random.Range(0.25f, 1f), Random.Range(0.25f, 1f));
            Normal = normal;
        }
    }
}
