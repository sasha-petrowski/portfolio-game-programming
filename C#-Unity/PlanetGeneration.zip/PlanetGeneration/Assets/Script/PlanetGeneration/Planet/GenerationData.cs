using UnityEngine;
using Noises;

namespace PlanetGeneration
{
    public class GenerationData
    {
        public float LandNoise;
        public float CliffNoise;
        public float PrecipitationNoise;
        public float TemperatureNoise;
        public float ElevationDetailNoise;
        public float ClimateDetailNoise;

        public float TemperatureValue;

        public float HeightValue;
        BiomeData Biome;

        public Color32 Color;

        public GenerationData(Vector3 planetPos, Vector3 normal)
        {
            /*
             Notes on geographical effects :

            + Positive effect
            - Negative effect
            / Averages out

            Temperature
                / Water bodies
                - Altitude
                +- Equator

            Precipitation
                + Water bodies
                + Equator
                + Altitude
                - Cliff

             */

            // 1 - Generate the base noise maps
            #region Base noises
            // Elevation
            LandNoise = Noise.Simplex3D(Planet.Settings.LandNoise, planetPos.x, planetPos.y, planetPos.z);
            CliffNoise = Noise.Simplex3D(Planet.Settings.CliffNoise, planetPos.x, planetPos.y, planetPos.z);

            // Climate
            PrecipitationNoise = Noise.Simplex3D(Planet.Settings.PrecipitationNoise, planetPos.x, planetPos.y, planetPos.z);
            TemperatureNoise = Noise.Simplex3D(Planet.Settings.TemperatureNoise, planetPos.x, planetPos.y, planetPos.z);

            // Other
            ElevationDetailNoise = Noise.Simplex3D(Planet.Settings.ElevationDetailNoise, planetPos.x, planetPos.y, planetPos.z);
            ClimateDetailNoise = Noise.Simplex3D(Planet.Settings.ClimateDetailNoise, planetPos.x, planetPos.y, planetPos.z);

            #endregion

            // 2 - Apply DetailNoises (to rough them equally with less processing)
            #region Detail to Noises
            LandNoise = LandNoise * (1 - Planet.Settings.DetailBlend) + ElevationDetailNoise * Planet.Settings.DetailBlend;
            CliffNoise = CliffNoise * (1 - Planet.Settings.DetailBlend) + (1 - ElevationDetailNoise) * Planet.Settings.DetailBlend;

            TemperatureNoise = TemperatureNoise * (1 - Planet.Settings.DetailBlend) + ElevationDetailNoise * Planet.Settings.DetailBlend;
            PrecipitationNoise = PrecipitationNoise * (1 - Planet.Settings.DetailBlend) + (1 - ClimateDetailNoise) * Planet.Settings.DetailBlend;
            #endregion

            // 3 - Land, Cliffs & Islands
            #region Base terrain Feature
            if (LandNoise > Planet.Settings.SeaLevel && LandNoise < CliffNoise)
            {
                //Cliffs
                float blend = Mathf.Pow(Mathf.Clamp01(1f + (LandNoise - Planet.Settings.CliffLevel) / (Planet.Settings.CoastLenght)), 2f);
                HeightValue = Mathf.Clamp01(CliffNoise * blend + LandNoise * (1 - blend));
            }
            else if (LandNoise < Planet.Settings.DeepSeaLevel && CliffNoise < Planet.Settings.IslandLevel)
            {
                //Islands
                float blend = Mathf.Pow(Mathf.Clamp01(-(LandNoise - Planet.Settings.DeepSeaLevel) / (Planet.Settings.IslandCoastLenght)), 2f);
                HeightValue = Mathf.Clamp01(Planet.Settings.SeaLevel + (Planet.Settings.IslandLevel - CliffNoise) * blend * Planet.Settings.IslandHeightMultiplier);

                PrecipitationNoise += Planet.Settings.PrecipitationIslandOffset;
            }
            else
            {
                //Default
                HeightValue = LandNoise;
            }
            #endregion

            // 4 - Rivers
            #region Secondary terrain Feature
            bool isRiver = false;
            float seaRiver = Mathf.Clamp(Planet.Settings.RiverSeaLenght + Planet.Settings.SeaLevel - LandNoise, 0, Planet.Settings.RiverSeaLenght);
            if (LandNoise > Planet.Settings.SeaLevel && Mathf.Abs(LandNoise - CliffNoise) <= Planet.Settings.RiverWidth + seaRiver)
            {
                //Rivers
                HeightValue = Mathf.Clamp01(HeightValue - Planet.Settings.RiverDepth);
                isRiver = true;
            }
            #endregion
            // From here we don't touch on Elevation noises anymore

            // 5 - Effect of Equator & Latitude on Precipitations and Temperature
            #region Equator & Latitude
            // Calculate absolute Latitude (used for Temperature)
            float latitude = Mathf.Abs(Mathf.Cos(normal.y * Mathf.PI * 0.5f));
            // Calculate Equator (used for precipitations)
            float equator = 1 - Mathf.Abs(Mathf.Sin(Mathf.Clamp(normal.y, -0.5f, 0.5f) * Mathf.PI));
            // Effect of Latitude on Temperature
            TemperatureNoise = latitude * (1 - Planet.Settings.TemperatureEquatorBlend) + TemperatureNoise * Planet.Settings.TemperatureEquatorBlend;
            // Effect of Equator on Precipitation
            PrecipitationNoise += equator * Planet.Settings.PrecipitationEquatorBlend;
            #endregion

            // 6 - Temperature is reduced by height while Precipitations are increased
            #region Mountain
            // Mountain temperature reduction (only at really high places (Pow 4) )
            if (HeightValue > Planet.Settings.SeaLevel)
            {
                TemperatureNoise -= Mathf.Pow((HeightValue - Planet.Settings.SeaLevel) / (1 - Planet.Settings.SeaLevel), 4) * (1 - Planet.Settings.SeaLevel);
            }
            #endregion

            // Remap temperature noise ( from  0,1  to  -1,1 )
            TemperatureNoise = TemperatureNoise * 2f - 1f;

            // 7 - Temperature is milder near bodies of water, and they obviously increase Humidity
            #region Water bodies heat retention
            // Temperature is averaged near bodies of water or in valleys
            float coastTempBlend = (Planet.Settings.TemperatureCoastLenght - Mathf.Abs(HeightValue - Planet.Settings.SeaLevel)) * Planet.Settings.TemperatureCoastBlend;
            if (coastTempBlend > 0)
            {
                if (LandNoise < CliffNoise)
                {
                    coastTempBlend = Mathf.Clamp01(coastTempBlend + LandNoise - CliffNoise);
                }
                TemperatureNoise = TemperatureNoise * (1 - coastTempBlend) + Planet.Settings.AVGTemperatureLevel * coastTempBlend;
            }
            #endregion

            TemperatureValue = (((TemperatureNoise) - Planet.Settings.LowTemperatureLevel) / (Planet.Settings.HighTemperatureLevel - Planet.Settings.LowTemperatureLevel) * (Planet.Settings.HighTemperature - Planet.Settings.LowTemperature) + Planet.Settings.LowTemperature);

            Biome = Planet.Settings.Biomes.Get(TemperatureNoise, PrecipitationNoise);


            #region Color Debug

            // Normal terrain
            if (Planet.Settings.DrawElevation)
            {
                Color = RGBGrayscale(HeightValue * HeightValue);
                Color.r += (byte)((CliffNoise - LandNoise) * 128);
                Color.b += (byte)((LandNoise - CliffNoise) * 128);
            }

            // Temperature
            else if (Planet.Settings.DrawTemperature)
            {
                Color = new Color32(0, 0, 0, 255);
                if (TemperatureNoise > Planet.Settings.HighTemperatureLevel - 0.1f)
                {
                    // Hot
                    Color.r = (byte)((TemperatureNoise + 0.1f - Planet.Settings.HighTemperatureLevel) * 150);
                }
                if (TemperatureNoise < Planet.Settings.LowTemperatureLevel + 0.1f)
                {
                    // Cold
                    Color.b = (byte)(-(TemperatureNoise - 0.1f - Planet.Settings.LowTemperatureLevel) * 150);
                }

                if (TemperatureNoise > 0)
                {
                    // Green positive Average
                    Color.g = (byte)(Mathf.Clamp01(Planet.Settings.HighTemperatureLevel - 0.1f - TemperatureNoise) * 255);
                }
                else
                {
                    // Green negative Average
                    Color.g = (byte)(Mathf.Clamp01(TemperatureNoise + 0.1f - Planet.Settings.LowTemperatureLevel) * 255);
                }
            }

            // Precipitations
            else if (Planet.Settings.DrawPrecipitation)
            {
                if (Planet.Settings.Grayscale)
                {
                    Color = RGBGrayscale(SeparateValue(PrecipitationNoise, 10));
                }
                else
                {
                    Color = RGBGradient(SeparateValue(1 - PrecipitationNoise, 10));
                }
                //Color = new Color32((byte)(0), (byte)(0), (byte)((PrecipitationNoise) * 255), 255);
            }

            // Equator
            else if (Planet.Settings.DrawPrecipitationLatitude)
            {
                if (Planet.Settings.Grayscale)
                {
                    Color = RGBGrayscale(SeparateValue(equator, 10));
                }
                else
                {
                    Color = RGBGradient(SeparateValue(1 - equator, 10));
                }
            }

            // Climate
            else if (Planet.Settings.DrawClimate)
            {
                float green = Mathf.Clamp01(PrecipitationNoise * (TemperatureNoise * 0.5f + 0.5f));
                Color = new Color32((byte)(Mathf.Clamp01((TemperatureNoise * 0.5f + 0.5f) - green) * 255), (byte)(green * 255), (byte)(Mathf.Clamp01(PrecipitationNoise - green) * 255), 255);
            }

            #endregion

            // Normal terrain
            else
            {
                if (isRiver)
                {
                    if (LandNoise < Planet.Settings.SeaLevel + Planet.Settings.RiverSeaBlend)
                    {
                        Color32 seaColor = Color32.Lerp(Biome.SeaColor, RGBGrayscale(HeightValue), 0.25f);
                        Color = Color32.Lerp(seaColor, Biome.RiverColor, (LandNoise - Planet.Settings.SeaLevel) / Planet.Settings.RiverSeaBlend);
                    }
                    else
                    {
                        Color = Biome.RiverColor;
                    }
                }
                // Sea if bellow SeaLevel && not Island
                else if (LandNoise <= Planet.Settings.SeaLevel && !(LandNoise < Planet.Settings.DeepSeaLevel && CliffNoise < Planet.Settings.IslandLevel))
                {
                    Color = Color32.Lerp(Biome.SeaColor, RGBGrayscale(HeightValue), 0.25f);
                }
                else
                {
                    float terrainHeight = Mathf.Clamp01((HeightValue - Planet.Settings.SeaLevel) / (1 - Planet.Settings.SeaLevel));
                    Color = Biome.TerrainGradient.Evaluate(terrainHeight);
                }
            }

            #region WaterMask

            // White Ocean mask
            if (Planet.Settings.DrawOceanMask && LandNoise <= Planet.Settings.SeaLevel && !(LandNoise < Planet.Settings.DeepSeaLevel && CliffNoise < Planet.Settings.IslandLevel))
            {
                // Sea is somewhat white to differentiate landmasses
                Color = Color32.Lerp(Color, RGBGrayscale(1 - LandNoise), 0.8f);
            }
            else if (Planet.Settings.DrawRiverMask && isRiver)
            {
                // Sea is somewhat white to differentiate landmasses
                Color = Color32.Lerp(Color, RGBGrayscale(1 - LandNoise), 0.5f);
            }

            #endregion
        }
        private float SeparateValue(float value, int step)
        {
            return (Mathf.Round(value * step) / step);
        }
        private Color32 RGBGradient(float value)
        {
            Color32 color = new Color32(0, 0, 0, 255);
            if (value > 0.99f)
            {
                color = new Color32(255, 255, 255, 255);
            }
            else if (value > 0.5f)
            {
                color.r = (byte)((value - .5f) * 255);
            }
            else
            {
                color.b = (byte)((-value + 0.5f) * 255);
            }
            return color;
        }
        private Color32 RGBGrayscale(float value)
        {
            return new Color32((byte)(value * 255), (byte)(value * 255), (byte)(value * 255), 255);
        }
    }
}