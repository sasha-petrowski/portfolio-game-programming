﻿using UnityEngine;

namespace PlanetGeneration
{
    public static class PlanetUtility
    {
        // the planet is generated from an Icosahedron so we need to store the way to create the primitive.

        public static readonly float IsocahedronT = (1 + Mathf.Pow(5, 0.5f)) / 2f;
        public static readonly Vector3[] IsocahedronVertex =
        {
            new Vector3(-1, IsocahedronT, 0).normalized, new Vector3(1, IsocahedronT, 0).normalized, new Vector3(- 1, -IsocahedronT, 0).normalized, new Vector3(1, -IsocahedronT, 0).normalized,
            new Vector3(0, -1, IsocahedronT).normalized, new Vector3(0, 1, IsocahedronT).normalized, new Vector3(0, -1, -IsocahedronT).normalized,  new Vector3(0, 1, -IsocahedronT).normalized,
            new Vector3(IsocahedronT, 0, -1).normalized, new Vector3(IsocahedronT, 0, 1).normalized, new Vector3(-IsocahedronT, 0, -1).normalized,  new Vector3(-IsocahedronT, 0, 1).normalized
        };
        public static readonly Vector3Int[] IsocahedronFaces =
        {
            new Vector3Int(0, 11, 5), new Vector3Int(0, 5, 1),  new Vector3Int(0, 1, 7),   new Vector3Int(0, 7, 10), new Vector3Int(0, 10, 11),
            new Vector3Int(1, 5, 9),  new Vector3Int(5, 11, 4), new Vector3Int(11, 10, 2), new Vector3Int(10, 7, 6), new Vector3Int(7, 1, 8),
            new Vector3Int(3, 9, 4),  new Vector3Int(3, 4, 2),  new Vector3Int(3, 2, 6),   new Vector3Int(3, 6, 8),  new Vector3Int(3, 8, 9),
            new Vector3Int(4, 9, 5),  new Vector3Int(2, 4, 11), new Vector3Int(6, 2, 10),  new Vector3Int(8, 6, 7),  new Vector3Int(9, 8, 1)
        };
        public static readonly Vector3Int[] IsocahedronNeighbors =
        {
            new Vector3Int(4, 6, 1), new Vector3Int(0, 5, 2), new Vector3Int(1, 9, 3), new Vector3Int(2, 8, 4), new Vector3Int(3, 7, 0),
            new Vector3Int(1, 15, 19), new Vector3Int(0, 16, 15), new Vector3Int(4, 17, 16), new Vector3Int(3, 18, 17), new Vector3Int(2, 19, 18),
            new Vector3Int(14, 15, 11), new Vector3Int(10, 16, 12), new Vector3Int(11, 17, 13), new Vector3Int(12, 18, 14), new Vector3Int(13, 19, 10),
            new Vector3Int(10, 5, 6), new Vector3Int(11, 6, 7), new Vector3Int(12, 7, 8), new Vector3Int(13, 8, 9), new Vector3Int(14, 9, 5)
        };
    }
}