#include "p_texte_enrichi.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAILLE 30

int _indentation = 0;
int _imbrication = 0;
int _ecris = 0;
int _ligne = 1;
t_mode _mode = NORMAL;

void changer_mode(t_mode mode){
    _mode = mode;
}

t_mode mode(){
    return _mode;
}

char* identation_to_str(){
    switch (_indentation % 3)
    {
    case 0:
        return "-";
        break;
    case 1:
        return "*";
        break;
    case 2:
        return "x";
        break;
    
    default:
        return NULL;
        break;
    }
}

void ouvrir_bloc(FILE* file){
    entamer_ligne(file);
    _ecris = TAILLE - ((_imbrication * 2) + (_indentation * 3));
    fprintf(file,"+");
    for(int i = 0; i < _ecris - 2; i++){
        fprintf(file,"-");
    }
    fprintf(file,"+");
    terminer_ligne(file);
    _imbrication++;
}

void fermer_bloc(FILE* file){
    if(_imbrication){
        if(! _ligne){
            terminer_ligne(file);
        }
        _imbrication--;
        while(_indentation) _indentation--;
        entamer_ligne(file);
        _ecris = TAILLE - ((_imbrication * 2) + (_indentation * 3));
        fprintf(file,"+");
        for(int i = 0; i < _ecris - 2; i++){
            fprintf(file,"-");
        }
        fprintf(file,"+");
        terminer_ligne(file);
    }
}

void indenter(){
    _indentation++;
}

void desindenter(){
    if(_indentation) _indentation--;
}

int est_en_fin_de_ligne();

int est_au_debut_de_ligne();

void entamer_ligne(FILE* file){
    if(_ecris > 0){
        terminer_ligne(file);
    }
    for(int i = 0; i < _imbrication; i++){
        fprintf(file,"|");
    }
    if(_indentation > 0){
        for(int i = 0; i < _indentation; i++){
            fprintf(file,"   ");
        }  
    }
    _ligne = 0;
}

void terminer_ligne(FILE* file){
    if(_ligne){
        entamer_ligne(file);
    }
    for(int i = 0; i < (TAILLE - ((_imbrication * 2) + (_indentation * 3) + _ecris)); i++){
        fprintf(file," ");
    }
    for(int i = 0; i < _imbrication; i++){
        fprintf(file,"|");
    }
    fprintf(file,"\n");
    _ligne = 1;
    _ecris = 0;
}

void pucer(FILE* file){
    if(_ligne){
        entamer_ligne(file);
    }
    fprintf(file," %s ", identation_to_str());
    indenter();
}

void ecrire_mot(const char* mot, FILE* file){
    if(_ligne){
        entamer_ligne(file);
    }
    _ecris += strlen(mot) + 1;
    if(peut_ecrire(_ecris) < 0){
        terminer_ligne(file);
        _ecris += strlen(mot) + 1;
        entamer_ligne(file);
    }
    if(_mode == MAJUSCULE){
        char str[TAILLE];
        strcpy(str, mot);
        for (int i = 0; ! str[i] == '\0'; i++) {
            if(str[i] >= 'a' && str[i] <= 'z') {
                str[i] = str[i] -32;
            }
        }
        fprintf(file,"%s ", str);
    }else{
        fprintf(file,"%s ", mot);
    }
}

int peut_ecrire(int nb_caracteres){
    return (TAILLE - ((_imbrication * 2) + (_indentation * 3) + _ecris)) > nb_caracteres;
}