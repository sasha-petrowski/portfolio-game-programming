#include <sys/socket.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/types.h>
#include "../texte/p_texte_enrichi.h"

#define BUFFER_SIZE 256

int cree_socket_tcp_ip()
{
    int sock;
    struct sockaddr_in adresse;
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        fprintf(stderr, "Erreur socket\n");
        return -1;
    }
    memset(&adresse, 0, sizeof(struct sockaddr_in));
    adresse.sin_family = AF_INET;
    adresse.sin_port = htons(1333);
    adresse.sin_addr.s_addr = htons(INADDR_ANY);
    if (bind(sock, (struct sockaddr *)&adresse, sizeof(struct sockaddr_in)) < 0)
    {
        close(sock);
        fprintf(stderr, "Erreur bind\n");
        return -1;
    }
    return sock;
}

int affiche_adresse_socket(int sock)
{
    struct sockaddr_in adresse;
    socklen_t longueur;
    longueur = sizeof(struct sockaddr_in);
    if (getsockname(sock, (struct sockaddr *)&adresse, &longueur) < 0)
    {
        fprintf(stderr, "Erreur getsockname\n");
        return -1;
    }
    printf("IP = %s, Port = %u\n", inet_ntoa(adresse.sin_addr), ntohs(adresse.sin_port));
    return 0;
}
char* mode_to_str(){
    switch (mode())
    {
    case MAJUSCULE:
        return "Majuscule";
        break;
    case MINUSCULE:
        return "Minuscule";
        break;
    default:
        return "Normal";
        break;
    }
}
int commande_utilisateur(FILE *file, char *cmd, int sock)
{
    if(strstr(cmd, "maj"))
    {
        printf("vous etes dans maj\n");
        changer_mode(MAJUSCULE);
    }else if(strstr(cmd, "min"))
    {
        printf("\nvous etes dans min\n");
        changer_mode(NORMAL);
    }else if(strstr(cmd, "ouvrir"))
    {
        printf("vous etes dans ouvrir\n");
        ouvrir_bloc(file);
    }else if(strstr(cmd, "fermer"))
    {
        printf("vous etes dans fermer\n");
        fermer_bloc(file);
    }else if(strstr(cmd, "desindenter"))
    {
        printf("vous etes dans desindenter\n");
        desindenter();
    }else if(strstr(cmd, "indenter"))
    {
        printf("vous etes dans indenter\n");
        indenter();
    }else if(strstr(cmd, "pucer"))
    {
        printf("vous etes dans pucer\n");
        pucer(file);
    }else if(strstr(cmd, "passer"))
    {
        printf("vous etes dans passer\n");
        terminer_ligne(file);
    }else if(strstr(cmd, "ecrire"))
    {
        printf("vous etes dans ecrire\n");
        write(sock, "Entrez le mot a ecrire\n:>", 26);
        read(sock, cmd, BUFFER_SIZE);
        cmd[strlen(cmd)-1] = '\0';
        ecrire_mot(cmd, file);
    }else
    {
        return 0;
    }
    return 1;
}

int main(void)
{
    int sock_contact;
    int sock_connectee;
    struct sockaddr_in adresse;
    socklen_t longueur;
    pid_t pid_fils;
    sock_contact = cree_socket_tcp_ip();
    if (sock_contact < 0)
        return -1;
    listen(sock_contact, 5);
    printf("Mon adresse (sock contact) -> ");
    affiche_adresse_socket(sock_contact);
    while (1)
    {
        longueur = sizeof(struct sockaddr_in);
        sock_connectee = accept(sock_contact, (struct sockaddr *)&adresse, &longueur);
        if (sock_connectee < 0)
        {
            fprintf(stderr, "Erreur accept\n");
            return -1;
        }
        pid_fils = fork();
        if (pid_fils == -1)
        {
            fprintf(stderr, "Erreur fork\n");
            return -1;
        }
        if (pid_fils == 0)
        {
            close(sock_contact);
            traite_connection(sock_connectee);
            close(sock_connectee);
            exit(0);
        }
    }
    return 0;
}

void traite_connection(int sock)
{
    struct sockaddr_in adresse;
    socklen_t longueur;
    char bufferR[BUFFER_SIZE];
    char bufferW[BUFFER_SIZE];
    int nb;
    longueur = sizeof(struct sockaddr_in);
    if (getpeername(sock, (struct sockaddr *)&adresse, &longueur) < 0)
    {
        fprintf(stderr, "Erreur getpeername\n");
        return;
    }
    sprintf(bufferW, "IP = %s, Port = %u\n", inet_ntoa(adresse.sin_addr), ntohs(adresse.sin_port));
    printf("Connexion : locale (sock_connectee) ");
    affiche_adresse_socket(sock);
    printf(" Machine distante : Client %d : %s", sock, bufferW);

    sprintf(bufferW, "../fichier/client_%d", sock);
    FILE *file = fopen(bufferW, "w");

    write(sock, "ENTREE > deconnection\nmaj > mode d'ecriture majuscule\nmin > mode d'écriture normale\nouvrir > ouvrir bloc\nfermer > fermer bloc\nindenter > indenter\ndesindenter > desindenter\npucer > pucer le texte\npasser > passer une ligne\necrire > ecrire un mot\n\n:> ", 250);
        
    while (1)
    {
        nb = read(sock, bufferR, BUFFER_SIZE);
        if (strlen(bufferR) == 1)
        {
            printf("Deconnection du client %d\n", sock);
            break;
        }
        bufferR[nb] = '\0';
        printf("L'utilsateur distant %d a tapé : %s\n", sock, bufferR);

        if (commande_utilisateur(file, bufferR, sock))
        {
            sprintf(bufferW, "\nCommande valide : %s\n:> ", bufferR);
        }
        else
        {
            sprintf(bufferW, "\n! Commande erreur : %s\n:> ", bufferR);
        }
        write(sock, bufferW, strlen(bufferW) + 1);
    }
    fclose(file);
}