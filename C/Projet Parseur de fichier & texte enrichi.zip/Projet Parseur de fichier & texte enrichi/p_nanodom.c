#include "p_nanodom.h"
#include "p_texte_enrichi.h"
#include <stdlib.h>

const char *t_token_image(t_token ceci)
{
    switch (ceci)
    {
    case DOCUMENT:
        return "DOCUMENT";
        break;
    case ANNEXE:
        return "ANNEXE";
        break;
    case SECTION:
        return "SECTION";
        break;

    case TITRE:
        return "TITRE";
        break;

    case LISTE:
        return "LISTE";
        break;

    case ITEM:
        return "ITEM";
        break;

    case IMPORTANT:
        return "IMPORTANT";
        break;

    case RETOUR_A_LA_LIGNE:
        return "RETOUR_A_LA_LIGNE";
        break;
    case MOT:
        return "MOT";
        break;

    default:
        return "";
        break;
    }
}
const char *t_parente_image(t_parente ceci)
{
    switch (ceci)
    {
    case 0:
        return "PERE";
        break;
    case 1:
        return "PREMIER_FILS";
        break;
    case 2:
        return "DERNIER_FILS";
        break;
    case 3:
        return "GRAND_FRERE";
        break;
    case 4:
        return "PETIT_FRERE";
        break;
    case 5:
        return "NB_PARENTES";
        break;

    default:
        return "";
        break;
    }
}

void creer_noeud(p_noeud *ceci, t_token etiquette, const char *contenu, p_noeud pere, p_noeud premier_fils, p_noeud dernier_fils, p_noeud grand_frere, p_noeud petit_frere)
{
    (*ceci) = (t_noeud *)malloc(sizeof(t_noeud));
    (*ceci)->l_etiquette = etiquette;
    (*ceci)->le_contenu = contenu;
    (*ceci)->les_parentes[PERE] = pere;
    (*ceci)->les_parentes[PREMIER_FILS] = premier_fils;
    (*ceci)->les_parentes[DERNIER_FILS] = dernier_fils;
    (*ceci)->les_parentes[GRAND_FRERE] = grand_frere;
    (*ceci)->les_parentes[PETIT_FRERE] = petit_frere;
}

void detruire_noeud(p_noeud *ceci)
{
    free(*ceci);
}

void modifier_etiquette_noeud(p_noeud ceci, t_token nouvelle_etiquette)
{
    ceci->l_etiquette = nouvelle_etiquette;
}

void modifier_contenu_noeud(p_noeud ceci, char *nouveau_contenu)
{
    ceci->le_contenu = nouveau_contenu;
}

void modifier_parente_noeud(p_noeud ceci, t_parente lien_de_parente, p_noeud nouveau_parent)
{
    if (ceci != NULL)
    {
        ceci->les_parentes[lien_de_parente] = nouveau_parent;
    }
}

void debugger_noeud(p_noeud ceci)
{
    printf("Noeud range a l'adresse %p\n", ceci);
    printf("    - ETIQUETTE : %s\n", t_token_image(ceci->l_etiquette));
    printf("    - CONTENU : %s\n", ceci->le_contenu);
    for (int i = 0; i < NB_PARENTES; i++)
    {
        
        printf("    - %s : %p\n", t_parente_image(i), ceci->les_parentes[i]);
        
    }
}

void inserer_aine(p_noeud ceci, p_noeud orphelin)
{
     if(ceci->les_parentes[PREMIER_FILS] == NULL){
        modifier_parente_noeud(ceci, PREMIER_FILS, orphelin);
        modifier_parente_noeud(orphelin, PERE, ceci);
        if(ceci->les_parentes[DERNIER_FILS] == NULL){
            modifier_parente_noeud(ceci, DERNIER_FILS, orphelin);
        } else {
            modifier_parente_noeud(orphelin, PETIT_FRERE, ceci->les_parentes[DERNIER_FILS]);
        }
    } else {
        modifier_parente_noeud(orphelin, PERE, ceci);
        modifier_parente_noeud(orphelin, PETIT_FRERE, ceci->les_parentes[PREMIER_FILS]);
        modifier_parente_noeud(ceci->les_parentes[PREMIER_FILS], GRAND_FRERE, orphelin);
        modifier_parente_noeud(ceci, PREMIER_FILS, orphelin);
    }
}

void inserer_cadet(p_noeud ceci, p_noeud orphelin){
    if(ceci->les_parentes[DERNIER_FILS] == NULL){
        modifier_parente_noeud(ceci, DERNIER_FILS, orphelin);
        modifier_parente_noeud(orphelin, PERE, ceci);
        if(ceci->les_parentes[PREMIER_FILS] == NULL){
            modifier_parente_noeud(ceci, PREMIER_FILS, orphelin);
        } else {
            modifier_parente_noeud(orphelin, GRAND_FRERE, ceci->les_parentes[PREMIER_FILS]);
        }
    } else {
        modifier_parente_noeud(orphelin, PERE, ceci);
        modifier_parente_noeud(orphelin, GRAND_FRERE, ceci->les_parentes[DERNIER_FILS]);
        modifier_parente_noeud(ceci->les_parentes[DERNIER_FILS], PETIT_FRERE, orphelin);
        modifier_parente_noeud(ceci, DERNIER_FILS, orphelin);
    }
}

void inserer_apres(p_noeud ceci, p_noeud orphelin)
{
    modifier_parente_noeud(orphelin, PERE, ceci->les_parentes[PERE]);
    modifier_parente_noeud(orphelin, PETIT_FRERE, ceci->les_parentes[PETIT_FRERE]);
    modifier_parente_noeud(orphelin, GRAND_FRERE, ceci);
    modifier_parente_noeud(ceci, PETIT_FRERE, orphelin);
    if (ceci == ceci->les_parentes[PERE]->les_parentes[DERNIER_FILS] || ceci->les_parentes[PERE]->les_parentes[DERNIER_FILS] == NULL)
    {
        modifier_parente_noeud(ceci->les_parentes[PERE], DERNIER_FILS, orphelin);
    }
}
void inserer_avant(p_noeud ceci, p_noeud orphelin)
{
    modifier_parente_noeud(orphelin, PERE, ceci->les_parentes[PERE]);
    modifier_parente_noeud(orphelin, GRAND_FRERE, ceci->les_parentes[GRAND_FRERE]);
    modifier_parente_noeud(orphelin, PETIT_FRERE, ceci);
    modifier_parente_noeud(ceci, GRAND_FRERE, orphelin);
    if (ceci == ceci->les_parentes[PERE]->les_parentes[PREMIER_FILS] || ceci->les_parentes[PERE]->les_parentes[PREMIER_FILS] == NULL)
    {
        modifier_parente_noeud(ceci->les_parentes[PERE], PREMIER_FILS, orphelin);
    }
}

void extraire(p_noeud ceci)
{
    if (ceci->les_parentes[PERE]->les_parentes[DERNIER_FILS] == ceci)
    {
        modifier_parente_noeud(ceci->les_parentes[PERE], DERNIER_FILS, ceci->les_parentes[GRAND_FRERE]);
    }
    else if (ceci->les_parentes[PERE]->les_parentes[PREMIER_FILS] == ceci)
    {
        modifier_parente_noeud(ceci->les_parentes[PERE], PREMIER_FILS, ceci->les_parentes[PETIT_FRERE]);
    }
    modifier_parente_noeud(ceci->les_parentes[GRAND_FRERE], PETIT_FRERE, ceci->les_parentes[PETIT_FRERE]);
    modifier_parente_noeud(ceci->les_parentes[PETIT_FRERE], GRAND_FRERE, ceci->les_parentes[GRAND_FRERE]);
    modifier_parente_noeud(ceci, PERE, NULL);
    modifier_parente_noeud(ceci, GRAND_FRERE, NULL);
    modifier_parente_noeud(ceci, PETIT_FRERE, NULL);
}

void ecrire_enrichi(t_arbre_nanodom ceci)
{
    if (ceci != NULL)
    {
        // ouvrir bloc
        if (ceci->l_etiquette == DOCUMENT || ceci->l_etiquette == SECTION || ceci->l_etiquette ==  ANNEXE){
            ouvrir_bloc();
        }else if(ceci->l_etiquette == TITRE){
            entamer_ligne();
            changer_mode(MAJUSCULE);
        }else if(ceci->l_etiquette == LISTE){
            terminer_ligne();
        }else if(ceci->l_etiquette == MOT){
            if(ceci->les_parentes[PERE]->l_etiquette != TITRE && (ceci->les_parentes[GRAND_FRERE] == NULL || (ceci->les_parentes[GRAND_FRERE] != MOT && ceci->les_parentes[GRAND_FRERE] != RETOUR_A_LA_LIGNE))) entamer_ligne();
            ecrire_mot(ceci->le_contenu);
        }else if(ceci->l_etiquette == ITEM){
            entamer_ligne();
            pucer();
            indenter();
        }else if(ceci->l_etiquette == IMPORTANT){
            changer_mode(MAJUSCULE);
        }else if(ceci->l_etiquette == RETOUR_A_LA_LIGNE){
            terminer_ligne();
            if(ceci->les_parentes[PETIT_FRERE] != NULL){
                entamer_ligne();
            }
        }
        //afficher les fils
        ecrire_enrichi(ceci->les_parentes[PREMIER_FILS]);

        // fermer bloc
        if (ceci->l_etiquette == SECTION || ceci->l_etiquette == DOCUMENT || ceci->l_etiquette ==  ANNEXE){
            fermer_bloc();
        }else if(ceci->l_etiquette == TITRE){
            changer_mode(NORMAL);
            terminer_ligne();
        }else if(ceci->l_etiquette == MOT){
            if(ceci->les_parentes[PETIT_FRERE] == NULL && ceci->les_parentes[PERE]->l_etiquette != TITRE) terminer_ligne();
        }else if(ceci->l_etiquette == LISTE){
            //change : entamer_ligne();
            //terminer_ligne();
        }else if(ceci->l_etiquette == ITEM){
            //terminer_ligne();
            desindenter();
        }else if(ceci->l_etiquette == IMPORTANT){
            changer_mode(NORMAL);
        }
        ecrire_enrichi(ceci->les_parentes[PETIT_FRERE]);
    }
}

void sauvegarder_enrichi(t_arbre_nanodom ceci, FILE *fichier)
{
    setfile(fichier);
    ecrire_enrichi(ceci);
}

void detruire_nanodom(t_arbre_nanodom *ceci){
    if(*ceci != NULL){
        detruire_nanodom(&((*ceci)->les_parentes[PREMIER_FILS]));
        detruire_nanodom(&((*ceci)->les_parentes[PETIT_FRERE]));
        detruire_noeud(ceci);
    }
}