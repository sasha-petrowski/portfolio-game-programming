#ifndef P_NANODOM_H
#define P_NANODOM_H

#include <stdio.h>

typedef enum e_token{
    DOCUMENT=0,
    ANNEXE=1,
    SECTION=2,
    TITRE=3,
    LISTE=4,
    ITEM=5,
    IMPORTANT=6,
    RETOUR_A_LA_LIGNE=7,
    MOT=8
}t_token;

const char* t_token_image(t_token ceci);

typedef enum e_parente{
    PERE=0,
    PREMIER_FILS=1,
    DERNIER_FILS=2,
    GRAND_FRERE=3,
    PETIT_FRERE=4,
    NB_PARENTES=5}t_parente;

const char* t_parente_image(t_parente ceci);

typedef struct s_noeud{
    t_token l_etiquette;
    const char* le_contenu;
    struct s_noeud* les_parentes[NB_PARENTES];
}t_noeud;
typedef t_noeud* p_noeud;
typedef p_noeud t_arbre_nanodom;

/**
 * \brief Cette fonction construit un nouveau noeud.
 * 
 * \param ceci : p_noeud* : Le noeud a creer.
 * \param etiquette : t_token : Le type de token du noeud.
 * \param contenu : const char* : Le contenu textuel ou un pointeur (null).
 * \param pere : p_noeud : Le noeud pere de ceci.
 * \param premier_fils : p_noeud : Le noeud fils ainee de ceci.
 * \param dernier_fils : p_noeud : Le noeud fils cadet de ceci.
 * \param grand_frere : p_noeud : Le noeud grand frére de ceci.
 * \param petit_frere : p_noeud : Le noeud petit frere de ceci.
 */
void creer_noeud(p_noeud* ceci, t_token etiquette, const char* contenu, p_noeud pere, p_noeud premier_fils, p_noeud dernier_fils, p_noeud grand_frere, p_noeud petit_frere);

/**
 * \brief Cette fonction détruit un noeud sans se soucier de l'arborescence.
 *
 * \param ceci : p_noeud* : Le noeud a détruire.
 */
void detruire_noeud(p_noeud* ceci);

/**
 * \brief Cette fonction modifie l'etiquette de ceci.
 *
 * \param ceci : p_noeud : Le noeud ciblé.
 * \param etiquette : t_token : Le nouveau type de token du noeud.
 */
void modifier_etiquette_noeud(p_noeud ceci, t_token nouvelle_etiquette);

/**
 * \brief Cette fonction modifie le contenu de ceci.
 *
 * \param ceci : p_noeud : Le noeud ciblé.
 * \param nouveau_contenu : char* : Le nouveau contenu du noeud.
 */
void modifier_contenu_noeud(p_noeud ceci, char* nouveau_contenu);

/**
 * \brief Cette fonction modifie le lien de parenté de ceci.
 *
 * \param ceci : p_noeud : Le noeud ciblé.
 * \param lien_de_parente : t_parente : Le lien de parenté ciblé.
 * \param nouveau_parent : p_noeud : Le nouveau parent du lien de parenté.
 */
void modifier_parente_noeud(p_noeud ceci, t_parente lien_de_parente, p_noeud nouveau_parent);

/**
 * \brief Cette fonction affiche ceci et son arborescence de façon debugger.
 *
 * \param ceci : p_noeud : Le noeud a afficher.
 */
void debugger_noeud(p_noeud ceci);

/**
 * \brief Cette fonction ajoute un fils aine a ceci, modifiant les liens de parenté selon le besoin.
 *
 * \param ceci : p_noeud : Le noeud parent.
 * \param orphelin : p_noeud : Le noeud enfant.
 */
void inserer_aine(p_noeud ceci, p_noeud orphelin);

/**
 * \brief Cette fonction ajoute un fils cadet a ceci, modifiant les liens de parenté selon le besoin.
 *
 * \param ceci : p_noeud : Le noeud parent.
 * \param orphelin : p_noeud : Le noeud enfant.
 */
void inserer_cadet(p_noeud ceci, p_noeud orphelin);

/**
 * \brief Cette fonction ajoute un frere cadet a ceci, modifiant les liens de parenté selon le besoin.
 *
 * \param ceci : p_noeud : Le noeud frere aine.
 * \param orphelin : p_noeud : Le noeud frere cadet.
 */
void inserer_apres(p_noeud ceci, p_noeud orphelin);

/**
 * \brief Cette fonction ajoute un frere aine a ceci, modifiant les liens de parenté selon le besoin.
 *
 * \param ceci : p_noeud : Le noeud frere cadet.
 * \param orphelin : p_noeud : Le noeud frere aine.
 */
void inserer_avant(p_noeud ceci, p_noeud orphelin);
/**
 * \brief Cette fonction sort un noeud et tous ses descendants de l’arbre. réarange l'arborescence, sans rien détruire.
 *
 * \param ceci : p_noeud : Le ciblé.
 */
void extraire(p_noeud ceci);

/**
 * \brief Cette fonction affiche l'arbre de façon enrichi.
 *
 * \param ceci : t_arbre_nanodom : L'arbre a ecrire.
 */
void ecrire_enrichi(t_arbre_nanodom ceci);

/**
 * \brief Cette fonction sauvegarde un arbre dans un dossier de façon enrichi.
 *
 * \param ceci : t_arbre_nanodom : L'arbre a sauvegarder.
 */
void sauvegarder_enrichi(t_arbre_nanodom ceci, FILE* fichier);

/**
 * \brief Cette fonction libere la memoire d'un arbre.
 *
 * \param ceci : t_arbre_nanodom : L'arbre a detruire.
 */
void detruire_nanodom(t_arbre_nanodom* ceci);

#endif