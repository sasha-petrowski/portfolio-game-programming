#include "p_extracteur.h"
#include "p_texte_enrichi.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

FILE* file;

char cs[256];
char cc;
int closing;
int end = 0;
int taille_cs;

void next_non_blank_char(){
    cc = fgetc(file);
    while(' ' == cc || '\n' == cc || '\r' == cc || cc == '\t'){
        cc = fgetc(file);
    }
}

int compare(char* ceci){
    int i = 0;
    while(cs[i] != '\0'){
        if(cs[i] != ceci[i]){
            return 0;
        }
        i++;
    }
    return 1;
}

void amorcer_lecture(char* file_txt){
    //char cs[256];
    //char cc;
    closing = 0;
    end = 0;
    taille_cs = 0;

    file = fopen(file_txt, "r");
    if(!file_txt){
        fprintf(stderr, "fichier \"%s\" inconnu\n", file_txt);
    }
    next_non_blank_char();
    next_string();
}

void terminer_lecture(){
    fclose(file);
}

void lire_balise(){
    int i = 0;
    while(cc != '>'){
        cs[i] = cc;
        next_non_blank_char();
        i++;
    }
    cs[i] = cc;
    cs[i+1] = '\0';
    next_non_blank_char();

    if(cs[1] == '/'){
        closing = 1;
    }else{
        closing = 0;
    }
}

void lire_texte(){
    int i = 0;
    while(cc != '<'){
        if(cc != '\n' && cc != 13){
            cs[i] = cc;
            i++;
        }else if(cc == '\n'){
            cs[i] = ' ';
            i++;
        }
        cc = fgetc(file);
    }
    while(i >= 1 && (' ' == cs[i-1] || '\n' == cs[i-1] || '\r' == cs[i-1] || '\t' == cs[i-1])){
        i--;
    }
    taille_cs = i;
    cs[i] = '\0';
    closing = 0;
}

void next_string(){
    if(cc == '<'){
        lire_balise();
    }
    else{
        lire_texte();
    }
}

void balise(char* balise){
    //debug :
    //printf("closing : %d | compare : %d | %s | cs : %s\n", closing,  compare(balise), balise, cs);
    //
    if(compare(balise) != 1){
        fprintf(stderr, "erreur : Balise attendu : '%s' Balise trouve : '%s' .\n", balise, cs);
        exit(-1);
    }
    if(cc != EOF)
    {
        next_string();
    }else{
        //printf("\nEND OF FILE\n");
        end = 1;
    }
}

void mot_simple(p_noeud *noeud_mot_simple){
    char* contenu = (char*)malloc(sizeof(char)*(taille_cs + 1));
    for(int i = 0; i< taille_cs; i++){
        contenu[i] = cs[i];
    }
    contenu[taille_cs] = '\0';
    //debug
    //printf("            |             | Contenu | cs : %s\n", contenu);
    //
    creer_noeud(noeud_mot_simple, MOT, contenu, NULL, NULL, NULL, NULL, NULL);
    next_string();
}

void br(p_noeud *noeud_br){
    balise("<br/>");
    //todo arbre
    creer_noeud(noeud_br, RETOUR_A_LA_LIGNE, NULL, NULL, NULL, NULL, NULL, NULL);
}

void mot_important(p_noeud *noeud_important){
    balise("<important>");
    //todo arbre
    creer_noeud(noeud_important, IMPORTANT, NULL, NULL, NULL, NULL, NULL, NULL);
    while(! closing){
        p_noeud noeud_mot_simple;
        mot_simple(&noeud_mot_simple);
        inserer_cadet(*noeud_important, noeud_mot_simple);
    }

    balise("</important>");
}

void mot_enrichi(p_noeud *noeud_mot){
    if(compare("<important>") == 1)
    {
        
        mot_important(noeud_mot);
    }
    else if(compare("<br/>") == 1)
    {
        br(noeud_mot);
    }
    else
    {
        mot_simple(noeud_mot);
    }
}

void texte(p_noeud *noeud_pere){
    while(! closing)
    {
        p_noeud noeud_mot;
        mot_enrichi(&noeud_mot);
        inserer_cadet(*noeud_pere, noeud_mot);
    }
}

void texte_liste(p_noeud *noeud_pere){
    p_noeud noeud_mot;
    mot_enrichi(&noeud_mot);
    inserer_cadet(*noeud_pere, noeud_mot);

    if(! closing && compare("<liste>") == 1)
    {
        liste_texte(noeud_pere);
    }
}

void liste_texte(p_noeud *noeud_pere){
    p_noeud noeud_liste;
    liste(&noeud_liste);
    inserer_cadet(*noeud_pere, noeud_liste);

    if(! closing)
    {
        texte_liste(noeud_pere);
    }
}

void item(p_noeud *noeud_item){
    balise("<item>");
    //todo arbre
    creer_noeud(noeud_item, ITEM, NULL, NULL, NULL, NULL, NULL, NULL);

    if(compare("<liste>") == 1)
    {
        liste_texte(noeud_item);
    }
    else
    {
        texte_liste(noeud_item);
    }

    balise("</item>");
}

void liste(p_noeud *noeud_liste){
    balise("<liste>");
    //todo arbre
    creer_noeud(noeud_liste, LISTE, NULL, NULL, NULL, NULL, NULL, NULL);

    while (! closing)
    {
        p_noeud noeud_item;
        item(&noeud_item);
        inserer_cadet(*noeud_liste, noeud_item);
    }

    balise("</liste>"); 
}

void titre(p_noeud *noeud_titre){
    balise("<titre>");
    //todo arbre
    creer_noeud(noeud_titre, TITRE, NULL, NULL, NULL, NULL, NULL, NULL);

    texte(noeud_titre);

    balise("</titre>");
}

void section(p_noeud *noeud_section){
    balise("<section>");
    //todo arbre

    creer_noeud(noeud_section, SECTION, NULL, NULL, NULL, NULL, NULL, NULL);

    contenu(noeud_section);
    //debugger_noeud(((*noeud_section)->les_parentes[PREMIER_FILS]));

    balise("</section>");
}

void contenu(p_noeud *noeud_pere){
    while(! closing){
        p_noeud noeud_contenu;
        if(compare("<section>") == 1)
        {
            section(&noeud_contenu);
        }
        else if(compare("<titre>") == 1)
        {
            titre(&noeud_contenu);
        }
        else if(compare("<liste>") == 1)
        {
            liste(&noeud_contenu);
        }
        else
        {
            mot_enrichi(&noeud_contenu);
        }
        inserer_cadet(*noeud_pere, noeud_contenu);
    }
}

void annexe(p_noeud *noeud_annexe){
    balise("<annexe>");
    //todo arbre
    creer_noeud(noeud_annexe, ANNEXE, NULL, NULL, NULL, NULL, NULL, NULL);

    contenu(noeud_annexe);

    balise("</annexe>");      
}

void document(p_noeud *noeud_document){
    balise("<document>");
    //todo arbre
    creer_noeud(noeud_document, DOCUMENT, NULL, NULL, NULL, NULL, NULL, NULL);

    contenu(noeud_document);

    balise("</document>");
}

p_noeud extraire_txt(char* file_txt){
    amorcer_lecture(file_txt);

    p_noeud noeud_document;
    document(&noeud_document);

    p_noeud dernier_noeud = noeud_document;
    while(end == 0){
        p_noeud noeud_annexe;
        annexe(&noeud_annexe);
            
        modifier_parente_noeud(dernier_noeud, PETIT_FRERE, noeud_annexe);
        modifier_parente_noeud(noeud_annexe, GRAND_FRERE, noeud_document);
        dernier_noeud = noeud_annexe;
    }
    terminer_lecture();

    return noeud_document;
}