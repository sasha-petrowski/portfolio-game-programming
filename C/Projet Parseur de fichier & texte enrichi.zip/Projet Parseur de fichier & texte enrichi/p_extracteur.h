#ifndef P_EXTRACTEUR_H
#define P_EXTRACTEUR_H

#include "p_nanodom.h"

void next_non_blank_char();

void amorcer_lecture(char* file_txt);

void terminer_lecture();

void lire_balise();

void lire_texte();

void next_string();

void balise(char* balise);

void mot_simple();

void br();

void mot_important();

void mot_enrichi();

void texte();

void texte_liste();

void liste_texte();

void item();

void liste();

void titre();

void section();

void contenu();

void annexe();

void document();

p_noeud extraire_txt(char* file_txt);

#endif