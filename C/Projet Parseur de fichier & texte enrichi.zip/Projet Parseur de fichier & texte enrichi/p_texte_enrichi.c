#include "p_texte_enrichi.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAILLE 50

int _indentation = 0;
int _imbrication = 0;
int _ecris = 0;
int _entamer_ligne = 0;
t_mode _mode = NORMAL;

FILE* savefile;

void setfile(FILE* file){
    savefile = file;
}

void changer_mode(t_mode mode){
    _mode = mode;
}

t_mode mode(){
    return _mode;
}

void ouvrir_bloc(){
    entamer_ligne();
    _ecris = TAILLE - ((_imbrication * 2) + (_indentation * 3));
    fprintf(savefile, "+");
    for(int i = 0; i < _ecris - 2; i++){
        fprintf(savefile, "-");
    }
    fprintf(savefile, "+");
    terminer_ligne();
    _imbrication++;
}

void fermer_bloc(){
    _imbrication--;
    entamer_ligne();
    _ecris = TAILLE - ((_imbrication * 2) + (_indentation * 3));
    fprintf(savefile, "+");
    for(int i = 0; i < _ecris - 2; i++){
        fprintf(savefile, "-");
    }
    fprintf(savefile, "+");
    terminer_ligne();
}

void indenter(){
    _indentation++;
}

void desindenter(){
    _indentation--;
}

int est_en_fin_de_ligne();

int est_au_debut_de_ligne();

void entamer_ligne(){
    if(_entamer_ligne == 0){
        for(int i = 0; i < _imbrication; i++){
            fprintf(savefile, "|");
        }
        if(_indentation > 0){
            for(int i = 0; i < _indentation; i++){
                fprintf(savefile, "   ");
            }  
        }
        _entamer_ligne = 1;
    }
}

void terminer_ligne(){
    if(_entamer_ligne == 1){
        for(int i = 0; i < peut_ecrire(); i++){
            fprintf(savefile, " ");
        }
        for(int i = 0; i < _imbrication; i++){
            fprintf(savefile, "|");
        }
        fprintf(savefile, "\n");
        _ecris = 0;
        _entamer_ligne = 0;
    }
}

void pucer(){
    fprintf(savefile, " # ");
}

void printc(const char* mot, int depart, int fin){
    for(int i = depart; i < fin && mot[i] != '\0'; i++){
        if(_mode == MAJUSCULE && mot[i] >= 'a' && mot[i] <= 'z')
        {
            fprintf(savefile, "%c", (mot[i] -32));
        }
        else
        {
            fprintf(savefile, "%c", mot[i]);
        }
    }
    fprintf(savefile, " ");

}

void ecrire_mot(const char* mot){
    if(peut_ecrire()-1 >= strlen(mot))
    {
        printc(mot, 0, strlen(mot));
        _ecris += strlen(mot)+1;
    }else{
        int current = 0;
        int last;
        while(current < strlen(mot))
        {
            last = current;
            if(_entamer_ligne == 0)
            {
                entamer_ligne();
            }
            if(current + peut_ecrire()-1 > strlen(mot)){
                current = strlen(mot);
            }
            else{
                current += peut_ecrire()-1;
            }
            printc(mot, last, current);
            _ecris += current-last+1;
            if(current != strlen(mot)) terminer_ligne();
        }
    }
}

int peut_ecrire(){
    return (TAILLE - ((_imbrication * 2) + (_indentation * 3) + _ecris));
}