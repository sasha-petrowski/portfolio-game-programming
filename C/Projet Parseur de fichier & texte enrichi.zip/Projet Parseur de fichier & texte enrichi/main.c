#include "p_nanodom.h"
#include "p_extracteur.h"


int main(){
    t_arbre_nanodom source_1;
    t_arbre_nanodom source_2;
    t_arbre_nanodom source_3;
    t_arbre_nanodom source_4;

    printf("source 1\n");
    source_1 = extraire_txt("sources/source_1.txt");
    
    FILE *save_1 = fopen("rendus/rendu_1.txt", "w");
    sauvegarder_enrichi(source_1, save_1);
    fclose(save_1);
    detruire_nanodom(&source_1);


    printf("source 2 \n");
    source_2 = extraire_txt("sources/source_2.txt");

    FILE *save_2 = fopen("rendus/rendu_2.txt", "w");
    sauvegarder_enrichi(source_2, save_2);
    fclose(save_2);
    detruire_nanodom(&source_2);


    printf("source 3\n");
    source_3 = extraire_txt("sources/source_3.txt");
    
    FILE *save_3 = fopen("rendus/rendu_3.txt", "w");
    sauvegarder_enrichi(source_3, save_3);
    fclose(save_3);
    detruire_nanodom(&source_3);


    printf("source 4\n");
    source_4 = extraire_txt("sources/source_4.txt");

    FILE *save_4 = fopen("rendus/rendu_4.txt", "w");
    sauvegarder_enrichi(source_4, save_4);
    fclose(save_4);
    detruire_nanodom(&source_4);

    return 0;
}