#ifndef P_TEXTE_ENRICHI
#define P_TEXTE_ENRICHI

#include <stdio.h>

typedef enum e_mode{NORMAL, MAJUSCULE, MINUSCULE} t_mode;

/**
 * \brief set la FILE utlisée pour sauvegarder le texte enrichi. 
 *
 * \param file : FILE* : la savefile.
 */
void setfile(FILE* file);

/**
 * \brief Cette change le mode d'ecriture du texte.
 *
 * \param ceci : t_mode : Le nouveau mode decriture.
 */
void changer_mode(t_mode mode);

/**
 * \brief return le mode d'ecriture actuellement utilisé.
 *
 * \return : t_mode : Le mode actuellement utilisé.
 */
t_mode mode();

/**
 * \brief Cette fonction ouvre un bloc imbriquer.
 */
void ouvrir_bloc();

/**
 * \brief Cette fonction ferme un bloc imbriquer.
 */
void fermer_bloc();

/**
 * \brief Cette fonction augmente de 1 l'indentation.
 */
void indenter();

/**
 * \brief Cette fonction reduit de 1 l'indentation.
 */
void desindenter();

int est_en_fin_de_ligne();

int est_au_debut_de_ligne();


/**
 * \brief Cette fonction print le début d'une ligne selon l'imbrication & l'indentation.
 */
void entamer_ligne();

/**
 * \brief Cette fonction print le début d'une ligne selon l'imbrication & l'indentation.
 */
void terminer_ligne();

/**
 * \brief Cette fonction print une puce de début de ligne selon l'indentation.
 */
void pucer();

/**
 * \brief Cette fonction print un mot selon le mode d'ecriture et saute une ligne si il le faut.
 * 
 * \param mot : const char* : le mot a ecrire.
 */
void ecrire_mot(const char* mot);

/**
 * \brief Cette fonction return 0 si on ne peut pas ecrire nb_caracteres, 1 si on peut.
 * 
 * \return : int : le nombre de caractéres que l'on peut encore afficher.
 */
int peut_ecrire();

#endif